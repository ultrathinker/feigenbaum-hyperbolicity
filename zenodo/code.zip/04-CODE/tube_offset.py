# -*- coding: utf-8 -*-
"""
tube_offset.py — член, которого не хватало в трубке Руше.

Проблема.  Трубка считает `DT` в ПАРАМЕТРИЗОВАННОМ ЦЕНТРЕ `P(ℓ)`, а
утверждение о гиперболичности относится к ИСТИННОЙ неподвижной точке
`G*(ℓ)`.  Между ними расстояние ≤ ρ_X = 1.75·ρ*_b (радиус ШАРА
СУЩЕСТВОВАНИЯ из сертификата, поле best.rho_star_b — НЕ радиус ворот
Канторовича ρ′, который на шесть порядков больше и означает другое:
внутри него гарантированы единственность и сходимость Ньютона, а не
расстояние до найденного решения).  Значит в возмущение Руше входит ещё
    ‖DT(G*(ℓ)) − DT(P(ℓ))‖₁ = ‖M′(G*) − M′(P)‖₁,
и его надо оценить в ТОЙ ЖЕ норме, в какой считается ‖Δ‖ (столбцовая
1-норма в b-базисе).

Оценка через уже сертифицированные величины, без новых допущений.
Сертификат существования даёт в этой самой норме:
    ‖Ã·(M′(u) − M′(P))‖₁ ≤ 1.75²·B_A·L·ρ*_b   для всех u из шара
(это ровно второе слагаемое Ẑ), и  Z1 = ‖I − Ã M′‖₁ < 1.
Из `Ã M′ = I − Z` следует `Ã⁻¹ = M′(I − Z)⁻¹`, откуда
    ‖Ã⁻¹‖₁ ≤ ‖M′‖₁ / (1 − Z1).
Следовательно
    ‖M′(G*) − M′(P)‖₁ ≤ ( ‖M′‖₁ / (1 − Z1) ) · 1.75² · B_A · L · ρ*_b .

Здесь `‖M′‖₁` — строгий супремум по боксу (интервальный ℓ и интервальный
центр, подразбиение) для ПОЛНОГО оператора на X₀, а не для его головной
проекции: к головной норме добавляется хвостовая масса головных столбцов
`‖C‖₁`, и берётся максимум с нормой хвостовых столбцов `1 + ‖[B;D]‖₁`
(единица — от тождественного оператора в M′ = I − DT; блоки C и [B;D] —
блоки DT, см. §4.6 статьи).
`Z1, B_A, L, ρ*_b` — из json бокса существования.

Запуск: python tube_offset.py [K]
Пишет `$HYP_OFFSETS` (по умолчанию — временный каталог ОС,
`renorm_tube/offsets.json`): по боксу существования — величина `extra`.
"""
import os, sys, json, glob, time, tempfile
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))

import rig_lib as rl
import tube_lib as tl
from flint import arb, ctx

import hyp_rouche as hr

ctx.prec = 256
NP = tl.N_p
PKG_ROOT = os.path.dirname(HERE)
SRC = os.environ.get('HYP_CERTS', os.path.join(PKG_ROOT, '03-CERTIFICATES', 'existence'))
BR = os.environ.get('HYP_BRANCHES', os.path.join(PKG_ROOT, '03-CERTIFICATES', 'branches'))


def mprime_norm_box(c_a, m, e0b, wb, ell0, w, K):
    """sup по боксу ‖M′‖₁ (столбцовая 1-норма), интервально, с подразбиением.

    STRICT-UP (18.08): максимум накапливается в arb, и только на выходе
    конвертируется во float ВВЕРХ.  Прежде стояло float(col.upper()), а float()
    округляет к ближайшему — верхняя граница переставала быть мажорантой
    (проверено: на боксах g20 и gtop вниз округлялся именно максимум).
    """
    best = arb(0)
    for s in range(K):
        lo = ell0 - w / 2 + w * s / K
        hi = ell0 - w / 2 + w * (s + 1) / K
        xlo = 2.0 * (lo - e0b) / wb
        xhi = 2.0 * (hi - e0b) / wb
        Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
        pkg = tl.build_pkg_fast(Pint, arb('%.17e' % lo).union(arb('%.17e' % hi)))
        if pkg is None:
            raise RuntimeError('пакет не построился')
        DT = hr.dt_from_pkg(pkg)
        for k in range(NP):
            col = arb(0)
            for j in range(NP):
                mjk = (arb(1) - DT[j][k]) if j == k else -DT[j][k]
                col = col + abs(mjk)
            cu = col.upper()
            if cu > best:
                best = cu
    return hr.up_float(best)


def main():
    K = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    if K < 1:
        raise SystemExit('K (число подразбиений) должен быть >= 1 '
                         '(получено %d)' % K)
    out = {}
    files = sorted(glob.glob(os.path.join(SRC, 'box_*.json')))
    print('боксов существования: %d' % len(files), flush=True)
    for f in files:
        j = json.load(open(f, encoding='utf-8'))
        tag = j.get('idx') or os.path.basename(f)[4:-5]
        if not j.get('passed'):
            print('  %s: бокс не прошёл, пропуск' % tag, flush=True)
            continue
        t0 = time.time()
        z = np.load(os.path.join(BR, 'branch_%s.npz' % tag))
        c_a, m = z['c_a'], int(z['m'][0])
        e0b, wb = float(z['ell0'][0]), float(z['w'][0])
        ell0, w = float(j['ell0']), float(j['w'])
        try:
            m1 = mprime_norm_box(c_a, m, e0b, wb, ell0, w, K)
        except Exception as e:
            print('  %s: ОШИБКА %s' % (tag, e), flush=True)
            continue
        # STRICT-UP: вся арифметика приёмки — в arb, наружу через up_float.
        # Раньше extra/C_norm/BD_norm считались в обычном float, где каждая
        # операция округляет к ближайшему и может опустить мажоранту.
        Z1 = arb(j['Z1'])
        B_A = arb(j['B_A'])
        if 'B_A_lo' not in j:
            # молчаливый откат на B_A вернул бы ровно ту нестрогость, ради
            # которой поле и заведено: деление мажоранты на мажоранту
            # знаменателя занижает результат.  Лучше упасть.
            raise RuntimeError('%s: в сертификате нет B_A_lo — пересчитайте '
                               'бокс текущим rig2fix3.py' % tag)
        B_A_lo = arb(j['B_A_lo'])
        L = arb(j['best']['L'])
        rho = arb(j['best']['rho_prime'])
        # RHO-STAR-FIX: rho_star хранится в json как ρ*_b (в
        # b-координатах, с B_A·dchk, включённым в числитель).  Возмущение Руше
        # ‖M′(G*) − M′(P)‖₁ тоже считается в столбцовой 1-норме b-базиса,
        # поэтому используем именно rho_star_b (он же 'rho_star' в json).
        # Если поля rho_star_b нет (старый json) — fallback на rho_star.
        if 'rho_star_b' in j['best']:
            rho_star = arb(j['best']['rho_star_b'])
        else:
            rho_star = arb(j['best']['rho_star'])
        m1a = arb(m1)
        den = 1 - Z1                     # Z1 — мажоранта, значит den — миноранта
        if not (den > 0):
            print('  %s: 1-Z1 не отделено от нуля, пропуск' % tag, flush=True)
            continue
        # --- связь проекции с полным оператором ---
        # В матричных блоках b-базиса  DT = [[A, B],[C, D]]  (голова
        # k,j<=N_p и хвост k,j>N_p) движок уже даёт строгие границы
        # столбцовых масс:
        #   Z1b = B_A · max_{k<=N_p} Σ_{j>N_p}|DT_jk| r^j   =>  ‖C‖₁ ≤ Z1b/B_A
        #   Z1c = (1+B_A) · (β̂_{N_p+1} + (c/r)^{N_p+1}β₀*)  =>  ‖[B;D]‖₁ ≤ Z1c/(1+B_A)
        # Блоки именно DT, а не M′ = I − DT.  Ã_full = Ã_head ⊕ I_tail, поэтому
        # I − Ã·M′ = (I − Ã) + Ã·DT, и на хвостовых столбцах первое слагаемое
        # зануляется: единица от M′ сокращается сама.  Множитель (1+B_A) —
        # головной выход через Ã_head плюс нетронутый хвостовой (§4.6 статьи).
        # Раньше комментарий приписывал блоки M′, у которого хвостовой столбец
        # содержит единицу; числа не менялись, но читатель кода получал то же
        # ложное отождествление, что и у читателя статьи.
        Z1b = arb(j['Z1b'])
        Z1c = arb(j['Z1c'])
        # делим на МИНОРАНТУ B_A: деление мажоранты на мажоранту знаменателя
        # даёт заниженный результат, а это верхние границы блоков
        C_norm = hr.up_float(Z1b / B_A_lo)
        BD_norm = hr.up_float(Z1c / (1 + B_A_lo))
        # FULL-NORM (18.08).  `mprime_norm_box` возвращает столбцовую норму
        # ГОЛОВЫ: max_{k<=N_p} Σ_{j<=N_p}.  В выводе ‖Ã⁻¹‖ ≤ ‖M′‖/(1−Z1) стоит
        # норма ПОЛНОГО оператора на X₀, а норма проекции её не мажорирует.
        # хвостовая ветвь полной нормы M′ — это 1 + ‖[B;D]‖ (единица от
        # тождественного оператора в M′ = I − DT), см. max() ниже.
        # Разбор по столбцам b-базиса:
        #   k <= N_p:  Σ_j |M′_jk| = (головная масса) + (хвостовая масса)
        #                          <= ‖M′_head‖₁ + ‖C‖₁
        #   k >  N_p:  Σ_j |M′_jk| <= 1 + ‖[B;D]‖₁
        # (единица — диагональ I в M′ = I − DT; блоки C и [B;D] — блоки DT)
        # Максимум суммы максимумов мажорирует максимум сумм, поэтому оценка
        # верна (и слегка консервативна).
        # у ПОЛНОГО M' = I - DT хвостовые столбцы содержат ещё
        # единицу от тождественного оператора (у DT её нет), поэтому
        # вторая ветвь — 1 + BD_norm, а не BD_norm.  Численно max всё
        # равно берётся на головной ветви (>= 6.34 против 1.0002) на всех
        # 46 боксах СУЩЕСТВОВАНИЯ, которые и перебирает этот цикл; 706 боксов
        # трубки наследуют готовый extra у своего родителя, ветвь на них
        # заново не выбирается.  Это отдельно сторожит _numbers_check.py —
        # он ходит по тому же offsets.json и печатает «на всех 46 боксах».
        # (Прежде здесь стояло «на всех 706 боксах», и та же фраза попала в
        #  §4.5 статьи: код и текст согласовывались друг с другом и оба
        #  называли не то множество, на котором ветвь выбирается.)
        m_full = max(hr.up_float(m1a + arb(C_norm)),
                     hr.up_float(arb(1) + arb(BD_norm)))
        m_full_a = arb(m_full)
        extra = hr.up_float((m_full_a / den) * arb('3.0625') * B_A * L * rho_star)
        extra_rho = hr.up_float((m_full_a / den) * arb('3.0625') * B_A * L * rho)
        out[tag] = {'ell0': ell0, 'w': w, 'lo': ell0 - w / 2, 'hi': ell0 + w / 2,
                    'Mprime_norm': m1, 'Mprime_full': m_full,
                    'Z1': float(Z1), 'B_A': float(B_A),
                    'L': float(L),
                    'rho_prime': float(rho), 'rho_star_b': float(rho_star),
                    'extra': extra, 'extra_rho_prime': extra_rho,
                    'Z1b': float(Z1b), 'Z1c': float(Z1c),
                    'C_norm': C_norm, 'BD_norm': BD_norm,
                    'tail_coupling': max(C_norm, BD_norm)}
        print('  %-8s [%.4f, %.4f] ‖M′‖=%.4f L=%.3e ρ*=%.2e -> extra=%.3e '
              '(при ρ′: %.3e)  [%.0fs]'
              % (tag, ell0 - w / 2, ell0 + w / 2, m1, float(L), float(rho_star), extra,
                 extra_rho, time.time() - t0), flush=True)
    # Умолчание писало `04-CODE/offsets.json`, то есть ВНУТРЬ
    # пакета.  Остальные писатели (cert.py, tube_run.py, glue.py) переведены
    # на временный каталог ОС; этот был пропущен.
    _offs_out = os.environ.get(
        'HYP_OFFSETS',
        os.path.join(tempfile.gettempdir(), 'renorm_tube', 'offsets.json'))
    os.makedirs(os.path.dirname(_offs_out), exist_ok=True)
    with open(_offs_out, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    if out:
        ex = [v['extra'] for v in out.values()]
        print('\nextra: min %.3e, max %.3e (по %d боксам)'
              % (min(ex), max(ex), len(ex)))


if __name__ == '__main__':
    main()
