# -*- coding: utf-8 -*-
"""
rig2fix3.py — RIGOROUS parameterized Kantorovich certificate via
sigma-Taylor models of the operator (op_sig + sig_lib).

Certificate (projected-system semantics of the march gates):
  for EVERY l in [l0-w/2, l0+w/2]: F~(.,l) has a zero in B_X(P(l), 1.75*rho')
  gate: Y0 + B_A*dchk + Zhat*rho' <= rho',  Zhat = Z1 + 3.0625*B_A*L*rho'

  Y0 = sum_i ||v1_i||_1 smax^i + B_A*tau_F + w2_sup + Ftail_sup
       v1_i = sum_{p+l=i} A~_p F~_l            (sigma-slices)
  Z1 = sum_i colnorm1(Z_i) smax^i + B_A*max_tau_col + Z1b + Z1c
       Z_i = delta_{i0} I - sum_{p+l=i} A~_p M'_l

Float-slice products carry an explicit arb rounding allowance (eps_slack).

Usage: python rig2fix3.py [w] [m] [D] [ell0]
Log: rig2fix2.log; JSON: rig2fix2.json
"""
import math
import io, sys, os, time, json, tempfile
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fp_lib as fl
import rig_lib as rl
import sig_lib as sl
import op_sig as osig
import lemma_domains as ld
import beta_bound_lib as bbl
from flint import arb, ctx, arb_mat
import tube_lib as tl
import hyp_rouche as hr

# (тот же класс, что hyp_rouche.py -> HYP_LOG, layer/*).  Дефолт НЕ
# ведёт внутрь пакета: запуск «как есть» дописывал файлы в пакет и ломал
# сверку с MANIFEST.sha256.  Пакет обязан оставаться пригодным только на
# чтение; чтобы ПЕРЕсобрать артефакты, CERT_OUT / GLUE_OUT /
# HYP_TUBE_OUT выставляются явно (см. 02-REPRODUCE.md).
_OUT = os.environ.get('CERT_OUT',
                      os.path.join(tempfile.gettempdir(), 'renorm_out'))
os.makedirs(_OUT, exist_ok=True)
LOG = os.path.join(_OUT, 'rig2fix2.log')
OUTJ = os.path.join(_OUT, 'rig2fix2.json')
NP = tl.N_p
C = tl.c_arb
R = tl.r_arb


def plog(msg):
    line = time.strftime('%H:%M:%S ') + msg
    print(line, flush=True)
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write(line + '\n')


def up_float(x):
    """Наименьший double, гарантированно НЕ МЕНЬШИЙ x.

    `float(arb)` округляет к БЛИЖАЙШЕМУ: результат может оказаться ниже
    настоящей верхней границы и перестать быть мажорантой.  Здесь после
    конверсии делается шаг вверх, если округление ушло вниз.
    """
    v = arb(x).upper()
    f = float(v)
    if arb(f) < v:
        f = math.nextafter(f, math.inf)
    return f


def dn_float(x):
    """Нижний конец arb с округлением ВНИЗ (зеркало up_float)."""
    v = arb(x).lower()
    f = float(v)
    if arb(f) > v:
        f = math.nextafter(f, -math.inf)
    return f


def fmt(x, d=6):
    """Диагностическая печать: округление к ближайшему.  Для полей, которые
    кто-то читает как ГРАНИЦУ, использовать fmt_up / fmt_dn."""
    return ('%.' + str(d) + 'e') % float(x)


def _fmt_dir(x, d, up):
    # STRICT-DEC (18.08): '%.6e' округляет к ближайшему, поэтому
    # записанное в json число могло оказаться НИЖЕ мажоранты (относительная
    # утечка до 5e-7).  Здесь десятичная запись двигается в нужную сторону.
    v = up_float(x) if up else dn_float(x)
    fs = '%.' + str(d) + 'e'
    s = fs % v
    for _ in range(4):
        if (float(s) >= v) if up else (float(s) <= v):
            return s
        step = float('1e%d' % (int(s.split('e')[1]) - d))
        s = fs % (v + step if up else v - step)
    raise RuntimeError('десятичное округление не сошлось: %s vs %r' % (s, v))


def fmt_up(x, d=6):
    """Мажоранта: десятичная запись не ниже истинной верхней границы."""
    return _fmt_dir(x, d, True)


def fmt_dn(x, d=6):
    """Миноранта: десятичная запись не выше истинной нижней границы."""
    return _fmt_dir(x, d, False)

def sigma_tails_full(ops, tay, m, ell0, w, B_A, prec=256):
    """sigma-wise tail pieces: (w2tail, Z1b, Z1c, diag)."""
    ctx.prec = prec
    smax = ops['smax']
    smax_f = float(smax)
    Rt = arb("1.20")
    ratio = R / Rt
    # u-coords coefficient sigma-sup from the SIGNED sigma-slices Pc
    # (keeps cancellations inside each slice; far tighter than |tay|-majorant)
    Pc_slices = ops['Pc']
    bc_sup = [arb(0)] * (NP + 1)
    for i in range(len(Pc_slices)):
        for k in range(NP + 1):
            if k < len(Pc_slices[i]):
                bc_sup[k] = bc_sup[k] + abs(Pc_slices[i][k]) * (smax ** i)

    def gabs(x):
        s = arb(0)
        for k in range(NP + 1):
            s = s + bc_sup[k] * (x ** k)
        return s.upper()

    c1_sup = (sum((abs(x) * (smax ** i) for i, x in enumerate(ops['_c1'])), arb(0))).upper()
    ell_sup = arb('%.17e' % ell0) + smax
    s_R = abs(C * (c1_sup - 1)) + Rt * c1_sup
    M_U_R = gabs(s_R)
    # LATENT-CHECK: ell_sup — ТОЧКА (верхний
    # конец ℓ-бокса), а не интервал.  M^ℓ растёт по ℓ только при M>=1; при
    # M<1 она убывает, и подстановка ell_sup вместо нижнего конца дала бы
    # ЗАНИЖЕНИЕ мажоранты.  На всех 46 боксах M_U_R >= 1.21 держится, но это
    # была совпадение режима, а не проверенная посылка — проверяем явно.
    if not (M_U_R >= arb(1)):
        raise RuntimeError('M_U_R < 1: подстановка ell_sup в M_U_R**ell_sup '
                            'занижает мажоранту, нужен нижний конец ℓ-бокса')
    M_W_R = (M_U_R ** ell_sup).upper()
    M_Ulm_R = (M_U_R ** (ell_sup - 1)).upper()
    M_H = gabs(M_W_R + C)
    alpha_sup = ops['alpha_sup']
    w2tail = (alpha_sup * M_H * ratio ** (NP + 1) / (1 - ratio)).upper()
    tail_hW = (M_W_R * ratio ** (tl.N_W + 1) / (1 - ratio)).upper()
    tail_hUlm = (M_Ulm_R * ratio ** (tl.N_W + 1) / (1 - ratio)).upper()
    tail_h_max = max(float(tail_hW), float(tail_hUlm))
    tail_h_max = arb('%.17e' % tail_h_max)
    # poly_norm_k from mprime slices (already r^j-scaled)
    poly_norm = []
    for k in range(NP):
        s = arb(0)
        for i in range(len(ops['Mprime_slices'])):
            colk = ops['Mprime_slices'][i][k]
            si = arb(0)
            for j in range(NP):
                si = si + abs(colk[j])
            s = s + si * (smax ** i)
        s = s + ops['taus_cols'][k]
        poly_norm.append(s.upper())
    crk = float(C / R)
    max_tail_prime = arb(0)
    for k in range(1, NP + 1):
        t = 4 * tail_h_max * (poly_norm[k - 1] + (crk ** k) * poly_norm[0])
        if t > max_tail_prime:
            max_tail_prime = t
    Z1b = (B_A * max_tail_prime).upper()
    # Z1c via beta_bound_ell with sigma-sup constants
    norm_W = ops['norm_W']
    norm_sm = ops['norm_sm']
    q = (norm_W / R).upper()
    q_s = (norm_sm / R).upper()
    consts = {
        'c': C, 'r': R,
        'A_abs_abar': alpha_sup,
        'q': q, 'q_s': q_s,
        'norm_U_lm1': ops['norm_Ulm'],
        'norm_Gprime_W': ops['norm_GpW'],
        'norm_Gprime_s': ops['norm_GpS'],
        'norm_T_ell': ((C + R) * ell_sup * ops['c2_sup']).upper(),
        'norm_G_of_W': ops['norm_GoW'],
        'G_at_1_sq': ops['G1sq'],
        'ell_box': (arb('%.17e' % ell0) - smax).union(arb('%.17e' % ell0) + smax),
    }
    if not (q < 1 and q_s < 1):
        raise RuntimeError('q or q_s >= 1: %s %s' % (q, q_s))
    from beta_bound_lib import beta_bound_ell
    beta_Np1, _, _, _ = beta_bound_ell(NP + 1, consts)
    # beta_0^* from the k=0 column
    b0star = arb(0)
    for i in range(len(ops['mprime0_slices'])):
        col = ops['mprime0_slices'][i]
        si = arb(0)
        for j in range(NP):
            si = si + abs(col[j])
        b0star = b0star + si * (smax ** i)
    b0star = (b0star + ops['tau_col0']).upper()
    Z1c = ((1 + B_A) * (beta_Np1 + (C / R) ** (NP + 1) * b0star)).upper()
    diag = {'M_U_R': M_U_R, 'M_W_R': M_W_R, 'M_H': M_H, 'q': q, 'q_s': q_s,
            'beta_Np1': beta_Np1, 'b0star': b0star}
    return w2tail, Z1b, Z1c, diag



def _tails_piece(c_a, m, lo, hi, xlo, xhi):
    """Хвостовые величины на ОДНОМ куске бокса (интервальный центр и ℓ)."""
    Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
    ell_box = lo.union(hi)
    F_poly = tl.compute_F_poly(Pint, ell_box)
    w2 = arb(0)
    for k in range(NP + 1, len(F_poly)):
        w2 = w2 + abs(F_poly[k]) * (R ** k)
    ft = tl.compute_F_tail_bound(Pint, ell_box)
    if ft is None:
        raise RuntimeError('F tail bound failed (alpha sign)')
    return w2.upper(), ft.upper()


def _tails_subdivided(c_a, m, ell0, w, Kmax=8):
    """TAIL-SUB (18.08 00:05).  Хвост Y0 считался одним куском на весь бокс,
    и на верхнем конце отрезка миллеровская обёртка раздувала его до 2.8e-8
    (при истинном ~1e-13).  Само по себе это ворота не валило, но раздувало
    ρ* = Y0/(1−Ẑ), а через него — член смещения неподвижной точки в трубке
    гиперболичности.  Тот же приём, что для Z1b/Z1c: супремум по боксу =
    максимум супремумов по кускам."""
    K = 1
    prev = None
    while True:
        w2m, ftm = arb(0), arb(0)
        for s in range(K):
            xlo, xhi = -1.0 + 2.0 * s / K, -1.0 + 2.0 * (s + 1) / K
            lo = ell0 - w / 2 + w * arb(s) / K
            hi = ell0 - w / 2 + w * arb(s + 1) / K
            a, b = _tails_piece(c_a, m, lo, hi, xlo, xhi)
            if a > w2m:
                w2m = a
            if b > ftm:
                ftm = b
        tot = float(w2m + ftm)
        if prev is not None and tot > 0.5 * prev:
            return w2m, ftm, K
        if K >= Kmax:
            return w2m, ftm, K
        prev = tot
        K *= 2


def _z1bc_subdivided(c_a, m, ell0, w, A_mid, B_A, Kmax=32, target=1e-3):
    """Z1b/Z1c по боксу через ИНТЕРВАЛЬНЫЙ путь с подразбиением.

    FIX-3b (17.08 22:20).  Одиночный вызов rig_lib.interval_Z1bc строит пакет
    оператора при интервальном центре по ВСЕМУ боксу сразу, и миллеровская
    обёртка e^{O(w*N_W)} раздувает Z1c: при ell0=3.60, w=0.05 он равен 1.199,
    что валит бокс.  Но супремум по боксу равен максимуму супремумов по его
    кускам, поэтому бокс режется на K частей: у каждой центр узкий и обёртка
    мала.  Замер на том же боксе: K=1 -> 1.199, K=2 -> 7.4e-5, K=4 -> 7.8e-7,
    K=8 -> 2.4e-7.  Утверждение при этом не меняется, меняется только способ
    получения той же верхней границы.
    """
    K = 1
    while True:
        b_max, c_max = arb(0), arb(0)
        for s in range(K):
            xlo, xhi = -1.0 + 2.0 * s / K, -1.0 + 2.0 * (s + 1) / K
            Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
            elo = ell0 - w / 2 + w * arb(s) / K
            ehi = ell0 - w / 2 + w * arb(s + 1) / K
            pkg = tl.build_pkg_fast(Pint, elo.union(ehi))
            if pkg is None:
                raise RuntimeError('interval pkg failed (K=%d, sub %d)' % (K, s))
            xn = tl.compute_x_norms_and_beta(pkg)
            _, _, Z1b_s, Z1c_s = tl.compute_Z1(
                pkg, A_mid, B_A, strict_consts=tl.build_strict_consts_from_pkg(pkg, xn))
            if Z1b_s.upper() > b_max:
                b_max = Z1b_s.upper()
            if Z1c_s.upper() > c_max:
                c_max = Z1c_s.upper()
        if c_max < arb('%.17e' % target) or K >= Kmax:
            return b_max, c_max, K
        K *= 2


def run(ell0, w, m, D, seed, prec=256):
    t_all = time.time()
    ell0_a = arb('%.17e' % ell0)
    w_a = arb('%.17e' % w)
    smax = w_a / 2
    ctx.prec = prec

    # ---------- branch + Taylor objects ----------
    t0 = time.time()
    br = rl.build_branch(ell0, w, m + 1, seed)
    c_a, c_A = br['c_a'], br['c_A']
    tay = np.zeros((m + 1, NP + 1))
    for k in range(NP + 1):
        tay[:, k] = fl.cheb_to_taylor(c_a[:, k], w)
    tay[0, 0] = 1.0
    tay[1:, 0] = 0.0
    tay_A = np.zeros((m + 1, NP, NP))
    for j in range(NP):
        for k in range(NP):
            tay_A[:, j, k] = fl.cheb_to_taylor(c_A[:, j, k], w)
    plog('branch+taylor in %.1fs' % (time.time() - t0))

    # B_A = sup ||A~(sigma)||_1
    #
    # STRICT-UP (18.08): раньше столбцовые суммы собирались в чистом
    # float64 (~80*(m+1) слагаемых с округлением к ближайшему), и итог
    # мог оказаться НИЖЕ истинного супремума — то есть B_A переставал быть
    # мажорантой.  Занижение порядка 80*(m+1)*eps*B_A ~ 3e-14 против
    # запасов в пять порядков, но буква нарушалась.  Теперь суммирование
    # идёт в arb, наружу выдаётся верхний конец.
    smax_a = arb('%.17e' % (w / 2))
    B_A = arb(0)
    for k in range(NP):
        col = arb(0)
        pw = arb(1)
        for p in range(m + 1):
            rowsum = arb(0)
            for j in range(NP):
                rowsum = rowsum + abs(arb(float(tay_A[p][j][k])))
            col = col + rowsum * pw
            pw = pw * smax_a
        cu = col.upper()
        if cu > B_A:
            B_A = cu
    B_A_f = up_float(B_A)

    # DeltaP: sup_sigma |P(sigma)-P(0)|_X  (X-norm = r^k-weighted u-coords!)
    deltaP = arb(0)
    for i in range(1, m + 1):
        Pc_i = tl.reexpand_fast([arb(x) for x in tay[i]], C, R, NP)
        s = arb(0)
        rk = arb(1)
        for k in range(NP + 1):
            s = s + abs(Pc_i[k]) * rk
            rk = rk * R
        deltaP = deltaP + s * (smax ** i)
    plog('B_A=%s DeltaP=%s' % (fmt(B_A), fmt(deltaP)))

    # ---------- DCHK-CONV: строгая оценка расхождения ----------
    # σ-модель строится по float64-конверсии чебышёв→тейлор (массив `tay`),
    # а движок работает с чебышёвским центром `c_a` напрямую.  Величина
    # d_chk обязана мажорировать расхождение двух путей ПО ВСЕМУ боксу.
    #
    # Прямой путь (посчитать обе стороны интервально и вычесть) не работает:
    # разность ~1e-15 тонет в раздутии слагаемых ~1e-3, сходимость по
    # подразбиению линейная (замер: K=2..64 даёт 0.19…0.0056 при пороге
    # 8e-14).  Поэтому оценивается не разность вычислений, а ПРИЧИНА
    # расхождения — погрешность самой конверсии:
    #
    #   ‖F(P_tay(σ)) − F(P_cheb(σ))‖ ≤ sup‖DF‖ · ‖P_tay(σ) − P_cheb(σ)‖,
    #
    # где sup‖DF‖ = sup‖M′‖₁ по боксу (M′ = I − DT), а ‖ΔP‖ считается
    # точно: та же чебышёвская рекуррентность выполняется в arb, и разность
    # с float64-результатом есть ровно погрешность конверсии.  Отмена
    # больших слагаемых здесь не происходит — раздутия нет.
    t0 = time.time()

    def _cheb_to_taylor_arb(cvec, w_a_):
        """та же рекуррентность, что fp_lib.cheb_to_taylor, но в arb"""
        n = len(cvec) - 1
        sc = arb(2) / w_a_
        Tkm2 = [arb(0)] * (n + 1); Tkm2[0] = arb(1)
        Tkm1 = [arb(0)] * (n + 1)
        if n >= 1:
            Tkm1[1] = sc
        total = [arb('0.5') * cvec[0] * Tkm2[i] for i in range(n + 1)]
        for k in range(1, n + 1):
            for i in range(n + 1):
                total[i] = total[i] + cvec[k] * Tkm1[i]
            if k < n:
                Tnew = [arb(0)] * (n + 1)
                for i in range(1, n + 1):
                    Tnew[i] = 2 * sc * Tkm1[i - 1]
                for i in range(n + 1):
                    Tnew[i] = Tnew[i] - Tkm2[i]
                Tkm2, Tkm1 = Tkm1, Tnew
        return total

    # погрешность конверсии по каждому коэффициенту
    dtay = [[arb(0)] * (NP + 1) for _ in range(m + 1)]
    for k in range(NP + 1):
        col = [arb(float(x)) for x in c_a[:, k]]
        ex = _cheb_to_taylor_arb(col, w_a)
        for i in range(m + 1):
            dtay[i][k] = ex[i] - arb(float(tay[i][k]))
    # ‖ΔP(σ)‖ в той же норме, что deltaP.
    #
    # ВАЖНО про порядок операций.  Коэффициентная мажоранта
    # Σ_i Σ_k |Δ[i][k]|·smax^i·r^k здесь бесполезна: погрешности конверсии
    # растут как (2/w)^i, а вес smax^i = (w/2)^i ровно это компенсирует, так
    # что каждый σ-порядок вносит полную величину, и сокращение между
    # порядками (ради которого конверсия и точна) теряется.  Замер на g01:
    # такая мажоранта даёт 3.7e-2 при истинном расхождении 1.7e-15.
    #
    # Поэтому сначала СВЁРТКА по σ при интервальном σ (сокращение между
    # порядками сохраняется внутри интервала), и только потом норма по k.
    s_full = (-smax).union(smax)
    dcoef = []
    for k in range(NP + 1):
        acc = arb(0)
        sp = arb(1)
        for i in range(m + 1):
            acc = acc + dtay[i][k] * sp
            sp = sp * s_full
        dcoef.append(acc)
    Dc = tl.reexpand_fast(dcoef, C, R, NP)
    dP_conv = arb(0)
    rk = arb(1)
    for k in range(NP + 1):
        dP_conv = dP_conv + abs(Dc[k]) * rk
        rk = rk * R
    dP_conv = dP_conv.upper()

    # sup‖M′‖₁ по боксу (M′ = I − DT), интервально, с подразбиением
    M1box = arb(0)
    K_M = 2
    for s_ in range(K_M):
        xlo, xhi = -1.0 + 2.0 * s_ / K_M, -1.0 + 2.0 * (s_ + 1) / K_M
        elo = ell0_a - w_a / 2 + w_a * arb(s_) / K_M
        ehi = ell0_a - w_a / 2 + w_a * arb(s_ + 1) / K_M
        Pint_ = rl.P_at_interval(
            c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
        pkg_ = tl.build_pkg_fast(Pint_, elo.union(ehi))
        if pkg_ is None:
            raise RuntimeError('M1box: пакет не построился')
        DT_ = hr.dt_from_pkg(pkg_)
        for kk in range(NP):
            colsum = arb(0)
            for jj in range(NP):
                mjk = (arb(1) - DT_[jj][kk]) if jj == kk else -DT_[jj][kk]
                colsum = colsum + abs(mjk)
            cu = colsum.upper()
            if cu > M1box:
                M1box = cu
    dchk_lin = (M1box * dP_conv).upper()
    plog('DCHK-CONV: ‖ΔP‖=%s  sup‖M′‖₁=%s  ->  линейный член %s  [%.1fs]'
         % (fmt(dP_conv), fmt(M1box), fmt(dchk_lin), time.time() - t0))

    # ---------- sigma-operator ----------
    t0 = time.time()
    P0 = [arb(float(x)) for x in tay[0]]
    P0[0] = arb(1)
    ops = osig.build_operator_sigma(P0, tay, m, ell0, w, D, prec=prec)
    plog('sigma-operator built in %.1fs (tau_F=%s, mU=%s)'
         % (time.time() - t0, fmt(ops['tau_F']), fmt(ops['mU'])))

    dchk = dchk_lin
    if not (dchk < arb('1e-6')):
        raise RuntimeError('DCHK-CONV SANITY FAILED: %s' % dchk)

    # LEMMA-FIX: лемма об области
    # (аналитичность ветки на |t-c| = 1.2) проверялась только маршем, хотя на
    # ней стоят все коши-хвосты.  Теперь проверяется на каждом боксе, по
    # интервальному центру и интервальному ℓ, и отказ валит бокс.
    t0 = time.time()
    # LEMMA-SUB (18.08 02:15): на верхнем конце отрезка лемма и основания
    # геометрий не проходят при интервальном центре по ВСЕМУ боксу — это
    # то же раздутие, что било по Z1c и по хвосту Y0, и лечится тем же:
    # проверяем на кусках.  Условие выполнено на боксе, если выполнено на
    # каждом куске (обе величины — супремумы по ℓ и по центру).
    def _lemma_bases_on(xlo, xhi, lo, hi):
        Pp = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
        eb = lo.union(hi)
        pk = tl.build_pkg_fast(Pp, eb)
        lm, ok = tl.verify_lemma_U(Pp, eb)
        xn = tl.compute_x_norms_and_beta(pk)
        cs = tl.build_strict_consts_from_pkg(pk, xn)
        bs = bbl.bases_check(cs)
        ok2 = bool(bs['q_lt1_strict'] and bs['q_s_lt1_strict'])
        return lm, ok, bs, ok2, pk

    K_lb = 1
    while True:
        worst_lem, worst_bs, allok = None, None, True
        _pkgb = None
        for _s in range(K_lb):
            xlo, xhi = -1.0 + 2.0 * _s / K_lb, -1.0 + 2.0 * (_s + 1) / K_lb
            lo = ell0_a - w_a / 2 + w_a * arb(_s) / K_lb
            hi = ell0_a - w_a / 2 + w_a * arb(_s + 1) / K_lb
            lm, ok, bs, ok2, pk = _lemma_bases_on(xlo, xhi, lo, hi)
            if _pkgb is None:
                _pkgb = pk
            if (worst_lem is None
                    or float(lm.get('margin_c', arb(0))) < float(worst_lem.get('margin_c', arb(0)))):
                worst_lem = lm
            if worst_bs is None or bs['q_upper_value'] > worst_bs['q_upper_value']:
                worst_bs = bs
            allok = allok and ok and ok2
        if allok or K_lb >= 8:
            break
        K_lb *= 2
    lem, lem_ok, bases = worst_lem, allok, worst_bs
    plog('лемма+основания: K=%d' % K_lb)
    plog('лемма об области: OK=%s U_min=%s margin_a=%s margin_c=%s  [%.1fs]'
         % (lem_ok, fmt(lem.get('U_min', arb(0)), 3),
            fmt(lem.get('margin_a', arb(0)), 3), fmt(lem.get('margin_c', arb(0)), 3),
            time.time() - t0))
    if not lem_ok:
        raise RuntimeError('LEMMA-1 FAILED on box: %s' % lem)

    # BASES-FIX: монотонность β̂_k
    # (из которой следует sup_{k>N_p} β_k = β_{N_p+1}) держится на q, q_s < 1.
    # В интервальном пути это не проверялось; теперь проверяется по всему
    # боксу и пишется в json.
    plog('основания геометрий (худший кусок): q=%.6f q_s=%.6f'
         % (bases['q_upper_value'], bases['q_s_upper_value']))
    if not (bases['q_lt1_strict'] and bases['q_s_lt1_strict']):
        raise RuntimeError('BASES CHECK FAILED: q=%s q_s=%s'
                           % (bases['q_upper_value'], bases['q_s_upper_value']))

    # ---------- float slices + radii ----------
    Fslices_f = [np.array([float(x) for x in sl_]) for sl_ in ops['Ftilde_slices']]
    Frad = [max(float(x.rad()) for x in sl_) if len(sl_) else 0.0
            for sl_ in ops['Ftilde_slices']]
    Mslices_f = []
    Mrad = []
    for i in range(D + 1):
        Mmat = np.zeros((NP, NP))
        mrad = 0.0
        for k in range(NP):
            col = ops['Mprime_slices'][i][k]
            for j in range(NP):
                Mmat[j, k] = float(col[j].mid())
                mrad = max(mrad, float(col[j].rad()))
        Mslices_f.append(Mmat)
        Mrad.append(mrad)
    plog('float slices extracted (max rad F=%s, M=%s)'
         % ('%.1e' % max(Frad), '%.1e' % max(Mrad)))

    # ---------- Y0 head ----------
    # HEADS-ARB: раньше произведения срезов считались в
    # numpy float64, а на округление накидывалась константа 1e-14, ниоткуда
    # не выведенная; arb(x).upper() потерянное направленное округление не
    # восстанавливает.  Теперь та же формула считается матрицами arb
    # (arb_mat — умножение на уровне C), поэтому округление учитывается самой
    # арифметикой шаров, а слагаемые eps_entries/Frad/Mrad не нужны.
    nF = len(Fslices_f)
    tot_deg = m + nF - 1
    A_arb = [arb_mat(NP, NP, [arb(float(tay_A[p][j, k]))
                              for j in range(NP) for k in range(NP)])
             for p in range(m + 1)]
    F_arb = [arb_mat(NP, 1, [sl_[j] for j in range(NP)])
             for sl_ in ops['Ftilde_slices']]
    v1_norms_a = [arb(0)] * (tot_deg + 1)
    for p in range(m + 1):
        for l in range(nF):
            v = A_arb[p] * F_arb[l]
            i = p + l
            acc = arb(0)
            for j in range(NP):
                acc = acc + abs(v[j, 0])
            v1_norms_a[i] = v1_norms_a[i] + acc
    Y0_head_a = arb(0)
    for i in range(tot_deg + 1):
        Y0_head_a = Y0_head_a + v1_norms_a[i] * (arb('%.17e' % (w / 2)) ** i)
    Y0_head_a = Y0_head_a.upper()
    Y0_head_f = up_float(Y0_head_a)      # STRICT-UP: вверх, не к ближайшему
    tau_F = ops['tau_F']
    Y0_tau = up_float(arb(B_A) * arb(tau_F))
    Y0_round = 0.0   # HEADS-ARB: округление внутри arb-арифметики
    t0 = time.time()
    try:
        w2_sup, ftail_sup, K_t = _tails_subdivided(c_a, m, ell0_a, w_a)
        plog('interval tails in %.1fs: w2=%s Ftail=%s [K=%d]'
             % (time.time() - t0, fmt(w2_sup), fmt(ftail_sup), K_t))
    except Exception as e:
        # FIX-3: обнуление здесь давало ТИХИЙ путь потери
        # всего k-хвоста из Y0.  Интервальный путь теперь несущий, поэтому его
        # отказ обязан валить бокс, а не молча удешевлять сертификат.
        raise RuntimeError('interval tails failed, box cannot be certified: %s' % e)
    t0 = time.time()
    w2tail_sig, Z1b_sig, Z1c_sig, diag_t = sigma_tails_full(ops, tay, m, ell0, w, B_A, prec=prec)
    plog('sigma tails in %.1fs: w2tail=%s Z1b=%s Z1c=%s [q=%s q_s=%s beta=%s]'
         % (time.time() - t0, fmt(w2tail_sig), fmt(Z1b_sig), fmt(Z1c_sig),
            fmt(diag_t['q'], 4), fmt(diag_t['q_s'], 4), fmt(diag_t['beta_Np1'])))
    # FIX-2 (audit 17.08).  Both expressions bound the SAME quantity --
    # the k-tail  sum_{k>N_p} |F_k| r^k  over the whole box:
    #   * interval route: w2 covers N_p < k <= N_ALG, ftail covers k > N_ALG
    #     (this is the march's own decomposition: record fields Y0 + F_tail);
    #   * sigma route:    w2tail_sig is a geometric majorant of all k > N_p.
    # The original code took max(w2, w2tail_sig) and then ALSO added ftail,
    # i.e. the worse of two valid bounds, plus a double count.  The minimum of
    # two valid upper bounds is a valid upper bound, so take it.
    # Why it matters: the interval route blows up at wide w (Miller wrapper
    # e^{O(w N_W)}) while the sigma route is weak at large ell (the k-tail of
    # G* decays slowly there).  min() is tight in both regimes.
    # FIX-3.  ПРАВКА 2 ОТОЗВАНА.  min(interval, sigma)
    # был неверен как шаг доказательства: sigma-оценка опирается на скалярные
    # константы c1_sup/alpha_sup, которые суть sup МОДУЛЯ sigma-многочлена
    # степени D, а не самих функций, и занижены на 0.2-5.6 %.  Там, где min()
    # выбирал sigma (боксы w20_07/08), Y0 переставал быть доказанной границей.
    # Здесь sigma-путь считается ТОЛЬКО как диагностика, а в Y0 идёт
    # интервальный путь, покрытие которого по k проверено:
    #   w2 закрывает 81 <= k <= 192, Ftail закрывает k >= 193, зазора нет.
    # Цена: там, где интервальный путь взрывается (миллеровская обёртка при
    # широком боксе), бокс режется на узкие, а не подпирается недоказанным.
    tail_interval = (w2_sup + ftail_sup).upper()
    tail_sigma = w2tail_sig.upper()
    tail_total = tail_interval
    tail_which = 'interval-only(fix3)'
    plog('tails: interval=%s sigma=%s -> using %s (%s)'
         % (fmt(tail_interval), fmt(tail_sigma), tail_which, fmt(tail_total)))
    Y0 = arb('%.17e' % Y0_head_f) + arb('%.17e' % Y0_tau) + arb('%.17e' % Y0_round) + tail_total
    Y0 = Y0.upper()
    plog('Y0 = %s   [head %s + tau %s + round %s + tail %s]'
         % (fmt(Y0), '%.3e' % Y0_head_f, '%.1e' % Y0_tau, '%.1e' % Y0_round,
            fmt(tail_total)))

    # ---------- Z1 head ----------
    # HEADS-ARB: та же формула в arb-матрицах.  Структура сохранена
    # буквально: Zpl = A_p @ M_l матрично, при i=0 вычитается из единичной,
    # затем колонные суммы модулей.  Обе прежние попытки переписать этот блок
    # ломались именно здесь — одна выродила произведение в поэлементное
    # (занижение Z1 в 2.7 раза), другая подменила норму I−AM на 1−Σ|AM|.
    M_arb = []
    for l in range(D + 1):
        ent = []
        for j in range(NP):
            for k in range(NP):
                ent.append(ops['Mprime_slices'][l][k][j])
        M_arb.append(arb_mat(NP, NP, ent))
    Z_colnorm_a = [[arb(0)] * NP for _ in range(tot_deg + 1)]
    for p in range(m + 1):
        for l in range(D + 1):
            Zpl = A_arb[p] * M_arb[l]
            i = p + l
            for k in range(NP):
                acc = arb(0)
                for j in range(NP):
                    e = Zpl[j, k]
                    if i == 0 and j == k:
                        e = arb(1) - e
                    elif i == 0:
                        e = -e
                    acc = acc + abs(e)
                Z_colnorm_a[i][k] = Z_colnorm_a[i][k] + acc
    # FIX (audit 17.08): the majorant of sup_sigma ||Z(sigma)||_1 is
    #   max_k sum_i colnorm_i[k] * smax^i,   NOT   max_i (max_k ...).
    # The original max_i understated Z1 by 4.7% at ell0=3, w=0.2.
    # This matches the docstring at the top of the file ("Z1 = sum_i ...").
    smax_a = arb('%.17e' % (w / 2))
    Z1_head_a = arb(0)
    for k in range(NP):
        col = arb(0)
        for i in range(tot_deg + 1):
            col = col + Z_colnorm_a[i][k] * (smax_a ** i)
        cu = col.upper()
        if cu > Z1_head_a:
            Z1_head_a = cu
    Z1_head_f = up_float(Z1_head_a)      # STRICT-UP: вверх, не к ближайшему
    max_tau_col = max(up_float(t) for t in ops['taus_cols'])
    Z1_tau = up_float(arb(B_A) * arb(max_tau_col))
    Z1_round = 0.0   # HEADS-ARB: округление внутри arb-арифметики
    # FIX-3: Z1b/Z1c опирались на те же недоказанные
    # sigma-константы, что и отозванная правка 2.  Берём интервальный путь —
    # он считает те же величины по всему боксу с интервальным ell и
    # интервальным центром, без sigma-усечения.  Отказ = провал бокса.
    t0 = time.time()
    Z1b_int, Z1c_int, K_used = _z1bc_subdivided(c_a, m, ell0_a, w_a, tay_A[0], B_A)
    plog('interval Z1bc in %.1fs: Z1b=%s Z1c=%s   (sigma-версии были %s / %s)'
         % (time.time() - t0, fmt(Z1b_int), fmt(Z1c_int), fmt(Z1b_sig), fmt(Z1c_sig))
         + '  [K=%d]' % K_used)
    Z1b = max(Z1b_int, arb(0))
    Z1c = Z1c_int
    Z1 = (arb('%.17e' % Z1_head_f) + arb('%.17e' % Z1_tau) +
          arb('%.17e' % Z1_round) + Z1b + Z1c).upper()
    plog('Z1 = %s   [head %s + tau %s + round %s + b/c]'
         % (fmt(Z1), '%.3e' % Z1_head_f, '%.1e' % Z1_tau, '%.1e' % Z1_round))

    # ---------- L-chain (sub-boxed: engine interval-l arithmetic is
    # march-grade, valid on sub-boxes of width <= ~0.05) ----------
    t0 = time.time()
    K = max(1, int(w / 0.04) + 1)
    dsub = smax * 2 / arb(K)
    Pc_norms = []
    for i in range(1, m + 1):
        Pc_i = ops['Pc'][i] if i < len(ops['Pc']) else [arb(0)] * (NP + 1)
        s = arb(0)
        rk = arb(1)
        for k in range(NP + 1):
            s = s + abs(Pc_i[k] if k < len(Pc_i) else arb(0)) * rk
            rk = rk * R
        Pc_norms.append(s)
    pkgs = []
    xns = []
    deltaPs = []
    for s_i in range(K):
        # sub-box center in sigma: sigma_s in [-smax + dsub*(s_i+0.5)]
        sig_s = -smax + dsub * (arb(2 * s_i + 1) / 2)
        lo = -smax + dsub * s_i
        hi = -smax + dsub * (s_i + 1)
        x_mid = (sig_s / smax) if smax > 0 else arb(0)
        P_s = rl.P_at(c_a, m, x_mid)
        ell_s = ell0_a + sig_s
        ell_box_s = (ell0_a + lo).union(ell0_a + hi)
        pkg_s = tl.build_pkg_fast(P_s, ell_box_s)
        if pkg_s is None:
            raise RuntimeError('sub pkg failed at %d/%d' % (s_i, K))
        xn_s = tl.compute_x_norms_and_beta(pkg_s)
        # DeltaP within the sub-box: sum_i ||Pc_i|| * i * (|sig_s|+dsub/2)^{i-1} * dsub/2
        dP = arb(0)
        for i in range(1, m + 1):
            dP = dP + Pc_norms[i - 1] * arb(i) * (abs(sig_s) + dsub / 2) ** (i - 1) * (dsub / 2)
        pkgs.append(pkg_s)
        xns.append(xn_s)
        deltaPs.append(dP)
    plog('L-pkgs (K=%d sub-boxes) in %.1fs' % (K, time.time() - t0))

    # ---------- gates ----------
    best = None
    grid = [arb('1e-7'), arb('3e-8'), arb('1e-8'), arb('3e-9'), arb('1e-9'),
            arb('3e-10'), arb('1e-10'), arb('1e-11'), arb('1e-12'),
            arb('1e-6'), arb('3e-7'), arb('1e-5'), arb('3e-6'),
            arb('3e-5'), arb('1e-4')]
    for rho_p in grid:
        L = None
        okL = True
        for s_i in range(K):
            # L-DOMAIN.  Единственность заявляется в X-шаре 1.75*rho' вокруг
            # ДВИЖУЩЕГОСЯ центра P(l), а он вложен в b-шар того же радиуса,
            # на котором и нужна липшицевость DF; в X-норме это радиус
            # 1.75^2*rho' = 3.0625*rho' вокруг P(l).  Центр подбокса P_s
            # отстоит от P(l) не больше чем на dP, поэтому вокруг P_s нужен
            # X-радиус 3.0625*rho' + dP.
            #
            # Раньше здесь стояло
            # `_compute_L(..., rho_p + dP/1.75)`, что даёт X-радиус
            # 1.75*rho' + dP — РОВНО НА 1.3125*rho' МЕНЬШЕ требуемого, и этот
            # разрыв не зависит от dP.  Стоявшая рядом калитка
            # `dP >= 1.3125*rho'` его не закрывала: она сравнивала
            # сертифицированный радиус с 3.0625*rho' так, как если бы шар был
            # центрирован в самом P_s, а не в P(l).  То есть обоснование не
            # сходилось, хотя запас по воротам это скрывал.
            #
            # `_compute_L(pkg, xn, x)` (см. его докстринг) сертифицирует L на
            # X-шаре радиуса 1.75*x, поэтому нужный аргумент —
            # (3.0625*rho' + dP)/1.75 = 1.75*rho' + dP/1.75.
            Lp = tl._compute_L(pkgs[s_i], xns[s_i],
                               arb('1.75') * rho_p + deltaPs[s_i] / arb('1.75'))
            if Lp is None:
                okL = False
                break
            Ls = Lp['L_strict']
            if L is None or Ls > L:
                L = Ls
        if not okL:
            plog("  rho'=%s: L-chain rejected (some sub-box)" % fmt(rho_p, 1))
            continue
        # Z1CONV-FIX (18.08): голова Z1 построена по σ-модели вокруг
        # float64-конверсии центра (массив `tay`), а теорема формулируется
        # вокруг чебышёвского центра.  Для Y0 расхождение конверсии учтено
        # членом B_A·d_chk (см. DCHK-CONV выше), а для Z1 аналога не было.
        # Оценка та же по строению:
        #     ‖Ã·(M′(P_tay) − M′(P_cheb))‖₁ ≤ B_A · L · ‖ΔP_conv‖ .
        Zconv = (B_A * L * dP_conv).upper()
        Zhat = Z1 + arb('3.0625') * B_A * L * rho_p + Zconv
        if not (Zhat < arb(1)):
            plog("  rho'=%s: Zhat=%s >= 1" % (fmt(rho_p, 1), fmt(Zhat, 3)))
            continue
        # GUARD-FIX: B_A*dchk (расхождение sigma-модели с движком) входит в
        # неравенство, а не проверяется отдельно рядом с ним.
        dchk = (dchk_lin + L * dP_conv * dP_conv).upper()
        lhs = Y0 + B_A * dchk + Zhat * rho_p
        ok = lhs <= rho_p
        plog("  rho'=%s: Lmax=%s Zhat=%s (Zconv=%s) lhs=%s  %s"
             % (fmt(rho_p, 1), fmt(L, 3), fmt(Zhat, 4), fmt(Zconv, 2),
                fmt(lhs, 3), 'PASS' if ok else 'fail'))
        if ok:
            num = (Y0 + B_A * dchk).upper()
            den = (1 - Zhat).lower()
            rho_star_b = ((Y0 + B_A * dchk) / (1 - Zhat)).upper()
            # Числитель и знаменатель ворот кладутся в json отдельно: без них
            # тождество ρ*_b·(1−Ẑ) = Y0 + B_A·d_chk не проверяется снаружи —
            # в json лежат СЕРЕДИНЫ шаров, а ρ*_b считается по их ХУДШИМ
            # концам, и разница доходила до 2 % (сбивая внешнюю сверку).
            plog("    ворота: num=%s den=%s (Zhat rad=%s, Y0 rad=%s, B_A rad=%s)"
                 % (fmt(num), fmt(den), fmt(arb(Zhat).rad(), 2),
                    fmt(arb(Y0).rad(), 2), fmt(arb(B_A).rad(), 2)))
            best = {'rho_prime': rho_p, 'L': L, 'Zhat': Zhat,
                    'rho_star': rho_star_b, 'rho_star_b': rho_star_b,
                    'rho_star_X': (arb('1.75') * rho_star_b).upper(),
                    'gate_num': num, 'gate_den': den,
                    'lhs': lhs}
            break
    t_cert = time.time() - t_all
    plog('CERTIFICATE %s in %.1fs' % ('PASSED' if best else 'FAILED', t_cert))

    # ---------- containment ----------
    containment = None
    if abs(ell0 - 3.0) < 1e-12:
        P3 = rl.P_at(c_a, m, arb(0))
        dX = arb(0)
        for k in range(NP + 1):
            dX = dX + abs(P3[k] - arb(float(seed[k]))) * ((C + R) ** k)
        if best is not None:
            rho_X = arb('1.75') * best['rho_prime']
            containment = {'dX': dX, 'rho_X': rho_X,
                           'contains': bool(dX + arb('1.75e-20') <= rho_X)}
        plog('containment: |P(3)-seed|_X=%s (+1.75e-20) vs rho_X=%s -> %s'
             % (fmt(dX), fmt(containment['rho_X']) if containment else 'n/a',
                containment['contains'] if containment else 'n/a'))

    out = {'ell0': ell0, 'w': w, 'm': m, 'D': D, 'prec': prec,
           'Y0': fmt_up(Y0), 'Z1': fmt_up(Z1), 'B_A': fmt_up(B_A),
           # B_A_lo нужен потребителям, которые ДЕЛЯТ на B_A (tube_offset:
           # ‖C‖ ≤ Z1b/B_A).  Деление на завышенный B_A даёт заниженное ‖C‖,
           # поэтому в знаменатель идёт миноранта, а не то же самое число.
           'B_A_lo': fmt_dn(B_A), 'deltaP': fmt_up(deltaP),
           # FIX-3: dchk обязан лежать в json — это вход охранного критерия
           # B_A*dchk <= 0.5*Y0, а из логов его легко потерять фильтром.
           'dchk': fmt_up(dchk), 'guard_lhs': fmt_up(B_A * dchk),
           'guard_rhs': fmt_dn(Y0 / 2),
           'guard_ok': bool(B_A * dchk <= Y0 / 2),
           'guard_in_gate': True,
           'lemma1_OK': bool(lem_ok),
           # величины леммы 1 — НИЖНИЕ границы, округляем вниз
           'lemma1_U_min': fmt_dn(lem.get('U_min', arb(0)), 4),
           'lemma1_margin_a': fmt_dn(lem.get('margin_a', arb(0)), 4),
           'lemma1_margin_c': fmt_dn(lem.get('margin_c', arb(0)), 4),
           'lemma1_nonzero_ok': bool(lem.get('nonzero_ok', False)),
           'lemma1_ReU_min_r_val': fmt_dn(lem.get('ReU_min_r', arb(0)), 4),
           'lemma1_ReU_min_R': fmt_dn(lem.get('ReU_min_R', arb(0)), 4),
           'bases_q': bases.get('q_upper_value'),
           'bases_q_s': bases.get('q_s_upper_value'),
           'bases_ok': bool(bases.get('q_lt1_strict') and bases.get('q_s_lt1_strict')),
           'lemma_bases_K': K_lb,
           'tau_F': fmt_up(ops['tau_F']), 'w2_sup': fmt_up(w2_sup),
           'Ftail_sup': fmt_up(ftail_sup), 'tail_interval': fmt_up(tail_interval),
           'tail_sigma': fmt_up(tail_sigma), 'tail_used': tail_which,
           'Z1b': fmt_up(Z1b), 'Z1c': fmt_up(Z1c),
           'Z1b_sigma': fmt_up(Z1b_sig), 'Z1c_sigma': fmt_up(Z1c_sig),
           'passed': best is not None,
           # L и Ẑ — арб-ШАРЫ (L = D_total/ρ_X, Ẑ = Z1 + 1.75²·B_A·L·ρ′).
           # В ворота идёт их ХУДШИЙ конец, поэтому в json пишется он же:
           # середина шара занижала бы L примерно вдвое и делала бы тождество
           # ρ*_b·(1−Ẑ) = Y0 + B_A·d_chk непроверяемым снаружи.
           'best': (  # rho_prime — ВХОДНОЙ параметр из сетки коротких десятичных
                     # (1e-7, 3e-8, ...), а не вычисленная граница: печать
                     # нейтральная и точная
                     {'rho_prime': fmt(best['rho_prime']),
                     'L': fmt_up(arb(best['L']).upper(), 4),
                     'L_mid': fmt(best['L'], 4),
                     'Zhat': fmt_up(arb(best['Zhat']).upper(), 6),
                     'rho_star': fmt_up(best['rho_star']),
                     'rho_star_b': fmt_up(best['rho_star_b']),
                     'rho_star_X': fmt_up(best['rho_star_X']),
                     'gate_num': fmt_up(best['gate_num']),
                     # знаменатель 1−Ẑ идёт в ρ* = num/den: вниз
                     'gate_den': fmt_dn(best['gate_den'])}
                    if best else None),
           'containment': ({'dX': fmt_up(containment['dX']),
                            'rho_X': fmt_dn(containment['rho_X']),
                            'contains': containment['contains']}
                           if containment else None),
           'time_s': round(t_cert, 2)}
    return out


def main():
    args = sys.argv[1:]
    w = float(args[0]) if len(args) > 0 else 1e-3
    m = int(args[1]) if len(args) > 1 else 4
    D = int(args[2]) if len(args) > 2 else 8
    ell0 = float(args[3]) if len(args) > 3 else 3.0
    if not (w > 0):
        raise SystemExit('w (полная ширина бокса) должна быть > 0 (получено %r)' % w)
    if m < 1:
        raise SystemExit('m (порядок ренормализации) должен быть >= 1 '
                         '(получено %d)' % m)
    if D < 1:
        raise SystemExit('D (глубина рекуррентности) должна быть >= 1 '
                         '(получено %d)' % D)
    # Здесь стоял путь `../_source/engine/hiprec_seeds.json` —
    # каталог рабочего дерева, которого в пакете нет: main() падал
    # FileNotFoundError при прямом запуске.  Тот же класс, что чинили в
    # кругах 9-10 у анкорных скриптов и tube_offset.py.  Сиды лежат
    # рядом с движком; переменная оставлена для чужой раскладки.
    _seeds_p = os.environ.get('HYP_SEEDS',
                              os.path.join(HERE, 'hiprec_seeds.json'))
    if not os.path.exists(_seeds_p):
        raise SystemExit('нет файла сидов: %s (задайте HYP_SEEDS)'
                         % _seeds_p)
    seeds = json.load(open(_seeds_p, encoding='utf-8'))
    pt = [min(seeds['points'], key=lambda p: abs(float(p['ell']) - ell0))]
    seed = np.array([float(x) for x in pt[0]['a64']])
    seed, _ = fl.solve_fixed_point(seed, ell0)
    plog('=== rig2: ell0=%g w=%.3e m=%d D=%d prec=256 ===' % (ell0, w, m, D))
    out = run(ell0, w, m, D, seed)
    with open(OUTJ, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=1)
    plog('written rig2.json')


if __name__ == '__main__':
    main()
