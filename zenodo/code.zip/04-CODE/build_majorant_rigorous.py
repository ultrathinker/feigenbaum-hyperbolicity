"""build_majorant_rigorous.py — strict arb-precision version of the majorant computation.

Rigorous quantities (tail bounds, norms of M^n) are arb intervals with
upper-bound rounding.  Float midpoints that come from the float stage
(v, phi, delta, inner product) are lifted with arb("[x]") from a decimal
string, which is NOT an enclosure of the original double: the ball is
centred on the decimal value, and the double may fall just outside it.
That is deliberate and harmless here — the gate below has ~11 orders of
margin — but do not read the lift as a rigorous enclosure.
"""
# ---------------------------------------------------------------------------
# ПРОИСХОЖДЕНИЕ, А НЕ МАРШРУТ ВОСПРОИЗВЕДЕНИЯ.
# Этот скрипт показывает, как были получены точечные константы §5, но его
# входные пути указывают на рабочее дерево, в котором он собирался, а не на
# пакет: запустить его отсюда нельзя, и ни один шаг проверки его не
# вызывает.  Его результаты лежат готовыми в 03-CERTIFICATES/pointwise/.
# ---------------------------------------------------------------------------

import json, os, sys, io, time, tempfile, math
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
from flint import arb, ctx


def up_float(x):
    """Наименьший double, гарантированно НЕ МЕНЬШИЙ величины x (arb или float).

    Наименьший double, гарантированно не меньший x (см. hyp_rouche.py::up_float,
    тот же приём: float(arb) округляет к ближайшему, здесь — шаг вверх при необходимости).
    """
    v = arb(x).upper()
    f = float(v)
    if arb(f) < v:
        f = math.nextafter(f, math.inf)
    return f
ctx.prec = 512

# Дефолт '.' означал бы запись `wave6_hyperb_l3/...` ПРЯМО В
# ПАКЕТ (тот же класс, что HYP_TUBE_OUT/CERT_OUT: запуск «как есть» ломал бы
# сверку с MANIFEST.sha256). Рабочее дерево в пакет не входит, поэтому без
# явного HYP_WORKTREE скрипт работает во временном каталоге и честно
# сообщает, что входных данных там нет.
DIR = os.environ.get('HYP_WORKTREE',
                     os.path.join(tempfile.gettempdir(), 'renorm_worktree'))

# === Load M_DT_prime arb intervals ===
with open(f'{DIR}/wave5_eigen_fix/M_DT_prime_arb.json') as f:
    md = json.load(f)

N_p = md['N_p']
if N_p != 80:
    raise SystemExit('ожидалось N_p = 80, в метаданных %r' % (N_p,))

def parse_arb(s):
    s = s.strip().strip('[]')
    return arb(s)

print('Loading M_DT_prime arb intervals...')
t0 = time.time()
M_DT_prime_arb = [[parse_arb(md['M_DT_prime'][j][k]) for k in range(N_p)] for j in range(N_p)]
print(f'  Loaded in {time.time()-t0:.1f}s')

# === Load constants ===
with open(f'{DIR}/wave6_hyperb_l3/loaded_constants.json') as f:
    consts = json.load(f)

delta_str = f"[{consts['delta_val']:.15f}]"  # midpoint as arb
delta_arb = arb(delta_str)
print(f'delta = {delta_arb}')

# Inner product <phi, v> = 1.085888366021814
inner_product = arb(f"[{consts['inner_product_float']:.15f}]")
print(f'<phi, v> = {inner_product}')

# beta_81 as arb
beta_81_str = consts['beta_81_str']
beta_81 = arb(beta_81_str)
print(f'beta_81 = {beta_81}')

# eps_v / eps_phi as arb intervals (loaded directly from wave5)
with open(f'{DIR}/wave5_eigen_fix/loaded_data.json') as f:
    Lfull = json.load(f)

eps_v = arb(Lfull['eps_v_loose_str'])
print(f'eps_v = {eps_v}')

eps_phi = arb(Lfull['eps_phi_loose_str'])
print(f'eps_phi = {eps_phi}')

# L and eps_DT
with open(f'{DIR}/wave5_fixL/fixL_result.json') as f:
    fixL = json.load(f)
L_strict = arb(fixL['L_strict'])
rho_prime = arb('1e-20')
eps_DT = L_strict * arb('1.75') * rho_prime      # = L * rho_X, мажоранта ||dDT||_{X->X}
# ПОЭЛЕМЕНТНАЯ граница стоит ещё одного 1.75: |dDT_jk| <= sum_j |dDT_jk|
# = ||dDT b_k||_b <= ||dDT b_k||_X <= ||dDT||_{X->X} * ||b_k||_X <= 1.75*eps_DT
# (||v||_b <= ||v||_X, потому что базис НОРМИРОВАН: ||e_k||_X = 1).
# Депонированные сертификаты собраны БЕЗ этого множителя (с eps_DT), потому
# что скрипт не воспроизводится из пакета: его входы — несохранённое рабочее
# дерево. Здесь стоит ВЕРНЫЙ множитель, так что перепрогон даст числа чуть
# больше депонированных; расхождение оценено в статье и вердикта не меняет:
# ||M^16||_1 растёт не более чем на 5.29e-12 при пороге 0.5.
EPS_DT_ELEMENTWISE = arb('1.75')
eps_DT_el = EPS_DT_ELEMENTWISE * eps_DT
print(f'eps_DT = {eps_DT}')

# v, phi (use float midpoint, lifted to arb)
with open(f'{DIR}/wave5_eigen_fix/loaded_data.json') as f:
    L = json.load(f)

v_arb = [arb(f"[{x:.15f}]") for x in L['v_norm_first80']]
phi_arb = [arb(f"[{x:.15f}]") for x in L['phi_norm_first80']]

# v_norm_inf and v_norm_X
v_norm_inf = arb(f"[{consts['v_norm_inf']:.15f}]")  # 1.0
v_norm_X = arb(f"[{consts['v_norm_X']:.15f}]")  # 1.6946263671147053

# tail_prime k=1..81 (python indexed 0..80)
tail_prime_arb = [arb(s) for s in L['tail_prime_k']]
print(f'tail_prime count = {len(tail_prime_arb)}')

# === Deflation coefficient ===
defl_coef = delta_arb / inner_product  # exact deflation kills delta direction
print(f'\ndefl_coef = {defl_coef}')

# === Q_head = M_DT_prime - defl_coef * v outer phi ===
# Entry [j][k] for j,k = 0..79 (head)
print('\nBuilding Q_head in arb...')
t0 = time.time()
Q_head = [[arb(0)] * N_p for _ in range(N_p)]
for j in range(N_p):
    for k in range(N_p):
        Q_head[j][k] = M_DT_prime_arb[j][k] - defl_coef * v_arb[j] * phi_arb[k]
print(f'  Q_head built in {time.time()-t0:.1f}s')

# Verify Q_head v = 0 (sanity)
print('Verifying Q_head v = 0...')
Qv = [sum(Q_head[j][k] * v_arb[k] for k in range(N_p)) for j in range(N_p)]
Qv_max_abs = max(float(abs(Qv[j]).upper()) for j in range(N_p))
print(f'  ||Q_head v||_sup upper bound = {Qv_max_abs:.3e}')

# === Compute |Q_head| + eps_DT (component-wise upper bound) ===
print('\nBuilding |Q_head| + eps_DT ...')
t0 = time.time()
Q_head_abs = [[arb(0)] * N_p for _ in range(N_p)]
for j in range(N_p):
    for k in range(N_p):
        Q_head_abs[j][k] = abs(Q_head[j][k]) + eps_DT_el
print(f'  Done in {time.time()-t0:.1f}s')

# Column sums
print('Column sums of Q_head_abs ...')
col_sums_arb = [sum(Q_head_abs[j][k] for j in range(N_p)) for k in range(N_p)]
col_sums_upper = [float(c.upper()) for c in col_sums_arb]
print(f'  max col sum (upper) = {max(col_sums_upper):.6e}')
print(f'  median col sum = {np.median(col_sums_upper):.6e}')
print(f'  min col sum = {min(col_sums_upper):.6e}')

# === Tail bounds in arb ===
c_over_r = arb('0.75')
neg_c_over_r = arb('-0.75')

# h2t_k = tail_prime[k-1] + |defl_coef| * |<phi, b_k>| * eps_v + eps_DT
# |<phi, b_k>| = |phi_k| + (c/r)^k * eps_phi  (assuming phi_0 is in [-eps_phi, +eps_phi])
print('\nBuilding h2t_k ...')
h2t_k = []
for k_py in range(N_p):
    k_brief = k_py + 1  # 1..80
    inner_phi_bk = abs(phi_arb[k_py]) + c_over_r**k_brief * eps_phi
    h2t_k.append(tail_prime_arb[k_py] + abs(defl_coef) * inner_phi_bk * eps_v + eps_DT)

h2t_max = max(float(h.upper()) for h in h2t_k)
print(f'  h2t_k max upper bound = {h2t_max:.6e}')

# q_t
beta_hat_81 = beta_81 + c_over_r**81 * beta_81 + eps_DT  # overestimate
q_t = beta_hat_81 * (arb(1) + abs(defl_coef) * v_norm_inf / (delta_arb - beta_81))
print(f'  beta_hat_81 = {beta_hat_81}')
print(f'  q_t = {q_t}')
print(f'  q_t upper bound = {float(q_t.upper()):.6e}')

# === Build 81x81 majority M in arb ===
print('\nBuilding 81x81 majority matrix M...')
M = [[arb(0)] * (N_p + 1) for _ in range(N_p + 1)]

# Head block
for j in range(N_p):
    for k in range(N_p):
        M[j][k] = Q_head_abs[j][k]

# Column 80 (=N_p)
for j in range(N_p):
    M[j][N_p] = q_t

# Row 80
for k in range(N_p):
    M[N_p][k] = h2t_k[k]
M[N_p][N_p] = q_t

# Print column sums of M
print('Column sums of M:')
col_sums_M = [sum(M[j][k] for j in range(N_p + 1)) for k in range(N_p + 1)]
col_sums_M_upper = [float(c.upper()) for c in col_sums_M]
for k in range(N_p + 1):
    pass
print(f'  max = {max(col_sums_M_upper):.6e} at col {col_sums_M_upper.index(max(col_sums_M_upper))}')
print(f'  min = {min(col_sums_M_upper):.6e}')

# === Power M^n ===
print('\n=== Computing M^n (strict arb, upper bounds of col sums) ===')
norms = {}

def arb_matmul(A, B):
    """Compute A @ B in arb (strict)."""
    n = len(A)
    m = len(B[0])
    p = len(B)
    C = [[arb(0)] * m for _ in range(n)]
    for i in range(n):
        for j in range(m):
            s = arb(0)
            for l in range(p):
                s = s + A[i][l] * B[l][j]
            C[i][j] = s
    return C

def max_col_sum_upper(Mat):
    """Max of upper bounds of column sums."""
    n = len(Mat)
    m = len(Mat[0])
    best = arb(0)
    for k in range(m):
        s = arb(0)
        for j in range(n):
            s = s + abs(Mat[j][k])
        if s.upper() > best.upper():
            best = s
    return best

Mpow = M
norms[1] = max_col_sum_upper(Mpow)
print(f'||M^1||_colsum upper = {float(norms[1].upper()):.6e}')

t0_total = time.time()
for k in range(1, 7):
    n = 2**k
    t0 = time.time()
    Mpow = arb_matmul(Mpow, Mpow)
    print(f'  Mpow = Mpow @ Mpow for n={n}: {time.time()-t0:.1f}s')
    norms[n] = max_col_sum_upper(Mpow)
    print(f'||M^{n}||_colsum upper = {float(norms[n].upper()):.6e}')

print(f'\nTotal power time: {time.time()-t0_total:.1f}s')

# === Gate check ===
print('\n=== Gate check (||M^n||_colsum upper < 0.5 for n <= 16) ===')
gate_pass = False
for n in [1, 2, 4, 8, 16]:
    val = up_float(norms[n])
    if val < 0.5:
        print(f'  PASS: n={n}, ||M^n||_colsum upper = {val:.6e} < 0.5')
        gate_pass = True
    else:
        print(f'  fail: n={n}, ||M^n||_colsum upper = {val:.6e} >= 0.5')

# === Midpoint spectrum (NOT RIGOROUS, for sanity) ===
eigvals_Q = np.linalg.eigvals(np.array([[float(Q_head[j][k].upper()) for k in range(N_p)] for j in range(N_p)]))  # use upper bounds of arb
mods_Q = np.abs(eigvals_Q)
idx_Q = np.argsort(mods_Q)[::-1]
print(f'\n=== Midpoint spectrum of Q_head (using arb upper bounds) ===')
print(f'  Spectral radius: {mods_Q.max():.6e}')
for i in idx_Q[:5]:
    print(f'    eigval = {eigvals_Q[i]:.6f}, |.| = {mods_Q[i]:.6f}')

# Save results
result = {
    'oid': 'hyp5w6l',
    'task': 'rigorous_majority_norms',
    'framework': 'python-flint arb prec=512',
    'N_p': N_p,
    'defl_coef_interpretation': 'delta / <phi, v> (ip = inner product, exact spectral deflation)',
    'defl_coef_value_str': str(defl_coef),
    'eps_DT_str': str(eps_DT),
    'eps_v_str': str(eps_v),
    'eps_phi_str': str(eps_phi),
    'q_t_str': str(q_t),
    'beta_81_str': str(beta_81),
    'beta_hat_81_str': str(beta_hat_81),
    'L_strict_str': str(L_strict),
    'rho_prime_str': str(rho_prime),
    'delta_str': str(delta_arb),
    'inner_product_str': str(inner_product),
    'h2t_k_max_str': str(max(h2t_k, key=lambda x: x.upper())),
    'norms_upper_bounds': {str(n): str(norms[n]) for n in sorted(norms.keys())},
    'gate_pass_n_le_16': gate_pass,
    'gate_threshold': 0.5,
    'midpoint_spectral_radius_Q_head_upper': float(mods_Q.max()),
    'note': 'All norms are STRICT UPPER BOUNDS via arb. The matrix M is nonneg; col sums read upper bounds.'
}

with open(f'{DIR}/wave6_hyperb_l3/norms_q_n_rigorous.json', 'w') as f:
    json.dump(result, f, indent=2)

print('\nSaved norms_q_n_rigorous.json')
print(f'\nFINAL VERDICT: gate_pass = {gate_pass}')
# Гейт считался строго, но скрипт завершался нулём при любом
# исходе — то есть сторож не мог покраснеть для автоматизации, а поля
# gate_pass_n_le_16 не читает ни один другой скрипт пакета. Теперь провал
# гейта = ненулевой код возврата.
if not gate_pass:
    print('*** FAIL: гейт ||M^n||_colsum < 0.5 при n <= 16 НЕ выполнен')
    sys.exit(1)
