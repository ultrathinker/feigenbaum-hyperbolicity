# -*- coding: utf-8 -*-
"""
tube_run.py — трубка гиперболичности на [2,4] цепочкой боксов Руше.

Логика цепочки (это и делает утверждение строгим без проверки спектра в
каждом боксе):

  * в точке ℓ=3 сертифицировано точечно (§4.7, §5.2), что у DT ровно одно собственное
    значение вне единичного круга;
  * для бокса с центром ℓ₀ теорема Руше переносит это число с центра на
    ВЕСЬ бокс, если R(ℓ₀)·‖Δ(бокс)‖ < 1;
  * соседние боксы ПЕРЕСЕКАЮТСЯ (минимальное перекрытие 3.3 % ширины), и
    на общем куске обе оценки Руше верны одновременно — значит счёт
    «снаружи ровно одно» переносится дальше по цепочке от якоря ℓ=3 в обе
    стороны.

    Здесь стоял критерий «шаг меньше
    ширины, поэтому центр соседа лежит внутри предыдущего бокса».  Он
    неверен дважды: как следование (шаг < w этого не влечёт) и по факту
    (центр соседа вне бокса в 693 парах из 705).  Это ископаемое от
    отброшенного критерия — статья числит его дефектом №4 в §4.9 и там же
    говорит, что достаточно пересечения.  Ни один гейт по нему не
    считался, так что числа не менялись; менялось только то, что докстринг
    объяснял читателю неверно.

Запуск полосы:  python tube_run.py <полоса> <всего_полос> <plan-файл>
Формат плана:   <тег> <ell0> <w> <N_узлов> <K>
"""
import os, sys, time, json, tempfile
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import hyp_rouche as hr
from flint import arb

# (тот же класс, что hyp_rouche.py -> HYP_LOG, layer/*).  Дефолт НЕ
# ведёт внутрь пакета: запуск «как есть» дописывал файлы в пакет и ломал
# сверку с MANIFEST.sha256.  Пакет обязан оставаться пригодным только на
# чтение; чтобы ПЕРЕсобрать артефакты, CERT_OUT / GLUE_OUT /
# HYP_TUBE_OUT выставляются явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('HYP_TUBE_OUT',
                     os.path.join(tempfile.gettempdir(), 'renorm_tube'))
os.makedirs(OUT, exist_ok=True)


def run_box(tag, ell0, w, N, K):
    t0 = time.time()
    rec = {'tag': tag, 'ell0': ell0, 'w': w, 'N': N, 'K': K,
           'lo': ell0 - w / 2, 'hi': ell0 + w / 2}
    try:
        # span: ветка обязана накрывать ВЕСЬ бокс трубки, иначе член `extra`
        # на выступающем куске ничем не обоснован (см. _containment.py).
        # SPAN-CLIP: вместимость требуется только на той части бокса
        # трубки, которая лежит в [2,4] — именно на ней делается утверждение.
        # Без клипа края отрезка отсекаются чисто арифметически: lo = ell0−w/2
        # во float даёт 1.9999999999999998, на два ulp ниже левого края бокса
        # существования, и вместимость отвергается при том, что на всём [2,4]
        # она есть.  Сужение бокса консервативно: ‖Δ‖ считается супремумом,
        # на меньшем множестве он не больше.
        span_lo = max(rec['lo'], 2.0)
        span_hi = min(rec['hi'], 4.0)
        c_a, m, e0b, wb, fname = hr.load_box(
            ell0, 0.0, span=(span_lo, span_hi))
        rec['branch'] = fname
        x0 = 2.0 * (ell0 - e0b) / wb
        P0 = hr.rl.P_at(c_a, m, arb('%.17e' % x0))
        pkg0 = hr.tl.build_pkg_fast(P0, arb('%.17e' % ell0))
        DT0 = hr.dt_from_pkg(pkg0)

        mid = np.array([[float(DT0[j][k]) for k in range(hr.NP)]
                        for j in range(hr.NP)])
        ev = np.linalg.eigvals(mid)
        ev = ev[np.argsort(-np.abs(ev))]
        rec['delta_mid'] = float(ev[0].real)
        rec['lam2_mid'] = float(abs(ev[1]))
        rec['n_out_mid_float'] = int((np.abs(ev) > 1).sum())

        R, th = hr.rigorous_R(DT0, N)
        rec['R'] = R
        rec['R_worst_theta'] = th
        d = hr.rigorous_delta(c_a, m, e0b, wb, ell0, w, DT0, K)
        rec['delta_norm'] = float(d)
        # произведение тоже округляем ВВЕРХ: умножение во float
        # округляет к ближайшему и может опустить его ниже истинного
        rec['prod'] = hr.up_float(arb(R) * d)
        rec['pass'] = bool(rec['prod'] < 1.0)
    except Exception as e:
        rec['pass'] = False
        rec['error'] = '%s: %s' % (type(e).__name__, str(e)[:200])
    rec['wall_s'] = round(time.time() - t0, 1)
    with open(os.path.join(OUT, 'box_%s.json' % tag), 'w') as f:
        json.dump(rec, f, indent=1)
    print('BOX %-8s ell0=%.5f w=%.4f -> %s  R=%.4f ||D||=%.4e prod=%.4f [%.0fs]'
          % (tag, ell0, w, 'PASS' if rec.get('pass') else 'FAIL',
             rec.get('R', float('nan')), rec.get('delta_norm', float('nan')),
             rec.get('prod', float('nan')), rec['wall_s']), flush=True)
    return rec


def main():
    if len(sys.argv) < 3:
        # Аргумент — ПОЛОСА плана, а не бокс: скрипт берёт из плана каждую
        # nlanes-ю строку, начиная с lane-й. Без этой калитки запуск без
        # аргументов падал голым IndexError.
        raise SystemExit(
            'Usage: python tube_run.py <полоса> <всего-полос> [файл-плана]\n'
            '  считаются строки плана с номерами lane, lane+nlanes, ...\n'
            '  один бокс: положите его строку в свой файл плана и запустите\n'
            '  python tube_run.py 0 1 <свой-план>\n'
            '  план по умолчанию — 04-CODE/tube_plan.txt')
    lane = int(sys.argv[1])
    nlanes = int(sys.argv[2])
    # nlanes<=0 делит на ноль ниже; lane вне [0,nlanes) не совпадёт ни с
    # одним `i % nlanes` НИ РАЗУ — скрипт тихо отработает "полоса N
    # готова", не обработав ни одного бокса.
    if nlanes < 1:
        raise SystemExit('nlanes должен быть >= 1 (получено %d)' % nlanes)
    if not (0 <= lane < nlanes):
        raise SystemExit('lane должен быть в [0, nlanes) = [0, %d) '
                         '(получено %d)' % (nlanes, lane))
    plan = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, 'tube_plan.txt')
    i = 0
    for lineno, line in enumerate(open(plan, encoding='utf-8'), 1):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        fields = line.split()
        if len(fields) != 5:
            raise SystemExit('%s:%d — ожидалось 5 полей (tag e0 w N K), '
                             'получено %d: %r'
                             % (plan, lineno, len(fields), line))
        tag, e0, w, N, K = fields
        if i % nlanes == lane:
            run_box(tag, float(e0), float(w), int(N), int(K))
        i += 1
    print('=== полоса %d готова ===' % lane, flush=True)


if __name__ == '__main__':
    main()
