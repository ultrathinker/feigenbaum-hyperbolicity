# -*- coding: utf-8 -*-
"""layer_lemma_u.py — лемма U на мономиальном базисе, без переразложения
вокруг интервального центра c′.

U(t) = P(t·A) считается схемой Хорнера прямо на исходных мономиальных
коэффициентах P — так же, как margin_W в сертификатах I1/I2.
Переразложение G_c = P(c′ + (t−c′)) вокруг ИНТЕРВАЛЬНОГО c′ (пакетная
tube_lib.verify_lemma_U → lemma_domains.verify_lemma_1) упирается в
проблему зависимости интервалов: коэффициенты переразложения и точка
вычисления зависят от одного и того же c′, а arb трактует их как
независимые, что удваивает ширину.  Прямая схема этого не делает и
держит ячейку примерно в 6.7 раза шире (§10.6).

Возвращает (dict с margin_a, margin_c, U_min, ReU_min_r, ReU_min_R,
nonzero_ok; OK).
"""
from flint import arb, acb


def lemma_U_direct(Pint, ell, A, cp, rp, R, M_arcs, horner, my_arc):
    """Возвращает (dict как у tl.verify_lemma_U, OK)."""
    one_minus = A - arb(1)
    max_tc = abs(cp) * abs(one_minus) + rp * abs(A)
    margin_a = rp - max_tc

    arc_w = 2 * arb.pi() / M_arcs

    Wc_max = arb(0)
    U_min = None
    ReU_min_r = None
    for i in range(M_arcs):
        th_lo = arb(i) * arc_w - arc_w / 2
        th_hi = arb(i) * arc_w + arc_w / 2
        z = my_arc(cp, rp, th_lo, th_hi)
        z_alpha = z * acb(A)
        U = horner(Pint, z_alpha)
        re_lo = U.real.lower()
        ReU_min_r = re_lo if ReU_min_r is None else min(ReU_min_r, re_lo)
        u_lo = U.abs_lower()
        U_min = u_lo if U_min is None else min(U_min, u_lo)
        W = U ** ell
        wc = (W - acb(cp)).abs_upper()
        if wc > Wc_max:
            Wc_max = wc
    margin_c = rp - Wc_max

    ReU_min_R = None
    for i in range(M_arcs):
        th_lo = arb(i) * arc_w - arc_w / 2
        th_hi = arb(i) * arc_w + arc_w / 2
        z = my_arc(cp, R, th_lo, th_hi)
        z_alpha = z * acb(A)
        U = horner(Pint, z_alpha)
        re_lo = U.real.lower()
        ReU_min_R = re_lo if ReU_min_R is None else min(ReU_min_R, re_lo)

    nonzero_ok = bool(float(ReU_min_r) > 0 and float(ReU_min_R) > 0)
    res = {
        'margin_a': margin_a, 'margin_c': margin_c, 'U_min': U_min,
        'ReU_min_r': ReU_min_r, 'ReU_min_R': ReU_min_R, 'nonzero_ok': nonzero_ok,
    }
    OK = (float(margin_a.lower()) > 0 and float(margin_c.lower()) > 0 and
          nonzero_ok and (U_min is not None and float(U_min) >= 0.5))
    return res, OK
