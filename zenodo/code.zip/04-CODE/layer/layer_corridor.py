# -*- coding: utf-8 -*-
"""layer_corridor.py — связная цепочка сертифицированных ячеек вместо
разрозненных точек (§10.13).

Строит L-образный коридор из 7 перекрывающихся ячеек, соединяющий базовый
слой (0.60, 0.80) с самым дальним из предъявленных, (0.55, 0.90):
  сначала вертикально (c = 0.60 фиксировано, r: 0.80 → 0.90),
  затем горизонтально (r = 0.90 фиксировано, c: 0.60 → 0.55).
Путь нарочно проходит рядом с уже предъявленными (0.60, 0.85) и
(0.60, 0.90) — коридор их не обходит, а соединяет.  Каждая ячейка —
полный прогон run_cell по всем 46 боксам.  Пишет corridor.log построчно,
по ячейке, не дожидаясь конца цепочки.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3

LOG = os.path.join(OUT, 'corridor.log')
OUT = os.path.join(OUT, 'corridor.json')

HW_C = 0.012   # полуширина по c для вертикального сегмента
HW_R = 0.015   # полуширина по r (используется в обоих сегментах)

# Вертикальный сегмент: c=0.60 фикс (полуширина HW_C), r-центры от 0.815 до 0.895
vert_centers_r = [0.815, 0.835, 0.855, 0.875, 0.895]
vert_cells = [(0.60 - HW_C, 0.60 + HW_C, rc - HW_R, rc + HW_R) for rc in vert_centers_r]

# Горизонтальный сегмент: r=0.90 фикс (полуширина HW_R), c-центры от 0.585 до 0.562
# (шире полуширина по c: 0.014, чтобы гарантированно накрыть конечную точку
# c=0.55 с запасом, а не впритык)
HW_C2 = 0.014
horiz_centers_c = [0.585, 0.562]
horiz_cells = [(cc - HW_C2, cc + HW_C2, 0.90 - HW_R, 0.90 + HW_R) for cc in horiz_centers_c]

CELLS = vert_cells + horiz_cells

results = []
t0 = time.time()
with open(LOG, 'a', encoding='utf-8') as log:
    log.write('=== driver_corridor %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
    log.write('путь: (0.60,0.80) -> (0.60,0.90) -> (0.55,0.90), %d ячеек\n' % len(CELLS))
    log.flush()
    for i, (c_lo, c_hi, r_lo, r_hi) in enumerate(CELLS):
        res = cf3.run_cell(c_lo, c_hi, r_lo, r_hi, log)
        res['idx'] = i
        results.append(res)
        with open(OUT, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=1)
    all_pass = all(r['cell_pass'] for r in results)
    worst = min((r['worst_margin'] for r in results if r['worst_margin'] is not None), default=None)
    summary = ('ИТОГО коридор: %d/%d ячеек PASS, худшая маржа=%s, %.0fs\n'
               % (sum(1 for r in results if r['cell_pass']), len(results),
                  ('%.3e' % worst) if worst is not None else 'n/a', time.time() - t0))
    log.write(summary)
    log.flush()
    print(summary, end='')
