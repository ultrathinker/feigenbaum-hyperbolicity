# -*- coding: utf-8 -*-
"""layer_cells_hw.py — таблица полуширин ячейки 𝔔 вокруг базового слоя.

Прогоняет ячейки [c₀−h, c₀+h] × [r₀−h, r₀+h] по возрастанию h и
останавливается на первой провалившейся — так находится граница
континуального охвата (§10.6).  Пишет cells3_hw.json и дописывает
cells3.log в $CERT_OUT.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3

C, R = 0.6, 0.8
HALFS = [2e-2, 3e-2, 5e-2, 7e-2, 1e-1, 1.2e-1, 1.5e-1, 1.8e-1]

out = []
log = open(os.path.join(OUT, 'cells3.log'), 'a', encoding='utf-8')
log.write('\n=== driver_hw3 (без bases_q) полная эскалация %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
for h in HALFS:
    t0 = time.time()
    res = cf3.run_cell(C - h, C + h, R - h, R + h, log)
    res['half_width'] = h
    out.append(res)
    with open(os.path.join(OUT, 'cells3_hw.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    if not res['cell_pass']:
        line = 'ГРАНИЦА: половина %g первая провалившаяся (%.0fs)' % (h, time.time() - t0)
        print(line, flush=True)
        log.write(line + '\n')
        log.flush()
        break
log.close()
