# -*- coding: utf-8 -*-
"""layer_recheck_all.py — полная перепроверка всех 644 точечных сертификатов
(14 слоёв × 46 боксов) сертификатором layer_cert, с K-эскалацией.

Пишет full_recheck_644.log и full_recheck_644.json в $CERT_OUT
(по умолчанию 03-CERTIFICATES/layer).  Ожидаемое: 644/644 прошли,
худшая маржа 1.10·10⁻³ на паре (0.70, 0.75) / g00 (§10.6, §10.9, §10.11).
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3

LAYERS = [
    (0.55,0.80), (0.70,0.80), (0.60,0.70), (0.60,0.90),
    (0.55,0.70), (0.55,0.90), (0.70,0.75), (0.65,0.85),
    (0.575,0.80), (0.625,0.80), (0.65,0.80), (0.60,0.75),
    (0.60,0.85), (0.65,0.75),
]

log = open(os.path.join(OUT, 'full_recheck_644.log'), 'a', encoding='utf-8')
log.write('\n=== full_recheck_644 %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
out = {}
n_total = 0
n_pass = 0
worst_margin = None
worst_key = None
for c, r in LAYERS:
    key = '(%.4g,%.4g)' % (c, r)
    cp, rp = cf3.set_cell(c, c, r, r)
    layer_res = {}
    for tag in cf3.BOX_TAGS:
        t0 = time.time()
        res = cf3.one_box(tag, cp, rp)
        n_total += 1
        # Кроме min_margin (минимума по ШЕСТИ маржам) пишем и
        # минимумы Re U / |U|.  Их нет в min_margin по построению, а §10.7
        # переносит Re U > 0 с P на G* неравенством `min Re U_P - ΔU > 0`,
        # которому нужен ЧИСЛОВОЙ минимум: до круга 66 это несущее число
        # нельзя было проверить по отгруженному пакету ни для одной из 644 пар.
        rec = {'pass': res['pass'], 'K': res.get('K'),
               'min_margin': res.get('min_margin'),
               'failed_gate': res.get('failed_gate')}
        _w = res.get('worst') or {}
        for _f in ('D_U_min', 'D_ReU_r_val', 'I1_ReU', 'I2_ReU', 'D_ReU_R'):
            if _f in _w:
                rec[_f] = _w[_f]
        layer_res[tag] = rec
        if res['pass']:
            n_pass += 1
            mm = res['min_margin']
            if mm is not None and (worst_margin is None or mm < worst_margin):
                worst_margin, worst_key = mm, (key, tag)
        line = 'point %-14s %-8s pass=%s K=%s margin=%s gate=%s (%.1fs)' % (
            key, tag, res['pass'], res.get('K'),
            ('%.3e' % res['min_margin']) if res.get('min_margin') is not None else 'n/a',
            res.get('failed_gate'), time.time()-t0)
        print(line, flush=True)
        log.write(line + '\n'); log.flush()
    out[key] = layer_res
    with open(os.path.join(OUT, 'full_recheck_644.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=1, ensure_ascii=False)

summary = 'ИТОГО: %d/%d прошли; худшая маржа %s @ %s' % (n_pass, n_total, worst_margin, worst_key)
print(summary, flush=True)
log.write(summary + '\n')
log.close()
