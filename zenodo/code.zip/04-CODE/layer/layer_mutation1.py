# -*- coding: utf-8 -*-
"""layer_mutation1.py — мутационный тест: сертификатор не «резиновый штамп».

Берётся заведомо ПРОХОДЯЩАЯ пара (базовый слой, g00), схема Хорнера
искусственно портится (сдвиг Re U на −10, имитация «задели разрез
(−∞,0]»), и проверяется, что one_box действительно репортует провал, а не
продолжает молча.  Проверяются оба направления:
  (A) неиспорченный horner  → pass=True,  D_cut_ok=True;
  (B) мутант                → pass=False, gate='lemma_U', D_cut_ok=False.
Если (B) не проваливается — гейт не проверяет то, что должен.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3
from flint import acb

LAYER = (0.60, 0.80)   # база - заведомо должна проходить
BOX = 'g00'            # g00 при базовом слое проходит с большим запасом,
                        # K=1 (см. full_recheck_644.log) - в отличие от
                        # gtop/g43, которым на некоторых слоях нужен K>8

cp, rp = cf3.set_cell(LAYER[0], LAYER[0], LAYER[1], LAYER[1])
baseline = cf3.one_box(BOX, cp, rp)
print('(A) baseline: pass=%s gate=%s D_cut_ok=%s margin=%s' % (
    baseline['pass'], baseline.get('failed_gate'),
    baseline['worst'].get('D_cut_ok'), baseline.get('min_margin')))
# Голые assert вырезаются при запуске `python -O`, и единственная
# в пакете проверка «сертификатор не резиновый штамп» сама становится штампом.
# Поэтому проверки идут через check(), который не зависит от флага -O.
_FAILS = []


def check(cond, msg):
    if not cond:
        _FAILS.append(msg)
        print('*** ПРОВАЛ: ' + msg)
    return bool(cond)


def finish():
    import sys as _s
    if _FAILS:
        print('МУТАЦИОННЫЙ ТЕСТ: ПРОВАЛ (%d)' % len(_FAILS))
        _s.exit(1)

check(baseline['pass'] is True, 'baseline должен проходить - тест сломан ДО мутации')
check(baseline['worst'].get('D_cut_ok') is True, 'D_cut_ok должен быть True на чистом прогоне')

_real_horner = cf3.horner
def poisoned_horner(P, z):
    v = _real_horner(P, z)
    # Сдвигаем Re часть в отрицательную область (имитация "задели разрез")
    return acb(v.real - 10, v.imag)

cf3.horner = poisoned_horner
try:
    mutant = cf3.one_box(BOX, cp, rp)
finally:
    cf3.horner = _real_horner  # обязательно вернуть как было

print('(B) mutant:   pass=%s gate=%s D_cut_ok=%s' % (
    mutant['pass'], mutant.get('failed_gate'), mutant['worst'].get('D_cut_ok')))
check(mutant['pass'] is False, 'МУТАЦИЯ НЕ ПОЙМАНА: гейт пропустил испорченный Re U!')
check(mutant.get('failed_gate') == 'lemma_U', 'провал не там, где ожидалось')
check(mutant['worst'].get('D_cut_ok') is False, 'D_cut_ok не отследил порчу')

# Контроль, что второй (незасорённый) прогон снова проходит - horner
# действительно восстановлен, мутация не "утекла" в глобальное состояние.
control = cf3.one_box(BOX, cp, rp)
print('(C) control (после восстановления horner): pass=%s' % control['pass'])
check(control['pass'] is True, 'horner не восстановлен корректно после теста')

print('МУТАЦИОННЫЙ ТЕСТ: OK - гейт ловит испорченный разрез, не ловит зря на чистом входе.')

finish()
