# -*- coding: utf-8 -*-
"""layer_cells_hist_merge.py — свести частичные прогоны layer_cells_hist.py.

`layer_cells_hist.py` считает один режим на процесс (режим читается при
импорте `layer_cert`) и пишет `cells3_hist_<метка>.json`. Этот скрипт
собирает их в один артефакт `cells3_hist.json`, упорядоченный так же, как
верхняя таблица §10.6: сначала строка со старой (движковой) леммой U, затем
мономиальная лемма по возрастанию полуширины. Частичные файлы удаляются.

Запуск:  CERT_OUT=<куда> python layer_cells_hist_merge.py
"""
import os, sys, json, glob, tempfile

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))

parts = sorted(glob.glob(os.path.join(OUT, 'cells3_hist_*.json')))
if not parts:
    print('нечего сводить: нет cells3_hist_*.json в ' + OUT)
    sys.exit(1)

rows = []
for f in parts:
    rows.extend(json.load(open(f, encoding='utf-8')))
# старая лемма U первой, дальше по возрастанию полуширины
rows.sort(key=lambda r: (not r.get('pkg_lemma'), r['half_width']))

logs = []
for f in sorted(glob.glob(os.path.join(OUT, 'cells3_hist_*.log'))):
    logs.append('--- ' + os.path.basename(f) + ' ---')
    logs.append(open(f, encoding='utf-8').read().rstrip())

with open(os.path.join(OUT, 'cells3_hist.json'), 'w', encoding='utf-8') as f:
    json.dump(rows, f, indent=2, ensure_ascii=False)
with open(os.path.join(OUT, 'cells3_hist.log'), 'w', encoding='utf-8') as f:
    f.write(chr(10).join(logs) + chr(10))

for f in parts + glob.glob(os.path.join(OUT, 'cells3_hist_*.log')):
    if os.path.basename(f) not in ('cells3_hist.json', 'cells3_hist.log'):
        os.remove(f)

print('сведено строк: %d -> cells3_hist.json' % len(rows))
for r in rows:
    print('  %-14s h=%-7g pass=%2d/46 worst=%.6e (%s) q_max=%.6f'
          % (r['mode'], r['half_width'], r['n_pass'], r['worst_margin'],
             r['worst_box'], r['q_max']))
