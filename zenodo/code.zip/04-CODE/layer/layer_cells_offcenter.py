# -*- coding: utf-8 -*-
"""layer_cells_offcenter.py — внецентренная ячейка c ∈ [0.55, 0.625],
r ∈ [0.70, 0.80] (центр (0.5875, 0.75), вне 𝔔).

Показывает, что смещение центра к верхнему краю ℓ→4 исчерпывает
геометрический запас (D1/D2) быстрее, чем простое расширение полуширины
вокруг базового слоя: ячейка не входит в 𝔔 целиком, и падают именно
margin_a/margin_c, а не снятая калитка q (§10.6).  Пишет
cells3_offcenter.json в $CERT_OUT.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3
log = open(os.path.join(OUT, 'cells3.log'), 'a', encoding='utf-8')
log.write('\n=== offcenter3 (re-check c in [0.55,0.625], r in [0.70,0.80]) %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
res = cf3.run_cell(0.55, 0.625, 0.70, 0.80, log)
with open(os.path.join(OUT, 'cells3_offcenter.json'), 'w', encoding='utf-8') as f:
    json.dump(res, f, indent=2, ensure_ascii=False)
log.close()
