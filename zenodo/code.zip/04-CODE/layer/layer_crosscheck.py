# -*- coding: utf-8 -*-
"""layer_crosscheck.py — сверка марж I1/I2 двумя разными реализациями.

Основной сертификатор (`layer_cert.one_box`) считает маржи переноса I1/I2
внутри общего цикла по гейтам, рядом с леммой U и диагностикой q. Здесь те же
четыре величины (`I1_margin_s`, `I1_margin_W`, `I2_margin_s`, `I2_margin_W`)
пересчитываются отдельно написанным кодом: свой цикл по дугам, свой обход
подынтервалов `ℓ`-бокса, без обращения к `layer_lemma_u` и без общей
структуры `one_box`.

**Что здесь ДРУГАЯ арифметика, а не только другой обход.** Ровно одно место:
  * полином считается прямым суммированием степеней (`powsum`), а не схемой
    Горнера сертификатора.

Второе разведение задумывалось — `A = (−1/G(1))^{−ℓ}` через
`exp(−ℓ·log(−1/G(1)))` (`alpha_pow`), а не оператором степени, — но
разведением НЕ ЯВЛЯЕТСЯ: в `arb` оператор степени при неточном показателе
реализован ровно этой композицией, а `ℓ` здесь — интервал; оба значения `A`
совпадают бит в бит и по середине, и по радиусу (это проверяет
`tests/_numbers_check.py`, пункт I12c).
Следствие: маржи `_s`, куда полином не входит, второй реализацией НЕ
ПОКРЫТЫ, и их `worst_rel_s = 0` — тождество, а не измерение. Настоящую
проверку несут только маржи `_W`.

**Чего эта проверка НЕ даёт.** Обе реализации опираются на одну и ту же
интервальную библиотеку (`python-flint`/`arb`), один и тот же
`rig_lib.P_at_interval` и — это важно — на ДОСЛОВНО ту же функцию заключения
дуги в `acb`-бокс (`my_arc` скопирована из `layer_cert` без изменений).
Заключение дуги здесь поэтому не проверяется вовсе. Независимость от самой
библиотеки остаётся открытым пунктом (§10.9).

Пишет crosscheck.log и crosscheck.json в $CERT_OUT.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])

import numpy as np
import rig_lib as rl
from flint import arb, acb, ctx
import layer_cert as lc

ctx.prec = 256
BR = os.environ['HYP_BRANCHES']
C0, R0 = arb(3) / arb(5), arb(4) / arb(5)
M_ARCS = 128

# Пары (слой, бокс), на которых сверка проводится: по три бокса на двух
# «дальних» слоях семейства.  Подразбиения среди них нет — все шесть идут
# при K=1 (см. crosscheck.log), так что случай K>1 этой сверкой не
# покрыт.
PAIRS = [
    ((0.55, 0.80), 'g00'), ((0.55, 0.80), 'g21'), ((0.55, 0.80), 'g42'),
    ((0.70, 0.80), 'g00'), ((0.70, 0.80), 'g21'), ((0.70, 0.80), 'g42'),
]
KEYS = ('I1_margin_s', 'I1_margin_W', 'I2_margin_s', 'I2_margin_W')


def my_arc(c, r, th_lo, th_hi):
    th = th_lo.union(th_hi)
    co, si = th.cos(), th.sin()
    return acb((c + r * co.lower()).union(c + r * co.upper()),
               (r * si.lower()).union(r * si.upper()))


def powsum(P, z):
    """Прямое суммирование степеней вместо схемы Горнера сертификатора.

    Математически то же самое, арифметически — другой путь: у Горнера
    (len(P)-1) умножений на аккумулятор, здесь столько же умножений, но
    накапливается отдельная степень z^k, и ошибки складываются иначе.

    Здесь стояло «прямое суммирование ЗАВЕДОМО не тоньше Горнера,
    поэтому расхождение систематически в одну сторону».  Это неверно и как
    следование (деревья зависимостей интервалов разные, ни одно не
    мажорирует другое), и по факту: на паре (0.55,0.80)/g00 alt даёт маржу
    БОЛЬШЕ сертификатора.  Направление теперь не постулируется, а
    считается ниже и пишется в протокол.
    """
    v = acb(0)
    zk = acb(1)
    for k in range(len(P)):
        v = v + acb(P[k]) * zk
        zk = zk * z
    return v


def alpha_pow(g1, ell):
    """A = (-1/g1)^(-ell) через exp(-ell*log(...)) вместо оператора **.

    ВНИМАНИЕ: разведением это НЕ является.  В arb оператор
    степени при НЕТОЧНОМ показателе реализован ровно как exp(y*log x), а
    здесь ell — интервал.  Оба пути дают A, совпадающее бит в бит и по mid,
    и по rad (проверяет tests/_numbers_check.py, пункт I12c).  Поэтому
    маржи I1_margin_s / I2_margin_s, куда полином не входит, второй
    реализацией НЕ ПОКРЫТЫ: их worst_rel_s = 0 — тождество, а не
    измерение.  Реальную проверку несут только маржи _W (Горнер против
    powsum).  Расходятся `**` и exp(log) лишь при точном показателе
    (целом или двоично-рациональном), которого здесь нет.
    """
    base = -arb(1) / g1
    return (base.log() * (-ell)).exp()


def margins_alt(tag, layer_c, layer_r, K):
    """Вторая реализация: только маржи I1/I2, свой обход."""
    z = np.load(os.path.join(BR, 'branch_%s.npz' % tag))
    c_a, m = z['c_a'], int(z['m'][0])
    e0, w = float(z['ell0'][0]), float(z['w'][0])
    cp, rp = arb('%.17e' % layer_c), arb('%.17e' % layer_r)
    worst = dict((k, None) for k in KEYS)

    def upd(k, v):
        if worst[k] is None or v < worst[k]:
            worst[k] = v

    arc_w = 2 * arb.pi() / M_ARCS
    lo = e0 - w / 2.0
    for s in range(K):
        hi = lo + w / K
        xlo, xhi = 2.0 * (lo - e0) / w, 2.0 * (hi - e0) / w
        Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
        ell = arb('%.17e' % lo).union(arb('%.17e' % hi))
        g1 = arb(0)
        for k in range(len(Pint)):
            g1 = g1 + Pint[k]
        A = alpha_pow(g1, ell)
        upd('I1_margin_s', float((R0 - (abs(cp * A - C0) + rp * abs(A))).lower()))
        upd('I2_margin_s', float((rp - (abs(C0 * A - cp) + R0 * abs(A))).lower()))
        for name, cc, rr, ct, rt in (('I1', cp, rp, C0, R0),
                                     ('I2', C0, R0, cp, rp)):
            maxW = arb(0)
            for i in range(M_ARCS):
                zz = my_arc(cc, rr, arb(i) * arc_w - arc_w / 2,
                            arb(i) * arc_w + arc_w / 2)
                U = powsum(Pint, zz * acb(A))
                u = (U ** ell - acb(ct)).abs_upper()
                if u > maxW:
                    maxW = u
            upd(name + '_margin_W', float((rt - maxW).lower()))
        lo = hi
    return worst


log = open(os.path.join(OUT, 'crosscheck.log'), 'w', encoding='utf-8')


def say(line):
    print(line, flush=True)
    log.write(line + chr(10))
    log.flush()


say('=== сверка марж I1/I2 двумя реализациями, %d пар ===' % len(PAIRS))
say('ВНИМАНИЕ: обе реализации на одной библиотеке (python-flint/arb) и на')
say('ДОСЛОВНО одной функции заключения дуги my_arc — она не проверяется.')
say('Разведена ОДНА вещь: оценка полинома (powsum против Горнера).')
say('A (exp/log против **) разведением НЕ является: в arb это одно и то '
    'же при неточном показателе, поэтому маржи _s не покрыты.')
report = []
worst_rel = 0.0
worst_s = 0.0
worst_w = 0.0
t0 = time.time()
for (lc_c, lc_r), tag in PAIRS:
    cp, rp = lc.set_cell(lc_c, lc_c, lc_r, lc_r)
    base = lc.one_box(tag, cp, rp)
    K = base.get('K', 1)
    alt = margins_alt(tag, lc_c, lc_r, K)
    say('--- слой (%.2f,%.2f), бокс %s, K=%d' % (lc_c, lc_r, tag, K))
    for k in KEYS:
        a = base['worst'].get(k)
        b = alt.get(k)
        if a is None or b is None:
            say('    %-13s одна из реализаций не дала значения' % k)
            continue
        rel = abs(a - b) / max(abs(a), 1e-300)
        worst_rel = max(worst_rel, rel)
        if k.endswith('_s'):
            worst_s = max(worst_s, rel)
        else:
            worst_w = max(worst_w, rel)
        say('    %-13s cert=%.9f  alt=%.9f  отн.=%.2e  %s'
            % (k, a, b, rel, 'ok' if rel < 1e-2 else 'РАСХОЖДЕНИЕ'))
        report.append({'layer': [lc_c, lc_r], 'box': tag, 'key': k,
                       'cert': a, 'alt': b, 'rel': rel})

say('')
# Порог. Проверяется ВЕЛИЧИНА расхождения, не его знак: наблюдаемое около
# 4·10⁻³, порог 10⁻² выше наблюдаемого меньше чем на порядок и на два
# порядка ниже расхождения, которое означало бы настоящую ошибку (там
# разъехались бы сами величины, а не их консервативность).  Знак
# считается отдельно и только сообщается — см. finer/coarser ниже.
THRESH = 1e-2
say('пар проверено: %d, худшее относительное расхождение: %.3e (%.0fс)'
    % (len(PAIRS), worst_rel, time.time() - t0))
say('  по маржам _s (полином не участвует): %.3e  '
    '[ТОЖДЕСТВО, не измерение: A у обеих сторон один и тот же, '
    'см. докстринг alpha_pow]' % worst_s)
_wr = [r for r in report if r['key'].endswith('_W')]
_finer = [r for r in _wr if r['alt'] > r['cert']]
say('  по маржам _W (полином участвует):    %.3e' % worst_w)
say('  из них alt консервативнее сертификатора: %d из %d; тоньше: %d%s'
    % (len(_wr) - len(_finer), len(_wr), len(_finer),
       (' (' + ', '.join('%s/%s' % (r['box'], r['key']) for r in _finer) + ')')
       if _finer else ''))
ok = worst_rel < THRESH
say('ИТОГ: %s' % ('согласовано (порог %.0e)' % THRESH if ok
                  else '*** РАСХОЖДЕНИЕ ВЫШЕ ПОРОГА %.0e ***' % THRESH))
with open(os.path.join(OUT, 'crosscheck.json'), 'w', encoding='utf-8') as f:
    json.dump({'pairs': len(PAIRS), 'worst_rel': worst_rel,
               'worst_rel_s': worst_s, 'worst_rel_W': worst_w,
               'thresh': THRESH, 'ok': ok, 'rows': report},
              f, indent=1, ensure_ascii=False)
log.close()
sys.exit(0 if ok else 2)
