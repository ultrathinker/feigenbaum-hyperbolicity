# -*- coding: utf-8 -*-
"""layer_cells_hist.py — верхняя таблица §10.6 в ИСТОРИЧЕСКИХ режимах.

Зачем.  Верхняя таблица §10.6 сравнивает старую (пакетную) лемму U и снятую
калитку D4 с текущей мономиальной леммой: она показывает, ПОЧЕМУ понадобилось
переразложение и почему D4 заменена на компактность через спектральный радиус.
Числа этой таблицы получены в режимах, которые в обычном прогоне выключены, и
до сих пор не имели артефакта в пакете — прослеживались только до текста.
Этот драйвер их и производит.

Режим задаётся переменными окружения `layer_cert` (они читаются при импорте,
поэтому один процесс = один режим):

    LAYER_GATE_D4=1                      — гейтить по снятой калитке D4 (q<1)
    LAYER_PKG_LEMMA=1 LAYER_GATE_D4=1    — вдобавок пакетная verify_lemma_U

Запуск:  HIST_TAG=<метка> python layer_cells_hist.py <полуширина> [...]

Пишет `cells3_hist_<метка>.json` и `cells3_hist_<метка>.log` в $CERT_OUT.
Метка нужна, чтобы несколько режимов/подмножеств можно было считать
параллельно, не деля один файл. Сводит их `layer_cells_hist_merge.py`.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3

C, R = 0.6, 0.8
TAG = os.environ.get('HIST_TAG', 'x')
HALFS = [float(a) for a in sys.argv[1:]] or [3e-3]
MODE = ('pkg_lemma+D4' if cf3.PKG_LEMMA else 'D4') if cf3.GATE_D4 else 'обычный'

out = []
log = open(os.path.join(OUT, 'cells3_hist_%s.log' % TAG), 'w', encoding='utf-8')
log.write('=== layer_cells_hist [%s] режим %s %s ===%s'
          % (TAG, MODE, time.strftime('%Y-%m-%d %H:%M:%S'), chr(10)))
log.flush()
for h in HALFS:
    t0 = time.time()
    res = cf3.run_cell(C - h, C + h, R - h, R + h, log)
    res['half_width'] = h
    res['mode'] = MODE
    res['pkg_lemma'] = bool(cf3.PKG_LEMMA)
    res['gate_d4'] = bool(cf3.GATE_D4)
    # margin_a / margin_c худшего бокса — вход подтаблицы §10.6
    wb = res.get('worst_box')
    if wb and wb in res['boxes']:
        w = res['boxes'][wb].get('worst', {})
        res['worst_margin_a'] = w.get('D_margin_a')
        res['worst_margin_c'] = w.get('D_margin_c')
    out.append(res)
    with open(os.path.join(OUT, 'cells3_hist_%s.json' % TAG), 'w',
              encoding='utf-8') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    line = ('h=%g режим=%s pass=%d/46 worst=%s (%s) q_max=%.6f (%.0fс)'
            % (h, MODE, res['n_pass'],
               ('%.4e' % res['worst_margin']) if res['worst_margin'] is not None
               else 'n/a', res['worst_box'], res['q_max'], time.time() - t0))
    print(line, flush=True)
    log.write(line + chr(10))
    log.flush()
log.close()
