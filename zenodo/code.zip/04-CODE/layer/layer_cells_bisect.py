# -*- coding: utf-8 -*-
"""layer_cells_bisect.py — три контрольные полуширины у самой границы 𝔔:
±3.5·10⁻² (комфортная подячейка), ±4·10⁻² (строгая граница, публикуемая
как 𝔔) и ±4.5·10⁻² (первая провалившаяся).  Именно эти три строки
опубликованы в таблице §10.6.  Пишет cells3_bisect.json в $CERT_OUT.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3

C, R = 0.6, 0.8
HALFS = [3.5e-2, 4e-2, 4.5e-2]

out = []
log = open(os.path.join(OUT, 'cells3.log'), 'a', encoding='utf-8')
log.write('\n=== bisect4 %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
for h in HALFS:
    res = cf3.run_cell(C - h, C + h, R - h, R + h, log)
    res['half_width'] = h
    out.append(res)
    with open(os.path.join(OUT, 'cells3_bisect.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
log.close()
