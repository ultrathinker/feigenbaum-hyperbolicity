# -*- coding: utf-8 -*-
"""layer_cert.py — сертификатор слоя/ячейки для §10 (теорема D).

Для каждого ℓ-бокса пакета проверяет условия семейства 𝔉 (§10.2):
  D1  margin_a > 0  — самовложение s(D′) ⊆ D′;
  D2  margin_c > 0  — самовложение W(D′) ⊆ D′;
  D3  |U| ≥ 1/2 и Re U > 0 на |t−c′| ∈ {r′, 6/5} — U без нулей, главная
      ветвь Log U однозначна, W = U^ℓ аналитична (поле D_cut_ok);
  I1  перенос с D′ на базовый слой D₀ = D(3/5, 4/5);
  I2  обратный перенос, с D₀ на D′.
Слой задаётся ИНТЕРВАЛАМИ (c′, r′), поэтому один прогон покрывает целую
ячейку слоёв, а не одну точку.  При нехватке запаса ℓ-бокс дробится на
K ∈ {1,2,4,8} частей: это лишь сужает интервал коэффициентов P(ℓ), само
утверждение по-прежнему делается для всего бокса как объединения частей.

Численная калитка q < 1, q_s < 1 здесь НЕ гейтит (§10.2, §10.4).
Компактность оператора композиции C_W: h ↦ h∘W следует из margin_c > 0
через спектральный радиус в весовой алгебре Винера:
    ρ(W−c′) = max_{D̄(c′,r′)} |W−c′| = r′ − margin_c < r′,
а ρ(g) ≤ ‖g‖ = q·r′ выполняется всегда — значит margin_c > 0 есть более
слабое и потому более широкое условие, чем q < 1.  То же для C_s через
margin_a > 0.  Величины q, q_s по-прежнему считаются и пишутся в протокол
как диагностика (на широких ячейках они превышают 1 при живых маржах).
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import json
import time
import numpy as np


import rig_lib as rl
import tube_lib as tl
import beta_bound_lib as bbl
from flint import arb, acb, ctx
from layer_lemma_u import lemma_U_direct

ctx.prec = 256
BR = os.environ['HYP_BRANCHES']
C0, R0 = arb(3) / arb(5), arb(4) / arb(5)
R_OUTER = arb('1.20')
M_ARCS = 128
NP0 = 80
THRESH = 1e-3

# Исторические режимы (нужны, чтобы воспроизвести верхнюю таблицу §10.6, где
# показано, ЧТО именно ограничивало охват до снятия двух узких мест):
#   LAYER_PKG_LEMMA=1 — лемма U считается пакетной tube_lib.verify_lemma_U
#     (переразложение вокруг ИНТЕРВАЛЬНОГО c′, M_ARCS_LEMMA=64) вместо прямой
#     мономиальной схемы layer_lemma_u. Даёт строку «старая lemma_U».
#   LAYER_GATE_D4=1 — гейтить по калитке D4 (q<1, q_s<1), снятой как
#     математически избыточная (§10.2, §10.4). Даёт строки «ЕЩЁ с калиткой D4».
# По умолчанию оба выключены: это текущий сертификатор.
PKG_LEMMA = os.environ.get('LAYER_PKG_LEMMA', '') not in ('', '0')
GATE_D4 = os.environ.get('LAYER_GATE_D4', '') not in ('', '0')
BOX_TAGS = ['g%02d' % i for i in range(44)] + ['ganchor', 'gtop']


def set_cell(c_lo, c_hi, r_lo, r_hi):
    tl.c_arb = arb('%.17e' % c_lo).union(arb('%.17e' % c_hi))
    tl.r_arb = arb('%.17e' % r_lo).union(arb('%.17e' % r_hi))
    tl.N_p = NP0
    return tl.c_arb, tl.r_arb


def my_arc(c, r, th_lo, th_hi):
    th = th_lo.union(th_hi)
    co, si = th.cos(), th.sin()
    return acb((c + r * co.lower()).union(c + r * co.upper()),
               (r * si.lower()).union(r * si.upper()))


def horner(P, z):
    v = acb(P[-1])
    for k in range(len(P) - 2, -1, -1):
        v = v * z + acb(P[k])
    return v


def one_box(tag, cp, rp, K_max=8):
    z = np.load(os.path.join(BR, 'branch_%s.npz' % tag))
    c_a, m = z['c_a'], int(z['m'][0])
    e0, w = float(z['ell0'][0]), float(z['w'][0])
    arc_w = 2 * arb.pi() / M_ARCS
    K = 1
    while K <= K_max:
        worst = {}
        gate = None
        ok = True
        lo = e0 - w / 2.0
        for s in range(K):
            hi = lo + w / K
            xlo, xhi = 2.0 * (lo - e0) / w, 2.0 * (hi - e0) / w
            Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
            ell = arb('%.17e' % lo).union(arb('%.17e' % hi))
            lo = hi

            g1 = arb(0)
            for k in range(len(Pint)):
                g1 = g1 + Pint[k]
            if not (float((-g1).lower()) > 0.0):
                ok, gate = False, 'alpha_pos'
                break
            A = (-arb(1) / g1) ** (-ell)

            if PKG_LEMMA:
                lm, ok_D = tl.verify_lemma_U(Pint, ell)
            else:
                lm, ok_D = lemma_U_direct(Pint, ell, A, cp, rp,
                                          R_OUTER, M_ARCS, horner, my_arc)
            for key, val in (('D_margin_a', lm.get('margin_a')),
                             ('D_margin_c', lm.get('margin_c'))):
                if val is not None:
                    fv = float(val.lower())
                    worst[key] = min(worst.get(key, fv), fv)
            for key, val in (('D_U_min', lm.get('U_min')),
                             ('D_ReU_r_val', lm.get('ReU_min_r')),   # без коллизии по регистру с D_ReU_R
                             ('D_ReU_R', lm.get('ReU_min_R'))):
                if val is not None:
                    fv = float(val)
                    worst[key] = min(worst.get(key, fv), fv)
            # Явный флаг разреза (-inf,0]: Re U>0 на r' И на R=6/5 (Шаг 3.6,
            # 19.08 - раньше проверялось только неявно через ok_D/лог).
            cut_ok = bool(lm.get('nonzero_ok'))
            worst['D_cut_ok'] = worst.get('D_cut_ok', True) and cut_ok
            if not ok_D:
                ok, gate = False, 'lemma_U'
                break

            # D4 (q, q_s). По умолчанию СЧИТАЕТСЯ для протокола, но НЕ гейтит:
            # калитка избыточна, margin_a/margin_c из ok_D сильнее и достаточны
            # (§10.2, §10.4). При LAYER_GATE_D4=1 возвращается как условие
            # провала — исторический режим для верхней таблицы §10.6.
            q = qs = None
            try:
                pkg = tl.build_pkg_fast(Pint, ell)
                if pkg is None:
                    raise RuntimeError('build_pkg_fast вернул None')
                xn = tl.compute_x_norms_and_beta(pkg)
                bs = bbl.bases_check(tl.build_strict_consts_from_pkg(pkg, xn))
                q = float(bs['q_upper_value'])
                qs = float(bs['q_s_upper_value'])
                worst['D_q'] = max(worst.get('D_q', q), q)
                worst['D_q_s'] = max(worst.get('D_q_s', qs), qs)
            except Exception:
                if GATE_D4:
                    ok, gate = False, 'pkg_none'
                    break
            if GATE_D4 and not (q is not None and q < 1.0
                                and qs is not None and qs < 1.0):
                ok, gate = False, 'bases_q'
                break

            for name in ('I1', 'I2'):
                if name == 'I1':
                    cc, rr, ct, rt = cp, rp, C0, R0
                else:
                    cc, rr, ct, rt = C0, R0, cp, rp
                ms = float((rt - (abs(cc * A - ct) + rr * abs(A))).lower())
                worst[name + '_margin_s'] = min(worst.get(name + '_margin_s', ms), ms)
                if not (ms > 0):
                    ok, gate = False, name + '_s'
                    break
                maxW = arb(0)
                minRe = None
                for i in range(M_ARCS):
                    zz = my_arc(cc, rr, arb(i) * arc_w - arc_w / 2,
                                arb(i) * arc_w + arc_w / 2)
                    U = horner(Pint, zz * acb(A))
                    rlo = float(U.real.lower())
                    minRe = rlo if minRe is None else min(minRe, rlo)
                    u = (U ** ell - acb(ct)).abs_upper()
                    if u > maxW:
                        maxW = u
                mw = float((rt - maxW).lower())
                worst[name + '_margin_W'] = min(worst.get(name + '_margin_W', mw), mw)
                worst[name + '_ReU'] = min(worst.get(name + '_ReU', minRe), minRe)
                if not (mw > 0):
                    ok, gate = False, name + '_W'
                    break
                if not (minRe > 0):
                    ok, gate = False, name + '_ReU'
                    break
            if not ok:
                break
        if ok:
            keys = ('D_margin_a', 'D_margin_c', 'I1_margin_s', 'I1_margin_W',
                    'I2_margin_s', 'I2_margin_W')
            mm = [worst[k] for k in keys if k in worst]
            return {'pass': True, 'K': K, 'worst': worst,
                    'min_margin': min(mm) if mm else None}
        K *= 2
    return {'pass': False, 'K': K // 2, 'failed_gate': gate, 'worst': worst}


def run_cell(c_lo, c_hi, r_lo, r_hi, log):
    t0 = time.time()
    cp, rp = set_cell(c_lo, c_hi, r_lo, r_hi)
    res = {'cell': [c_lo, c_hi, r_lo, r_hi], 'boxes': {}}
    n_pass = 0
    fails = []
    worst_min = None
    worst_box = None
    qmax = 0.0
    for tag in BOX_TAGS:
        r = one_box(tag, cp, rp)
        res['boxes'][tag] = r
        qmax = max(qmax, r['worst'].get('D_q', 0.0))
        if r['pass']:
            n_pass += 1
            if r['min_margin'] is not None and (worst_min is None or r['min_margin'] < worst_min):
                worst_min, worst_box = r['min_margin'], tag
        else:
            fails.append([tag, r.get('failed_gate')])
    cell_pass = (n_pass == len(BOX_TAGS))
    comfortable = bool(cell_pass and worst_min is not None and worst_min > THRESH)
    res.update({'n_pass': n_pass, 'fails': fails, 'worst_margin': worst_min,
                'worst_box': worst_box, 'q_max': qmax, 'cell_pass': cell_pass,
                'comfortable': comfortable, 'wall_s': round(time.time() - t0, 1)})
    if cell_pass:
        verdict = 'PASS' + (' (запас > 1e-3)' if comfortable else ' (маржа < 1e-3)')
    else:
        verdict = 'FAIL %s' % (fails[:3],)
    wm = ('%.3e' % worst_min) if worst_min is not None else 'n/a'
    line = ('cell3 c=[%.4f,%.4f] r=[%.4f,%.4f]: pass=%d/46 worst=%s (%s) q_max=%.6f %s (%.0fs)'
            % (c_lo, c_hi, r_lo, r_hi, n_pass, wm, worst_box, qmax, verdict, res['wall_s']))
    print(line, flush=True)
    log.write(line + '\n')
    log.flush()
    return res


if __name__ == '__main__':
    print('layer_cert.py — библиотека (режим читается из окружения при')
    print('импорте), самостоятельно ничего не считает.')
    print('Запускать через 04-CODE/layer/layer_cells_hist.py, например:')
    print('  HIST_TAG=d4a LAYER_GATE_D4=1 python 04-CODE/layer/layer_cells_hist.py 0.003 0.005')
    print('см. 02-REPRODUCE.md §10.6.')
