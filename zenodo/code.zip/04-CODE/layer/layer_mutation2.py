# -*- coding: utf-8 -*-
"""layer_mutation2.py — мутационный тест гейтов D1 и D2 по отдельности.

layer_mutation1 портит схему Хорнера целиком, а значит задевает сразу все
величины (margin_a, margin_c, разрез) — это не показывает, что гейты
независимы.  Здесь порча точечная: обёртка вокруг lemma_U_direct
подменяет ТОЛЬКО margin_a (или ТОЛЬКО margin_c) на заведомо отрицательное
значение, с пересчётом OK по тому же правилу, что и оригинал.
Ожидается, что испорченное поле отражает подставленное значение, а два
соседних остаются честными и не проваливаются за компанию (§10.6).
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3
from flint import arb

LAYER = (0.60, 0.80)
BOX = 'g00'
cp, rp = cf3.set_cell(LAYER[0], LAYER[0], LAYER[1], LAYER[1])

baseline = cf3.one_box(BOX, cp, rp)
print('(A) baseline: pass=%s D_margin_a=%.4g D_margin_c=%.4g D_cut_ok=%s' % (
    baseline['pass'], baseline['worst']['D_margin_a'], baseline['worst']['D_margin_c'],
    baseline['worst'].get('D_cut_ok')))
# Голые assert вырезаются при запуске `python -O`, и единственная
# в пакете проверка «сертификатор не резиновый штамп» сама становится штампом.
# Поэтому проверки идут через check(), который не зависит от флага -O.
_FAILS = []


def check(cond, msg):
    if not cond:
        _FAILS.append(msg)
        print('*** ПРОВАЛ: ' + msg)
    return bool(cond)


def finish():
    import sys as _s
    if _FAILS:
        print('МУТАЦИОННЫЙ ТЕСТ: ПРОВАЛ (%d)' % len(_FAILS))
        _s.exit(1)

check(baseline['pass'] is True, "baseline['pass'] is True")

_real_lemma_U_direct = cf3.lemma_U_direct


def make_poisoned(field):
    def poisoned(Pint, ell, A, cp_, rp_, R, M_arcs, horner, my_arc):
        res, OK = _real_lemma_U_direct(Pint, ell, A, cp_, rp_, R, M_arcs, horner, my_arc)
        res = dict(res)
        res[field] = arb('-1e-3')
        OK_new = (float(res['margin_a'].lower()) > 0 and
                  float(res['margin_c'].lower()) > 0 and
                  bool(res.get('nonzero_ok')) and
                  float(res.get('U_min', 0)) >= 0.5)
        return res, OK_new
    return poisoned


for field, other in (('margin_a', 'margin_c'), ('margin_c', 'margin_a')):
    cf3.lemma_U_direct = make_poisoned(field)
    try:
        mutant = cf3.one_box(BOX, cp, rp)
    finally:
        cf3.lemma_U_direct = _real_lemma_U_direct
    w = mutant['worst']
    print('(B, poison %s) pass=%s gate=%s D_%s=%.4g D_%s=%.4g D_cut_ok=%s' % (
        field, mutant['pass'], mutant.get('failed_gate'),
        field, w.get('D_' + field), other, w.get('D_' + other), w.get('D_cut_ok')))
    check(mutant['pass'] is False, 'МУТАЦИЯ %s НЕ ПОЙМАНА' % field)
    check(mutant.get('failed_gate') == 'lemma_U', "mutant.get('failed_gate') == 'lemma_U'")
    check(w.get('D_' + field) < 0, 'испорченное поле не отражено в worst')
    check(w.get('D_' + other) > 0, 'соседнее поле задето порчей - гейты перепутаны')
    check(w.get('D_cut_ok') is True, 'D_cut_ok задет порчей margin_a/margin_c - должен быть независим')

control = cf3.one_box(BOX, cp, rp)
print('(C) control (после восстановления lemma_U_direct): pass=%s' % control['pass'])
check(control['pass'] is True, "control['pass'] is True")
check(cf3.lemma_U_direct is _real_lemma_U_direct, 'cf3.lemma_U_direct is _real_lemma_U_direct')

print('МУТАЦИОННЫЙ ТЕСТ 2: OK - margin_a и margin_c ловятся НЕЗАВИСИМО друг от '
      'друга и от D_cut_ok, соседние поля не задеты, откат корректен.')

finish()
