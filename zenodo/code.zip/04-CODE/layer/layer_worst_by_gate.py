# -*- coding: utf-8 -*-
"""layer_worst_by_gate.py — честный худший результат по КАЖДОМУ гейту
в отдельности по всем 644 парам.

Общая «худшая маржа» — это минимум по шести гейтам сразу; для таблицы
§10.6 нужен минимум по каждому из них порознь (D_margin_a, D_margin_c,
I1_margin_s, I1_margin_W, I2_margin_s, I2_margin_W), плюс максимум по
диагностическим q, q_s.  Пишет worst_by_gate.log и worst_by_gate.json
в $CERT_OUT.

Сюда входят и поля Re U (D_U_min, D_ReU_r_val, I1_ReU, I2_ReU,
D_ReU_R).  До круга 66 они НЕ отгружались ни для одной точечной пары:
сертификатор гейтит Re U как `> 0` без запаса, а min_margin считается
только по шести маржам.  Между тем §10.7 переносит Re U > 0 с P на G*
неравенством `min Re U_P - ΔU > 0`, которому нужен ЧИСЛОВОЙ минимум, —
то есть несущее число нельзя было проверить по пакету.  Направление у
них такое же, как у марж: меньше — хуже, поэтому is_q остаётся False.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import layer_cert as cf3

LAYERS = [(0.55, 0.80), (0.70, 0.80), (0.60, 0.70), (0.60, 0.90),
          (0.55, 0.70), (0.55, 0.90), (0.70, 0.75), (0.65, 0.85),
          (0.575, 0.80), (0.625, 0.80), (0.65, 0.80), (0.60, 0.75),
          (0.60, 0.85), (0.65, 0.75)]
FIELDS = ('D_margin_a', 'D_margin_c', 'I1_margin_s', 'I1_margin_W',
          'I2_margin_s', 'I2_margin_W', 'D_q', 'D_q_s',
          # несущие для §10.7 минимумы Re U и |U|
          'D_U_min', 'D_ReU_r_val', 'I1_ReU', 'I2_ReU', 'D_ReU_R')

worst = {f: (None, None, None) for f in FIELDS}  # value, layer, box
t0 = time.time()
n = 0
with open(os.path.join(OUT, 'worst_by_gate.log'), 'a', encoding='utf-8') as log:
    log.write('=== worst_by_gate %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
    for (c, r) in LAYERS:
        cp, rp = cf3.set_cell(c, c, r, r)
        for tag in cf3.BOX_TAGS:
            res = cf3.one_box(tag, cp, rp)
            w = res['worst']
            for f in FIELDS:
                v = w.get(f)
                if v is None:
                    continue
                cur = worst[f][0]
                is_q = f in ('D_q', 'D_q_s')
                better = (cur is None) or (v > cur if is_q else v < cur)
                if better:
                    worst[f] = (v, '(%.3g,%.3g)' % (c, r), tag)
            n += 1
        line = 'слой (%.3f,%.3f) готов, всего пар %d (%.0fs)' % (c, r, n, time.time() - t0)
        print(line, flush=True)
        log.write(line + '\n')
        log.flush()
    log.write('ИТОГО worst_by_gate:\n')
    for f in FIELDS:
        v, layer, box = worst[f]
        line = '  %-14s = %.6g @ %s / %s' % (f, v, layer, box)
        print(line)
        log.write(line + '\n')
    log.flush()
with open(os.path.join(OUT, 'worst_by_gate.json'), 'w', encoding='utf-8') as f:
    json.dump({k: {'value': v[0], 'layer': v[1], 'box': v[2]} for k, v in worst.items()}, f,
              ensure_ascii=False, indent=1)
