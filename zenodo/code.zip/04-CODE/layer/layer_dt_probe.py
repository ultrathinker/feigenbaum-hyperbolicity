# -*- coding: utf-8 -*-
"""layer_dt_probe.py — проверка того, что смена слоя реально доходит до
оператора DT, то есть инвариантность спектра не тавтологична (§10.8).

Если бы матрица DT была бит-в-бит одинаковой на всех слоях, утверждение
«δ не зависит от слоя» ничего не значило бы: движок просто игнорировал бы
слой.  Здесь на якорном боксе (ganchor, ℓ = 3) матрица DT собирается в
базисе каждого слоя, и сравниваются САМИ МАТРИЦЫ (поэлементно и по норме
Фробениуса), а не только спектры.  Пишет dt_layer_probe.log и
dt_layer_probe.json в $CERT_OUT.
"""
import os, sys, json, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
os.environ.setdefault('HYP_ENG', PARENT)
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG, '03-CERTIFICATES', 'branches'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG).  Дефолт НЕ ведёт
# внутрь пакета: запуск без CERT_OUT дописывал бы закоммиченный артефакт
# и ломал сверку с манифестом.  Чтобы ПЕРЕсобрать артефакты пакета,
# CERT_OUT выставляется явно (см. 02-REPRODUCE.md).
OUT = os.environ.get('CERT_OUT',
                     os.path.join(tempfile.gettempdir(), 'layer_out'))
if not os.path.isdir(OUT):
    os.makedirs(OUT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.environ['HYP_ENG'])
import numpy as np


import rig_lib as rl
import tube_lib as tl
import hyp_rouche as hr
from flint import arb, ctx

ctx.prec = 256
BR = os.environ['HYP_BRANCHES']
NP0 = 80


def set_layer(c, r, npn=NP0):
    tl.c_arb = arb('%.17e' % c)
    tl.r_arb = arb('%.17e' % r)
    tl.N_p = npn
    hr.C_A = tl.c_arb
    hr.R_A = tl.r_arb
    hr.NP = npn
    hr.MPR = -tl.c_arb / tl.r_arb


def dt_float(c, r, ell=3.0):
    set_layer(c, r)
    z = np.load(os.path.join(BR, 'branch_ganchor.npz'))
    c_a, m = z['c_a'], int(z['m'][0])
    e0, w = float(z['ell0'][0]), float(z['w'][0])
    x0 = 2.0 * (ell - e0) / w
    P = rl.P_at(c_a, m, arb('%.17e' % x0))
    pkg = tl.build_pkg_fast(P, arb('%.17e' % ell))
    if pkg is None:
        raise SystemExit(
            'build_pkg_fast returned None on layer (%g,%g)' % (c, r))
    DT = hr.dt_from_pkg(pkg)
    M = np.array([[float(DT[j][k]) for k in range(NP0)] for j in range(NP0)])
    # radius of the arb balls, to see how wide the enclosure is
    rad = max(float(DT[j][k].rad()) for j in range(NP0) for k in range(NP0))
    return M, rad


def spec(M):
    ev = np.linalg.eigvals(M)
    ev = ev[np.argsort(-np.abs(ev))]
    return ev


LAYERS = [(0.60, 0.80), (0.55, 0.80), (0.70, 0.80), (0.60, 0.70), (0.60, 0.90),
          (0.55, 0.70), (0.55, 0.90), (0.70, 0.75), (0.65, 0.85),
          (0.575, 0.80), (0.625, 0.80), (0.65, 0.80), (0.60, 0.75),
          (0.60, 0.85), (0.65, 0.75)]
out = {'layers': []}
log = open(os.path.join(OUT, 'dt_layer_probe.log'), 'w', encoding='utf-8')


def say(s):
    print(s)
    log.write(s + '\n')
    log.flush()


M0 = None
for (c, r) in LAYERS:
    t0 = time.time()
    M, rad = dt_float(c, r)
    ev = spec(M)
    n_out = int((np.abs(ev) > 1).sum())
    rec = {'c': c, 'r': r, 'delta': float(ev[0].real),
           'n_out': n_out, 'top5': [[float(x.real), float(x.imag)] for x in ev[:5]],
           'fro': float(np.linalg.norm(M)), 'max_abs': float(np.abs(M).max()),
           'arb_rad_max': rad, 'wall_s': round(time.time() - t0, 1)}
    if M0 is None:
        M0 = M.copy()
        rec['rel_diff_vs_base'] = 0.0
        rec['max_entry_diff'] = 0.0
    else:
        d = M - M0
        rec['rel_diff_vs_base'] = float(np.linalg.norm(d) / np.linalg.norm(M0))
        rec['max_entry_diff'] = float(np.abs(d).max())
    out['layers'].append(rec)
    say('layer c=%.3f r=%.3f : delta=%.15f  n_out=%d  ||M||_F=%.4e  '
        'rel_diff_vs_base=%.3e  max_entry_diff=%.3e  arb_rad<=%.2e  (%.1fs)'
        % (c, r, rec['delta'], n_out, rec['fro'], rec['rel_diff_vs_base'],
           rec['max_entry_diff'], rad, rec['wall_s']))
    say('   top5: ' + ', '.join('%.12f%+.12fi' % (x.real, x.imag) for x in ev[:5]))

base = out['layers'][0]['delta']
say('')
say('spread of delta across layers: %.3e' % max(abs(l['delta'] - base) for l in out['layers']))
say('VERDICT: layer patch reaches DT  = %s'
    % ('YES' if max(l['rel_diff_vs_base'] for l in out['layers']) > 1e-6 else 'NO -- TAUTOLOGY!'))
with open(os.path.join(OUT, 'dt_layer_probe.json'), 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)
log.close()
