"""
tube_lib.py (v6) — shared math for kit_batch engine_v6.

v6 changes vs v5:
  F0. General-ℓ DF/L/β: v5 hardcoded the ℓ=2.5 derivative pieces
      (ᾱ^{−7/2} = ᾱ^{−(ℓ+1)}, Ū^{3/2} = Ū^{ℓ−1}, factors 5/2 = ℓ) while W̄
      itself was built with the true interval ℓ. At ℓ≠2.5 the matrix M was
      NOT the derivative of F (FD test: 29% rel. error at ℓ=3), so Z1a was
      self-consistent but certified nothing. v6 uses ell_box everywhere:
      Ū^{ℓ−1} via Miller, ᾱ^{−(ℓ+1)}, and the L-chain constants generalized
      by the two reference implementations (wave5_fixL ℓ=3, wave6_kant_l25
      ℓ=2.5).
  F2. All max/min foldings of certifying quantities use DIRECTED endpoint
      bounds (.upper()/.lower(), exact arb, decidable comparisons) instead
      of certified ball comparisons that silently drop candidates.
  F4. F_tail in Y₀ computed honestly for the current ℓ-box and seed
      (compute_F_tail_bound) instead of the wave3 ℓ=2.5 constant.
  F6. ‖Ã‖₁ gets a directed arb upper bound (A_norm1_up).

Key changes vs wave11 (tube_lib_v2.py):
  1. **Quasi-Newton reseeding (variant A)**: at each step, use the cached
     Ã (updated every ~20 steps) and F̃(â) (the X₀-coefficient vector of F)
     to perform quasinewton: â ← â − Ã·F̃(â) (float/midpoint, 1-2 iters
     until ‖F̃‖_mid < 1e-30). This replaces the broken Picard iteration of
     wave11, which had no fixed point. The seed is no longer fixed; the
     rigorous part is the Cantorovich gate around the new seed.
  2. **Strict Z1c**: replace the float-fit β_k ≈ C·κ^k with the strict
     arb-formula β̂_{N_p+1} from beta_bound_lib.beta_bound_l25(mono).
  3. **Updated tube parameters** (per BRIEF-TUBE-V3-MX.md §2):
     H_INIT = 5e-6 (BRIEF target 1.2e-5 incompatible with the Y0-rad
     gate, see H_INIT_TARGET below), H_MAX = 5e-5, target ρ̂' ≈ 3.5e-5.

All arithmetic is rigorous: flint arb at prec=512 for floats, mpmath mpf for
high-precision Newton-style refinement where used.  The Newton output is
widened by a small symmetric eps before being converted to arb so downstream
interval arithmetic has room to grow.
"""
import json, os, math, time
import numpy as np
import mpmath
from mpmath import mp, mpf
from flint import arb, acb, ctx, arb_poly


PREC = 512        # default; can be reset via set_prec() before any arb work
ctx.prec = PREC
mp.dps = 60


def set_prec(new_prec):
    """Reset flint arb precision. Call BEFORE any arb-heavy work.

    All interval magnitudes we care about are ~1e-7 … 1e-5 (Y₀, Z₁); even
    prec=192 gives ~60 decimal digits of mantissa — orders of magnitude
    more than the needed ~7 digits of scientific precision.
    """
    global PREC
    if new_prec < 64:
        raise ValueError(f"prec must be ≥ 64, got {new_prec}")
    PREC = new_prec
    ctx.prec = PREC
    mp.dps = max(60, int(new_prec / 4))   # mpmath dps ∝ prec/4 (60 default)
    return PREC

# constants — identical to wave6_kant_l25 / wave10_tube_pilot
c_arb = arb(3) / arb(5)
r_arb = arb(4) / arb(5)
ELL_32_arb = arb(3) / arb(2)

# sizes
N_G = 64
N_W = 192
N_p = 80
N_ALG = 192

# lemma + cauchy discretization
M_ARCS_LEMMA = 64       # M=64 for speed (brief §3 says it's enough)
M_ARCS_CAUCHY = 128

# tube parameters (wave13_tube_mx — per BRIEF-TUBE-V3-MX.md §2)
H_INIT = 5e-6             # NOTE: BRIEF target 1.2e-5 incompatible with the Y0-rad
                          # gate (Y0 rad = 1.91h, not 1.91h/2 as BRief writes); see REPORT.
H_MAX = 5e-5              # per BRIEF §2
H_MIN = 1e-6
H_INIT_TARGET = 1.2e-5    # documented BRIEF target (see REPORT)
WALL_BUDGET_SEC_DEFAULT = 2 * 3600    # 2 h budget per worker (orchestrator overrides)

# Ã update cadence
ATILDE_UPDATE_EVERY = 20
Z1A_THRESHOLD = 1e-3

# Quasi-Newton reseeding tolerances
QN_MAX_ITER = 2
QN_TOL = 1e-30         # ‖F̃‖_mid target

# small symmetric epsilon added when wrapping Newton output as arb ball.
# Chosen so that the midpoint is exact; the eps covers truncation of mpmath dps=60.
NEWTON_BALL_EPS_REL = 1e-17


# ====================== utilities ======================

def arb_mid(s):
    if not isinstance(s, str):
        return float(s)
    inner = s.strip()
    if inner.startswith('['):
        inner = inner[1:-1].strip()
    plus = inner.find('+/-')
    if plus == -1:
        return float(inner.strip().split()[0])
    return float(inner[:plus].strip())


def x_norm(poly):
    s = arb(0)
    for k in range(len(poly)):
        s = s + abs(poly[k]) * (r_arb ** k)
    return s


def abs_arb(x):
    lo = x.lower()
    hi = x.upper()
    lo_abs = -lo if lo < 0 else lo
    hi_abs = -hi if hi < 0 else hi
    return lo_abs if lo_abs > hi_abs else hi_abs


def atomic_write_json(path, obj):
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(obj, f, indent=2)
    os.replace(tmp, path)


def log_msg(logfile, *args):
    line = " ".join(str(a) for a in args)
    print(line, flush=True)
    with open(logfile, 'a', encoding='utf-8') as f:
        f.write(line + "\n")


# ====================== Newton continuation at ℓ_mid (mpmath) ======================

def _mp_c(r_mp):
    return mpmath.mpf("0.6"), mpmath.mpf("0.8")


def newton_seed_mp(ell_mid_mp, a_init, n_iter=2, dps=60, N=None):
    """Plain iteration G_{n+1} = F(G_n) at ℓ = ell_mid_mp, starting from a_init.

    This is the "Newton" of the brief: 1-2 iterations of F(G) starting from
    the previous step's converged seed (linear/quadratic convergence depending
    on how close we already are).  mpmath dps=60, N = len(a_init) by default.

    Returns a list of mpmath.mpf of length N.
    """
    mp.dps = dps
    if N is None:
        N = len(a_init)
    ell = mpmath.mpf(ell_mid_mp)
    c_mp, r_mp = _mp_c(r_arb)

    a = [mpmath.mpf(ai) for ai in a_init]
    # zero-pad/truncate to N
    if len(a) < N:
        a = a + [mpmath.mpf(0)] * (N - len(a))
    elif len(a) > N:
        a = a[:N]

    for it in range(n_iter):
        G_at_1 = sum(a[:N])
        abar = -mpmath.mpf(1) / G_at_1
        abar_inv_ell = abar ** (-ell)

        # Ū in u-coords (truncate at N)
        Ubar_u_mp = [mpmath.mpf(0)] * (N + 1)
        for j in range(N + 1):
            s = mpmath.mpf(0)
            for k in range(j, N):
                # binom(k, j) * c^(k-j)
                binom = mpmath.mpf(1)
                for m in range(j):
                    binom = binom * (k - m) / (m + 1)
                s = s + a[k] * (abar_inv_ell ** k) * binom * (c_mp ** (k - j))
            Ubar_u_mp[j] = s

        # Miller for W̄ = Ū^ℓ
        w_coeffs = [mpmath.mpf(0)] * (N + 1)
        w_coeffs[0] = Ubar_u_mp[0] ** ell
        for n in range(1, N + 1):
            s = mpmath.mpf(0)
            for k in range(1, n + 1):
                coef = (ell + 1) * k - n
                s = s + coef * Ubar_u_mp[k] * w_coeffs[n - k]
            w_coeffs[n] = s / (n * Ubar_u_mp[0])

        # Horner composition of G against (W̄ - c), truncated to N
        G_poly_mp = a
        W_minus_c_mp = list(w_coeffs)
        W_minus_c_mp[0] = W_minus_c_mp[0] - c_mp

        acc = [mpmath.mpf(G_poly_mp[N - 1])]
        for k in range(N - 2, -1, -1):
            new_len = len(acc) + len(W_minus_c_mp) - 1
            new_acc = [mpmath.mpf(0)] * min(new_len, N + 1)
            for i in range(len(acc)):
                ai = acc[i]
                if ai == 0:
                    continue
                for j in range(len(W_minus_c_mp)):
                    if i + j > N:
                        break
                    new_acc[i + j] = new_acc[i + j] + ai * W_minus_c_mp[j]
            new_acc[0] = new_acc[0] + mpmath.mpf(G_poly_mp[k])
            acc = new_acc

        # Picard: a_new = abar * acc  (correct fixed-point iteration:
        # the actual fixed-point equation is G = abar·G∘W̄ — the pilot's
        # docstring is contradictory but wave6's Y₀ = ‖F̄‖_X is consistent
        # with the multiplicative equation G* = abar·G*∘W̄ + noise).
        # Empirically (see test): starting from hiprec at ℓ=2.5, this
        # iteration drifts slowly (~1e-3 after 1 iter), so we DON'T trust it
        # to converge in 1-2 steps. We use the hiprec seed DIRECTLY (n_iter=0).
        a_new = [mpmath.mpf(0)] * N
        for k in range(N):
            a_new[k] = abar * acc[k]
        a = a_new

    return a


def mp_to_arb_ball_list(a_mp, eps_rel=NEWTON_BALL_EPS_REL):
    """Wrap a list of mpmath.mpf as arb balls with a tiny symmetric eps."""
    out = []
    for ai in a_mp:
        a = arb(str(ai))
        # mid is ai (mpmath dps=60 ⇒ ≈ 18 decimals ⇒ mid matches within flint rounding)
        eps = eps_rel * (abs(ai) + mpmath.mpf("1e-300"))
        out.append(arb(str(ai - eps)).union(arb(str(ai + eps))))
    return out


def seed_drift_norm_upper(a_step_arb, a_cell_arb):
    """v6/F1: strict arb upper bound on d_X = ‖â_step − â_cell‖_X.

    Both inputs are origin-basis arb ball lists (the Kantorovich centers with
    their tiny wrap radii — included in the bound automatically). The X-norm
    is Σ|h_k|·r^k over the c-recentered coefficients; recentring is the
    rigorous arb Taylor shift (reexpand_fast). Returns an EXACT arb (upper
    endpoint), suitable for decidable downstream comparisons.

    This is the measured drift entering ρ′_eff = ρ̂′ + d_X/1.75 of the
    per-step gate (REVIEW-ENGINE F1, recipe 2): for x ∈ B′(â_step, ρ̂′),
    ‖x − â_cell‖_X ≤ 1.75·ρ̂′ + d_X = 1.75·ρ′_eff, so Z-quantities derived
    on B_X(â_cell, 1.75·ρ′_eff) cover the step ball. No empirical slope is
    involved — d_X is measured rigorously at every step.
    """
    N = max(len(a_step_arb), len(a_cell_arb))
    diff = []
    for k in range(N):
        x = a_step_arb[k] if k < len(a_step_arb) else arb(0)
        y = a_cell_arb[k] if k < len(a_cell_arb) else arb(0)
        diff.append(x - y)
    h = reexpand_fast(diff, c_arb, r_arb, N - 1)
    s = arb(0)
    for k in range(len(h)):
        s = s + abs(h[k]) * (r_arb ** k)
    return s.upper()


# ====================== Quasi-Newton reseeding (variant A) ======================

def quasi_newton_reseed(a_u, ell_box, A_tilde, A_norm1,
                        max_iter=QN_MAX_ITER, tol=QN_TOL, verbose=False):
    """Quasi-Newton reseed at interval ell_box using cached Ã.

    Inputs:
      a_u: list of length N_p+1, float (or arb midpoint) — Taylor coefficients
           of G at center c, in u-coords.
      ell_box: arb interval [ell_mid - h/2, ell_mid + h/2].
      A_tilde: numpy.ndarray (N_p, N_p) — the cached inverse of M' in b-basis.
      A_norm1: float — ‖Ã‖₁ (only used for diagnostics).
      max_iter: maximum number of Newton iterations.
      tol: stop when ‖F̃‖_inf < tol.

    Returns:
      (a_new, info): a_new is a length N_p+1 list of floats (the new seed);
                     info is a dict with iter_count, residual_norm, etc.

    Method (per BRIEF-TUBE-V3-MX.md §1.A):
      Compute F̄(â) = G(â) + abar·Ḡ(W̄(â)) in u-coords (from compute_F_poly).
      Form F̃(â) = F̄_coefs[k] · r^k for k=1..N_p (X₀-coords of F̄).
      Newton step in X₀-coords: ΔX₀ = Ã · F̃(â).
      Convert back to u-coords: Δu[k] = ΔX₀[k-1] / r^k for k=1..N_p.
      Update: â_new[k] = â[k] - Δu[k] for k=1..N_p; â_new[0] = â[0].
      Iterate until ‖F̃‖_mid < tol or max_iter reached.

    **NOT** rigorous.  The rigorous part is the Cantorovich gate around the
    new seed.  This is float/midpoint arithmetic only.
    """
    a = list(a_u)
    if len(a) < N_p + 1:
        raise SystemExit(f"a must have at least N_p+1 = {N_p+1} coefficients")
    # truncate / pad to N_p+1
    a = a[:N_p+1] + [0.0] * (N_p + 1 - len(a)) if len(a) < N_p+1 else a[:N_p+1]

    c = 0.6
    r = 0.8
    r_mid = r

    info = {'iter_count': 0, 'residual_norms': [], 'deltas': []}

    for it in range(max_iter):
        # Build arb balls from a (use midpoint of any, but a is float here)
        a64_arb = [arb(ai) for ai in a[:N_G + 1]]

        # Compute F̄(â) in u-coords (full arb, then take midpoint)
        F_poly = compute_F_poly(a64_arb, ell_box)
        F_coefs = []
        for k in range(N_p + 1):
            try:
                F_coefs.append(float(F_poly[k]))
            except Exception:
                F_coefs.append(0.0)

        # F̃ in X₀-coords: F̃[k] = F_coefs[k] · r^k for k=1..N_p
        F_tilde = np.array([F_coefs[k] * (r_mid ** k) for k in range(1, N_p + 1)],
                           dtype=np.float64)

        # ‖F̃‖_mid (infinity norm) for stopping criterion
        F_inf = float(np.max(np.abs(F_tilde)))
        info['residual_norms'].append(F_inf)

        if verbose:
            print(f"  [QN it {it}] ‖F̃‖_inf = {F_inf:.3e}", flush=True)

        if F_inf < tol:
            break

        # Newton step in X₀-coords: ΔX₀ = Ã · F̃
        delta_X0 = A_tilde @ F_tilde  # shape (N_p,)
        info['deltas'].append(float(np.max(np.abs(delta_X0))))

        # Convert back to u-coords: Δu[k] = ΔX₀[k-1] / r^k for k=1..N_p
        for k in range(1, N_p + 1):
            a[k] = a[k] - delta_X0[k - 1] / (r_mid ** k)

        info['iter_count'] = it + 1

    return a[:N_p+1], info


def quasi_newton_reseed_arb(a_u, ell_box, A_tilde, A_norm1,
                            max_iter=QN_MAX_ITER, tol=QN_TOL, verbose=False):
    """Same as quasi_newton_reseed but takes mpmath mpf list and returns mpmath
    mpf list (for use in the worker after the first computation)."""
    a_float = [float(ai) for ai in a_u]
    a_float = a_float[:N_p+1] + [0.0] * max(0, N_p + 1 - len(a_float))
    a_new, info = quasi_newton_reseed(a_float, ell_box, A_tilde, A_norm1,
                                       max_iter=max_iter, tol=tol, verbose=verbose)
    a_mp = [mpf(str(ai)) for ai in a_new]
    return a_mp, info


# ====================== build polys at interval ℓ_box (arb, C-speed) ======================

def miller_power_fast(u_coeffs, ell, N, c, r):
    """Same as polyball.miller_power but returns arb_poly directly."""
    if not (u_coeffs[0] > 0.5):
        raise ValueError("u_0 must be > 0.5 (branch condition, §5.3.2 — not a condition of Miller's formula)")
    w = [arb(0)] * (N + 1)
    w[0] = u_coeffs[0] ** ell
    for n in range(1, N + 1):
        s = arb(0)
        for k in range(1, n + 1):
            coef = (ell + 1) * k - n
            s = s + coef * u_coeffs[k] * w[n - k]
        w[n] = s / (n * u_coeffs[0])
    # Return arb_poly (so caller can use [k], len(), etc.)
    return arb_poly(w), w


def reexpand_fast(coeffs_at_0, new_center, r, N):
    out = []
    for k in range(N + 1):
        s = arb(0)
        for j in range(k, len(coeffs_at_0)):
            aj = coeffs_at_0[j]
            binom = arb(1)
            for m in range(k):
                binom = binom * (j - m) / (m + 1)
            s = s + aj * binom * (new_center ** (j - k))
        out.append(s)
    return out


def build_pkg_fast(a64_arb, ell_box):
    """Build all derived polys needed by DF/Ã at interval ell_box.

    Returns dict with: G_c, G_c_prime, abar, G_at_1, G_at_1_sq,
                      Ubar_u_coeffs, s_c_minus_c, U_c,
                      W_P, W_c_shifted, U_pow_lm1,
                      tail_hW, tail_hUlm1, M_full, tail_cols, ell_box
    """
    G_at_1 = arb(0)
    for ak in a64_arb:
        G_at_1 = G_at_1 + ak
    abar = -arb(1) / G_at_1
    if not (abar > 0):
        # ᾱ must be certified positive: non-integer powers of a ball touching
        # (−∞,0] silently produce NaN balls downstream.
        return None
    G_at_1_sq = G_at_1 ** 2

    alpha_ell = abar ** ell_box
    abar_inv_ell = alpha_ell ** (-1)

    # Ū in u-coords
    Ubar_at_t = [a64_arb[k] * (abar_inv_ell ** k) for k in range(N_G + 1)]
    Ubar_u_coeffs = reexpand_fast(Ubar_at_t, c_arb, r_arb, N_G)
    u0 = Ubar_u_coeffs[0]
    if not (u0 > 0.5):
        return None

    # G at center c
    G_c = arb_poly(a64_arb)
    G_c = G_c(arb_poly([c_arb, arb(1)]))
    G_c_prime = G_c.derivative()

    # s̄ in u-coords
    s_c_minus_c = arb_poly([c_arb * (abar_inv_ell - arb(1)), abar_inv_ell])
    U_c = G_c(s_c_minus_c)

    # Miller for W̄ and U^{3/2}
    u_padded = list(Ubar_u_coeffs) + [arb(0)] * (N_W - N_G)
    W_P, W_P_list = miller_power_fast(u_padded, ell_box, N_W, c_arb, r_arb)
    W_c_shifted = arb_poly(W_P_list)
    W_c_shifted[0] = W_c_shifted[0] - c_arb
    # Truncate W_c_shifted to N_p — the tail beyond N_p contributes to
    # tail_cols (via the Cauchy tail bound 4*max(tail_hW, tail_hU32)*poly_norm)
    # and we only need the head coefficients of v_c(W_c_shifted) for M.
    W_c_shifted_head = arb_poly(W_P_list[:N_p + 1])
    W_c_shifted_head[0] = W_c_shifted_head[0] - c_arb

    # v6/F0: Ū^{ℓ−1} at the TRUE interval ℓ. v5 hardcoded Ū^{3/2} (the ℓ=2.5
    # case), so at ℓ≠2.5 the M matrix was not the derivative of F (see
    # (FD test, 29% rel. error at ℓ=3).
    ell_m1 = ell_box - arb(1)
    U_pow_lm1_P, U_pow_lm1_list = miller_power_fast(u_padded, ell_m1, N_W, c_arb, r_arb)
    U_pow_lm1 = arb_poly(U_pow_lm1_list)
    U_pow_lm1_head = arb_poly(U_pow_lm1_list[:N_p + 1])

    # Cauchy tails on |t-c| = R = 1.2 — small M_ARCS for speed
    from lemma_domains import arc_to_acb_box
    R = arb("1.20")
    arc_w = 2 * arb.pi() / M_ARCS_CAUCHY
    M_W = arb(0)
    M_Ulm1 = arb(0)
    U_c_list = list(U_c)
    for m in range(M_ARCS_CAUCHY):
        th_lo = arb(m) * arc_w - arc_w / 2
        th_hi = arb(m) * arc_w + arc_w / 2
        z_arc = arc_to_acb_box(c_arb, R, th_lo, th_hi)
        z_minus_c = z_arc - acb(c_arb)
        # Horner on U_c at z_minus_c (acb)
        val = acb(U_c_list[N_G])
        for k in range(N_G - 1, -1, -1):
            val = val * z_minus_c + acb(U_c_list[k])
        U_abs_up = val.abs_upper()
        # v6/F2: directed max — upper bound of a max is the max of exact
        # UPPER endpoints; the certified `>` on overlapping balls silently
        # dropped candidates (collapsed to 0 on interval ℓ).
        M_W_arc_up = (U_abs_up ** ell_box).upper()
        if M_W_arc_up > M_W:
            M_W = M_W_arc_up
        M_Ulm1_arc_up = (U_abs_up ** ell_m1).upper()
        if M_Ulm1_arc_up > M_Ulm1:
            M_Ulm1 = M_Ulm1_arc_up

    ratio = r_arb / R
    tail_hW = M_W * (ratio ** (N_W + 1)) / (1 - ratio)
    tail_hUlm1 = M_Ulm1 * (ratio ** (N_W + 1)) / (1 - ratio)

    # DF for ell_box — v6/F0: ᾱ^{−(ℓ+1)} (was hardcoded ᾱ^{−7/2} = ℓ=2.5 case)
    abar_inv_ellp1 = abar ** (-(ell_box + arb(1)))

    def DF_at_ell(v_c):
        v_at_1 = v_c(arb(1) - c_arb)
        Da_v = v_at_1 / G_at_1_sq
        coef = -ell_box * abar_inv_ellp1 * Da_v
        Ds_v = arb_poly([c_arb * coef, coef])
        v_of_s = v_c(s_c_minus_c)
        inner = v_of_s + Gprime_of_s * Ds_v
        # Truncate intermediate products — for the head (degrees ≤ N_p) of the
        # final result, intermediate products only need their head.
        # v6/F0: DW = ℓ·Ū^{ℓ−1}·DŪ (was ℓ·Ū^{3/2}·DŪ)
        DW_v = ell_box * U_pow_lm1_head * inner
        if DW_v.degree() > N_p:
            DW_v = arb_poly(list(DW_v)[:N_p + 1])
        v_of_W = v_c(W_c_shifted_head)
        result = v_c + Da_v * GC_of_W_head + abar * (v_of_W + Gprime_of_W_head * DW_v)
        if result.degree() > N_p:
            result = arb_poly(list(result)[:N_p + 1])
        return result

    Gprime_of_s = G_c_prime(s_c_minus_c)
    # Compute G' and G evaluated at the TRUNCATED W_c (degree ≤ N_p), then
    # truncate the result to head. For the HEAD of (G'(W) * DW_v + ...), only
    # the HEAD of G'(W) matters; the tail of G'(W) only contributes to the
    # tail (which is bounded by additional_tail = 4*max(tail_hW, tail_hU32)*poly_norm).
    Gprime_of_W = G_c_prime(W_c_shifted_head)
    if Gprime_of_W.degree() > N_p:
        Gprime_of_W_head = arb_poly(list(Gprime_of_W)[:N_p + 1])
    else:
        Gprime_of_W_head = Gprime_of_W
    GC_of_W = G_c(W_c_shifted_head)
    if GC_of_W.degree() > N_p:
        GC_of_W_head = arb_poly(list(GC_of_W)[:N_p + 1])
    else:
        GC_of_W_head = GC_of_W

    # ------------------------------------------------------------------
    # CTAIL-FIX.
    #
    # Раньше здесь стояло:  tail = sum_{j=N_p+1}^{len(DF_e_k)-1} |DF_e_k[j]| r^j,
    # но DF_at_ell обрезает результат на N_p, поэтому сумма была ПУСТА, и весь
    # хвост столбца покрывался величиной 4*max(tail_hW, tail_hUlm1)*poly_norm —
    # коши-хвостом ряда W за степенью N_W = 192.  Это другая величина, меньше
    # истинной на 13-24 порядка (прямой замер: истинный ||C|| до 1.95e-8
    # против заявленных 5.7e-32).  Классическое «ограничена модель, а не
    # величина»: ограничен хвост усечения W, а не хвост композиции с ним.
    #
    # Здесь тот же столбец считается ДО степени N_ALG = 192, и хвост берётся
    # честно: sum_{j=N_p+1}^{N_ALG}.  Член 4*max(tail_h*)*poly_norm остаётся —
    # он покрывает то, для чего и предназначался: усечение самих W и U^{l-1}
    # за N_W.  Стоимость — сотня умножений многочленов степени 192 на бокс.
    def _trunc(pl, n):
        return arb_poly(list(pl)[:n + 1]) if pl.degree() > n else pl

    def _compose_trunc(pp, qq, n):
        """pp(qq) методом Горнера с усечением на степени n."""
        d = pp.degree()
        if d < 0:
            return arb_poly()
        res = arb_poly([pp[d]])
        for i in range(d - 1, -1, -1):
            res = _trunc(res * qq, n)
            res = res + arb_poly([pp[i]])
        return res

    NL = N_ALG
    W_long = _trunc(W_c_shifted, NL)
    Ulm_long = _trunc(U_pow_lm1, NL)
    Gp_W_long = _compose_trunc(G_c_prime, W_long, NL)
    GC_W_long = _compose_trunc(G_c, W_long, NL)
    Gp_s_long = _compose_trunc(G_c_prime, s_c_minus_c, NL)
    # степени W и s, накопленные один раз для всех k
    W_pow = [arb_poly([arb(1)])]
    s_pow = [arb_poly([arb(1)])]
    for _k in range(1, N_p + 1):
        W_pow.append(_trunc(W_pow[-1] * W_long, NL))
        s_pow.append(_trunc(s_pow[-1] * s_c_minus_c, NL))

    def _col_tail_long(k):
        """sum_{j>N_p}^{N_ALG} |DF(e_k)_j| r^j — честный хвост столбца."""
        inv_rk = arb(1) / (r_arb ** k) if k else arb(1)
        v_at_1 = ((arb(1) - c_arb) ** k) * inv_rk
        Da_v = v_at_1 / G_at_1_sq
        coef = -ell_box * abar_inv_ellp1 * Da_v
        Ds_v = arb_poly([c_arb * coef, coef])
        v_of_s = s_pow[k] * inv_rk
        inner = v_of_s + Gp_s_long * Ds_v
        DW_v = _trunc(ell_box * Ulm_long * inner, NL)
        v_of_W = W_pow[k] * inv_rk
        res = (arb_poly([arb(0)] * k + [inv_rk]) + Da_v * GC_W_long
               + abar * (v_of_W + _trunc(Gp_W_long * DW_v, NL)))
        res = _trunc(res, NL)
        t = arb(0)
        for j in range(N_p + 1, min(res.degree(), NL) + 1):
            t = t + abs(res[j]) * (r_arb ** j)
        return t

    # ------------------------------------------------------------------
    # CTAIL-FIX3 (18.08): хвост аналитического столбца — ВСЕ члены.
    #
    # Что было не так в CTAIL-FIX2.  res считался вычислительно до N_MAX = 320,
    # а остаток за N_MAX ограничивался КОШИ только у члена 5
    # (abar·G'_c(W-c)·DW_v); в комментарии стояло, что «остальные члены имеют
    # степень <= max(N_p, N_G) = 80, хвост 0».  Это неверно: W-c — РЯД (в коде
    # усечён на N_W = 192), поэтому и v_c(W-c) = (W-c)^k/r^k, и G_c(W-c) имеют
    # ненулевые коэффициенты сколь угодно высокой степени — уже для
    # полиномиального W это k·N_W = 15360.  Их хвосты за N_MAX не входили ни в
    # один член оценки.  Сверх того сам W (и U^{l-1}) берутся усечёнными на
    # N_W, а ошибка усечения была выброшена вместе со старым (действительно
    # негодным) членом 4·max(tail_hW, tail_hUlm1)·poly_norm.
    #
    # Наивное исправление не работает: sup_{|u|<=R}|v_c(W)| растёт как
    # ((M_W+c)/r)^k, при l~4 и k=80 это ~10^231 против коши-множителя
    # (r/R)^{321} ~ 10^{-57} — ворота взорвались бы.
    #
    # Что теперь.  Хвост оценивается не через sup на окружности R, а во
    # взвешенной l1-норме (та же банахова алгебра, что и всюду в работе):
    #
    #     A_f(L) := sum_j |f_j| (L·r)^j ,   L >= 1 ,
    #
    # для неё A_{fg} <= A_f · A_g (норма свёртки), и для любого N
    #
    #     sum_{j>N} |f_j| r^j = sum_{j>N} |f_j|(L r)^j L^{-j} <= L^{-(N+1)}·A_f(L).
    #
    # Хвост произведения поэтому ограничивается произведением A-норм
    # сомножителей, и коэффициентный спад W работает там, где sup взрывается.
    # Хвосты самих рядов W, U^{l-1} за N_W входят в их A-нормы через коши:
    # |w_j| <= M_W/R_c^j даёт A-массу M_W·(L r/R_c)^{N_W+1}/(1 - L r/R_c), что
    # требует L < R_c/r = 1.5.
    #
    # Итог для столбца k:
    #   tail_cols[k] = tail_direct   sum_{j=N_p+1}^{N_MAX}, прямой счёт по головам
    #                + E_trunc(k)    замена W, U^{l-1} их усечениями на N_W
    #                + T_L(k)        хвост за N_MAX, все пять членов, min по L
    #
    # Корректность суммы: для точного res
    #   sum_{j>N_p}|res_j|r^j <= sum_{N_p<j<=N_MAX}|res^голов_j|r^j
    #                            + ||res - res^голов|| + sum_{j>N_MAX}|res_j|r^j.
    # Численно T_L ~ 1e-37 и E_trunc ~ 1e-35 против tail_direct ~ 1e-4...1e-33:
    # оценка стала выведенной, а значения сертификатов — те же в 7 знаках.
    N_MAX = 320            # > N_ALG + max(k, N_G) + 64 для всех k≤N_p

    R_cauchy = R

    # Расширяем W̄ до N_MAX, G_c(W̄−c), G'_c(W̄−c), G'_c(s̄) до N_MAX,
    # W^k и s^k до N_MAX — всё, что нужно для прямого res до N_MAX.
    W_long_ext = _trunc(W_c_shifted, N_W)         # W̄ известна до N_W=192
    Gp_W_long_ext = _compose_trunc(G_c_prime, W_long_ext, N_MAX)
    GC_W_long_ext = _compose_trunc(G_c, W_long_ext, N_MAX)
    Gp_s_long_ext = _compose_trunc(G_c_prime, s_c_minus_c, N_MAX)
    W_pow_ext = [arb_poly([arb(1)])]
    s_pow_ext = [arb_poly([arb(1)])]
    for _kk in range(1, N_p + 1):
        W_pow_ext.append(_trunc(W_pow_ext[-1] * W_long_ext, N_MAX))
        s_pow_ext.append(_trunc(s_pow_ext[-1] * s_c_minus_c, N_MAX))
    Ulm_long_ext = _trunc(U_pow_lm1, N_W)

    # ---- A-нормы для оценки хвоста за N_MAX (см. CTAIL-FIX3 выше) ----
    def _A_series(coeffs, lam):
        a = arb(0)
        p = arb(1)
        lr = lam * r_arb
        for i in range(len(coeffs)):
            a = a + abs(coeffs[i]) * p
            p = p * lr
        return a

    def _A_poly_in(pc, A_in):
        # A_{P(f)}(L) <= sum_j |P_j| · A_f(L)^j
        a = arb(0)
        p = arb(1)
        for i in range(len(pc)):
            a = a + abs(pc[i]) * p
            p = p * A_in
        return a

    Wm_list = list(W_long_ext)
    Ulm_list = list(Ulm_long_ext)
    Gc_list = list(G_c)
    Gp_list = list(G_c_prime)
    s_list = list(s_c_minus_c)

    LAM = []
    for lam in (arb('1.20'), arb('1.30'), arb('1.35'), arb('1.40'), arb('1.45')):
        x = lam * r_arb / R_cauchy
        if not (x < 1):
            continue
        wtail = (M_W * x ** (N_W + 1) / (1 - x)).upper()
        utail = (M_Ulm1 * x ** (N_W + 1) / (1 - x)).upper()
        A_W = (_A_series(Wm_list, lam) + wtail).upper()
        A_U = (_A_series(Ulm_list, lam) + utail).upper()
        A_s = _A_series(s_list, lam).upper()
        LAM.append({'A_W': A_W, 'A_U': A_U, 'A_s': A_s,
                    'A_GW': _A_poly_in(Gc_list, A_W).upper(),
                    'A_GpW': _A_poly_in(Gp_list, A_W).upper(),
                    'A_Gps': _A_poly_in(Gp_list, A_s).upper(),
                    'pow': (lam ** (-(N_MAX + 1))).upper(),
                    'cR': (abs(c_arb) + lam * r_arb).upper()})
    if not LAM:
        return None

    # ---- множители для E_trunc: всё в r-норме, L не участвует ----
    nu_W = (_A_series(Wm_list, arb(1)) + tail_hW).upper()        # >= ||W-c||
    nu_U = (_A_series(Ulm_list, arb(1)) + tail_hUlm1).upper()    # >= ||U^{l-1}||
    n_s = _A_series(s_list, arb(1)).upper()
    nGp_W = _A_poly_in(Gp_list, nu_W).upper()
    nGp_s = _A_poly_in(Gp_list, n_s).upper()
    # ||P(a) - P(b)|| <= (sum_j |P_j| j nu^{j-1}) · ||a - b||  при ||a||,||b|| <= nu
    dG_lip = arb(0)
    xp = arb(1)
    for i in range(1, len(Gc_list)):
        dG_lip = dG_lip + abs(Gc_list[i]) * arb(i) * xp
        xp = xp * nu_W
    dGp_lip = arb(0)
    xp = arb(1)
    for i in range(1, len(Gp_list)):
        dGp_lip = dGp_lip + abs(Gp_list[i]) * arb(i) * xp
        xp = xp * nu_W

    # M matrix (raw, no r^j scaling) and tail_cols
    M = []
    tail_cols = []
    for k in range(N_p + 1):
        if k == 0:
            e_k = arb_poly([arb(1)])
        else:
            e_k = arb_poly([arb(0)] * k + [arb(1) / (r_arb ** k)])
        DF_e_k = DF_at_ell(e_k)
        coeffs_head = [DF_e_k[j] for j in range(N_p + 1)]
        M.append(coeffs_head)

        # Da_v, coef — локальные, нужны для прямого res и Коши-хвоста
        v_at_1 = e_k(arb(1) - c_arb)
        Da_v_k = v_at_1 / G_at_1_sq
        coef_k = -ell_box * abar_inv_ellp1 * Da_v_k
        Ds_v = arb_poly([c_arb * coef_k, coef_k])

        # Прямое res до N_MAX
        inv_rk = arb(1) / (r_arb ** k) if k else arb(1)
        v_of_s_ext = _trunc(s_pow_ext[k] * inv_rk, N_MAX)
        inner_ext = _trunc(v_of_s_ext + _trunc(Gp_s_long_ext * Ds_v, N_MAX), N_MAX)
        DW_v_ext = _trunc(ell_box * _trunc(Ulm_long_ext * inner_ext, N_MAX), N_MAX)
        v_of_W_ext = _trunc(W_pow_ext[k] * inv_rk, N_MAX)
        res_ext = _trunc(e_k + Da_v_k * GC_W_long_ext
                         + abar * (v_of_W_ext + _trunc(Gp_W_long_ext * DW_v_ext, N_MAX)),
                         N_MAX)
        # Суммируем Σ_{j=N_p+1}^{N_MAX} |res_j| r^j
        tail_direct = arb(0)
        for j in range(N_p + 1, min(res_ext.degree(), N_MAX) + 1):
            tail_direct = tail_direct + abs(res_ext[j]) * (r_arb ** j)

        # E_trunc: цена замены W и U^{l-1} их усечениями на N_W.  res зависит
        # от них через G_c(W-c), (W-c)^k/r^k, G'_c(W-c) и U^{l-1}; inner
        # (v_of_s, G'_c(s-c), Ds_v) — точные полиномы от s, усечений нет.
        n_vos = (n_s ** k * inv_rk).upper()
        n_Ds = (abs(coef_k) * (abs(c_arb) + r_arb)).upper()
        n_inner = (n_vos + nGp_s * n_Ds).upper()
        dv_W = (arb(k) * nu_W ** (k - 1) * tail_hW * inv_rk).upper() if k else arb(0)
        # G'(f)g - G'(f_h)g_h = (G'(f)-G'(f_h))·g + G'(f_h)·(g-g_h)
        d_term5 = (abs(ell_box) * n_inner
                   * (dGp_lip * tail_hW * nu_U + nGp_W * tail_hUlm1)).upper()
        E_trunc = (abs(Da_v_k) * dG_lip * tail_hW
                   + abs(abar) * (dv_W + d_term5)).upper()

        # T_L: хвост за N_MAX по ВСЕМ членам, минимум по сетке L
        T_lam = None
        for LD in LAM:
            A_vos = (LD['A_s'] ** k * inv_rk).upper()
            A_voW = (LD['A_W'] ** k * inv_rk).upper()
            A_Ds = (abs(coef_k) * LD['cR']).upper()
            A_inner = (A_vos + LD['A_Gps'] * A_Ds).upper()
            A_DW = (abs(ell_box) * LD['A_U'] * A_inner).upper()
            tot = (abs(Da_v_k) * LD['A_GW']
                   + abs(abar) * (A_voW + LD['A_GpW'] * A_DW)).upper()
            v = (LD['pow'] * tot).upper()
            if T_lam is None or v < T_lam:
                T_lam = v

        tail_cols.append(tail_direct + E_trunc + T_lam)

    # Transpose to M[j][k]
    M_T = [[M[k][j] for k in range(N_p + 1)] for j in range(N_p + 1)]

    return {
        'G_c': G_c,
        'G_c_prime': G_c_prime,
        'abar': abar,
        'G_at_1': G_at_1,
        'G_at_1_sq': G_at_1_sq,
        'Ubar_u_coeffs': Ubar_u_coeffs,
        's_c_minus_c': s_c_minus_c,
        'U_c': U_c,
        'W_P': W_P,
        'W_c_shifted': W_c_shifted,
        'U_pow_lm1': U_pow_lm1,
        'tail_hW': tail_hW,
        'tail_hUlm1': tail_hUlm1,
        'M_full': M_T,
        'tail_cols': tail_cols,
        'u0': u0,
        'ell_box': ell_box,
    }


# ====================== Ã via numpy LU (cached, reused) ======================

def build_A_tilde(pkg):
    M_raw = np.zeros((N_p + 1, N_p + 1))
    for j in range(N_p + 1):
        for k in range(N_p + 1):
            M_raw[j, k] = arb_mid(pkg['M_full'][j][k])
    M_e = M_raw * (r_arb.mid() ** np.arange(N_p + 1))[:, None]
    M_prime = np.zeros((N_p, N_p))
    c_mid = c_arb.mid()
    r_mid = r_arb.mid()
    for j in range(1, N_p + 1):
        for k in range(1, N_p + 1):
            M_prime[j - 1, k - 1] = M_e[j, k] - (-c_mid / r_mid) ** k * M_e[j, 0]
    from scipy.linalg import lu_factor, lu_solve
    LU, piv = lu_factor(M_prime)
    A_tilde = np.zeros((N_p, N_p))
    for col in range(N_p):
        e_col = np.zeros(N_p)
        e_col[col] = 1.0
        x_col = lu_solve((LU, piv), e_col)
        A_tilde[:, col] = x_col
    A_norm1 = float(np.max(np.sum(np.abs(A_tilde), axis=0)))
    # v6/F6: directed arb upper bound of ‖Ã‖₁ — the float nearest-rounding sum
    # could undershoot the exact 1-norm. arb(float(·)) is exact; column sums
    # are balls; take the max of exact upper endpoints (F2 pattern).
    A_norm1_up = arb(0)
    for col in range(N_p):
        s = arb(0)
        for row in range(N_p):
            s = s + abs(arb(float(A_tilde[row, col])))
        s_up = s.upper()
        if s_up > A_norm1_up:
            A_norm1_up = s_up
    return A_tilde, A_norm1, A_norm1_up


# ====================== Z₁ ======================

def compute_Z1(pkg, A_tilde, A_norm1, beta_C=None, beta_kappa=None,
                 strict_consts=None, verbose=False):
    """Compute Z₁ = Z1a + Z1b + Z1c.

    If strict_consts is provided, Z1c uses the STRICT arb-formula β̂_{N_p+1}
    from beta_bound_lib.beta_bound_ell (v6: general interval ℓ).
    Otherwise it falls back to the float-fit C·κ^{N_p+1} (legacy).

    strict_consts dict (general ℓ, from build_strict_consts_from_pkg):
        A_abs_abar, q, q_s, norm_Gprime_W, norm_U_lm1, norm_Gprime_s,
        norm_T_ell, norm_G_of_W, G_at_1_sq, ell_box  (all as arb).
    """
    M_full_raw = pkg['M_full']
    tail_cols_e = pkg['tail_cols']
    A_tilde_arb = [[arb(float(A_tilde[j][k])) for k in range(N_p)] for j in range(N_p)]
    # v6/F6: A_norm1 may arrive as an exact arb upper bound (A_norm1_up)
    A_norm1_arb = A_norm1 if isinstance(A_norm1, arb) else arb(A_norm1)

    M_e = [[M_full_raw[j][k] * r_arb ** j for k in range(N_p + 1)] for j in range(N_p + 1)]
    M_prime = [[None] * N_p for _ in range(N_p)]
    for j in range(N_p):
        for k in range(N_p):
            jj, kk = j + 1, k + 1
            M_prime[j][k] = M_e[jj][kk] - (-c_arb / r_arb) ** kk * M_e[jj][0]

    # Z1a — v6/F2: directed max. The certified `col_sum > Z1a` on overlapping
    # balls was undecidable for ALL columns on interval ℓ, silently leaving
    # Z1a = 0 (honest value ~1e-3..5e-3). Upper bound of a max = max of exact
    # upper endpoints (decidable comparisons, no candidate ever dropped).
    Z1a = arb(0)
    for k in range(N_p):
        col_sum = arb(0)
        for j in range(N_p):
            am_jk = arb(0)
            for l in range(N_p):
                am_jk = am_jk + A_tilde_arb[j][l] * M_prime[l][k]
            am_jk = (arb(1) if j == k else arb(0)) - am_jk
            col_sum = col_sum + abs(am_jk)
        cs_up = col_sum.upper()
        if cs_up > Z1a:
            Z1a = cs_up

    # Z1b — v6/F2: same directed-max fix for the tail-column fold
    max_tail_prime = arb(0)
    for k in range(1, N_p + 1):
        tail_pk = tail_cols_e[k] + (c_arb / r_arb) ** k * tail_cols_e[0]
        tp_up = tail_pk.upper()
        if tp_up > max_tail_prime:
            max_tail_prime = tp_up
    Z1b = A_norm1_arb * max_tail_prime

    # Z1c — STRICT β̂_{N_p+1}; v6/F0: general-ℓ formula (was beta_bound_l25
    # with hardcoded ℓ=5/2 factor and ‖U^{3/2}‖ at every ℓ)
    if strict_consts is not None:
        from beta_bound_lib import beta_bound_ell
        beta_Np1, *_ = beta_bound_ell(N_p + 1, strict_consts)
        if verbose:
            print(f"  [Z1c strict] β̂_{N_p+1} = {beta_Np1}")
    else:
        C_beta = arb(float(beta_C))
        kappa_beta = arb(float(beta_kappa))
        beta_Np1 = C_beta * kappa_beta ** (N_p + 1)
    diff_e0 = [M_e[j][0] - (arb(1) if j == 0 else arb(0)) for j in range(N_p + 1)]
    beta_0_star = arb(0)
    for j in range(N_p + 1):
        beta_0_star = beta_0_star + abs(diff_e0[j])
    # TAIL-FIX-B0 (18.08): b-колонка несёт слагаемое (-c/r)^k*DF(e0) ЦЕЛИКОМ
    # (см. tail_pk = tail_cols_e[k] + (c/r)^k*tail_cols_e[0] в фолде Z1b выше,
    # где tail_cols_e[0] — это ровно хвостовые строки j > N_p той же колонки
    # DF(e0), с тем же масштабом r^j, что и M_e). beta_0_star выше суммирует
    # только головные строки j <= N_p (M_e хранит только их). Недостающая
    # хвостовая масса строк j > N_p колонки e0 — это tail_cols_e[0].
    beta_0_star = beta_0_star + tail_cols_e[0]
    Z1c = (arb(1) + A_norm1_arb) * (beta_Np1 + (c_arb / r_arb) ** (N_p + 1) * beta_0_star)

    Z1 = Z1a + Z1b + Z1c
    return Z1, Z1a, Z1b, Z1c


def build_strict_consts_from_pkg(pkg, xn):
    """Extract strict β-formula constants from pkg + xn for Z1c (general ℓ)."""
    return {
        'c': c_arb,
        'r': r_arb,
        'A_abs_abar': xn['A_abs_abar'],
        'q': xn['q'],
        'q_s': xn['q_s'],
        'norm_U_lm1': xn['norm_U_lm1'],
        'norm_Gprime_W': xn['norm_Gprime_W'],
        'norm_Gprime_s': xn['norm_Gprime_s'],
        'norm_T_ell': xn['norm_T_ell'],
        'norm_G_of_W': xn['norm_G_of_W'],
        'G_at_1_sq': pkg['G_at_1_sq'],
        'ell_box': pkg['ell_box'],
    }


# ====================== X-norms + β-kappa fit ======================

def _binom_abs_series(a, kap, N=120, with_n=False):
    """Строгая сумма ряда из МОДУЛЕЙ обобщённых биномиальных коэффициентов.

        with_n=False:  Σ_{n≥0} |C(a,n)|·κ^n        — мажоранта ‖(1+v)^a‖
        with_n=True:   Σ_{n≥1} n·|C(a,n)|·κ^{n−1}  — липшицева константа
                                                     v ↦ (1+v)^a на ‖v‖ ≤ κ

    Обе нужны потому, что для НЕЦЕЛОЙ степени субмультипликативность
    банаховой алгебры не работает: знаки C(a,n) чередуются, и ‖U^a‖ может
    быть больше ‖U‖^a (при a = 1.5, U = 1 + 0.5z отношение 1.00895).

    Хвост: при n > a верно |C(a,n+1)|/|C(a,n)| = (n−a)/(n+1) < 1, значит
    |C(a,n)| убывает и |C(a,n)| ≤ |C(a,N)| при n ≥ N.  Тогда
        Σ_{n≥N} κ^n        ≤ κ^N/(1−κ),
        Σ_{n≥N} n·κ^{n−1}  ≤ (N κ^{N−1} − (N−1) κ^N)/(1−κ)².
    Требуется κ < 1 и N > sup a; на [2,4] хватает N = 120.
    """
    if not (kap < arb(1)):
        return None
    if not (arb(N) > a):
        return None
    total = arb(0)
    cn = arb(1)                       # C(a,0)
    kp = arb(1)                       # κ^n  (или κ^{n−1} при with_n)
    if not with_n:
        total = cn * kp
    for n in range(1, N):
        cn = cn * (a - arb(n - 1)) / arb(n)
        if with_n:
            total = total + arb(n) * abs(cn) * kp     # kp = κ^{n−1}
            kp = kp * kap
        else:
            kp = kp * kap
            total = total + abs(cn) * kp
    # хвост от n = N
    cN = cn * (a - arb(N - 1)) / arb(N)
    kN = kp if with_n else kp * kap                   # κ^{N−1} либо κ^N
    one_m = 1 - kap
    if with_n:
        tail = abs(cN) * (arb(N) * kN - arb(N - 1) * kN * kap) / one_m ** 2
    else:
        tail = abs(cN) * kN / one_m
    return (total + tail).upper()


def compute_x_norms_and_beta(pkg):
    G_c = pkg['G_c']
    G_c_prime = pkg['G_c_prime']
    W_c_shifted = pkg['W_c_shifted']
    s_c_minus_c = pkg['s_c_minus_c']
    U_c = pkg['U_c']
    U_pow_lm1 = pkg['U_pow_lm1']
    ell_box = pkg['ell_box']

    # TRUNC-TAIL (18.08): W_c_shifted и U_pow_lm1 — ряды Миллера, ОБРЕЗАННЫЕ
    # на N_W = 192, поэтому x_norm от них занижает истинную X-норму на хвост.
    # Коши-хвосты по окружности |t−c| = 1.2 пакет уже считает в build_pkg_fast;
    # величины порядка 10⁻³³, но без них это не верхние границы.
    # (U_c усечения не имеет: это композиция полиномов, степень ровно N_G.)
    # Хвост ДОБАВЛЯЕТСЯ к шару, а не заменяет его: `.upper()` здесь схлопывал
    # бы шар в точку, и опубликованная мажоранта q поехала бы ВНИЗ на 3·10⁻⁹
    # (радиус arb хранится 30-битным числом и при делении округляется наружу,
    # так что (шар/r).upper() > шар.upper()/r).  Мажоранта не имеет права
    # уменьшаться от правки, даже оставаясь верной.
    norm_W_c_shifted = x_norm(W_c_shifted) + pkg['tail_hW']
    q = norm_W_c_shifted / r_arb
    norm_U_strict = x_norm(U_c)
    norm_s_c_minus_c = x_norm(s_c_minus_c)
    q_s = norm_s_c_minus_c / r_arb
    norm_U_sq = x_norm(U_c * U_c)
    norm_U_lm1 = x_norm(U_pow_lm1) + pkg['tail_hUlm1']
    # TRUNC-TAIL: W_c_shifted — ОБРЕЗАННЫЙ ряд Миллера (N_W), поэтому
    # композиции с ним тоже недооценены на Lip(.;nu_W)*tail_hW.
    # Пропуск <= 1.7e-34 (G') и <= 6.5e-34 (G) — на 23 порядка ниже
    # радиуса самих arb-шаров этих величин, поэтому верхние концы
    # де-факто остаются мажорантами; по ПОСТРОЕНИЮ, однако, поправки нет.
    norm_Gprime_W = x_norm(G_c_prime(W_c_shifted))
    norm_Gprime_s = x_norm(G_c_prime(s_c_minus_c))
    # v6/F0: ‖(u+c)·ℓ·ᾱ^{−(ℓ+1)}‖ at the TRUE ℓ (was (5/2)·ᾱ^{−7/2} = ℓ=2.5)
    norm_T_ell = (c_arb + r_arb) * ell_box * pkg['abar'] ** (-(ell_box + arb(1)))
    # TRUNC-TAIL, см. замечание выше у norm_Gprime_W.
    norm_G_of_W = x_norm(G_c(W_c_shifted))
    A_abs_abar = abs(pkg['abar'])

    # v6/F0: ℓ·‖Ū^{ℓ−1}‖ (was (5/2)·‖Ū^{3/2}‖)
    ELL_factor = ell_box * norm_U_lm1

    n_extra = 20
    beta_k_bounds = []
    for k in range(N_p + 1, N_p + 1 + n_extra):
        ql_k = q ** k
        qs_k = q_s ** k
        d1 = arb(1) / arb(2) ** k
        term1 = A_abs_abar * ql_k
        term2 = A_abs_abar * norm_Gprime_W * ELL_factor * (
            qs_k + norm_Gprime_s * norm_T_ell * d1)
        term3 = d1 * norm_G_of_W / pkg['G_at_1_sq']
        beta_k_bounds.append(term1 + term2 + term3)

    # Fit log-linear
    log_betas = []
    ks = list(range(N_p + 1, N_p + 1 + len(beta_k_bounds)))
    for k, b in zip(ks, beta_k_bounds):
        mid = float(b)
        if mid > 0:
            log_betas.append((k, math.log(mid)))
        else:
            log_betas.append((k, -1000))
    if len(log_betas) >= 2:
        A_mat = sum(1 for _, _ in log_betas)
        B_mat = sum(k for k, _ in log_betas)
        C_mat = sum(k * k for k, _ in log_betas)
        D_mat = sum(lb for _, lb in log_betas)
        E_mat = sum(k * lb for k, lb in log_betas)
        det = A_mat * C_mat - B_mat * B_mat
        if det != 0:
            a = (D_mat * C_mat - B_mat * E_mat) / det
            b = (A_mat * E_mat - B_mat * D_mat) / det
            C_fit = math.exp(a)
            kappa_fit = math.exp(b)
        else:
            C_fit = None
            kappa_fit = None
    else:
        C_fit = None
        kappa_fit = None

    return {
        'q': q,
        'q_s': q_s,
        'norm_U_strict': norm_U_strict,
        'norm_s_c_minus_c': norm_s_c_minus_c,
        'norm_U_sq': norm_U_sq,
        'norm_U_lm1': norm_U_lm1,
        'norm_Gprime_W': norm_Gprime_W,
        'norm_Gprime_s': norm_Gprime_s,
        'norm_T_ell': norm_T_ell,
        'norm_G_of_W': norm_G_of_W,
        'A_abs_abar': A_abs_abar,
        'C_fit': C_fit,
        'kappa_fit': kappa_fit,
        'norm_W_c_shifted': norm_W_c_shifted,
    }


# ====================== F̄ + Y₀ ======================

def compute_F_poly(a64_arb, ell_box):
    """Compute F̄ at interval ell_box (N_ALG=192) — poly part only."""
    G_at_1 = arb(0)
    for ak in a64_arb:
        G_at_1 = G_at_1 + ak
    abar = -arb(1) / G_at_1

    G_c = arb_poly(a64_arb)
    G_c = G_c(arb_poly([c_arb, arb(1)]))

    abar_ell = abar ** ell_box
    abar_inv_ell = abar_ell ** (-1)
    Ubar_at_t = [a64_arb[k] * (abar_inv_ell ** k) for k in range(N_G + 1)]
    Ubar_u_coeffs = reexpand_fast(Ubar_at_t, c_arb, r_arb, N_G)
    u_padded = list(Ubar_u_coeffs) + [arb(0)] * (N_W - N_G)
    W_P, W_P_list = miller_power_fast(u_padded, ell_box, N_W, c_arb, r_arb)
    w_c_list = list(W_P_list)
    w_c_list[0] = w_c_list[0] - c_arb

    # Horner
    res_list = [G_c[N_G]]
    for k in range(N_G - 1, -1, -1):
        new_len = len(res_list) + len(w_c_list) - 1
        new_res = [arb(0)] * new_len
        for i in range(len(res_list)):
            for j in range(len(w_c_list)):
                new_res[i + j] = new_res[i + j] + res_list[i] * w_c_list[j]
        res_list = new_res
        if len(res_list) > N_ALG + 1:
            res_list = res_list[:N_ALG + 1]
        while len(res_list) < 1:
            res_list.append(arb(0))
        res_list[0] = res_list[0] + G_c[k]

    F_poly_list = [ck * abar for ck in res_list]
    F_total_list = list(G_c)
    while len(F_total_list) < len(F_poly_list):
        F_total_list.append(arb(0))
    for k in range(len(F_poly_list)):
        F_total_list[k] = F_total_list[k] + F_poly_list[k]
    if len(F_total_list) > N_ALG + 1:
        F_total_list = F_total_list[:N_ALG + 1]
    return arb_poly(F_total_list)


def compute_F_tail_bound(a64_arb, ell_box):
    """v6/F4: strict upper bound on the truncated tail Σ_{k>N_ALG}|F̄_k|·r^k
    for the CURRENT ℓ-box and CURRENT seed (v5 hardcoded 1.56e-33 — the
    wave3 constant for ℓ=2.5 and a foreign seed).

    Math. F̄ = Ḡ + ᾱ·H with H = Ḡ_c∘(W̄−c); Ḡ_c has degree ≤ N_p ≤ N_ALG, so
    the truncated mass comes from ᾱ·H only. Miller yields the EXACT Taylor
    coefficients of the analytic branch W̄ = Ū^ℓ up to degree N_W, and the
    head (≤ N_ALG ≤ N_W) of Ḡ_c∘(truncated w) equals the head of Ḡ_c∘(W̄−c)
    — every term containing the W̄-tail has degree > N_W. Hence the missing
    mass is exactly the Cauchy tail of the analytic H on |t−c| ≤ R:
        Σ_{k>N}|H_k|·r^k ≤ M_H·(r/R)^{N+1}/(1−r/R),
        M_H = sup_{|t−c|=R}|H| ≤ Σ_j |g_j|·M̃^j,     M̃ = M_W_R + c,
        M_W_R = sup_{|t−c|=R}|Ū^ℓ| ≤ (Σ_j |g_j|·s_R^j)^ℓ   (disk majorant),
        s_R = |c·(ᾱ^{−ℓ}−1)| + R·ᾱ^{−ℓ} ≥ sup_{|t−c|=R}|t·ᾱ^{−ℓ}−c|.
    The disk majorant is orders looser than the arc max but the result stays
    ~1e-31..1e-33 vs Y₀ ~1e-5 — cheap and honest. Analyticity of the branch
    (Ū avoiding (−∞,0]) is the same inherited Lemma-U assumption wave3 used.

    Returns an arb upper bound (ball), or None if ᾱ is not certified > 0.
    """
    R = arb("1.20")
    G_at_1 = arb(0)
    for ak in a64_arb:
        G_at_1 = G_at_1 + ak
    abar = -arb(1) / G_at_1
    if not (abar > 0):
        return None
    G_c = arb_poly(a64_arb)
    G_c = G_c(arb_poly([c_arb, arb(1)]))
    inv_ae = (abar ** ell_box) ** (-1)
    s_R = abs(c_arb * (inv_ae - arb(1))) + R * inv_ae

    def gabs_at(x):
        s = arb(0)
        xp = arb(1)
        for j in range(len(G_c)):
            s = s + abs(G_c[j]) * xp
            xp = xp * x
        return s

    M_U_R = gabs_at(s_R)
    if not (M_U_R > 0):
        return None
    M_W_R = M_U_R ** ell_box
    M_H = gabs_at(M_W_R + c_arb)
    ratio = r_arb / R
    tail = abs(abar) * M_H * ratio ** (N_ALG + 1) / (1 - ratio)
    return tail


def compute_Y0(F_total_poly, A_tilde, F_tail):
    """v6/F4: F_tail is now a REQUIRED argument (per-step honest bound from
    compute_F_tail_bound); v5 buried the wave3 ℓ=2.5 constant here."""
    F_coefs = [F_total_poly[k] for k in range(len(F_total_poly))]
    F_N = len(F_coefs)

    f_tilde_head = [F_coefs[k] * r_arb ** k for k in range(1, N_p + 1)]
    A_f = [arb(0)] * N_p
    for j in range(N_p):
        s = arb(0)
        for k in range(N_p):
            s = s + arb(float(A_tilde[j][k])) * f_tilde_head[k]
        A_f[j] = s
    Y0_part1 = arb(0)
    for j in range(N_p):
        Y0_part1 = Y0_part1 + abs(A_f[j])

    Y0_part2 = arb(0)
    for k in range(N_p + 1, F_N):
        Y0_part2 = Y0_part2 + abs(F_coefs[k]) * r_arb ** k

    Y0 = Y0_part1 + Y0_part2 + F_tail
    return Y0


# ====================== L-chain + gates ======================

def try_rho_prime_and_L(pkg, xn, Y0, Z1, A_norm1,
                         target_rho_prime=arb("3.5e-5")):
    """Returns dict with chosen rho_prime, L_strict, Z_hat, gate5_lhs, rho_star — or None.

    Per BRIEF-TUBE-V3-MX.md §2: target ρ̂' ≈ 3.5e-5. We search the grid in
    decreasing order starting from 3.5e-5, falling back to smaller values if
    3.5e-5 doesn't satisfy the gates.
    """
    A_norm1_arb = arb(A_norm1)
    # Grid ordered: try 3.5e-5 first (target), then 3e-5, larger, then smaller.
    rho_prime_grid = [
        arb("3.5e-5"), arb("5e-5"), arb("3e-5"), arb("5e-4"), arb("1e-4"),
        arb("1e-3"), arb("1e-5"), arb("1e-6"), arb("1e-7"), arb("1e-8"),
        arb("1e-9"), arb("1e-10"), arb("1e-11"), arb("1e-12"), arb("1e-13"),
    ]
    for rho_prime in rho_prime_grid:
        gate_pkg = _compute_L(pkg, xn, rho_prime)
        if gate_pkg is None:
            continue
        L_strict = gate_pkg['L_strict']
        Z_hat = Z1 + arb("1.75") ** 2 * A_norm1_arb * L_strict * rho_prime
        if not (Z_hat < arb(1)):
            continue
        g5_lhs = Y0 + Z_hat * rho_prime
        if g5_lhs <= rho_prime:
            rho_star = Y0 / (arb(1) - Z_hat)
            return {
                'rho_prime': rho_prime,
                'rho_X': arb("1.75") * rho_prime,
                'Z_hat': Z_hat,
                'gate5_lhs': g5_lhs,
                'rho_star': rho_star,
                'L_strict': L_strict,
                'gate_pkg': gate_pkg,
            }
    return None


def _compute_L(pkg, xn, rho_prime):
    """Strict Lipschitz chain for DF on B_X(â, ρ_X), ρ_X = 1.75·ρ̂′.

    v6/F0: general interval ℓ. Every ℓ=2.5-specialized constant of v5 is
    replaced by its ℓ-role, pinned by the two proven reference chains
    (wave5_fixL/compute_fixL — ℓ=3; wave6_kant_l25/step4_L_and_final — ℓ=2.5):
        5/2 → ℓ,  ᾱ^{−7/2} → ᾱ^{−(ℓ+1)},  (·)^{3/2} → (·)^{ℓ−1},
        Hbar/DH exponents −7/2, −9/2 → −(ℓ+1), −(ℓ+2),
        DH first factor (5/2)·7 = 2·ℓ·(ℓ+1) — kept with the factor 2 so v6
        dominates BOTH references (wave5 used ℓ·(ℓ+1); wave6 used 2·ℓ·(ℓ+1)).
    MVT lower ends use (ᾱ − δα) (v5 used ᾱ itself — v6 is more conservative).
    Domain checks are certified ACCEPTANCE (`not (x < y) → None`), so an
    undecidable comparison rejects instead of passing through.
    """
    G_c = pkg['G_c']
    G_c_prime = pkg['G_c_prime']
    G_at_1 = pkg['G_at_1']
    U_c_poly = pkg['U_c']
    ell = pkg['ell_box']

    m1 = abs(G_at_1)
    Gprime_norm = x_norm(G_c_prime)
    t_norm = c_arb + r_arb
    rho_X = arb("1.75") * rho_prime
    if not (m1 - rho_X > 0):
        return None

    abs_alpha_diff = rho_X / (m1 * (m1 - rho_X))
    abar_lo = pkg['abar'] - abs_alpha_diff
    if not (abar_lo > 0):
        return None
    # |δ(ᾱ^{−ℓ})| ≤ ℓ·(ᾱ−δα)^{−(ℓ+1)}·δα   (MVT, min of the base)
    abs_alpha_inv_diff = ell * abar_lo ** (-(ell + arb(1))) * abs_alpha_diff
    abs_s_diff = t_norm * abs_alpha_inv_diff
    U_diff = rho_X + Gprime_norm * abs_s_diff

    norm_U_strict = xn['norm_U_strict']
    norm_U_lm1 = xn['norm_U_lm1']
    norm_W_c_shifted = xn['norm_W_c_shifted']

    # FRAC-POW (18.08).  Здесь стояло ℓ·(‖Ū‖+ΔU)^{ℓ−1}·ΔU со ссылкой на MVT.
    # Для ЦЕЛОЙ степени это верно, для нецелой — нет: субмультипликативность
    # банаховой алгебры не переносится на дробные степени (у C(a,n) знаки
    # чередуются, и ‖U^a‖ бывает больше ‖U‖^a).  Правильная форма — MVT в
    # интегральном виде:
    #     U_G^ℓ − U_P^ℓ = ℓ∫₀¹ (U_P+θH)^{ℓ−1} H dθ,   H = U_G − U_P,
    # законная потому, что спектр каждого U_P+θH лежит в |w−1| ≤ κ_U < 1, то
    # есть в правой полуплоскости, где z^ℓ однозначна.  Отсюда
    #     ‖W_G − W̄‖ ≤ ℓ·(‖Ū^{ℓ−1}‖ + S(ℓ−1,κ_U)·ΔU)·ΔU,
    # где ‖Ū^{ℓ−1}‖ — настоящая норма (её движок и так считает), а
    # S — липшицева константа разложения вокруг единицы.  При целом ℓ обе
    # формулы совпадают тождественно.
    kap_U = (x_norm(U_c_poly - arb_poly([arb(1)])) + U_diff).upper()
    if not (kap_U < arb(1)):
        return None
    lip_lm1 = _binom_abs_series(ell - arb(1), kap_U, with_n=True)
    if lip_lm1 is None:
        return None
    W_diff = ell * (norm_U_lm1 + lip_lm1 * U_diff) * U_diff
    q_hat = (norm_W_c_shifted + W_diff) / r_arb
    if not (q_hat < arb(1)):
        return None
    CD2 = (1 - q_hat) ** (-2)
    compos_diff = CD2 * W_diff / r_arb
    kappa = q_hat * r_arb

    def LG_at(kappa_local, poly):
        s = arb(0)
        for k in range(1, len(poly)):
            s = s + arb(k) * abs(poly[k]) * (kappa_local ** (k - 1))
        return s

    LG_qr = LG_at(kappa, G_c)
    LGp_qr = LG_at(kappa, G_c_prime)
    norm_s_c_minus_c = xn['norm_s_c_minus_c']
    kappa_s = norm_s_c_minus_c + abs_s_diff
    if not (kappa_s < r_arb):
        return None
    CD2s = (1 - kappa_s / r_arb) ** (-2)
    LG_s = LG_at(kappa_s, G_c)
    LGp_s = LG_at(kappa_s, G_c_prime)

    NDelta_p = lambda kap: (rho_X / r_arb) * (1 - kap / r_arb) ** (-2)
    NDelta_qr = NDelta_p(kappa)
    NDelta_ks = NDelta_p(kappa_s)

    Delta_alpha2 = 2 * rho_X / (m1 - rho_X) ** 3
    norm_G_of_W = xn['norm_G_of_W']
    norm_Gprime_W = xn['norm_Gprime_W']
    norm_Gprime_s = xn['norm_Gprime_s']

    T2 = (1 / m1 ** 2) * (rho_X + LG_qr * W_diff) + Delta_alpha2 * (norm_G_of_W + rho_X + LG_qr * W_diff)
    abs_abar = abs(pkg['abar'])
    T3 = abs_alpha_diff + abs_abar * CD2 * W_diff / r_arb

    Abar = abs_abar
    DA = abs_alpha_diff
    Bbar = norm_Gprime_W
    DB = NDelta_qr + LGp_qr * W_diff
    # C = ℓ·Ū^{ℓ−1}:  C̄ = ℓ·‖Ū^{ℓ−1}‖   (ℓ=3: 3·‖Ū²‖, ℓ=2.5: (5/2)·‖Ū^{3/2}‖)
    Cbar = ell * norm_U_lm1
    # ΔC — та же поправка, что и в W_diff: скалярная степень нормы заменена
    # рядом из модулей биномиальных коэффициентов вокруг единицы.  Здесь
    # ‖Ū^{ℓ−2}‖ отдельно не считается, поэтому берётся мажоранта
    # Σ_{n≥0}|C(ℓ−2,n)|κ_U^n; ΔC входит в DT4 малой поправкой (порядка 10⁻⁵
    # от Cbar), так что запас формулы роли не играет.
    nrm_lm2 = _binom_abs_series(ell - arb(2), kap_U)
    lip_lm2 = _binom_abs_series(ell - arb(2), kap_U, with_n=True)
    if nrm_lm2 is None or lip_lm2 is None:
        return None
    DC = ell * (ell - arb(1)) * (nrm_lm2 + lip_lm2 * U_diff) * U_diff
    Dbar_up = arb(1)
    DD = CD2s * abs_s_diff / r_arb

    DT4 = DA * (Bbar + DB) * (Cbar + DC) * (1 + DD) + Abar * (
        DB * (Cbar + DC) * (1 + DD) + Bbar * (DC * (1 + DD) + Cbar * DD)
    )

    Ebar = norm_Gprime_s
    DE = NDelta_ks + LGp_s * abs_s_diff
    # H = (u+c)·(−ℓ·ᾱ^{−(ℓ+1)})·(v(1)/G(1)²);  ‖u+c‖_X = c+r = t_norm
    Hbar_up = ell * (Abar - DA) ** (-(ell + arb(1))) * t_norm * (1 / m1 ** 2 + Delta_alpha2)
    DH = t_norm * (
        2 * ell * (ell + arb(1)) * (Abar - DA) ** (-(ell + arb(2))) * DA * (1 / m1 ** 2)
        + ell * (Abar - DA) ** (-(ell + arb(1))) * Delta_alpha2
    )

    def delta_product(bars, deltas):
        prod_A_plus_dA = arb(1)
        prod_Abar = arb(1)
        for ab, da in zip(bars, deltas):
            prod_A_plus_dA = prod_A_plus_dA * (ab + da)
            prod_Abar = prod_Abar * ab
        return prod_A_plus_dA - prod_Abar

    bars_T5 = [Abar, Bbar, Cbar, Ebar, Hbar_up]
    deltas_T5 = [DA, DB, DC, DE, DH]
    DT5 = delta_product(bars_T5, deltas_T5)

    D_total = T2 + T3 + DT4 + DT5
    L_strict = D_total / rho_X

    return {
        'L_strict': L_strict,
        'q_hat': q_hat,
        'kap_U': kap_U,
        'kappa_s': kappa_s,
        'W_diff': W_diff,
        'U_diff': U_diff,
        'D_total': D_total,
        'T2': T2,
        'T3': T3,
        'DT4': DT4,
        'DT5': DT5,
        'rho_X': rho_X,
        'CD2': CD2,
        'CD2s': CD2s,
    }


# ====================== Lemma U verification ======================

def verify_lemma_U(a64_arb, ell_box):
    """Lemma U on |t-c|=R=1.2 with M=64 arcs."""
    from lemma_domains import verify_lemma_1
    G_c = arb_poly(a64_arb)
    G_c = G_c(arb_poly([c_arb, arb(1)]))
    G_c_coeffs = [G_c[k] for k in range(len(G_c))]
    abar = -arb(1) / sum(a64_arb)
    alpha_ell = abar ** ell_box

    res = verify_lemma_1(
        G_poly_coeffs=G_c_coeffs,
        alpha=abar,
        ell=ell_box,
        c=c_arb,
        r=r_arb,
        R=arb("1.20"),
        M=M_ARCS_LEMMA,
    )
    # NONZERO: Re U > 0 на обеих окружностях обязателен.  Отсюда по
    # гармоничности Re U минимум достигается на границе, значит Re U > 0 во
    # всём круге; отсюда U не имеет нулей (рекуррентность Миллера для
    # W = U^ell не встречает особенности) и главная ветвь Log U однозначна.
    OK = (res['margin_a'] > 0 and
          res['margin_c'] > 0 and
          bool(res.get('nonzero_ok')) and
          (res['U_min'] is not None and res['U_min'] >= arb("0.5")))
    return res, OK
