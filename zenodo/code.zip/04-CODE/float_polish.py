#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
float_polish.py — Pure-float (mpmath) seed polishing, ported from wave11.

Per BRIEF-KIT-V5.md §1: the polish is PURE-float (no arb in the polish
loop). The orchestrator's no_qn recommendation was rejected because ARB
mixing in the polish loop pollutes the accept-test with interval widths
that blow up in the 1/r^k · C(j,k) basis recomputation.

Wave11 (working) implementation uses:
  - Miller/residual in arb with immediate .mid() drop (no interval carried)
  - basis shift (u ↔ c) and Newton correction in mpmath dps=40
  - basis-shift via Taylor reexpand (mpmath)
  - Damping factors {1, 0.5, 0.25, ...} for accept-test

Bench: 1.08 s/polish; residual 7e-6 → 1e-7 per iter.
"""
import sys, os, time
import numpy as np
import mpmath

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tube_lib import N_G, N_p, N_ALG, c_arb, r_arb
from flint import arb as _flint_arb
from tube_lib import compute_F_poly as _compute_F_poly_arb


FLOAT_POLISH_DPS = 40
DAMPING_FACTORS = (1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125)
R_FLOAT_MP = mpmath.mpf('0.8')
C_FLOAT_MP = mpmath.mpf('0.6')


def _mpf_from_arb(x):
    """Drop an arb to mpmath via midpoint."""
    if hasattr(x, 'mid'):
        return mpmath.mpf(x.mid())
    return mpmath.mpf(x)


def _float_reexpand(coeffs, c, N):
    """mpmath Taylor shift to new center c. coeffs at origin; returns coeffs
    at c with length N+1.
    """
    out = []
    for k in range(N + 1):
        s = mpmath.mpf(0)
        binom = mpmath.mpf(1)
        for j in range(k, len(coeffs)):
            if j > k:
                binom = binom * j / (j - k)
            s += coeffs[j] * binom * (c ** (j - k))
        out.append(s)
    return out


def _quick_resid_float(a_mpf_ext, ell_pt_float, n_check=40):
    """Float (mpmath) residual norm for accept-test.

    Recomputes F̄ via the same Miller/Horner pipeline as the kit's arb
    compute_F_poly, then drops to mpmath immediately (.mid() per coord).
    """
    a_arb = [_flint_arb(mpmath.nstr(x, FLOAT_POLISH_DPS)) for x in a_mpf_ext]
    F = _compute_F_poly_arb(a_arb, _flint_arb(ell_pt_float))
    s = mpmath.mpf(0)
    r_f = R_FLOAT_MP
    for k in range(min(n_check, len(F))):
        s += abs(_mpf_from_arb(F[k])) * (r_f ** k)
    return float(s)


def newton_step_float(a_mpf_ext, ell_point_float, A_tilde, k_cutoff=40):
    """Single Newton step in pure mpmath (no arb in the loop).

    a_mpf_ext: list of N_p+1 mpmath.mpf, ORIGIN basis.
    Returns: list of N_p+1 mpmath.mpf, ORIGIN basis.
    """
    mpmath.mp.dps = FLOAT_POLISH_DPS
    c_f = C_FLOAT_MP
    r_f = R_FLOAT_MP
    neg_c_over_r_f = -c_f / r_f

    a_arb = [_flint_arb(mpmath.nstr(x, FLOAT_POLISH_DPS)) for x in a_mpf_ext]
    F_poly = _compute_F_poly_arb(a_arb, _flint_arb(ell_point_float))
    F_coefs = [_mpf_from_arb(F_poly[k]) if k < len(F_poly) else mpmath.mpf(0)
               for k in range(N_p + 1)]
    f_tilde_head = [F_coefs[k] * (r_f ** k) for k in range(1, N_p + 1)]

    # A · f_tilde_head (mpmath)
    A_f = [mpmath.mpf(0)] * N_p
    for j in range(N_p):
        s = mpmath.mpf(0)
        for k in range(N_p):
            s += mpmath.mpf(float(A_tilde[j][k])) * f_tilde_head[k]
        A_f[j] = s

    # Shift a (origin) → h (c-center)
    h_cur = _float_reexpand(a_mpf_ext, c_f, N_p)

    # δv in c-coords: dv[k] = -A_f[k-1] (with k_cutoff) for k=1..N_p
    dv = [mpmath.mpf(0)] * (N_p + 1)
    for k in range(1, N_p + 1):
        dv[k] = -A_f[k - 1] if k <= k_cutoff else mpmath.mpf(0)
    dv0 = mpmath.mpf(0)
    for k in range(1, N_p + 1):
        dv0 -= dv[k] * (neg_c_over_r_f ** k)
    dv[0] = dv0

    # Convert dv (c-coords) → δh (origin)
    dh = [dv[k] / (r_f ** k) for k in range(N_p + 1)]
    h_new = [h_cur[k] + dh[k] for k in range(N_p + 1)]

    # Shift h_new (c-coords) → a_new (origin)
    a_new = _float_reexpand(h_new, -c_f, N_p)
    return a_new


def float_polish_step(a, ell_mid_float, A_tilde, max_iter=3, tol=1e-12,
                      k_cutoff=40, verbose=False):
    """Pure-mpmath Newton polish (1–3 iters), with damping accept-test.

    a: list/array of N_p+1 mpmath or float (converted to mpmath internally).
    ell_mid_float: float — evaluation point.
    A_tilde: np.ndarray (N_p, N_p) — cached inverse Jacobian.
    Returns: (a_polished, info)
        a_polished: np.ndarray of length N_p+1, mpmath-cast to float for output
                    (downstream arb compute_F_poly handles the precision).
        info: dict with iter_count, residual_norms, deltas, method.
    """
    mpmath.mp.dps = FLOAT_POLISH_DPS

    # Convert input to mpmath (list of N_p+1)
    if hasattr(a, 'tolist'):
        a_list = [mpmath.mpf(float(x)) for x in a.tolist()]
    else:
        a_list = [mpmath.mpf(float(x)) for x in a]
    # Pad/truncate to N_p+1
    if len(a_list) < N_p + 1:
        a_list = a_list + [mpmath.mpf(0)] * (N_p + 1 - len(a_list))
    a_list = a_list[:N_p + 1]

    info = {'iter_count': 0, 'residual_norms': [], 'deltas': [], 'method': 'float'}

    try:
        best_a = list(a_list)
        best_resid = _quick_resid_float(best_a, ell_mid_float)
    except Exception as e:
        if verbose:
            print(f"  [polish] initial resid failed: {e}", flush=True)
        # return original as numpy
        return np.array([float(x) for x in a_list], dtype=np.float64), info

    info['residual_norms'].append(best_resid)
    if verbose:
        print(f"  [polish it 0] ‖F̃‖₁ = {best_resid:.3e}", flush=True)

    a_cur = best_a
    for it in range(max_iter):
        if best_resid < tol:
            break
        try:
            a_full = newton_step_float(a_cur, ell_mid_float, A_tilde, k_cutoff=k_cutoff)
        except Exception as e:
            if verbose:
                print(f"  [polish] step failed: {e}", flush=True)
            break

        accepted = False
        for lam in DAMPING_FACTORS:
            try:
                if lam == 1.0:
                    a_try = a_full
                else:
                    a_try = [a_cur[k] + lam * (a_full[k] - a_cur[k]) for k in range(N_p + 1)]
                resid_try = _quick_resid_float(a_try, ell_mid_float)
            except Exception:
                continue
            if resid_try < best_resid:
                best_a = a_try
                best_resid = resid_try
                a_cur = a_try
                accepted = True
                info['deltas'].append(float(np.max(np.abs(np.array(
                    [float(a_full[k] - a_cur[k]) for k in range(N_p + 1)])))))
                break
        info['residual_norms'].append(best_resid)
        info['iter_count'] = it + 1
        if verbose:
            print(f"  [polish it {it + 1}] ‖F̃‖₁ = {best_resid:.3e} (lam={lam})", flush=True)
        if not accepted:
            break

    a_out = np.array([float(x) for x in best_a], dtype=np.float64)
    return a_out, info


if __name__ == '__main__':
    print("float_polish.py: import smoke test OK")