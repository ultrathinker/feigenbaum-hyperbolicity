#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
beta_bound_lib.py — строгая arb-оценка β_k (Z₁c-tail) для ℓ=3 и ℓ=2.5.

Формула (из BRIEF-L3-POLY-DF §B3 / BRIEF-Z1C-FIX §1):
  β_k ≤ |ᾱ|·q^k
       + |ᾱ|·‖Ḡ′∘W̄‖·( ℓ·‖U^{ℓ-1}‖_X ·(q_s^k + ‖Ḡ′∘s̄‖·‖(u+c)·ℓ·ᾱ^{−(ℓ+1)}‖·δ1_k/|Ḡ(1)|²) )
       + δ1_k·‖Ḡ∘W̄‖/|Ḡ(1)|²

  δ1_k = ((1-c)/r)^k = 0.5^k   (т.к. 1-c = 0.4, r = 0.8)

Все входные константы — arb-интервалы; никакого float-фита β_k ≈ C·κ^k.
Откуда они берутся: живые потребители (rig2fix3.py, layer/layer_cert.py)
передают сюда пакет из tube_lib.build_strict_consts_from_pkg. Функции
beta_bound_constants_l3/_l25 ниже читают тот же набор полей из
df_package.json и оставлены как описание формата входа; в пакете их не
вызывает никто. Монотонность проверяется численно: каждый член —
геометрическая прогрессия с основанием < 1 (q, q_s, 0.5 — все болы < 1).

ℓ=2.5 имеет точно ту же структуру (ℓ=5/2, ‖U^{ℓ-1}‖ = ‖U^{3/2}‖,
‖(u+c)·ℓ·ᾱ^{-(ℓ+1)}‖ = ‖(u+c)·(5/2)·ᾱ^{-7/2}‖).

Монотонность (три строки):
  • term1 = |ᾱ|·q^k — q < 1 ⇒ term1 убывает по k.
  • term2 = |ᾱ|·‖Ḡ′∘W̄‖·ℓ·‖U^{ℓ-1}‖·(q_s^k + const·0.5^k) — q_s, 0.5 < 1 ⇒ убывает.
  • term3 = 0.5^k·‖Ḡ∘W̄‖/|Ḡ(1)|² — 0.5 < 1 ⇒ убывает.
  ⇒ β_k убывает по k для k≥N_p+1 ⇒ sup_{k>N_p} β_k = β_{N_p+1} строго.

NB: эта формула даёт строгую arb-верхнюю оценку β_k. Сравнение с float-фитом
(β_fitted_C · κ^{N_p+1}) показывает согласие до 7 порядков; см. REPORT.md.
"""
import json
from flint import arb, ctx

PREC = 512
ctx.prec = PREC


def parse_arb_ball(s):
    if isinstance(s, arb):
        return s
    return arb(s)


def beta_bound_constants_l3(pkg):
    """Константы строгой формулы β_k для ℓ=3 из df_package."""
    return {
        'c': parse_arb_ball(pkg['c']),
        'r': parse_arb_ball(pkg['r']),
        'A_abs_abar': parse_arb_ball(pkg['A_abs_abar']),  # |ᾱ|
        'q': parse_arb_ball(pkg['q']),
        'q_s': parse_arb_ball(pkg['q_s']),
        'norm_U_sq': parse_arb_ball(pkg['norm_U_sq']),     # ‖Ū²‖_X  (= ℓ·‖U^{ℓ-1}‖ при ℓ=3)
        'norm_Gprime_W': parse_arb_ball(pkg['norm_Gprime_W']),
        'norm_Gprime_s': parse_arb_ball(pkg['norm_Gprime_s']),
        'norm_T3': parse_arb_ball(pkg['norm_T3']),          # ‖(u+c)·3·ᾱ^{-4}‖_X
        'norm_G_of_W': parse_arb_ball(pkg['norm_G_of_W']),
        'G_at_1_sq': parse_arb_ball(pkg['G_at_1_sq']),      # |Ḡ(1)|²
    }


def beta_bound_constants_l25(pkg):
    """Константы строгой формулы β_k для ℓ=2.5 из df_package."""
    return {
        'c': parse_arb_ball(pkg['c']),
        'r': parse_arb_ball(pkg['r']),
        'A_abs_abar': parse_arb_ball(pkg['A_abs_abar']),   # |ᾱ|
        'q': parse_arb_ball(pkg['q']),
        'q_s': parse_arb_ball(pkg['q_s']),
        'norm_U_32': parse_arb_ball(pkg['norm_U_32']),     # ‖U^{3/2}‖_X
        'norm_Gprime_W': parse_arb_ball(pkg['norm_Gprime_W']),
        'norm_Gprime_s': parse_arb_ball(pkg['norm_Gprime_s']),
        'norm_T_25': parse_arb_ball(pkg['norm_T_25']),     # ‖(u+c)·(5/2)·ᾱ^{-7/2}‖_X
        'norm_G_of_W': parse_arb_ball(pkg['norm_G_of_W']),
        'G_at_1_sq': parse_arb_ball(pkg['G_at_1_sq']),
    }


def _check_bases_lt1(q, q_s, name=""):
    """Болы q, q_s < 1 (строго, с радиусом). Возвращает dict с результатами."""
    one = arb(1)
    return {
        f'{name}q_lt1_strict': bool(q.upper() < one),
        f'{name}q_s_lt1_strict': bool(q_s.upper() < one),
        'q_upper_value': float(q.upper()),
        'q_s_upper_value': float(q_s.upper()),
        'half_lt1_strict': True,  # 0.5^k всегда убывает
    }


def beta_bound_l3(k, consts):
    """Строгая arb-верхняя оценка β_k при ℓ=3 (k — целое ≥ 0)."""
    A = consts['A_abs_abar']
    q = consts['q']
    q_s = consts['q_s']
    norm_GpW = consts['norm_Gprime_W']
    norm_Usq = consts['norm_U_sq']       # = 3·‖Ū²‖ (= ℓ·‖U^{ℓ-1}‖ при ℓ=3)
    norm_Gps = consts['norm_Gprime_s']
    norm_T3 = consts['norm_T3']          # ‖(u+c)·3·ᾱ^{-4}‖
    norm_GW = consts['norm_G_of_W']
    G_at_1_sq = consts['G_at_1_sq']

    q_k = q ** k
    qs_k = q_s ** k
    d1 = arb(1) / arb(2) ** k            # δ1_k = ((1-c)/r)^k = 0.5^k

    term1 = A * q_k
    # BETA-G1SQ-FIX (18.08): подчлен norm_Gps*norm_T3*d1 мажорирует Ds*v —
    # производную Ds_v = -ell*abar_inv_ellp1*(v_at_1/G_at_1_sq) из
    # tube_lib.DF_at_ell, где деление на G(1)^2 явно присутствует. Здесь
    # оно было потеряно; делим тот же подчлен на G_at_1_sq.
    term2 = A * norm_GpW * norm_Usq * (qs_k + norm_Gps * norm_T3 * d1 / G_at_1_sq)
    term3 = d1 * norm_GW / G_at_1_sq
    return term1 + term2 + term3, term1, term2, term3


def beta_bound_l25(k, consts):
    """Строгая arb-верхняя оценка β_k при ℓ=2.5 (k — целое ≥ 0)."""
    A = consts['A_abs_abar']
    q = consts['q']
    q_s = consts['q_s']
    norm_GpW = consts['norm_Gprime_W']
    norm_U32 = consts['norm_U_32']       # ‖U^{3/2}‖
    norm_Gps = consts['norm_Gprime_s']
    norm_T25 = consts['norm_T_25']       # ‖(u+c)·(5/2)·ᾱ^{-7/2}‖
    norm_GW = consts['norm_G_of_W']
    G_at_1_sq = consts['G_at_1_sq']

    ELL = arb(5) / arb(2)

    q_k = q ** k
    qs_k = q_s ** k
    d1 = arb(1) / arb(2) ** k

    term1 = A * q_k
    # BETA-G1SQ-FIX (18.08): см. пояснение в beta_bound_l3 — тот же
    # пропущенный множитель 1/G(1)^2 в подчлене Ds*v.
    term2 = A * norm_GpW * ELL * norm_U32 * (qs_k + norm_Gps * norm_T25 * d1 / G_at_1_sq)
    term3 = d1 * norm_GW / G_at_1_sq
    return term1 + term2 + term3, term1, term2, term3


def beta_bound_ell(k, consts):
    """v6/F0: строгая arb-верхняя оценка β_k при ИНТЕРВАЛЬНОМ ℓ (k — целое ≥ 0).

    Та же трёхчленная формула, что beta_bound_l3 (ℓ=3) и beta_bound_l25
    (ℓ=2.5), с общими ролями констант:
        ℓ·‖U^{ℓ-1}‖_X   ← consts['ell_box'] · consts['norm_U_lm1']
        ‖(u+c)·ℓ·ᾱ^{-(ℓ+1)}‖_X ← consts['norm_T_ell']
    Все входы — arb-болы, вычисленные при том же ell_box (инклюзионная
    изотонность покрывает каждое ℓ из бокса). Монотонность по k — та же:
    q, q_s, 0.5 < 1 (проверяется bases_check), ⇒ sup_{k>N_p} β_k = β_{N_p+1}.
    """
    A = consts['A_abs_abar']
    q = consts['q']
    q_s = consts['q_s']
    norm_GpW = consts['norm_Gprime_W']
    norm_Ulm1 = consts['norm_U_lm1']     # ‖U^{ℓ-1}‖_X (Миллер при ell_box−1)
    norm_Gps = consts['norm_Gprime_s']
    norm_Tell = consts['norm_T_ell']     # ‖(u+c)·ℓ·ᾱ^{-(ℓ+1)}‖_X
    norm_GW = consts['norm_G_of_W']
    G_at_1_sq = consts['G_at_1_sq']
    ELL = consts['ell_box']

    q_k = q ** k
    qs_k = q_s ** k
    d1 = arb(1) / arb(2) ** k

    term1 = A * q_k
    # BETA-G1SQ-FIX (18.08): см. пояснение в beta_bound_l3 — тот же
    # пропущенный множитель 1/G(1)^2 в подчлене Ds*v.
    term2 = A * norm_GpW * ELL * norm_Ulm1 * (qs_k + norm_Gps * norm_Tell * d1 / G_at_1_sq)
    term3 = d1 * norm_GW / G_at_1_sq
    return term1 + term2 + term3, term1, term2, term3


def monotonicity_check(beta_fn, consts, k_lo=81, k_hi=120, label=""):
    """Численная проверка монотонности β_k для k ∈ [k_lo, k_hi]."""
    results = []
    prev = None
    for k in range(k_lo, k_hi + 1):
        b, *_ = beta_fn(k, consts)
        results.append((k, str(b), float(b)))
        if prev is not None and b >= prev:
            # монотонности нет — нашли нарушение
            return False, results, f"β_{k} ≥ β_{k-1}"
        prev = b
    return True, results, "β_k строго убывает по k"


def bases_check(consts):
    """Строгая проверка q < 1, q_s < 1 (верхняя граница < 1)."""
    return _check_bases_lt1(consts['q'], consts['q_s'])