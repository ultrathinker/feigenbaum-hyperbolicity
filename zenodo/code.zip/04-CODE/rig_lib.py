# -*- coding: utf-8 -*-
"""
rig_lib.py — RIGOROUS (arb) parameterized Kantorovich certificate for the
fixed-point equation F(G, l) = G + alpha*G(W), alpha = -1/G(1), on an
l-box of width w, with polynomial-in-l center P(l) and interpolated
inverse A~(l).

Scheme (mirrors the engine's tube_lib.py semantics exactly; the engine
lives alongside this file in 04-CODE and is imported read-only and reused
for all point-l evaluations):

  unknowns   : x in X0 coords (u-coords at c=0.6, r=0.8, rows/cols 1..N_p)
  center     : P(l) = Chebyshev interp of degree m of the branch, a_0 = 1 EXACT
  inverse    : A~(l) = Chebyshev interp of degree m of inv(M'(l_j)) at nodes
  gate       : Y0 + Zhat*rho' <= rho',  Zhat = Z1sup + 1.75^2 * B_A * L * rho'

  Y0  <= sum_i |v1_i|_1 + Tail_v1 + w2_sup + Ftail_sup
         v1(l) = A~(l) F~(P(l), l)   (analytic in l; Q-node Chebyshev interp)
  Z1  <= sum_i colsum|Z_i| + Tail_Z + Z1bc_sup
         Z(l)  = I - A~(l) M'(P(l), l) (matrix; Q-node Chebyshev interp)
  Tail_* <= 2*B(eta)*rho_ell^{-(Q+1)}/(1-rho_ell^{-1}),  B from complex-l
         disk majorants (|sigma| <= eta), rho_ell = (eta+sqrt(eta^2+h^2))/h.
  L    : engine _compute_L at interval l over the FULL box, center P(l_mid),
         radius rho_X + DeltaP (DeltaP = sup_l |P(l)-P(l_mid)|_X).

The theorem certified: for EVERY l in the box, F~(.,l) has a zero in
B_X(P(l), 1.75*rho') (same projected-system semantics as the march gates).
"""
import io, sys, os, math, time, json
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import tube_lib as tl
from flint import arb, acb, ctx, arb_poly
import fp_lib as fl

ctx.prec = 512

NP = tl.N_p
NG = tl.N_G
C = tl.c_arb
R = tl.r_arb


def plog(logfile, msg):
    line = time.strftime('%H:%M:%S ') + msg
    print(line, flush=True)
    with open(logfile, 'a', encoding='utf-8') as f:
        f.write(line + '\n')


# ------------------------------------------------------------------ #
# Chebyshev machinery (arb)
# ------------------------------------------------------------------ #

def cheb_nodes_arb(n, l0, w):
    """Gauss-Chebyshev nodes as exact-ish arb points (l_j, x_j)."""
    out = []
    for j in range(n):
        th = arb.pi() * (arb(2 * j + 1)) / arb(2 * n)
        x = (th).cos()
        out.append((l0 + (w / 2) * x, x))
    return out


def clenshaw_arb(coefs, x):
    """Clenshaw: p(x) = c_0/2 + sum_{k>=1} c_k T_k(x) (c_0 stored UNHALVED)."""
    m = len(coefs) - 1
    if m == 0:
        return coefs[0] / 2
    b1 = arb(0)
    b2 = arb(0)
    for k in range(m, 0, -1):
        b0 = 2 * x * b1 - b2 + coefs[k]
        b2, b1 = b1, b0
    return x * b1 - b2 + coefs[0] / 2


def clenshaw_np(coefs, x):
    """float Clenshaw, p = c_0/2 + sum_{k>=1} c_k T_k (c_0 stored UNHALVED)."""
    m = coefs.shape[-1] - 1
    b1 = np.zeros(coefs.shape[:-1])
    b2 = np.zeros_like(b1)
    for k in range(m, 0, -1):
        b0 = 2 * x * b1 - b2 + coefs[..., k]
        b2, b1 = b1, b0
    return x * b1 - b2 + coefs[..., 0] / 2


def interp_matrix_arb(n):
    """Q = n x n matrix with rows [T_k(x_j)] for the n Gauss nodes (arb).
    Used to map nodal values -> cheb coefficients: c = (2/n) * M @ vals."""
    M = []
    nodes = cheb_nodes_arb(n, arb(0), arb(2))  # x_j in [-1,1]
    for j in range(n):
        xj = nodes[j][1]
        row = []
        Tkm2 = arb(1)
        Tkm1 = xj
        for k in range(n):
            row.append(Tkm2 if k == 0 else (Tkm1 if k == 1 else None))
            if k >= 1:
                Tnew = 2 * xj * Tkm1 - Tkm2
                Tkm2, Tkm1 = Tkm1, Tnew
        # fill Nones
        filled = []
        Tkm2 = arb(1)
        Tkm1 = xj
        for k in range(n):
            if k == 0:
                filled.append(arb(1))
            elif k == 1:
                filled.append(xj)
            else:
                Tnew = 2 * xj * filled[k - 1] - filled[k - 2]
                filled.append(Tnew)
        M.append(filled)
    return M, nodes


def cheb_coeffs_from_vals(vals, n):
    """vals: list of n arb vectors (or matrices as nested lists) at the n
    Gauss nodes. Returns cheb coefficients (c_0 HALVED convention), same
    nested structure, as arb."""
    M, _ = interp_matrix_arb(n)
    # c_k = (2/n) * sum_j T_k(x_j) * vals_j ; c_0 halved
    def scale(obj, fac):
        if isinstance(obj, arb):
            return obj * fac
        return [scale(o, fac) for o in obj]

    def combine(terms):
        """sum of list of like-structured arb objects"""
        def add2(a, b):
            if isinstance(a, arb):
                return a + b
            return [add2(x, y) for x, y in zip(a, b)]
        acc = terms[0]
        for t in terms[1:]:
            acc = add2(acc, t)
        return acc

    out = []
    for k in range(n):
        fac = (arb(2) / n) if k > 0 else (arb(1) / n)
        terms = [scale(vals[j], M[j][k]) for j in range(n)]
        out.append(scale(combine(terms), fac))
    return out


def vec1_norm(v):
    s = arb(0)
    for x in v:
        s = s + abs(x)
    return s


def mat_colnorm1(M):
    """max over columns of sum_j |M[j][k]| (lists of lists, arb)."""
    ncol = len(M[0])
    best = arb(0)
    for k in range(ncol):
        s = arb(0)
        for j in range(len(M)):
            s = s + abs(M[j][k])
        if s > best:
            best = s
    return best


# ------------------------------------------------------------------ #
# Branch sampling (float) and polynomial objects
# ------------------------------------------------------------------ #

def build_branch(ell0, w, m_nodes, a_seed):
    """Solve the branch at m_nodes Chebyshev nodes (float64 via fp_lib).
    Returns dict with nodal solutions and Chebyshev coefficients of the
    0-center coefficients (a_0 == 1 kept EXACT), plus node values."""
    ls = fl.cheb_nodes(m_nodes, ell0, w)
    order = np.argsort(np.abs(ls - ell0))
    a_sols = {}
    a0, _ = fl.solve_fixed_point(a_seed, ell0)
    a_sols[ell0] = a0
    for j in order:
        lj = float(ls[j])
        if lj in a_sols:
            continue
        best = min(a_sols.keys(), key=lambda k: abs(k - lj))
        a, info = fl.solve_fixed_point(a_sols[best], lj)
        if info['resid'][-1] > 1e-13:
            raise RuntimeError('node solve failed at l=%.10f resid %.1e' % (lj, info['resid'][-1]))
        a_sols[lj] = a
    A_nodes = np.zeros((m_nodes, NP + 1))
    Minv_nodes = np.zeros((m_nodes, NP, NP))
    for idx in range(m_nodes):
        A_nodes[idx] = a_sols[ls[idx]]
        op = fl.Op(a_sols[ls[idx]], ls[idx])
        _, Mp = fl.build_Mprime(op, NP)
        Minv_nodes[idx] = np.linalg.inv(Mp)
    c_a = fl.cheb_fit(A_nodes)
    c_a[0, 0] = 2.0     # a_0(l) == 1 EXACT  <=> c_0 = 2, c_{i>=1} = 0
    c_a[1:, 0] = 0.0
    c_A = fl.cheb_fit(Minv_nodes)
    return {'ls': ls, 'a_nodes': A_nodes, 'Minv_nodes': Minv_nodes,
            'c_a': c_a, 'c_A': c_A}


def P_at(c_a, m, x_arb):
    """Evaluate P(l) (0-center coeffs, length NP+1) at Chebyshev arg x (arb).
    Returns list of arb. Uses only degrees <= m."""
    out = []
    for k in range(NP + 1):
        coefs = [arb(c_a[i, k]) for i in range(m + 1)]
        coefs[0] = arb(c_a[0, k])
        if m >= 1:
            pass
        out.append(clenshaw_arb(coefs, x_arb))
    out[0] = arb(1)  # exact normalization
    return out


def P_at_interval(c_a, m, x_int):
    """P over an x-interval [lo,hi] (arb intervals): coefficient intervals."""
    out = []
    for k in range(NP + 1):
        coefs = [arb(c_a[i, k]) for i in range(m + 1)]
        out.append(clenshaw_arb(coefs, x_int))
    out[0] = arb(1)
    return out


def Atilde_at(c_A, m, x_float):
    """float evaluation of the interpolated inverse at Chebyshev arg x."""
    return clenshaw_np(np.transpose(c_A[:m + 1], (1, 2, 0)), x_float)


# ------------------------------------------------------------------ #
# Point-l engine evaluation (head pieces)
# ------------------------------------------------------------------ #

def point_eval(P_list, ell_pt):
    """Full engine evaluation at a POINT l. Returns dict:
       Ftilde (list NP of arb), F_head_tail (sum_{N_p<k<=N_ALG} |F_k| r^k),
       Mprime (NPxNP arb lists), pkg."""
    pkg = tl.build_pkg_fast(P_list, ell_pt)
    F_poly = tl.compute_F_poly(P_list, ell_pt)
    Ftilde = [F_poly[k] * (R ** k) for k in range(1, NP + 1)]
    head_tail = arb(0)
    for k in range(NP + 1, len(F_poly)):
        head_tail = head_tail + abs(F_poly[k]) * (R ** k)
    # Mprime from pkg M_full (rows scaled by r^j as in compute_Z1)
    M_full = pkg['M_full']
    mpr = (-C / R)
    Mprime = []
    for j in range(NP):
        jj = j + 1
        rj = R ** jj
        row = []
        for k in range(NP):
            kk = k + 1
            row.append((M_full[jj][kk] - (mpr ** kk) * M_full[jj][0]) * rj)
        Mprime.append(row)
    return {'Ftilde': Ftilde, 'head_tail': head_tail, 'Mprime': Mprime, 'pkg': pkg}


def v1_at(P_list, ell_pt, c_A, m, x_float):
    """v1(l) = A~(l) F~(P(l), l) (NP arb vector) at a point."""
    pe = point_eval(P_list, ell_pt)
    A = Atilde_at(c_A, m, x_float)
    A_arb = [[arb(A[j][k]) for k in range(NP)] for j in range(NP)]
    v1 = []
    for j in range(NP):
        s = arb(0)
        for k in range(NP):
            s = s + A_arb[j][k] * pe['Ftilde'][k]
        v1.append(s)
    return v1, pe


def Zhead_at(P_list, ell_pt, c_A, m, x_float):
    """Z(l) = I - A~(l) M'(P(l), l) as NP x NP arb lists at a point."""
    pe = point_eval(P_list, ell_pt)
    A = Atilde_at(c_A, m, x_float)
    A_arb = [[arb(A[j][k]) for k in range(NP)] for j in range(NP)]
    Z = []
    for j in range(NP):
        row = []
        for k in range(NP):
            s = (arb(1) if j == k else arb(0))
            acc = arb(0)
            for l_ in range(NP):
                acc = acc + A_arb[j][l_] * pe['Mprime'][l_][k]
            row.append(s - acc)
        Z.append(row)
    return Z, pe


# ------------------------------------------------------------------ #
# interval-l evaluations for the small tail pieces
# ------------------------------------------------------------------ #

def interval_tails(c_a, m, ell0, w):
    """Tail pieces over the FULL box with interval-l and interval center
    (loose but these are ~1e-30 scale):
       w2_sup: sum_{k>N_p} |F_k| r^k,  Ftail_sup: engine F tail bound."""
    Pint = P_at_interval(c_a, m, arb(-1).union(arb(1)))
    ell_box = (ell0 - w / 2).union(ell0 + w / 2)
    F_poly = tl.compute_F_poly(Pint, ell_box)
    w2 = arb(0)
    for k in range(NP + 1, len(F_poly)):
        w2 = w2 + abs(F_poly[k]) * (R ** k)
    ft = tl.compute_F_tail_bound(Pint, ell_box)
    if ft is None:
        raise RuntimeError('F tail bound failed (alpha sign)')
    return w2.upper(), ft.upper()


def interval_Z1bc(c_a, m, ell0, w, A_mid, B_A):
    """Z1b + Z1c over the full box (interval-l, interval center pkg).
    B_A (arb upper bound of sup_l ||A~(l)||_1) is used as the A-norm."""
    Pint = P_at_interval(c_a, m, arb(-1).union(arb(1)))
    ell_box = (ell0 - w / 2).union(ell0 + w / 2)
    pkg = tl.build_pkg_fast(Pint, ell_box)
    if pkg is None:
        raise RuntimeError('interval pkg failed')
    xn = tl.compute_x_norms_and_beta(pkg)
    Z1, Z1a, Z1b, Z1c = tl.compute_Z1(pkg, A_mid, B_A,
                                      strict_consts=tl.build_strict_consts_from_pkg(pkg, xn))
    return Z1b.upper(), Z1c.upper(), pkg, xn
