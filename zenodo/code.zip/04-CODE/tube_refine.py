# -*- coding: utf-8 -*-
"""
tube_refine.py — план добивки: боксы, которым не хватает запаса после
добавления члена смещения неподвижной точки (`extra`, см. tube_offset.py).

Критерий приёмки бокса:  R·(‖Δ‖ + extra) < 1.
Здесь для добивки берётся более жёсткий порог MARG (по умолчанию 0.90),
чтобы не переделывать дважды.

Каждый непроходной бокс заменяется ТРЕМЯ боксами половинной ширины с
центрами c−w/4, c, c+w/4: они покрывают ровно тот же отрезок [c−w/2, c+w/2]
и перекрываются между собой на w/4, поэтому ни цепочка, ни покрытие не
рвутся.  ‖Δ‖ при этом падает примерно вдвое.

Запуск: python tube_refine.py [порог] > tube_plan2.txt
"""
import os, sys, json, glob

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
MARG = float(sys.argv[1]) if len(sys.argv) > 1 else 0.90
if not (MARG > 0):
    raise SystemExit('MARG (порог добивки) должен быть > 0 (получено %r)' % MARG)


def load_offsets():
    p = os.path.join(HERE, 'offsets.json')
    if not os.path.exists(p):
        raise SystemExit('нет offsets.json — сначала tube_offset.py')
    return json.load(open(p, encoding='utf-8'))


def extra_for(offs, ell):
    """extra для ℓ: берём максимум по всем боксам существования, которые
    накрывают эту точку (перекрытия есть — берём худший)."""
    cand = [v['extra'] for v in offs.values() if v['lo'] <= ell <= v['hi']]
    if not cand:
        # вне покрытия — берём ближайший бокс
        v = min(offs.values(), key=lambda v: min(abs(v['lo'] - ell), abs(v['hi'] - ell)))
        return v['extra'], False
    return max(cand), True


def main():
    offs = load_offsets()
    recs = []
    for f in glob.glob(os.path.join(HERE, 'tube_out', 'box_*.json')):
        recs.append(json.load(open(f, encoding='utf-8')))
    recs.sort(key=lambda r: r['ell0'])
    bad = []
    for r in recs:
        if not r.get('pass'):
            bad.append((r, None, 'ворота не пройдены'))
            continue
        ex, inside = extra_for(offs, r['ell0'])
        tot = r['R'] * (r['delta_norm'] + ex)
        if tot >= MARG or not inside:
            bad.append((r, tot, 'вне покрытия' if not inside else 'мало запаса'))
    sys.stderr.write('боксов всего %d, на добивку %d (порог %.2f)\n'
                     % (len(recs), len(bad), MARG))
    for r, tot, why in bad:
        w2 = r['w'] / 2
        for j, sh in enumerate((-r['w'] / 4, 0.0, r['w'] / 4)):
            print('%s%s %.6f %.5f %d %d'
                  % (r['tag'], 'abc'[j], r['ell0'] + sh, w2, r['N'], r['K']))
        sys.stderr.write('  %s ell0=%.4f w=%.4f prod=%.4f -> total=%s (%s)\n'
                         % (r['tag'], r['ell0'], r['w'], r.get('prod', -1),
                            ('%.4f' % tot) if tot else 'n/a', why))


if __name__ == '__main__':
    main()
