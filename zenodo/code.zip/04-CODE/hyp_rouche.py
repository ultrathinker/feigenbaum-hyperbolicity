# -*- coding: utf-8 -*-
"""
hyp_rouche.py — СТРОГИЙ сертификат гиперболичности на ℓ-боксе через Руше.

Маршрут доведён до чисел (w=0.007 при ℓ₀=3),
но в его реализации остались две дыры на несущих местах:

  (A) норма резольвенты в узлах считалась `numpy.linalg.solve` во float64,
      то есть R(z_k) — приближение, а не включение; дуговая оценка Неймана
      поверх нестрогого основания строгой не делает;
  (B) возмущение Δ строилось при ЗАФИКСИРОВАННОМ центре P(ℓ₀) с интервальным
      ℓ. Это охватывает движение параметра, но НЕ движение самой неподвижной
      точки вдоль ветви. Пропущен член ‖M(P(ℓ),ℓ) − M(P(ℓ₀),ℓ)‖.
      (В отчёте он назван «завышением»; на самом деле он просто отсутствует.)

Здесь обе дыры закрыты.

Схема
-----
DT(ℓ) = I − M′(P(ℓ), ℓ) — производная оператора ренормализации на слое X₀.
У DT в точке ℓ=3 ровно одно собственное значение вне единичного круга (δ★),
это сертифицировано точечным якорем (§4.7, §5.2).

Теорема Руше в операторной форме: если на контуре Γ нет спектра DT₀ и
    sup_{z∈Γ} ‖(DT₀ − z)⁻¹‖ · ‖Δ‖ < 1,
то DT₀ + Δ имеет столько же собственных значений внутри Γ, сколько DT₀.
Берём Γ = единичная окружность. Тогда «снаружи ровно одно» переносится с
центра бокса на весь бокс, а простота δ получается даром.

(A) R строго: в каждом узле z_k берём ПРИБЛИЖЁННЫЙ обратный A_k (float),
    и в acb считаем E_k = I − A_k(DT₀ − z_k). Если ‖E_k‖₁ < 1, то
        ‖(DT₀ − z_k)⁻¹‖₁ ≤ ‖A_k‖₁ / (1 − ‖E_k‖₁),
    и это ВКЛЮЧЕНИЕ. Между узлами — оценка Неймана по дуге:
        ‖(DT₀ − z)⁻¹‖ ≤ R_k / (1 − |z − z_k|·R_k).

(B) Δ строго: DT считается при ИНТЕРВАЛЬНОМ центре (P_at_interval по ветке)
    и ИНТЕРВАЛЬНОМ ℓ одновременно. Против миллеровской обёртки — подразбиение
    бокса на K частей с максимумом по частям (тот же приём, что вытащил
    сертификат существования).

Запуск:  python hyp_rouche.py <ell0> <w_list> [N_nodes] [K]
Пример:  python hyp_rouche.py 3.0 0.001,0.003,0.005,0.007,0.010
"""
import math
import os, sys, time, json, tempfile
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
# Движок берётся ИЗ ПАКЕТА: умолчание — каталог этого файла (04-CODE), ровно
# как объявлено в таблице переменных 02-REPRODUCE.md. Другое дерево
# подставляется только явным HYP_ENG; если названного каталога нет,
# откатываемся сюда же, чтобы опечатка в переменной не уводила импорт наружу.
ENG = os.environ.get('HYP_ENG', HERE)
if not os.path.isdir(ENG):
    ENG = HERE
# По умолчанию ветки берём из самого пакета.  Прежний умолчательный путь
# 'sweep_out3' — рабочий каталог машины автора, в пакете его нет, и любой
# скрипт без HYP_BRANCHES падал на несуществующем каталоге.
BRANCH_DIR = os.environ.get(
    'HYP_BRANCHES',
    os.path.join(os.path.dirname(ENG), '03-CERTIFICATES', 'branches'))
sys.path.insert(0, ENG)

import fp_lib as fl
import rig_lib as rl
import tube_lib as tl
from flint import arb, acb, acb_mat, ctx

ctx.prec = 256
NP = tl.N_p
C_A, R_A = tl.c_arb, tl.r_arb
MPR = -C_A / R_A

# Раньше журнал открывался на дозапись ПРЯМО В ПАПКЕ МОДУЛЯ, то есть
# сам факт `import hyp_rouche` менял содержимое пакета и ломал сверку с
# манифестом (`_manifest.py verify`).  Проверяющему приходилось делать копию
# движка в отдельной папке только из-за этой строки.  Теперь путь берётся из
# `HYP_LOG`, а по умолчанию журнал пишется во временный каталог ОС.
LOG = open(os.environ.get(
    'HYP_LOG', os.path.join(tempfile.gettempdir(), 'hyp_rouche.log')),
    'a', encoding='utf-8')
# То же соображение (см. выше) для второго выхода CLI-режима
# (main() -> rouche_<ell>.json): раньше он писался прямо в HERE
# (04-CODE, внутрь пакета) без переменной окружения.
ROUCHE_OUT = os.environ.get('HYP_ROUCHE_OUT', tempfile.gettempdir())


def say(s):
    print(s, flush=True)
    LOG.write(s + '\n')
    LOG.flush()


# ------------------------------------------------------------------ DT
def dt_from_pkg(pkg):
    """DT = I − M′ в b-базисе, элементы arb.
       M′[j][k] = r^{j+1}·( M_full[j+1][k+1] − (−c/r)^{k+1}·M_full[j+1][0] )."""
    Mf = pkg['M_full']
    rp = [R_A ** (j + 1) for j in range(NP)]
    mp = [MPR ** (k + 1) for k in range(NP)]
    DT = [[None] * NP for _ in range(NP)]
    for j in range(NP):
        col0 = Mf[j + 1][0]
        for k in range(NP):
            v = rp[j] * (Mf[j + 1][k + 1] - mp[k] * col0)
            DT[j][k] = (arb(1) - v) if j == k else -v
    return DT


def load_box(ell0, w, npz_dir=None, span=None):
    """Ветка бокса: c_a, m.

    span=(lo, hi) — требование ВМЕСТИМОСТИ: годятся только те ветки, чей
    бокс существования целиком накрывает [lo, hi].  Это нужно потому, что
    член смещения `extra` (tube_offset.py) доказан лишь внутри бокса
    существования: если бокс трубки выступает наружу, на выступе оценка
    ничем не обоснована.  Без span выбирается ветка по центру, как раньше.
    """
    sw = npz_dir or BRANCH_DIR
    best = None
    # Порядок os.listdir не гарантирован файловой системой,
    # а критерий выбора ветки использует строгое `>` — при РАВНОМ запасе d
    # выбранная ветка зависела бы от порядка обхода. sorted() делает выбор
    # детерминированным на любой машине.
    for f in sorted(os.listdir(sw)):
        if not f.startswith('branch_') or not f.endswith('.npz'):
            continue
        z = np.load(os.path.join(sw, f))
        e0, ww = float(z['ell0'][0]), float(z['w'][0])
        if span is not None:
            if not (e0 - ww / 2 <= span[0] and span[1] <= e0 + ww / 2):
                continue
        if e0 - ww / 2 <= ell0 <= e0 + ww / 2:
            d = min(ell0 - (e0 - ww / 2), (e0 + ww / 2) - ell0)
            if best is None or d > best[0]:
                best = (d, z, e0, ww, int(z['m'][0]), f)
    if best is None:
        raise RuntimeError('нет ветки, накрывающей ell0=%.5f' % ell0)
    _, z, e0, ww, m, f = best
    return z['c_a'], m, e0, ww, f


def up_float(x):
    """Наименьший double, гарантированно НЕ МЕНЬШИЙ величины x (arb или float).

    Нужна потому, что `float(arb)` округляет к БЛИЖАЙШЕМУ: результат может
    оказаться ниже настоящей верхней границы и перестать быть мажорантой.
    Здесь после конверсии делается шаг вверх, если округление ушло вниз.
    """
    v = arb(x).upper()
    f = float(v)
    if arb(f) < v:
        f = math.nextafter(f, math.inf)
    return f


# --------------------------------------------------------- (A) строгий R
def rigorous_R(DT0, N):
    """Включение sup_{|z|=1} ‖(DT0−z)⁻¹‖₁ через приближённый обратный + Нейман.

    STRICT-UP (18.08).  Прежняя версия теряла строгость в трёх местах, и все
    три невидимы по выходу — ворота проходили, а число переставало быть
    мажорантой:

      * `float(sE.upper())` округляет к БЛИЖАЙШЕМУ, а не вверх; на якорном
        боксе примерно половина из 28 800 столбцовых величин сохранялась
        НИЖЕ настоящей верхней границы;
      * `arc = np.pi/N` во float может оказаться меньше истинного π/N, и
        тогда дуги не накрывают окружность целиком;
      * узлы `np.exp(1j·θ)` лежат на окружности лишь приближённо, и этот
        промах в радиус покрытия не входил.

    Теперь величины остаются arb до самого конца, π/N округляется вверх, а
    расстояние от узла до точной точки окружности `exp(2πik/N)` считается в
    arb и прибавляется к радиусу покрытия.  Поправка порядка 10⁻¹⁶ при запасе
    ворот ~10⁻², но без неё цепочка неравенств не замкнута.

    Возвращает (R, θ) с R — float, округлённым ВВЕРХ (см. up_float).
    """
    mid = np.array([[float(DT0[j][k]) for k in range(NP)] for j in range(NP)])
    R_rig = arb(0)
    worst = None
    arc = (arb.pi() / arb(N)).upper()          # ≥ истинного π/N
    for kk in range(N):
        th = 2 * np.pi * kk / N
        zc = np.exp(1j * th)
        # приближённый обратный — во float, он НЕ часть доказательства
        Ak = np.linalg.inv(mid - zc * np.eye(NP))
        zr = arb('%.17e' % zc.real)
        zi = arb('%.17e' % zc.imag)
        # промах узла мимо точной точки окружности exp(2*pi*i*k/N)
        tk = 2 * arb.pi() * arb(kk) / arb(N)
        dev = (((zr - tk.cos()) ** 2 + (zi - tk.sin()) ** 2).sqrt()).upper()
        Am = acb_mat(NP, NP)
        Bm = acb_mat(NP, NP)
        for j in range(NP):
            for k in range(NP):
                Am[j, k] = acb(arb('%.17e' % Ak[j, k].real),
                               arb('%.17e' % Ak[j, k].imag))
                v = DT0[j][k]
                Bm[j, k] = acb(v - zr if j == k else v,
                               -zi if j == k else arb(0))
        Pm = Am * Bm
        # ВАЖНО: сравнивать надо ВЕРХНИЕ границы. Оператор `>` у arb истинен
        # только при гарантированном превосходстве, поэтому интервал,
        # содержащий ноль, не «больше» нуля, и максимум молча остался бы
        # нулевым.  Держим верхние концы как arb и сравниваем их — они
        # точечные, сравнение однозначно.
        nE = arb(0)
        nA = arb(0)
        for k in range(NP):
            sE = arb(0)
            sA = arb(0)
            for j in range(NP):
                e = Pm[j, k] - (acb(1) if j == k else acb(0))
                sE = sE + abs(e)
                sA = sA + abs(Am[j, k])
            uE = sE.upper()
            if uE > nE:
                nE = uE
            uA = sA.upper()
            if uA > nA:
                nA = uA
        if not (nE < arb(1)):
            raise RuntimeError('нейман не сходится в узле %d: ||E||=%s' % (kk, nE))
        Rk = (nA / (1 - nE)).upper()
        # радиус покрытия вокруг узла: хорда дуги π/N плюс промах узла
        dk = (arc + dev).upper()
        den = 1 - dk * Rk
        if not (den > arb(0)):
            raise RuntimeError('дуговая оценка не работает в узле %d' % kk)
        Rk_arc = (Rk / den).upper()
        if Rk_arc > R_rig:
            R_rig, worst = Rk_arc, th
    return up_float(R_rig), worst


# --------------------------------------------------- (B) строгое ‖Δ‖ по боксу
def rigorous_delta(c_a, m, e0_branch, w_branch, ell0, w, DT0, K):
    """max по K подынтервалам от ‖DT(бокс) − DT₀‖₁, интервальный центр И ℓ.

    STRICT-UP (18.08): столбцовые суммы больше не проходят через
    `float(col.upper())` — округление к ближайшему могло опустить их ниже
    настоящей верхней границы.  Максимум берётся по точечным arb-концам,
    наружу выдаётся arb, округлённый вверх.
    """
    best = arb(0)
    for s in range(K):
        lo = ell0 - w / 2 + w * s / K
        hi = ell0 - w / 2 + w * (s + 1) / K
        xlo = 2.0 * (lo - e0_branch) / w_branch
        xhi = 2.0 * (hi - e0_branch) / w_branch
        Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
        ellb = arb('%.17e' % lo).union(arb('%.17e' % hi))
        pkg = tl.build_pkg_fast(Pint, ellb)
        if pkg is None:
            raise RuntimeError('интервальный пакет не построился (K=%d, s=%d)' % (K, s))
        DTb = dt_from_pkg(pkg)
        for k in range(NP):
            col = arb(0)
            for j in range(NP):
                col = col + abs(DTb[j][k] - DT0[j][k])
            u = col.upper()
            if u > best:
                best = u
    return arb(up_float(best))


def main():
    ell0 = float(sys.argv[1]) if len(sys.argv) > 1 else 3.0
    ws = [float(x) for x in (sys.argv[2] if len(sys.argv) > 2
                             else '0.001,0.003,0.005,0.007,0.010').split(',')]
    if any(not (x > 0) for x in ws):
        raise SystemExit('все ширины w должны быть > 0 (получено %r)' % ws)
    N = int(sys.argv[3]) if len(sys.argv) > 3 else 180
    K = int(sys.argv[4]) if len(sys.argv) > 4 else 4

    say('')
    say('=' * 74)
    say('СТРОГИЙ РУШЕ, ℓ₀=%.5f, узлов на окружности N=%d, подразбиение K=%d'
        % (ell0, N, K))
    say('=' * 74)

    c_a, m, e0b, wb, fname = load_box(ell0, 0.0)
    say('ветка: %s (ℓ₀=%.4f, w=%.3f, m=%d)' % (fname, e0b, wb, m))

    t0 = time.time()
    x0 = 2.0 * (ell0 - e0b) / wb
    P0 = rl.P_at(c_a, m, arb('%.17e' % x0))
    pkg0 = tl.build_pkg_fast(P0, arb('%.17e' % ell0))
    DT0 = dt_from_pkg(pkg0)
    say('DT₀ построен за %.1f с' % (time.time() - t0))

    mid = np.array([[float(DT0[j][k]) for k in range(NP)] for j in range(NP)])
    ev = np.linalg.eigvals(mid)
    ev = ev[np.argsort(-np.abs(ev))]
    n_out = int((np.abs(ev) > 1).sum())
    say('контроль: δ = %.12f, |λ₂| = %.12f, снаружи единичного круга: %d'
        % (ev[0].real, abs(ev[1]), n_out))

    t0 = time.time()
    R_rig, th = rigorous_R(DT0, N)
    say('R (строго, включение) = %.6f   [худший узел θ=%.4f рад, %.0f с]'
        % (R_rig, th, time.time() - t0))
    say('  => допустимое ‖Δ‖ < %.6f' % (1.0 / R_rig))

    rows = []
    say('')
    say('%-9s %-14s %-12s %-8s %-7s' % ('w', '‖Δ‖ (строго)', 'R·‖Δ‖', 'Руше', 'сек'))
    for w in ws:
        t0 = time.time()
        try:
            d = rigorous_delta(c_a, m, e0b, wb, ell0, w, DT0, K)
        except Exception as e:
            say('%-9.4f ОШИБКА %s' % (w, str(e)[:50]))
            continue
        # Было `R_rig * float(d)` — обычное умножение двух
        # уже округлённых вверх чисел, round-to-nearest. В боевом пути
        # (tube_run.py:86-88) та же величина считается строго; здесь
        # приводим к тому же виду, иначе печатаемая ширина w_cert
        # получена нестрогим сравнением.
        prod = up_float(arb(R_rig) * d)
        ok = prod < 1.0
        rows.append({'w': w, 'delta': float(d), 'prod': prod, 'pass': bool(ok)})
        say('%-9.4f %-14.6e %-12.6f %-8s %-7.0f'
            % (w, float(d), prod, 'PASS' if ok else 'FAIL', time.time() - t0))

    good = [r for r in rows if r['pass']]
    w_cert = max((r['w'] for r in good), default=0.0)
    say('')
    say('СЕРТИФИЦИРОВАННАЯ ПОЛУШИРИНА при ℓ₀=%.4f: w = %.4f' % (ell0, w_cert))
    if w_cert > 0:
        say('  бокс покрывает [%.5f, %.5f], длина %.4f'
            % (ell0 - w_cert / 2, ell0 + w_cert / 2, w_cert))
        say('  на [2,4] потребуется ~%d боксов' % int(np.ceil(2.0 / w_cert)))
    json.dump({'ell0': ell0, 'N': N, 'K': K, 'R_rig': R_rig,
               'n_out_at_center': n_out, 'rows': rows, 'w_cert': w_cert},
              open(os.path.join(ROUCHE_OUT, 'rouche_%.4f.json' % ell0), 'w'),
              indent=1)


if __name__ == '__main__':
    main()
