#!/usr/bin/env bash
# Полный пересчёт всех сертификатов пакета с нуля.
#
#   bash rerun_all.sh [число_полос]
#
# Порядок обязателен: существование -> склейка -> смещения -> трубка ->
# приёмка.  Смещения читают сертификаты существования (L, rho*), трубка
# читает ветки, приёмка читает и то и другое.
#
# Прогресс пишется в rerun_progress.log с флашем и временем: фоновый stdout
# буферизуется, и пустой лог неотличим от зависания.
set -u
NL=${1:-12}
PY=${PY:-python}
PKG=$(cd "$(dirname "$0")/.." && pwd)
CODE="$PKG/04-CODE"
# Каталог результатов — ВНЕ пакета: пакет обязан оставаться пригодным
# только на чтение.  Задаётся переменной HYP_RERUN; без неё — во
# временный каталог ОС (тот же принцип, что у CERT_OUT, GLUE_OUT,
# HYP_TUBE_OUT, HYP_LOG и остальных писателей пакета).  Раньше здесь
# по умолчанию стоял $PKG/_rerun — то есть ВНУТРИ пакета, вопреки
# комментарию выше.
OUT="${HYP_RERUN:-${TMPDIR:-/tmp}/renorm_rerun}"
LOG="$OUT/rerun_progress.log"

mkdir -p "$OUT/existence" "$OUT/tube" "$OUT/logs"
: > "$LOG"

say() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOG"; }

# Ветки читают этапы 2-4, а ПИШЕТ их этап 1 (cert.py кладёт branch_*.npz
# в CERT_OUT, ниже это "$OUT/existence").  Раньше здесь стоял каталог
# пакета, и «полный пересчёт» на этапах 2-4 молча читал СТАРЫЕ ветки.
export HYP_BRANCHES="$OUT/existence"
export PYTHONIOENCODING=utf-8
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
export NUMEXPR_NUM_THREADS=2

cd "$CODE"

# ---------------------------------------------------------------- 1. боксы
say "ЭТАП 1/5: существование, 46 боксов, $NL полос"
for L in $(seq 0 $((NL - 1))); do
  # runplan6.sh читает $PYTHON, а этот скрипт — $PY: без явной передачи
  # этап 1 ушёл бы на интерпретатор по умолчанию, а этапы 2-6 — на
  # выбранный пользователем.
  CERT_OUT="$OUT/existence" PYTHON="$PY" bash runplan6.sh "$L" "$NL" \
      > "$OUT/logs/exist_$L.log" 2>&1 &
done
wait
n=$(ls "$OUT/existence"/box_g*.json 2>/dev/null | wc -l)
say "ЭТАП 1/5 готов: боксов $n/46"
[ "$n" -eq 46 ] || { say "ОСТАНОВ: не все боксы существования посчитались"; exit 1; }

# ------------------------------------------------------------- 2. склейка
say "ЭТАП 2/5: склейка"
HYP_CERTS="$OUT/existence" GLUE_OUT="$OUT/existence" \
  "$PY" -u glue.py > "$OUT/logs/glue.log" 2>&1
rc=$?
tail -3 "$OUT/logs/glue.log" | tee -a "$LOG"
# Раньше здесь стоял только `tail`, и
# провалившаяся склейка не останавливала пересчёт — у неё не было
# машинно-видимого сигнала.  Теперь glue.py отдаёт 0/2, и мы его читаем.
[ "$rc" -eq 0 ] || { say "ОСТАНОВ: склейка не прошла (glue.py rc=$rc)"; exit 1; }

# ------------------------------------------------------------ 3. смещения
say "ЭТАП 3/5: смещения (46 строгих ||M'||)"
HYP_CERTS="$OUT/existence" HYP_OFFSETS="$OUT/tube/offsets.json" \
  "$PY" -u tube_offset.py > "$OUT/logs/offsets.log" 2>&1
rc=$?
tail -3 "$OUT/logs/offsets.log" | tee -a "$LOG"
[ "$rc" -eq 0 ] || { say "ОСТАНОВ: смещения не посчитались (tube_offset.py rc=$rc)"; exit 1; }

# -------------------------------------------------------------- 4. трубка
# 706 боксов = tube_plan.txt (696) минус девять, распавшихся на половинки,
# плюс 18 половинок и один добор t0589b.
say "ЭТАП 4/5: трубка, 706 боксов, $NL полос"
PLAN="$OUT/plan_all.txt"
grep -v -E '^t(0025|0033|0041|0049|0057|0065|0073|0081|0089) ' tube_plan.txt > "$PLAN"
cat tube_plan_span.txt tube_plan_fix.txt >> "$PLAN"
say "  в плане строк: $(grep -c . "$PLAN")"
for L in $(seq 0 $((NL - 1))); do
  HYP_TUBE_OUT="$OUT/tube" CERT_OUT="$OUT/tube" \
    "$PY" -u tube_run.py "$L" "$NL" "$PLAN" \
      > "$OUT/logs/tube_$L.log" 2>&1 &
done
wait
n=$(ls "$OUT/tube"/box_t*.json 2>/dev/null | wc -l)
say "ЭТАП 4/5 готов: боксов $n/706"
[ "$n" -eq 706 ] || { say "ОСТАНОВ: посчиталось $n боксов трубки из 706"; exit 1; }

# -------------------------------------------------------------- 5. приёмка
say "ЭТАП 5/5: приёмка"
HYP_TUBE_OUT="$OUT/tube" HYP_OFFSETS="$OUT/tube/offsets.json" \
  HYP_CERTS="$OUT/existence" CERT_OUT="$OUT/logs" \
  "$PY" -u tube_accept.py > "$OUT/logs/accept.log" 2>&1
rc=$?
tail -12 "$OUT/logs/accept.log" | tee -a "$LOG"
[ "$rc" -eq 0 ] || { say "ОСТАНОВ: приёмка трубки не прошла (tube_accept.py rc=$rc)"; exit 1; }
say "ВСЁ ГОТОВО"

# ------------------------------------------------ 6. сводка новых максимумов
# После правок строгости все несущие числа сдвигаются в последних знаках.
# Печатаем максимумы, чтобы обновить статью и приложение A по факту.
say "ЭТАП 6/6: сводка максимумов для статьи"
HYP_CERTS="$OUT/existence" HYP_TUBE_OUT="$OUT/tube" \
  "$PY" -u - <<'PYEOF' 2>&1 | tee -a "$LOG"
import glob, json, os
E = os.environ['HYP_CERTS']; T = os.environ['HYP_TUBE_OUT']
def mx(rows, key, sub=None):
    vals = []
    for r in rows:
        v = (r.get('best') or {}).get(key) if sub else r.get(key)
        if v is not None:
            vals.append((float(v), r.get('tag')))
    return max(vals) if vals else (float('nan'), '-')
ex = [json.load(open(f, encoding='utf-8')) for f in glob.glob(os.path.join(E, 'box_g*.json'))]
tb = [json.load(open(f, encoding='utf-8')) for f in glob.glob(os.path.join(T, 'box_t*.json'))]
print('--- существование (%d) ---' % len(ex))
for k in ('Y0', 'Z1', 'dchk', 'B_A'):
    print('  max %-6s = %.6e  (%s)' % ((k,) + mx(ex, k)))
for k in ('Zhat', 'L', 'rho_star_b', 'rho_star_X'):
    print('  max %-11s = %.6e  (%s)' % ((k,) + mx(ex, k, sub=1)))
print('--- трубка (%d) ---' % len(tb))
for k in ('R', 'delta_norm', 'prod'):
    print('  max %-11s = %.6e  (%s)' % ((k,) + mx(tb, k)))
print('  провалов трубки: %d' % sum(1 for r in tb if not r.get('pass')))
PYEOF
say "СВОДКА ГОТОВА"
