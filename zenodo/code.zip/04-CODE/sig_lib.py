# -*- coding: utf-8 -*-
"""
sig_lib.py — sigma-Taylor (l-dependence) bivariate series engine, arb.

Representation: a sigma-object is  (slices, tau)
  slices[i] : list of arb — t-series (u-coords) coefficient of sigma^i, i <= D
  tau       : arb — bound of  sum_{i>D} ||slice_i||_X * smax^i   (tail mass)
Invariant (SIGMA direction only): for the object as represented at t-cap N,
  sup_{|sigma|<=smax} ||obj||_X <= sum_{i<=D} ||slices[i]||_X smax^i + tau.

The invariant is about the SIGMA tail and nothing else.  It is NOT an
unconditional statement about the true bivariate object: `conv(a, b, N)` drops
t-degrees above N, that mass enters neither `dropped` nor `tau`, and `dropped`
itself is accumulated from already t-truncated slices.  Everything above the
t-cap is paid for OUTSIDE this module, and uniformly in sigma:
`rig2fix3._tails_piece` computes  w2 = sum_{k>N_p} |F_k| r^k  and
`tube_lib.compute_F_tail_bound` at an INTERVAL centre and an INTERVAL ell
spanning the whole box, so the resulting w2_sup / Ftail_sup bound the t-tail
for every ell in the box, hence for every sigma-order at once; the box is
subdivided and the supremum taken piecewise.  Y0 adds them explicitly:
  Y0 = sum_i ||v1_i||_1 smax^i + B_A*tau_F + w2_sup + Ftail_sup.
Read together, `tau` covers the sigma tail inside the t-cap and w2/Ftail cover
everything above it.  A caller that uses `tau` alone as a bound on the true
object, without that external term, is using it outside its contract.

Every operation keeps the sigma-direction invariant:
  mul: slices = exact sigma-convolution of kept slices (cap D); the mass
       dropped by capping is computed EXACTLY from the kept slice norms;
       input taus propagate as  tauA*MB + MA*tauB + tauA*tauB.
  add / scalar ops: obvious.

Base objects (t-series, u-coords, at sigma=0):
  conv(a,b,N)        truncated t-product
  tinv(b0, N)        t-series inverse of b0 (b0[0] != 0)
  tlog_seed(u, N)    Log(u) with L[0] = log(u[0]) and the L'-recursion
  powers of a t-series via repeated convolution.
"""
from flint import arb, ctx


def xnorm(h, r):
    s = arb(0)
    rk = arb(1)
    for k in range(len(h)):
        s = s + abs(h[k]) * rk
        rk = rk * r
    return s


def conv(a, b, N):
    out = [arb(0)] * (N + 1)
    for i in range(min(len(a), N + 1)):
        ai = a[i]
        if ai == 0:
            continue
        jmax = min(len(b), N + 1 - i)
        for j in range(jmax):
            if b[j] != 0:
                out[i + j] = out[i + j] + ai * b[j]
    return out


def tinv(b, N):
    """inverse of t-series b (b[0] != 0), truncated to N."""
    if b[0] == 0:
        raise ZeroDivisionError('tinv: b[0]=0')
    out = [arb(0)] * (N + 1)
    out[0] = 1 / b[0]
    for n in range(1, N + 1):
        s = arb(0)
        for k in range(n):
            if b[n - k] != 0 and out[k] != 0:
                s = s + b[n - k] * out[k]
        out[n] = -s / b[0]
    return out


def tlog(u, N):
    """Log of t-series u (u[0] > 0.5 real positive so the principal branch is
    the continued one). L[0] = log(u[0]); L_n from  U' = L' U."""
    out = [arb(0)] * (N + 1)
    out[0] = u[0].log()
    for n in range(N):
        # coefficient n of U' is (n+1) u_{n+1}
        up = arb(n + 1) * u[n + 1]
        # U' = L' U :  (n+1)L_{n+1} u0 + sum_{j=1..n} j L_j u_{n+1-j}
        s = arb(0)
        for j in range(1, n + 1):
            if out[j] != 0 and u[n + 1 - j] != 0:
                s = s + arb(j) * out[j] * u[n + 1 - j]
        out[n + 1] = (up - s) / (arb(n + 1) * u[0])
    return out


class Sig:
    """sigma-object: slices + tau, with cap D and smax fixed at construction."""
    __slots__ = ('slices', 'tau', 'D', 'smax')

    def __init__(self, slices, tau, smax):
        self.slices = slices
        self.tau = tau
        self.D = len(slices) - 1
        self.smax = smax

    def total_mass(self, r):
        """M = sum_{i<=D} ||slice_i||_X smax^i + tau."""
        s = arb(0)
        for i in range(len(self.slices)):
            s = s + xnorm(self.slices[i], r) * (self.smax ** i)
        return (s + self.tau).upper()

    def supnorm(self, r):
        """sup_{|sigma|<=smax} ||obj(sigma)||_X (upper)."""
        return self.total_mass(r)

    def add(self, other):
        n = max(len(self.slices), len(other.slices))
        sl = []
        for i in range(n):
            a = self.slices[i] if i < len(self.slices) else None
            b = other.slices[i] if i < len(other.slices) else None
            if a is None:
                sl.append(b)
            elif b is None:
                sl.append(a)
            else:
                m = max(len(a), len(b))
                sl.append([(a[k] if k < len(a) else arb(0)) +
                           (b[k] if k < len(b) else arb(0)) for k in range(m)])
        return Sig(sl, self.tau + other.tau, self.smax)

    def scale(self, c):
        """multiply by a scalar arb c (sigma-independent)."""
        return Sig([[c * x for x in sl] for sl in self.slices],
                   abs(c) * self.tau, self.smax)

    def mul(self, other, D, N, r):
        """bivariate product with sigma-cap D and t-cap N."""
        la, lb = len(self.slices), len(other.slices)
        sl = [None] * (D + 1)
        dropped = arb(0)
        # full sigma-convolution mass for i <= la+lb-1; keep i <= D
        for i in range(la + lb - 1):
            acc = None
            for j in range(max(0, i - lb + 1), min(i, la - 1) + 1):
                a = self.slices[j]
                b = other.slices[i - j]
                pr = conv(a, b, N)
                if acc is None:
                    acc = pr
                else:
                    m = max(len(acc), len(pr))
                    acc = [(acc[k] if k < len(acc) else arb(0)) +
                           (pr[k] if k < len(pr) else arb(0)) for k in range(m)]
            if acc is None:
                continue
            if i <= D:
                sl[i] = acc
            else:
                dropped = dropped + xnorm(acc, r) * (self.smax ** i)
        # slice arrays may have different lengths: pad
        for i in range(D + 1):
            if sl[i] is None:
                sl[i] = [arb(0)]
        MA = self.total_mass(r)
        MB = other.total_mass(r)
        tau = self.tau * MB + MA * other.tau + self.tau * other.tau + dropped
        return Sig(sl, tau.upper(), self.smax)

    def mul_scalar_sig(self, s, D, r):
        """multiply by a SCALAR sigma-series s (list of arb, s[i]=coeff sigma^i,
        with its own tau_s). Same bookkeeping.

        TAU-FIX-1.  Старая строка
            tau = MA * arb(0) + dropped
        теряла СОБСТВЕННЫЙ tau объекта: произведение s(sigma)*A(sigma) содержит
        s * (отброшенный хвост A), масса которого не превосходит tau_A * M_s,
        но и не равна нулю.  Вызовы идут на объектах с ненулевым tau
        (op_sig.py:148, 195-197, 227-235), так что дефект был живой."""
        la, ls = len(self.slices), len(s)
        sl = [None] * (D + 1)
        dropped = arb(0)
        for i in range(la + ls - 1):
            terms = []
            for j in range(max(0, i - ls + 1), min(i, la - 1) + 1):
                terms.append((s[i - j], self.slices[j]))
            if not terms:
                continue
            if i <= D:
                # sigma^i slice: sum of scalar*slice (t-series scaled) — but the
                # t-lengths may exceed N; keep as is (scalar mult keeps length)
                sl[i] = _scaled_sum(terms)
            else:
                nm = arb(0)
                for c, arr in terms:
                    nm = nm + abs(c) * xnorm(arr, r)
                dropped = dropped + nm * (self.smax ** i)
        for i in range(D + 1):
            if sl[i] is None:
                sl[i] = [arb(0)]
        Ms = arb(0)
        for i in range(len(s)):
            Ms = Ms + abs(s[i]) * (self.smax ** i)
        # TAU-FIX-1: собственный хвост объекта, умноженный на массу скаляра.
        # tau самого s добавляет вызывающий (smul_sig_with_tau).
        tau = self.tau * Ms + dropped
        return Sig(sl, tau.upper(), self.smax)

    def smul_sig_with_tau(self, s, s_tau, D, r):
        res = self.mul_scalar_sig(s, D, r)
        MA = self.total_mass(r)
        res.tau = (res.tau + MA * s_tau).upper()
        return res

    def shift_mul_sigma(self, D, r):
        """multiply by sigma (coefficient shift); dropped top slice mass."""
        # был баг (замечание по проверке): нулевой срез добавлялся как
        # скаляр arb(0), а срезы — это t-ряды; xnorm на скаляре падает.
        sl = [[arb(0)]] + list(self.slices)
        dropped = arb(0)
        if len(sl) > D + 1:
            dropped = xnorm(sl[D + 1], r) * (self.smax ** (D + 1))
            sl = sl[:D + 1]
        return Sig(sl, (self.tau + dropped).upper(), self.smax)


def _scaled_sum(terms):
    """sum of scalar*slice with common t-length."""
    m = max(len(arr) for _, arr in terms)
    out = [arb(0)] * m
    for c, arr in terms:
        for k in range(len(arr)):
            out[k] = out[k] + c * arr[k]
    return out


def sig_from_poly(coeffs_slices, smax):
    """exact polynomial sigma-object (tau = 0)."""
    return Sig([list(s) for s in coeffs_slices], arb(0), smax)


def horner_compose(Gc_slices, Q, D, N, r):
    """compose the sigma-varying t-series Gc (Sig) with the Sig Q:
       result = Gc[deg] + result*Q (Horner over t-coefficients of each slice).
    Gc_slices: Sig whose slices share a common t-length."""
    deg = len(Gc_slices.slices[0]) - 1
    res_slices = [[(s[deg] if deg < len(s) else arb(0))]
                  for s in Gc_slices.slices]
    # tau первого аргумента здесь ТЕРЯЛСЯ: и seed, и каждый добавляемый
    # столбец строились с arb(0). Оба боевых вызова передают Gc с tau = 0
    # (Pc и Pcp — точные сигма-срезы многочлена-центра), поэтому потери сейчас
    # нет; но контракт был бы нарушен молча, как только Gc принесёт свой хвост.
    # Схема Горнера линейна по Gc, поэтому tau Gc входит в результат
    # ровно один раз на каждый добавляемый столбец: seed несёт его сам, а
    # каждое сложение добавляет свою долю.
    res = Sig(res_slices, Gc_slices.tau, Gc_slices.smax)
    for k in range(deg - 1, -1, -1):
        res = res.mul(Q, D, N, r)
        col = Sig([[s[k] if k < len(s) else arb(0)] for s in Gc_slices.slices],
                  Gc_slices.tau, Gc_slices.smax)
        res = res.add(col)
    return res


# ---------------- scalar sigma-series (list of arb + tau) ---------------- #

def scalar_recip(g, D, smax):
    """1/g for scalar sigma-series g with g[0] ~ O(1), via the geometric
    recursion; tau from the geometric tail (valid when |g/g0 - 1| < 1)."""
    g = list(g) + [arb(0)] * (D + 1 - len(g)) if len(g) < D + 1 else list(g)
    g0 = g[0]
    out = [arb(0)] * (D + 1)
    out[0] = 1 / g0
    for n in range(1, D + 1):
        s = arb(0)
        for k in range(1, n + 1):
            if g[k] != 0 and out[n - k] != 0:
                s = s + g[k] * out[n - k]
        out[n] = -s / g0
    # 1/g(sigma) = (1/g0) * 1/(1+h(sigma)), h = g/g0-1:
    h_abs = arb(0)
    for i in range(1, len(g)):
        h_abs = h_abs + abs(g[i] / g0) * (smax ** i)
    if not (h_abs < 1):
        raise RuntimeError('scalar_recip: |h| >= 1 (%s)' % h_abs)
    # TAU-FIX-2 (17.08 23:35).  Старая оценка  h_abs^{D+1}/(1-h_abs)  считала
    # только слагаемые h^n с n > D.  Но h^n при n <= D тоже даёт вклад в
    # sigma-степени > D (h — не моном), и этот вклад терялся.
    # Контрпример: h = 0.1 s + 0.1 s^2, D=1, smax=1: истинный хвост >= 0.09,
    # старая оценка 0.05 -> НЕ мажоранта.
    # Верно: |[1/(1+h)]_i| <= u_i, где u — коэффициенты 1/(1-H), H = sum|h_k|s^k,
    # то есть u_0 = 1, u_n = sum_{k=1..n} |h_k| u_{n-k}; при этом
    # sum_i u_i smax^i = 1/(1-h_abs) в замкнутом виде.  Хвост = замкнутое
    # значение минус посчитанная голова — это точный хвост мажоранты.
    habs_k = [arb(0)] + [abs(g[i] / g0) * (smax ** i) for i in range(1, len(g))]
    u = [arb(1)] + [arb(0)] * D
    for n in range(1, D + 1):
        acc = arb(0)
        for k in range(1, min(n, len(habs_k) - 1) + 1):
            acc = acc + habs_k[k] * u[n - k]
        u[n] = acc
    head_maj = arb(0)
    for i in range(D + 1):
        head_maj = head_maj + u[i]          # u_i уже несут smax^i внутри habs_k
    tau = abs(out[0]) * (1 / (1 - h_abs) - head_maj)
    if not (tau >= 0):
        tau = abs(out[0]) * (1 / (1 - h_abs))   # деградация к безусловной массе
    return out, tau.upper(), h_abs


def scalar_log_from_recip(g, D, smax):
    """Log(g) = Log(g0) + Log(1+h); h-abs must be < 1. Returns (series, tau)."""
    g = list(g) + [arb(0)] * (D + 1 - len(g)) if len(g) < D + 1 else list(g)
    g0 = g[0]
    h = [arb(1)] + [g[i] / g0 for i in range(1, len(g))]
    # h[0] = 1 - 1 = ... careful: h = g/g0 - 1 -> h[0] = 0
    h = [arb(0)] + [g[i] / g0 for i in range(1, len(g))]
    h_abs = arb(0)
    for i in range(1, len(h)):
        h_abs = h_abs + abs(h[i]) * (smax ** i)
    if not (h_abs < 1):
        raise RuntimeError('scalar_log: |h| >= 1')
    # Log(1+h) = sum (-1)^{n+1} h^n / n : power series in sigma
    # compute h^n as scalar sigma-series powers to D
    out = [g0.log()] + [arb(0)] * D
    hp = [arb(1)] + [arb(0)] * D    # h^0
    for n in range(1, D + 1):
        # h^n = hp * h truncated at D
        new = [arb(0)] * (D + 1)
        for i in range(D + 1):
            if hp[i] == 0:
                continue
            for j in range(0, D + 1 - i):
                if h[j] != 0:
                    new[i + j] = new[i + j] + hp[i] * h[j]
        hp = new
        for i in range(D + 1):
            out[i] = out[i] + ((arb(-1) ** (n + 1)) / n) * hp[i]
    # TAU-FIX-3 (17.08 23:35).  Тот же дефект, что в scalar_recip: старая
    # оценка учитывала только n > D.  Мажоранта Log(1+h) — это -log(1-H),
    # H = sum |h_k| s^k; её хвост считаем как «замкнутое значение минус
    # посчитанная голова мажоранты».
    hk = [arb(0)] + [abs(h[i]) * (smax ** i) for i in range(1, len(h))]
    # v_i = коэффициенты -log(1-H), умноженные на smax^i:
    #   v_n = h_n + (1/n) * sum_{k=1..n-1} k * v_k * h_{n-k}
    v = [arb(0)] * (D + 1)
    for n in range(1, D + 1):
        acc = (hk[n] if n < len(hk) else arb(0)) * arb(n)
        for k in range(1, n):
            hnk = hk[n - k] if n - k < len(hk) else arb(0)
            acc = acc + arb(k) * v[k] * hnk
        v[n] = acc / arb(n)
    head_maj = arb(0)
    for i in range(D + 1):
        head_maj = head_maj + v[i]
    closed = -((1 - h_abs).log())
    tau = closed - head_maj
    if not (tau >= 0):
        tau = closed
    return out, tau.upper()


def scalar_exp(M, D, smax):
    """exp(M) for scalar sigma-series M with M[0] arbitrary:
    E[0] = exp(M[0]); E_n = (1/n) sum_{j=1..n} j M_j E_{n-j}.
    tau <= e^{Ms} * (Ms - |M0|)^{D+1}/(D+1)! style bound."""
    E = [arb(0)] * (D + 1)
    E[0] = M[0].exp()
    for n in range(1, D + 1):
        s = arb(0)
        for j in range(1, n + 1):
            if M[j] != 0 and E[n - j] != 0:
                s = s + arb(j) * M[j] * E[n - j]
        E[n] = s / n
    # TAU-FIX-4 (17.08 23:35).  Старая оценка e^{Ms} * rest^{D+1}/(D+1)! —
    # лагранжев остаток, а не мажоранта ряда по sigma: слагаемые R^n/n! с
    # n <= D тоже дают вклад в степени > D.  Правильная мажоранта:
    #   |[exp(M - M_0)]_i| <= [exp(R)]_i,  R = sum_{i>=1} |M_i| s^i,
    # хвост = |e^{M_0}| * ( e^{R(smax)} - sum_{i<=D} [exp R]_i smax^i ).
    Rk = [arb(0)] + [abs(M[i]) * (smax ** i) for i in range(1, len(M))]
    Rs = arb(0)
    for i in range(1, len(Rk)):
        Rs = Rs + Rk[i]
    # e_n = (1/n) sum_{j=1..n} j * R_j * e_{n-j}   (со scale smax^n внутри)
    e = [arb(1)] + [arb(0)] * D
    for n in range(1, D + 1):
        acc = arb(0)
        for j in range(1, min(n, len(Rk) - 1) + 1):
            acc = acc + arb(j) * Rk[j] * e[n - j]
        e[n] = acc / arb(n)
    head_maj = arb(0)
    for i in range(D + 1):
        head_maj = head_maj + e[i]
    tail_maj = Rs.exp() - head_maj
    if not (tail_maj >= 0):
        tail_maj = Rs.exp()
    tau = abs(E[0]) * tail_maj
    return E, tau.upper()


def _fact(n):
    f = arb(1)
    for i in range(2, n + 1):
        f = f * i
    return f


def t_exp_seed(M_sig, X0_slice, D, N, r):
    """bivariate exp: X = exp(M) with the t-seed X(0) = X0_slice given.
    Recursion: dX/dsigma = X * dM/dsigma  (slice-wise):
      (i+1) X_{i+1} = sum_{j=0..i} (j+1) M_{j+1} * X_{i-j}   (t-convolutions)
    Tail: tau_X <= M_X * (tau_M + tail-of-capping) + ... plus exp-type
    Poisson tail via the scalar majorant of (M - M0)."""
    smax = M_sig.smax
    X = [list(X0_slice)]
    for i in range(D):
        acc = [arb(0)] * (N + 1)
        for j in range(0, i + 1):
            Mj1 = M_sig.slices[j + 1] if j + 1 < len(M_sig.slices) else None
            Xi_j = X[i - j]
            if Mj1 is None:
                continue
            fac = arb(j + 1)   # scalar (j+1) * M_{j+1}
            pr = conv([fac * (Mj1[k] if k < len(Mj1) else arb(0))
                       for k in range(N + 1)], Xi_j, N)
            acc = [(acc[k] if k < len(acc) else arb(0)) +
                   (pr[k] if k < len(pr) else arb(0)) for k in range(max(len(acc), len(pr)))]
            acc = acc[:N + 1]
        X.append([x / arb(i + 1) for x in acc])
    # tail bound: X satisfies dX/ds = X dM/ds; with majorants
    # Mhat(s) = sum ||M_i|| s^i + tau_M, Xhat <= exp-ish...
    # simple valid bound: Xhat <= X0hat * exp(Mhat - M0hat) and the sigma-Taylor
    # of exp at order D misses  <= value * (Mhat-M0hat)^{D+1}/(D+1)! e^{...}
    # TAU-FIX-5 (17.08 23:35).  Хвост усечения по sigma — как в scalar_exp,
    # через мажорантную рекурсию, а не через лагранжев остаток.
    # X(sigma) = X_0 * exp(M(sigma) - M(0)) в коммутативной алгебре t-рядов
    # (веса r^k делают ||a*b|| <= ||a|| ||b||), поэтому мажоранта коэффициентов:
    #   x_0 = ||X_0||,  n*x_n = sum_{j=1..n} j*m_j*x_{n-j},  m_j = ||M_j|| smax^j,
    #   sum_i x_i = x_0 * exp(sum_j m_j).
    X0 = xnorm(X0_slice, r).upper()
    m = [arb(0)]
    for j in range(1, len(M_sig.slices)):
        m.append(xnorm(M_sig.slices[j], r).upper() * (smax ** j))
    Rs = arb(0)
    for j in range(1, len(m)):
        Rs = Rs + m[j]
    x = [X0] + [arb(0)] * D
    for n in range(1, D + 1):
        acc = arb(0)
        for j in range(1, min(n, len(m) - 1) + 1):
            acc = acc + arb(j) * m[j] * x[n - j]
        x[n] = acc / arb(n)
    head_maj = arb(0)
    for i in range(D + 1):
        head_maj = head_maj + x[i]
    tail_trunc = X0 * Rs.exp() - head_maj
    if not (tail_trunc >= 0):
        tail_trunc = X0 * Rs.exp()
    # снос tau_M: возмущение M на массу tau_M (в sup-норме по sigma) меняет
    # X_0 exp(M - M_0) не более чем на X_0 e^{Rs} (e^{2 tau_M} - 1).
    tM = M_sig.tau
    if not (tM < arb('0.5')):
        raise RuntimeError('t_exp_seed: tau_M too large (%s)' % tM)
    tau_prop = X0 * Rs.exp() * ((2 * tM).exp() - 1)
    tau = tail_trunc + tau_prop
    return Sig(X, tau.upper(), smax)
