#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
macro_micro.py — Lever B: two-level (macro-cell / micro-step) tube march.

Per BRIEF-TUBE-V4-SPEED.md §2.

Two-level scheme:
  MACRO-CELL (Δℓ_cell, default 0.002):
      Compute ONCE for the whole cell:
        • build_pkg_fast with INTERVAL ℓ_cell (Lemma U, M matrix, W̄ for X_norms)
        • x-norm + β-fit
        • Ã at cell MIDPOINT (float matrix — for QN)
        • Z1a/Z1b/Z1c (strict β̂ formula) — interval upper bounds
        • L-strict + Lemma U check
      Result: Ẑ_cell, A_tilde_cell, lemma_OK — valid for the whole cell.

  MICRO-STEP h inside the cell:
      • QN polish (uses Ã_cell — fresh per cell, fixes staleness)
      • compute_F_poly (with its OWN Miller power, since seed changes)
      • Y₀ using Ã_cell
      • Gate: Y₀ + Ẑ_cell·ρ̂′ ≤ ρ̂′

This way we SKIP at micro-step:
    build_pkg_fast     (~1.5 s saved)
    xnorm + β-fit     (~0.5 s saved)
    compute_Z1         (~0.2 s saved)
Total micro-step ≈ compute_F_poly + polish + Y₀ + drift/L ≈ 1.5–3 s.

Math justification (v6, closes REVIEW-ENGINE F1):
  ℓ-direction: pkg/Z₁/L/лемма U считаются с интервальным ℓ всей ячейки;
    инклюзионная изотонность arb покрывает каждый под-бокс ℓ шага. ✓
  Seed-direction (v5 was UNSOUND here — the drift of the polished seed left
    the derivation ball entirely): at every micro-step we MEASURE the drift
        d_X = strict arb upper bound of ‖â_step − â_cell‖_X
    (tube_lib.seed_drift_norm_upper) and inflate the radius:
        ρ′_eff = ρ̂′ + d_X/1.75.
    For any x ∈ B′(â_step, ρ̂′):
        ‖x − â_cell‖_X ≤ 1.75·ρ̂′ + d_X = 1.75·ρ′_eff,
    so the step ball lies inside B_X(â_cell, 1.75·ρ′_eff). The Lipschitz
    chain is re-evaluated PER STEP at ρ′_eff (its internal domain checks
    q̂<1, κ_s<r then hold on exactly that inflated ball), giving
        sup_{x∈B′(â_step,ρ̂′)} ‖I − Ã·DF(x)‖′
          ≤ Z₁(â_cell, ℓ_cell) + 1.75²·‖Ã‖₁·L(ρ′_eff)·ρ′_eff  =: Ẑ_eff.
    Gate: Y₀ + Ẑ_eff·ρ̂′ ≤ ρ̂′ (the Kantorovich radius of the step stays ρ̂′;
    only the Z-majorization region is inflated). No empirical slope enters
    the certificate — d_X is measured rigorously each step; the configured
    drift_slope_budget is used ONLY to pre-select ρ̂′ at macro time
    (planning, not proof).
"""
# ---------------------------------------------------------------------------
# ПРОИСХОЖДЕНИЕ, А НЕ МАРШРУТ ВОСПРОИЗВЕДЕНИЯ.
# Этот скрипт показывает, как были получены точечные константы §5, но его
# входные пути указывают на рабочее дерево, в котором он собирался, а не на
# пакет: запустить его отсюда нельзя, и ни один шаг проверки его не
# вызывает.  Его результаты лежат готовыми в 03-CERTIFICATES/pointwise/.
# ---------------------------------------------------------------------------
# ⚠ ВНИМАНИЕ, ФОРМУЛА ОБЛАСТИ ЗДЕСЬ УСТАРЕЛА.
# micro_step() ниже расширяет радиус как rho_eff = rho_prime + drift_d/1.75.
# Такой ход неверен: требуемый зазор 0.75·rho_prime
# НЕ зависит от измеренного дрейфа d_X. Ни одна опубликованная константа §5 через
# эту ветку не считалась: micro_step и try_rho_prime_and_L в пакете НИКЕМ не
# вызываются (проверено grep-ом; импорт на строке ~79 — мёртвый).
# Код оставлен как исторический; ПЕРЕИСПОЛЬЗОВАТЬ ФОРМУЛУ НЕЛЬЗЯ.
# ---------------------------------------------------------------------------

import json, sys, io, os, time
os.chdir(os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import mpmath
from mpmath import mpf
from flint import arb, arb_poly

sys.path.insert(0, '../wave6_kant_l25/lib')
sys.path.insert(0, '.')

import tube_lib
from tube_lib import (
    N_G, N_W, N_p, N_ALG,
    c_arb, r_arb,
    H_INIT, H_MAX, H_MIN, ATILDE_UPDATE_EVERY,
    mp_to_arb_ball_list,
    build_pkg_fast, build_A_tilde, compute_Z1,
    compute_x_norms_and_beta, compute_F_poly, compute_Y0,
    compute_F_tail_bound, seed_drift_norm_upper,
    try_rho_prime_and_L, verify_lemma_U,
    build_strict_consts_from_pkg,
    quasi_newton_reseed_arb,
    _compute_L, log_msg,
)


def _zero_tail_mpf(a):
    """v6/F7: certified centers are polynomials of degree ≤ N_G — zero the
    coefficients k > N_G (the U/W-branch of the operator truncates the seed
    to N_G; with a degree-≤N_G center that truncation is EXACT, so the
    computed F̄ is F̄ of the actual center). The polish correction lives in
    k ≤ 40, so nothing of value is lost."""
    out = list(a)
    for k in range(N_G + 1, len(out)):
        out[k] = mpf(0)
    return out


def _macro_z1(pkg, A_tilde, A_norm1, strict_consts):
    """Wrapper around compute_Z1."""
    Z1, Z1a, Z1b, Z1c = compute_Z1(
        pkg, A_tilde, A_norm1, strict_consts=strict_consts,
    )
    return Z1, Z1a, Z1b, Z1c


def compute_macro_data(a, ell_cell_lo, ell_cell_hi,
                        target_rho_prime=arb("3.5e-5"),
                        rho_prime_grid=None,
                        return_logs=False,
                        compute_tangent=True,
                        drift_slope_budget=0.5):
    """Compute macro-cell data for cell [lo, hi].

    v6 changes:
      * the cell seed tail is zeroed (F7) — the certified anchor is a
        polynomial of degree ≤ N_G, consistent with the step centers;
      * ρ̂′ is selected so that the PLANNED drift-inflated Ẑ_eff stays < 1:
        ρ′_eff_plan = ρ̂′ + d_budget/1.75, d_budget = drift_slope_budget ×
        (cell_hi − cell_lo). The budget is a PLANNING device only — the
        per-step gate re-measures the actual drift rigorously (micro_step);
      * A_norm1_up: directed arb upper bound of ‖Ã‖₁ (F6) used in every
        certifying formula (the float A_norm1 stays for diagnostics);
      * a_cell_arb (the exact ball list the pkg was built from) is returned
        for the per-step drift measurement.

    Returns dict with cached quantities (or None on failure):
        cell_lo, cell_hi, ell_mid, pkg_full, xn,
        A_tilde (np.ndarray float), A_norm1 (float), A_norm1_up (arb),
        Z1, Z1a, Z1b, Z1c (arb),
        Z_hat (planned drift-inflated Ẑ_eff — for logs), L_strict (its L),
        rho_prime (arb), rho_eff_plan (arb), d_budget (float),
        a_cell_mpf, a_cell_arb, lemma_OK, lemma_res.

    Heavy cost: ~ t_pkg + t_xnorm + t_atilde + t_z1 + t_lemma ≈ 3–5 s
    (computed ONCE per cell).
    """
    ell_mid = (ell_cell_lo + ell_cell_hi) / 2.0
    ell_box_full = (arb(ell_cell_lo)).union(arb(ell_cell_hi))

    a_cell = _zero_tail_mpf(a)                       # v6/F7
    a64_arb = mp_to_arb_ball_list(a_cell, eps_rel=1e-17)

    t0 = time.time()
    pkg = build_pkg_fast(a64_arb, ell_box_full)
    if pkg is None:
        return None
    t_pkg = time.time() - t0

    t0 = time.time()
    lemma_res, lemma_OK = verify_lemma_U(a64_arb, ell_box_full)
    t_lemma = time.time() - t0
    if not lemma_OK:
        return None

    t0 = time.time()
    # Ã at cell mid (use the same pkg, build_A_tilde reads arb_mid of M_full
    # so it's already evaluated at the box's midpoint = cell mid)
    A_tilde, A_norm1, A_norm1_up = build_A_tilde(pkg)
    t_atilde = time.time() - t0

    t0 = time.time()
    xn = compute_x_norms_and_beta(pkg)
    if xn['C_fit'] is None or xn['kappa_fit'] is None:
        return None
    strict_consts = build_strict_consts_from_pkg(pkg, xn)
    t_xnorm = time.time() - t0

    t0 = time.time()
    Z1, Z1a, Z1b, Z1c = _macro_z1(pkg, A_tilde, A_norm1_up, strict_consts)
    t_z1 = time.time() - t0

    t0 = time.time()
    if rho_prime_grid is None:
        rho_prime_grid = [
            arb("2.9e-5"), arb("3.2e-5"), arb("2.4e-5"),
            arb("2e-5"), arb("3.5e-5"), arb("1e-5"),
        ]
    # v6/F1: select ρ̂′ so the drift-inflated PLAN survives; the actual gate
    # re-measures d per step. d_budget does NOT enter any certificate.
    d_budget = drift_slope_budget * abs(ell_cell_hi - ell_cell_lo)
    rho_prime = None
    L_plan = None
    Z_hat_plan = None
    rho_eff_plan = None
    for rp in rho_prime_grid:
        rp_eff = rp + arb(d_budget) / arb("1.75")
        gate_pkg = _compute_L(pkg, xn, rp_eff)
        if gate_pkg is None:
            continue
        L_rp = gate_pkg['L_strict']
        Z_hat_rp = Z1 + arb("1.75") ** 2 * A_norm1_up * L_rp * rp_eff
        if Z_hat_rp < arb(1):
            rho_prime = rp
            L_plan = L_rp
            Z_hat_plan = Z_hat_rp
            rho_eff_plan = rp_eff
            break
    t_l = time.time() - t0
    if rho_prime is None:
        return None

    out = {
        'cell_lo': ell_cell_lo, 'cell_hi': ell_cell_hi, 'ell_mid': ell_mid,
        'pkg_full': pkg,
        'A_tilde': A_tilde, 'A_norm1': A_norm1, 'A_norm1_up': A_norm1_up,
        'Z1': Z1, 'Z1a': Z1a, 'Z1b': Z1b, 'Z1c': Z1c,
        'Z_hat': Z_hat_plan, 'L_strict': L_plan, 'rho_prime': rho_prime,
        'rho_eff_plan': rho_eff_plan, 'd_budget': d_budget,
        'a_cell_mpf': a_cell, 'a_cell_arb': a64_arb,
        'lemma_res': lemma_res, 'lemma_OK': lemma_OK,
        'xn': xn,
        't_pkg': t_pkg, 't_lemma': t_lemma, 't_atilde': t_atilde,
        't_xnorm': t_xnorm, 't_z1': t_z1, 't_l': t_l,
    }

    # Optional Lever C: tangent seed v = -Ã·∂F̄/∂ℓ at cell midpoint
    # Disabled by default in wave15 (empirically worse than float-polish).
    if compute_tangent:
        out['tangent_v'] = _compute_tangent_v(
            a, ell_mid, A_tilde, delta_test=1e-5,
        )
        out['tangent_anchor_ell'] = ell_mid
    else:
        out['tangent_v'] = None
        out['tangent_anchor_ell'] = None
    return out


def _compute_tangent_v(a, ell_anchor, A_tilde, delta_test=1e-5):
    """Compute tangent direction v = -Ã · ∂F̄/∂ℓ at ℓ_anchor.

    Uses central finite difference: F̄(ℓ+δ, a) - F̄(ℓ-δ, a) / (2δ).
    Returns np.ndarray of length N_p+1 with v[0]=0 (Ã·∂F̄/∂ℓ has no k=0 component).
    """
    ell_hi_box = (arb(ell_anchor + delta_test) - arb(delta_test/10)).union(
                  arb(ell_anchor + delta_test) + arb(delta_test/10))
    ell_lo_box = (arb(ell_anchor - delta_test) - arb(delta_test/10)).union(
                  arb(ell_anchor - delta_test) + arb(delta_test/10))
    a64_arb = mp_to_arb_ball_list(a, eps_rel=1e-17)
    F_hi = compute_F_poly(a64_arb, ell_hi_box)
    F_lo = compute_F_poly(a64_arb, ell_lo_box)
    # F̄ coefficients → X_p-coords
    r_mid = float(r_arb)
    v = np.zeros(N_p + 1)
    for k in range(1, N_p + 1):
        f_hi_k = float(F_hi[k]) if k < len(F_hi) else 0.0
        f_lo_k = float(F_lo[k]) if k < len(F_lo) else 0.0
        dF_dl_k = (f_hi_k - f_lo_k) / (2 * delta_test)
        f_tilde_k = dF_dl_k * r_mid ** k
        v[k] = -float(A_tilde[0, k-1]) * f_tilde_k if False else 0.0
    # Actually do full matrix mult: v_Xp = -A · f_tilde_Xp
    f_tilde = np.array([
        ((float(F_hi[k]) if k < len(F_hi) else 0.0) -
         (float(F_lo[k]) if k < len(F_lo) else 0.0)) /
        (2 * delta_test) * r_mid ** k
        for k in range(1, N_p + 1)
    ], dtype=np.float64)
    delta_X0 = A_tilde @ f_tilde  # shape (N_p,)
    # v in u-coords: v[k] = -delta_X0[k-1] / r^k
    for k in range(1, N_p + 1):
        v[k] = -delta_X0[k - 1] / r_mid ** k
    return v


def micro_step(a, ell_lo, ell_next, cell_data,
               polish_method='float', max_polish_iter=3,
               polish_tol=1e-12, tangent_v=None, tangent_anchor_ell=None):
    """Single micro-step INSIDE a cell, certifying ℓ ∈ [ell_lo, ell_next]
    (or [ell_next, ell_lo] when marching down).

    v6 signature: takes the EXACT float endpoint ell_next instead of h —
    the certified box is union(arb(ell_lo), arb(ell_next)), i.e. exactly
    the floats that go into the record and into the next step's start
    (F5: no ulp slivers; F3: the caller clips ell_next to cell_hi).

    Per BRIEF-KIT-V5.md §1, the seed polish is PURE-FLOAT (no arb) by
    default. Rigorous side per step (v6):
      * center tail zeroed (F7) — certified center has degree ≤ N_G;
      * honest per-step F_tail (F4) for the current ℓ-box and seed;
      * measured drift d_X → ρ′_eff → per-step L → Ẑ_eff (F1, see module
        docstring for the chain);
      * gate: Y₀ + Ẑ_eff·ρ̂′ ≤ ρ̂′ (certified arb comparison).

    polish_method:
      'float'  — float_polish_step (numpy, default, RECOMMENDED)
      'qn'     — quasi_newton_reseed_arb (legacy, ARB-mixed, for fallback)
      'none'   — no polish (the rejected no_qn strategy)
      'tangent' — tangent-only seed, no polish

    Returns dict with seed, Y0, gate_pass, fail_reason, drift/Z_hat_eff
    diagnostics, t_breakdown, qn_info.
    """
    from float_polish import float_polish_step

    h = abs(ell_next - ell_lo)
    ell_mid = 0.5 * (ell_lo + ell_next)
    ell_box_micro = arb(ell_lo).union(arb(ell_next))   # v6/F5: exact floats

    A_tilde = cell_data['A_tilde']
    A_norm1 = cell_data['A_norm1']
    A_norm1_up = cell_data['A_norm1_up']

    # Seed polish
    t0 = time.time()
    if polish_method == 'tangent' and tangent_v is not None and tangent_anchor_ell is not None:
        delta_ell = ell_mid - tangent_anchor_ell
        a_qn = list(a)
        N = min(len(a_qn), len(tangent_v))
        for k in range(N):
            try:
                a_qn[k] = a_qn[k] + mpf(delta_ell) * mpf(float(tangent_v[k]))
            except Exception:
                pass
        qn_info = {'iter_count': 0, 'residual_norms': [], 'deltas': [],
                   'method': 'tangent'}
    elif polish_method == 'float':
        # PURE-FLOAT polish (numpy, no arb) — BRIEF-KIT-V5 default
        a_arr, qn_info = float_polish_step(
            a, ell_mid, A_tilde,
            max_iter=max_polish_iter, tol=polish_tol,
        )
        # Convert back to mpf for downstream arb compute_F_poly.
        # Keep full N_p+1 length — the trailing coefficients are needed
        # by the next step's Newton iteration (A_tilde is N_p×N_p).
        a_qn = [mpf(str(float(ak))) for ak in a_arr]
        # Pad/truncate to N_p+1 (not N_G+1) to preserve the Newton basis.
        if len(a_qn) < N_p + 1:
            a_qn = a_qn + [mpf(0)] * (N_p + 1 - len(a_qn))
        elif len(a_qn) > N_p + 1:
            a_qn = a_qn[:N_p + 1]
        qn_info['method'] = 'float'
    elif polish_method == 'qn':
        a_qn, qn_info = quasi_newton_reseed_arb(
            a, ell_box_micro, A_tilde, A_norm1,
            max_iter=max_polish_iter, tol=polish_tol,
        )
        qn_info['method'] = 'qn'
    else:  # 'none'
        a_qn = list(a)
        qn_info = {'iter_count': 0, 'residual_norms': [], 'deltas': [],
                   'method': 'none'}
    t_qn = time.time() - t0

    # v6/F7: the certified center is a polynomial of degree ≤ N_G
    a_qn = _zero_tail_mpf(a_qn)

    # F̄ (with Miller power) + honest per-step tail (v6/F4)
    t0 = time.time()
    a64_arb = mp_to_arb_ball_list(a_qn, eps_rel=1e-17)
    F_poly = compute_F_poly(a64_arb, ell_box_micro)
    F_tail = compute_F_tail_bound(a64_arb, ell_box_micro)
    t_fpoly = time.time() - t0

    rho_prime = cell_data['rho_prime']
    Z1 = cell_data['Z1']

    # v6/F1: measured drift → inflated radius → per-step L → Ẑ_eff
    t0 = time.time()
    drift_d = seed_drift_norm_upper(a64_arb, cell_data['a_cell_arb'])
    rho_eff = rho_prime + drift_d / arb("1.75")
    gate_pkg = _compute_L(cell_data['pkg_full'], cell_data['xn'], rho_eff)
    t_drift = time.time() - t0

    fail_reason = None
    Z_hat_eff = None
    L_step = None
    if F_tail is None:
        fail_reason = 'ftail'
    elif gate_pkg is None:
        # L-chain domain broke on the inflated ball — drift too large for
        # this cell; the caller should re-anchor (new macro cell), not
        # shrink h.
        fail_reason = 'L_domain'
    else:
        L_step = gate_pkg['L_strict']
        Z_hat_eff = Z1 + arb("1.75") ** 2 * A_norm1_up * L_step * rho_eff
        if not (Z_hat_eff < arb(1)):
            fail_reason = 'Z_ge_1'

    # Y₀
    t0 = time.time()
    if fail_reason is None:
        Y0 = compute_Y0(F_poly, A_tilde, F_tail)
        g5_lhs = Y0 + Z_hat_eff * rho_prime
        g_pass = bool(g5_lhs <= rho_prime)
        margin_ok = bool(g5_lhs <= rho_prime * arb("0.5"))
        rho_star = Y0 / (arb(1) - Z_hat_eff)
        if not g_pass:
            fail_reason = 'gate'
    else:
        Y0 = arb("nan")
        g5_lhs = arb("nan")
        g_pass = False
        margin_ok = False
        rho_star = arb("nan")
    t_y0 = time.time() - t0

    return {
        'seed': a_qn,
        'a_qn': a_qn,
        'ell_lo': ell_lo,
        'ell_next': ell_next,
        'ell_mid': ell_mid,
        'Y0': Y0,
        'F_poly': F_poly,
        'F_tail': F_tail,
        'qn_info': qn_info,
        'gate_pass': g_pass,
        'fail_reason': fail_reason,
        'margin_ok': margin_ok,
        'g5_lhs': g5_lhs,
        'rho_star': rho_star,
        'rho_prime': rho_prime,
        'rho_prime_eff': rho_eff,
        'drift_d': drift_d,
        'Z_hat': Z_hat_eff,          # per-step Ẑ_eff (kept under old key)
        'Z_hat_eff': Z_hat_eff,
        'L_step': L_step,
        'Z1': Z1,
        'A_norm1': A_norm1,
        't_qn': t_qn, 't_fpoly': t_fpoly, 't_y0': t_y0, 't_drift': t_drift,
        't_total': t_qn + t_fpoly + t_y0 + t_drift,
    }
