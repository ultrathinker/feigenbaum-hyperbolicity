# -*- coding: utf-8 -*-
"""
_fix_span.py — план замены боксов трубки, не вмещающихся ни в один бокс
существования.

Такой бокс режется на два, каждый из которых целиком лежит в своём боксе
существования; куски перекрываются (боксы существования перекрываются на
0.005), поэтому цепочка и покрытие сохраняются.

Запуск: python _fix_span.py > tube_plan_span.txt
"""
import os, sys, json, glob

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
offs = json.load(open(os.path.join(HERE, 'offsets.json'), encoding='utf-8'))
EPS = 1e-6
LO, HI = 2.0, 4.0

bad = []
for f in sorted(glob.glob(os.path.join(HERE, 'tube_out', 'box_*.json'))):
    j = json.load(open(f, encoding='utf-8'))
    if not j.get('pass'):
        continue
    lo, hi = max(j['lo'], LO), min(j['hi'], HI)     # важна только часть в [2,4]
    if lo >= hi:
        continue
    if any(v['lo'] <= lo and hi <= v['hi'] for v in offs.values()):
        continue
    bad.append((j, lo, hi))

sys.stderr.write('боксов без вмещающего бокса существования: %d\n' % len(bad))
for j, lo, hi in bad:
    left = [v for v in offs.values() if v['lo'] <= lo <= v['hi']]
    right = [v for v in offs.values() if v['lo'] <= hi <= v['hi']]
    if not left or not right:
        sys.stderr.write('  %s: нет накрывающего бокса для края!\n' % j['tag'])
        continue
    L = max(left, key=lambda v: v['hi'])            # самый «правый» из левых
    Rr = min(right, key=lambda v: v['lo'])          # самый «левый» из правых
    a_hi = min(hi, L['hi'] - EPS)
    b_lo = max(lo, Rr['lo'] + EPS)
    if not (b_lo < a_hi):
        sys.stderr.write('  %s: куски не перекрываются (%.6f !< %.6f)\n'
                         % (j['tag'], b_lo, a_hi))
        continue
    for tag, (x, y) in (('%sL' % j['tag'], (lo, a_hi)),
                        ('%sR' % j['tag'], (b_lo, hi))):
        print('%s %.7f %.7f %d %d' % (tag, (x + y) / 2, y - x, j['N'], j['K']))
    sys.stderr.write('  %s [%.6f, %.6f] -> L[%.6f, %.6f] в %s, R[%.6f, %.6f] в %s\n'
                     % (j['tag'], lo, hi, lo, a_hi, L.get('ell0'),
                        b_lo, hi, Rr.get('ell0')))
