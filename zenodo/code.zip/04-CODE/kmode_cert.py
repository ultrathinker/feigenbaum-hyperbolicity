# -*- coding: utf-8 -*-
"""kmode_cert.py — сертификат K-моды при ell=3.

Считает строго (arb, prec=256) три числа, на которые ссылается §5.1.2 и
строки 59-61 Приложения A:

    G_at_1      = Gbar(1)
    Gprime_at_1 = Gbar'(1)
    lambda_K    = 3*Gbar'(1)/Gbar(1)

Зачем отдельный артефакт.  До круга 4 в §8 стояло
`3*2.1085438.../0.51875535...`, где числитель — это `||Gbar'||_X`
(норма на всём X-диске, поле `kant_l3.json::Gprime_norm`), а нужно было
значение в точке t=1.  Напечатанный результат 7.16329 при этом был верен,
то есть ошибку нельзя было увидеть, сверив итог; её видно только если
значение в точке где-то лежит и с ним можно сверить подстановку.  Теперь
лежит здесь.

ВАЖНО про базис: коэффициенты `G_c` — в сдвинутой переменной (t - c),
c = 3/5, поэтому точке t=1 отвечает аргумент 1 - c = 2/5.  Наивная сумма
коэффициентов даёт не Gbar(1), а Gbar(1 + c) — на этом легко ошибиться.

Вывод — только через CERT_OUT (умолчание — временный каталог ОС), как у
остальных писателей пакета: сертификаты в 03-CERTIFICATES открыты на
чтение, перезаписывать их прогоном нельзя.

    CERT_OUT=/tmp/out python 04-CODE/kmode_cert.py
"""
import json
import os
import sys
import tempfile

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.chdir(HERE)

import rig_lib as rl
import tube_lib as tl
import hyp_rouche as hr
from flint import arb, ctx

_OUT = os.environ.get('CERT_OUT',
                      os.path.join(tempfile.gettempdir(), 'renorm_out'))
os.makedirs(_OUT, exist_ok=True)

ctx.prec = 256
ELL = 3.0

c_a, m, e0b, wb, fname = hr.load_box(ELL, 0.0)
x0 = 2.0 * (ELL - e0b) / wb
P0 = rl.P_at(c_a, m, arb('%.17e' % x0))
pkg = tl.build_pkg_fast(P0, arb('%.17e' % ELL))

shift = arb(1) - tl.c_arb          # t = 1  <->  аргумент 1 - c
G1 = pkg['G_c'](shift)
Gp1 = pkg['G_c_prime'](shift)
lam = arb(3) * Gp1 / G1

# Сверка с независимо посчитанным в движке G_at_1: если базис понят
# неверно, эти два числа разъедутся, и скрипт обязан упасть здесь.
G1_engine = pkg.get('G_at_1')
if G1_engine is not None:
    if not ((G1 - arb(G1_engine)).abs_upper() < 1e-30):
        raise SystemExit(
            'Gbar(1) не совпал с pkg["G_at_1"]: %s vs %s' % (G1, G1_engine))

# lambda_K > 1 — в этом весь смысл замечания §9; если нет, что-то не то.
# Сравнивается ГАРАНТИРОВАННАЯ НИЖНЯЯ ГРАНИЦА шара, а не его середина:
# при сравнении по середине рост радиуса, накрывающий 1, остался бы
# незамеченным. Запас здесь огромный (lam ~ 7.16), вердикт от этого не
# меняется — меняется его обоснованность.
# Не `assert`: голый assert вырезается под `python -O`, и единственная
# калитка утверждения §9 стала бы резиновым штампом (тот же приём, что
# в layer/layer_mutation1.py).
if not (lam.lower() > 1.0):
    raise SystemExit('lambda_K не отделена от 1 снизу: %s' % lam)

out = {
    'task': 'kmode',
    'ell': 3.0,
    'prec': 256,
    'basis_note': "коэффициенты G_c в переменной (t - c), c = 3/5; t=1 <-> 2/5",
    'G_at_1': G1.str(17, radius=False),
    'Gprime_at_1': Gp1.str(17, radius=False),
    'lambda_K': lam.str(17, radius=False),
    'G_at_1_ball': G1.str(30),
    'Gprime_at_1_ball': Gp1.str(30),
    'lambda_K_ball': lam.str(30),
    'lambda_K_gt_1': bool(lam.lower() > 1.0),
    'source_box': str(fname),
}
dst = os.path.join(_OUT, 'kmode_l3.json')
with open(dst, 'w', encoding='utf-8') as fh:
    json.dump(out, fh, ensure_ascii=False, indent=1)
print('Gbar(1)   = %s' % out['G_at_1'])
print("Gbar'(1)  = %s" % out['Gprime_at_1'])
print('lambda_K  = %s' % out['lambda_K'])
print('записано: %s' % dst)
