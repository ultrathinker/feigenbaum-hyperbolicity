# -*- coding: utf-8 -*-
"""
cert.py -- generic single-box certificate runner (rig2fix, Z1 rule corrected).

Usage:  python cert.py <tag> <ell0> <w> [m] [D]
        например: python cert.py g00 2.025 0.05
        (теги и параметры боксов — в 03-CERTIFICATES/existence/box_g*.json,
         поля idx, ell0, w, m, D)

Writes box_<tag>.json and branch_<tag>.npz в каталог $CERT_OUT (умолчание —
временный каталог ОС, см. комментарий к OUTDIR ниже), формат тот же, что у
sweep.py, поэтому glue.py принимает смесь широких и уточнённых боксов.
"""
import os, sys, json, time, tempfile
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import fp_lib as fl
import rig_lib as rl
import rig2fix3 as R

# Каталог вывода — только через CERT_OUT: ветки .npz могут читаться
# трубкой параллельно, и перезапись на живом чтении — торн-рид.
# (тот же класс, что hyp_rouche.py -> HYP_LOG, layer/*).  Дефолт НЕ
# ведёт внутрь пакета: запуск «как есть» дописывал файлы в пакет и
# ломал сверку с MANIFEST.sha256.  Пакет обязан оставаться пригодным
# только на чтение; чтобы ПЕРЕсобрать его артефакты, CERT_OUT/
# GLUE_OUT/HYP_TUBE_OUT выставляются явно (см. 02-REPRODUCE.md).
OUTDIR = os.environ.get('CERT_OUT',
                        os.path.join(tempfile.gettempdir(), 'renorm_out'))
os.makedirs(OUTDIR, exist_ok=True)
SEEDS = json.load(open(os.path.join(HERE, 'hiprec_seeds.json'), encoding='utf-8'))
_orig_bb = rl.build_branch


def seed_at(ell0, max_step=0.09):
    pt = min(SEEDS['points'], key=lambda p: abs(float(p['ell']) - ell0))
    l = float(pt['ell'])
    a = np.array([float(x) for x in pt['a64']])
    a, info = fl.solve_fixed_point(a, l)
    n = max(1, int(np.ceil(abs(ell0 - l) / max_step)))
    for j in range(n):
        lj = l + (ell0 - l) * (j + 1) / n
        a, info = fl.solve_fixed_point(a, lj)
        if info['resid'][-1] > 1e-13:
            raise RuntimeError('continuation failed at %.6f (%.2e)' % (lj, info['resid'][-1]))
    return a, l, n, info['resid'][-1]


def run(tag, ell0, w, m=8, D=8):
    print('\n' + '=' * 72, flush=True)
    print('BOX %s  ell0=%.5f  [%.5f, %.5f]  w=%.4g m=%d D=%d'
          % (tag, ell0, ell0 - w / 2, ell0 + w / 2, w, m, D), flush=True)
    print('=' * 72, flush=True)
    t0 = time.time()
    try:
        seed, from_ell, n, resid = seed_at(ell0)
        print('  seed: from ell=%.3f in %d steps, resid %.2e' % (from_ell, n, resid), flush=True)
        br = _orig_bb(ell0, w, m + 1, seed)
        np.savez(os.path.join(OUTDIR, 'branch_%s.npz' % tag),
                 c_a=br['c_a'], c_A=br['c_A'], ls=br['ls'],
                 ell0=np.array([ell0]), w=np.array([w]), m=np.array([m]))

        def fake(*a, **k):
            return {'ls': br['ls'].copy(), 'a_nodes': br['a_nodes'].copy(),
                    'Minv_nodes': br['Minv_nodes'].copy(),
                    'c_a': br['c_a'].copy(), 'c_A': br['c_A'].copy()}
        rl.build_branch = fake
        R.rl.build_branch = fake
        out = R.run(ell0, w, m, D, seed)
    except Exception as e:
        out = {'ell0': ell0, 'w': w, 'passed': False,
               'exception': '%s: %s' % (type(e).__name__, str(e)[:300])}
        print('  EXCEPTION: %s' % out['exception'], flush=True)
    finally:
        rl.build_branch = _orig_bb
        R.rl.build_branch = _orig_bb
    out.update({'idx': tag, 'ell_lo': ell0 - w / 2, 'ell_hi': ell0 + w / 2,
                'm': m, 'D': D, 'wall_s': round(time.time() - t0, 1),
                # Метка движка одно время отставала: строка не обновилась,
                # когда cert.py перевели на следующую версию rig2fix.  Что
                # все боксы боевого прогона считались уже новой версией,
                # видно по полю tail_used, которого в первой версии нет
                # вовсе.  Метка в уже сохранённых box_*.json осталась
                # старой; числа верные.  Ни одной из промежуточных версий
                # rig2fix в пакете нет — поставляется rig2fix3.py.
                'engine': 'rig2fix3 (Z1 sum_i; tail и Z1bc — только интервальный путь)'})
    with open(os.path.join(OUTDIR, 'box_%s.json' % tag), 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=1)
    print('  BOX %s -> %s  Y0=%s Z1=%s Zhat=%s  [%.0fs]'
          % (tag, 'PASS' if out.get('passed') else 'FAIL', out.get('Y0'),
             out.get('Z1'), (out.get('best') or {}).get('Zhat'), out['wall_s']),
          flush=True)
    return out


if __name__ == '__main__':
    a = sys.argv[1:]
    if len(a) < 3:
        # Без этого запуск «как есть» падал голым IndexError, хотя строка
        # Usage стоит в докстринге тремя десятками строк выше.
        raise SystemExit(
            'Usage: python cert.py <tag> <ell0> <w> [m=8] [D=8]\n'
            '  например: python cert.py g00 2.025 0.05\n'
            '  теги и параметры боксов — 03-CERTIFICATES/existence/box_g*.json '
            '(поля idx, ell0, w, m, D)')
    run(a[0], float(a[1]), float(a[2]),
        int(a[3]) if len(a) > 3 else 8, int(a[4]) if len(a) > 4 else 8)
