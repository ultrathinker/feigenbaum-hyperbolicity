#!/usr/bin/env bash
# Прогон всех 46 боксов существования из plan3.txt одной полосой.
#
#   bash runplan6.sh <полоса> <всего_полос>
#
# Полосы 0..N-1 запускаются параллельно.  Каталог вывода — переменная
# CERT_OUT (по умолчанию ./out); туда лягут box_<тег>.json и branch_<тег>.npz.
# Ветки писать в 03-CERTIFICATES/branches/ поверх существующих не нужно:
# трубка гиперболичности читает их именно оттуда.
set -u
LANE=$1; N=$2
: "${CERT_OUT:=out}"
: "${PYTHON:=python}"
mkdir -p "$CERT_OUT"
i=0
while read -r tag ell0 w m D; do
  [ -z "${tag:-}" ] && continue
  case "$tag" in \#*) continue;; esac
  if [ $((i % N)) -eq "$LANE" ]; then
    echo "--- $(date +%H:%M:%S) start $tag ell0=$ell0 w=$w ---"
    CERT_OUT="$CERT_OUT" OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 \
      NUMEXPR_NUM_THREADS=2 PYTHONIOENCODING=utf-8 \
      "$PYTHON" -u cert.py "$tag" "$ell0" "$w" "$m" "$D" 2>&1 \
      | grep -E "^BOX|-> (PASS|FAIL)|EXCEPTION|tails:|interval Z1bc|self-check|sigma-operator|Y0 = |Z1 = |ворота:"
  fi
  i=$((i+1))
done < plan3.txt
echo "=== $(date +%H:%M:%S) lane $LANE DONE ==="
