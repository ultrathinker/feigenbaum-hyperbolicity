# -*- coding: utf-8 -*-
"""
tube_accept.py — приёмка трубки гиперболичности.

Проверяет ровно то, из чего складывается утверждение «на всём [2,4] у DT
ровно одно собственное значение вне единичного круга»:

  1. каждый бокс прошёл ворота Руше:  R(ℓ₀)·‖Δ(бокс)‖ < 1;
  2. цепочка непрерывна: соседние боксы ПЕРЕСЕКАЮТСЯ.
     Почему достаточно пересечения, а не «центр внутри предыдущего»:
     Руше даёт постоянство счёта на ВСЁМ боксе (счёт равен счёту в центре,
     где считалась резольвента).  Если боксы i и i+1 имеют общую точку ℓ*,
     то счёт в ℓ* равен и счёту в центре i, и счёту в центре i+1 — значит
     они равны между собой.  Шаг центров 0.8·w это обеспечивает
     (перекрытие 0.2·w), хотя центр соседа и лежит вне предыдущего бокса;
  3. якорь: бокс, накрывающий ℓ=3, где счёт сертифицирован точечно;
  4. покрытие: объединение боксов накрывает [2,4] без щелей.

Запуск: python tube_accept.py
"""
import os, sys, json, glob
import math
from fractions import Fraction

from flint import arb, ctx

ctx.prec = 128


def up(x):
    """float ВВЕРХ от верхнего конца arb (см. STRICT-UP в accept_full)."""
    v = arb(x).upper()
    f = float(v)
    if arb(f) < v:
        f = math.nextafter(f, math.inf)
    return f

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
# `04-CODE/tube_out` и `04-CODE/offsets.json` в
# пакете не существуют, поэтому прогон без env не проверял ничего.
OUT = os.environ.get('HYP_TUBE_OUT',
                     os.path.join(PKG, '03-CERTIFICATES', 'tube'))
ANCHOR = 3.0
TARGET_LO, TARGET_HI = 2.0, 4.0


def load_offsets():
    p = os.environ.get('HYP_OFFSETS', os.path.join(OUT, 'offsets.json'))
    if not os.path.exists(p):
        print('нет файла смещений: %s' % p)
        return {}
    return json.load(open(p, encoding='utf-8'))


def offset_for(offs, rec):
    """Смещение и хвостовые нормы берутся из ТОГО ЖЕ бокса существования,
    чью ветку использовал бокс трубки (поле `branch` в его json): именно её
    центр `P(ℓ)` стоит в `DT`, и именно к ней относится ρ*.  Если поля нет
    (старый формат) — худшее по всем накрывающим боксам."""
    tag = None
    br = rec.get('branch')
    if br and br.startswith('branch_') and br.endswith('.npz'):
        tag = br[len('branch_'):-4]
    if tag and tag in offs:
        v = offs[tag]
        return {'extra': v['extra'], 'C_norm': v['C_norm'],
                'BD_norm': v['BD_norm'], 'src': tag}
    cand = [v for v in offs.values() if v['lo'] <= rec['ell0'] <= v['hi']]
    if not cand:
        return None
    return {'extra': max(v['extra'] for v in cand),
            'C_norm': max(v['C_norm'] for v in cand),
            'BD_norm': max(v['BD_norm'] for v in cand), 'src': 'max'}


def full_test(r, off):
    """Полный тест Руше для ОПЕРАТОРА (не только его проекции).

    DT = [[A,B],[C,D]] в b-базисе — блоки САМОГО DT, а не M′ = I − DT.
    Разница не в букве: у DT хвостовой столбец мал (‖[B;D]‖ ≤ 1.95e-4),
    у M′ он содержит ещё единицу от тождественного оператора, и сравнение
    с ⊕ 0 ниже для M′ было бы ЛОЖНЫМ (возмущение ≈ 1 против R_A ≈ 3).
    раньше этот докстринг называл оператор M′ — то же ложное
    отождествление, которое этот докстринг раньше и создавал; §4.6 статьи
    он и есть единственное локальное обоснование формулы ниже.
    Сравниваем полный оператор при ℓ из бокса
    с блочно-диагональным S = A(ℓ₀) ⊕ 0 (хвостовой блок НУЛЕВОЙ):
      * резольвента S на |z|=1 — максимум по блокам: max(R_A, 1) = R_A;
      * возмущение DT − S по столбцовой норме:
        головные столбцы  [A′−A(ℓ₀); C′]  -> ‖Δ_бокс‖ + extra + ‖C‖,
        хвостовые столбцы [B′; D′]        -> ‖[B;D]‖ + extra.
    Хвостовой блок спектра вне круга не даёт: rho(D) ≤ ‖D‖ ≪ 1, поэтому
    счёт снаружи у S тот же, что у A(ℓ₀).

    Здесь было написано «сравниваем с
    A(ℓ₀) ⊕ D», и это не соответствовало формулам ниже: против ⊕ D
    хвостовое возмущение равно ‖B′‖ + ‖D′ − D‖, а ‖[B;D]‖ + extra — это
    норма всего хвостового столбца DT вместе с D′, то есть возмущение
    против ⊕ 0.  Числа не менялись: R_tot = max(R_A, 1/(1−‖D‖−extra))
    ≥ R_A — то, что нужно для сравнения с ⊕ 0, и даже с запасом.

    18.08 B-FIX: хвостовой столбец при переходе P → G* сдвигается на `extra`
    (см. tube_offset.py), поэтому честная верхняя граница ‖[B;D]‖+extra, а
    не 2‖[B;D]‖.  Старая формула мажорирует новую только при extra≤‖[B;D]‖;
    на 46 боксах BD_norm∈[1.29e-7, 1.95e-4] и extra до 2.86e-6 — на нижнем
    конце диапазона неравенство «2‖[B;D]‖ ≥ ‖[B;D]‖+extra» местами
    нарушено.  Спасал max() с головным членом, но выводить 2‖[B;D]‖ было
    не из чего.

    Про множитель 2 при ‖C‖ (вывод, а не «safety-factor»).  Блоки A, B, C, D
    здесь и ниже — блоки DT, а НЕ M' = I - DT: у M' хвостовой столбец несёт
    ещё единицу от тождественного оператора, и подстановка её массы сюда
    была бы неверна (§4.6 статьи, вывод через Ã_full = Ã_head ⊕ I_tail).
    Головной столбец полного возмущения есть
    Δ_полн = [A(ℓ,G*) − A(ℓ₀,P) ; C(ℓ,G*)], и его
    1-норма не превосходит суммы норм блоков:

        ‖Δ_полн‖₁ ≤ ‖A(ℓ,G*) − A(ℓ₀,P)‖₁ + ‖C(ℓ,G*)‖₁ ≤ (‖Δ‖ + extra) + ‖C‖ ,

    где `extra` покрывает переход P → G* (tube_offset.py).  Это и есть
    честная граница; используемая ниже ‖Δ‖ + extra + 2‖C‖ её мажорирует,
    поскольку 2‖C‖ ≥ ‖C‖.  То есть множитель 2 — не недоказанный шаг, а
    сознательный запас поверх выведенной оценки; он оставлен, чтобы число в
    сертификате не пришлось пересчитывать при уточнении ‖C‖.
    """
    if off is None:
        return None
    if not (off['BD_norm'] < 1.0):
        return {'ok': False, 'why': 'хвостовой блок не сжимает'}
    # Знаменатель берём по ‖D‖ + extra, а не по ‖D‖ в центре: блок D
    # параметризован в P(ℓ), а теорема применяется в G*(ℓ), и переход между
    # ними стоит не больше `extra`.  Оценка от этого только строже; на всех
    # 706 боксах R_tot всё равно определяется R_A ≈ 3, поскольку
    # 1/(1 − 1.95·10⁻⁴ − 2.9·10⁻⁶) ≈ 1.0002.
    # STRICT-UP (18.08): всё считается в arb и округляется ВВЕРХ.
    # Раньше R_tot, pert и произведение считались в обычном float, где каждая
    # операция округляет к ближайшему; ворота '<1' занижение не ловят по
    # построению, так что округление обязано быть направленным.
    BD = arb(off['BD_norm'])
    EX = arb(off['extra'])
    CN = arb(off['C_norm'])
    d_eff = up(BD + EX)
    if not (d_eff < 1.0):
        return {'ok': False, 'why': 'хвостовой блок не сжимает с учётом extra'}
    R_tot = max(r['R'], up(arb(1) / (arb(1) - arb(d_eff))))
    delta_norm = r.get('delta_norm')
    if delta_norm is None:
        return {'ok': False, 'why': "в записи бокса нет поля 'delta_norm'"}
    pert = max(up(arb(delta_norm) + EX + 2 * CN), up(BD + EX))
    prod = up(arb(R_tot) * arb(pert))
    return {'ok': prod < 1.0, 'R_tot': R_tot, 'pert': pert, 'prod': prod}


def main():
    recs = []
    for f in sorted(glob.glob(os.path.join(OUT, 'box_*.json'))):
        with open(f, encoding='utf-8') as fh:
            try:
                recs.append(json.load(fh))
            except json.JSONDecodeError as e:
                print('ОШИБКА: битый json %s: %s' % (f, e))
                return 1
    if not recs:
        print('нет результатов')
        return 1
    recs.sort(key=lambda r: r['ell0'])
    n = len(recs)

    # Цепочка, якорь и покрытие ниже сравнивали ПЕЧАТЬ `lo`/`hi` (float от
    # `ell0 ∓ w/2`), а движок сертифицирует бокс на
    # `arb('%.17e' % ell0) ∓ arb('%.17e' % w)/2`.  Разница до 1 ulp с каждой
    # стороны, и на левом конце отрезка она решающая: `2.025 − 0.05/2` во
    # float даёт РОВНО 2.0, поэтому «накрывает [2,4]» проходило с нулевым
    # запасом и не устанавливало ничего.  Считаем точные концы (тот же приём,
    # что в `glue.py::_cert_ends` и `_containment.py`) и требуем, чтобы
    # печать им отвечала — иначе испорченный `w` при нетронутых `lo`/`hi`
    # молча расширяет «сертифицированный» бокс.
    _ends_bad = []
    for r in recs:
        e, wq = Fraction('%.17e' % r['ell0']), Fraction('%.17e' % r['w'])
        r['lo_cert'], r['hi_cert'] = e - wq / 2, e + wq / 2
        if r['lo'] != r['ell0'] - r['w'] / 2 or r['hi'] != r['ell0'] + r['w'] / 2:
            _ends_bad.append(r['tag'])
    print('печатные концы согласованы с ell0 ∓ w/2: %s%s'
          % ('да' if not _ends_bad else '*** НЕТ ***',
             '' if not _ends_bad else ' ' + str(_ends_bad[:5])))

    # Флаг `pass` читался через `r.get('pass')`, то есть по
    # правдоподобию: строка, число, что угодно непустое сходило за успех.
    # Сохранённый флаг и так слабое свидетельство (полный тест ниже
    # пересчитывается заново) — но раз уж он читается, читаться он должен
    # строго, и нечитаемое значение обязано валить приёмку.
    nonbool = [r['tag'] for r in recs if not isinstance(r.get('pass'), bool)]
    if nonbool:
        print('поле pass не булево в %d боксах: %s'
              % (len(nonbool), ', '.join(nonbool[:5])))
        return 1

    bad = [r for r in recs if r['pass'] is not True]
    print('боксов: %d,  провалов ворот: %d' % (n, len(bad)))
    for r in bad[:10]:
        print('   FAIL %s ell0=%.6f: %s' % (r['tag'], r['ell0'],
                                            r.get('error', 'prod=%.4f' % r.get('prod', -1))))

    # --- цепочка ---
    okrecs = [r for r in recs if r['pass'] is True]
    breaks = []
    # Точное касание (b.lo == a.hi) здесь считается РАЗРЫВОМ, а не
    # достаточным пересечением -- в отличие от glue.py (46 боксов
    # существования, критерий §3.6). Это намеренно: дефект 5 (§4.9)
    # показал, что такое касание на практике случается и численно
    # хрупко (границы двух боксов посчитаны независимо); тогда его
    # закрыли добавлением бокса, а не ослаблением этой проверки.
    for i in range(len(okrecs) - 1):
        a, b = okrecs[i], okrecs[i + 1]
        if not (b['lo_cert'] < a['hi_cert']):
            breaks.append((a['tag'], b['tag'], float(a['hi_cert']),
                           float(b['lo_cert']), a['w']))
    print('разрывов цепочки (соседние боксы не пересекаются): %d' % len(breaks))
    for t in breaks[:10]:
        print('   %s -> %s: hi=%.6f <= lo=%.6f' % (t[0], t[1], t[2], t[3]))

    # запас цепочки: длина пересечения соседей в долях ширины
    margins = [float((okrecs[i]['hi_cert'] - okrecs[i + 1]['lo_cert'])
                     / Fraction('%.17e' % okrecs[i]['w']))
               for i in range(len(okrecs) - 1)]
    print('запас перекрытия (доля ширины): min %.3f, median %.3f'
          % (min(margins), sorted(margins)[len(margins) // 2]))

    # --- якорь ---
    anch = [r for r in recs
            if r['lo_cert'] <= Fraction(ANCHOR) <= r['hi_cert']
            and r['pass'] is True]
    print('боксов, накрывающих якорь ℓ=%.1f: %d %s'
          % (ANCHOR, len(anch), [r['tag'] for r in anch[:5]]))

    # --- покрытие ---
    ivs = sorted((r['lo_cert'], r['hi_cert']) for r in recs if r['pass'] is True)
    merged = []
    for lo, hi in ivs:
        if merged and lo <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], hi)
        else:
            merged.append([lo, hi])
    print('компонент покрытия: %d' % len(merged))
    for lo, hi in merged[:6]:
        print('   [%.6f, %.6f]' % (float(lo), float(hi)))
    covers = any(lo <= Fraction(TARGET_LO) and hi >= Fraction(TARGET_HI)
                 for lo, hi in merged)
    print('накрывает [%.1f, %.1f]: %s' % (TARGET_LO, TARGET_HI,
                                          'ДА' if covers else 'НЕТ'))
    if not covers and merged:
        print('   реально накрыто: [%.6f, %.6f]'
              % (float(merged[0][0]), float(merged[-1][1])))
        gaps = [(float(merged[i][1]), float(merged[i + 1][0]))
                for i in range(len(merged) - 1)]
        for g in gaps[:8]:
            print('   ЩЕЛЬ [%.6f, %.6f]' % g)

    # --- сводка чисел ---
    ok = [r for r in recs if r['pass'] is True]
    if ok:
        pr = [r['prod'] for r in ok]
        R = [r['R'] for r in ok]
        D = [r['delta_norm'] for r in ok]
        dl = [r['delta_mid'] for r in ok]
        l2 = [r['lam2_mid'] for r in ok]
        nout = set(r['n_out_mid_float'] for r in ok)
        print('\nR:      %.4f … %.4f' % (min(R), max(R)))
        print('‖Δ‖:    %.3e … %.3e' % (min(D), max(D)))
        print('R·‖Δ‖:  %.4f … %.4f   (порог 1)' % (min(pr), max(pr)))
        print('δ(ℓ):   %.4f … %.4f' % (min(dl), max(dl)))
        print('λ₂(ℓ):  %.4f … %.4f' % (min(l2), max(l2)))
        print('число собственных значений вне круга в центрах (float): %s' % sorted(nout))
        tot = sum(r.get('wall_s', 0) for r in recs)
        print('счёт: %.1f ядро-часов' % (tot / 3600))

    # --- полный тест: проекция -> оператор ---
    offs = load_offsets()
    full_bad, full_ok, no_off = [], [], []
    worst = None
    n_src_max = 0
    if offs:
        for r in okrecs:
            off = offset_for(offs, r)
            if off is not None and off.get('src') == 'max':
                n_src_max += 1
            t = full_test(r, off)
            if t is None:
                no_off.append(r['tag'])
            elif t['ok']:
                full_ok.append((r, t))
            else:
                full_bad.append((r, t))
            # «Худший полный тест» берём по ВСЕМ боксам, у которых он посчитан,
            # а не только по ПРОШЕДШИМ.  Раньше `worst` обновлялся внутри
            # `elif t['ok']`, и напечатанное число было максимумом по прошедшим,
            # то есть меньше единицы ПО ПОСТРОЕНИЮ: провалившийся бокс из него
            # выпадал.  Это делало строку бесполезной как границу по семейству —
            # и хуже: при порче одного бокса она не росла, а УМЕНЬШАЛАСЬ
            # (0.991844 -> 0.989007), потому что худший из оставшихся ниже.
            # Вердикт приёмки по-прежнему решает `full_bad`, а не эта величина.
            if 'prod' in t and (worst is None or t['prod'] > worst[1]['prod']):
                worst = (r, t)
        print('\nполный тест (оператор, а не только проекция):')
        print('  прошли %d, не прошли %d, без данных о смещении %d'
              % (len(full_ok), len(full_bad), len(no_off)))
        print('  боксов без поля branch (запасной путь src=max по всем '
              'накрывающим боксам смещений): %d' % n_src_max)
        if worst:
            # Раньше здесь стояли только 4 знака после запятой, округлённые
            # К БЛИЖАЙШЕМУ (`%.4f` от уже направленно округлённого вверх `prod`).
            # Это создавало щель до 5·10⁻⁵ между напечатанным числом и настоящей
            # мажорантой: `_numbers_check.py` мог спот-проверить только СТРОКУ
            # «0.9919», а направление против точного факта проверить было нечем.
            # Полная точность печатается ЯВНО, чтобы живая сверка была возможна.
            # Четыре знака печатаем с округлением ВВЕРХ: величина мажорируется
            # единицей, значит короткая запись обязана быть не меньше факта.
            # `%.4f` округляет к ближайшему и на 0.991843707457 даёт 0.9918 —
            # МЕНЬШЕ мажоранты; читатель, сверяющий статью со этой строкой,
            # принимал 0.9919 статьи за ошибку (так и случилось в ревью).
            _p = worst[1]['prod']
            _p4 = math.ceil(_p * 10000.0) / 10000.0
            # Формат строки разбирается воротами (_numbers_check.py), поэтому
            # «= %.4f  (точно: %.12f)» сохраняется дословно, а пометка про
            # направление округления приписывается ПОСЛЕ.
            print('  худший запас: %s ell0=%.5f  R_tot·(‖Δ‖+extra+хвост) = %.4f '
                  ' (точно: %.12f)  [4 знака округлены ВВЕРХ]'
                  % (worst[0]['tag'], worst[0]['ell0'], _p4, _p))
        for r, t in sorted(full_bad, key=lambda x: -x[1].get('prod', 0))[:10]:
            print('   НЕ ПРОШЁЛ %s ell0=%.5f w=%.5f: %s'
                  % (r['tag'], r['ell0'], r['w'],
                     ('prod=%.4f' % t['prod']) if 'prod' in t else t.get('why')))
    else:
        print('\n(смещений нет — полный тест НЕ ВЫПОЛНЯЛСЯ, приёмка не пройдена)')

    verdict = (not bad) and (not breaks) and covers and len(anch) > 0 \
        and bool(offs) and not full_bad and not no_off and not _ends_bad
    print('\nПРИЁМКА: %s' % ('ПРОЙДЕНА' if verdict else 'НЕ ПРОЙДЕНА'))
    return 0 if verdict else 2


if __name__ == '__main__':
    sys.exit(main())
