# -*- coding: utf-8 -*-
"""
_containment.py — проверка вложенности боксов трубки в боксы существования.

Член `extra` и блочные нормы для бокса трубки берутся из ТОГО бокса
существования, чью ветку использовал бокс трубки.  Эти величины доказаны
для ℓ ВНУТРИ бокса существования.  Значит бокс трубки обязан целиком
лежать внутри своего бокса существования — иначе на выступающем куске
`extra` формально не обоснован.
"""
import os, sys, json, glob
from fractions import Fraction


def _cert_ends(ell0, w):
    """Концы ИМЕННО ТОГО ℓ-интервала, на котором бокс сертифицирован.

    В json лежат `lo`/`hi` = ПЕЧАТЬ `ell0 ∓ w/2` во float, а движок работает
    с `arb('%.17e' % ell0) ∓ arb('%.17e' % w)/2` (`rig2fix3.py`,
    `hyp_rouche.rigorous_delta`).  Разница до 1 ulp с каждой стороны, и на
    левом конце отрезка она решает: `2.025 − 0.05/2` во float даёт РОВНО
    `2.0`, поэтому сравнение печати с печатью давало запас `0.000e+00` и не
    устанавливало ничего.  Точный конец `g00` лежит на 9.14e-17 НИЖЕ двойки,
    то есть запас положителен — но это надо ПОСЧИТАТЬ, а не унаследовать от
    округления.  Тот же приём уже применён в `glue.py::_cert_ends`.
    """
    a, b = Fraction('%.17e' % ell0), Fraction('%.17e' % w)
    return a - b / 2, a + b / 2

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
# Умолчания указывали на `04-CODE/tube_out`
# и `04-CODE/offsets.json` — в пакете нет ни того, ни другого.  Без env
# скрипт падал трейсбеком на первой же строке, и добавленная
# диагностика пустого входа (ниже, «НЕЧЕГО ПРОВЕРЯТЬ», код 2) была
# недостижима.  Умолчание — туда, где сертификаты реально лежат; та же
# конвенция, что в `tests/_stats.py` и `tests/_numbers_check.py`.
TUBE = os.environ.get('HYP_TUBE_OUT',
                      os.path.join(PKG, '03-CERTIFICATES', 'tube'))
OFFS = os.environ.get('HYP_OFFSETS', os.path.join(TUBE, 'offsets.json'))
if not os.path.exists(OFFS):
    print('НЕЧЕГО ПРОВЕРЯТЬ: нет файла смещений %s.' % OFFS)
    print('Задайте HYP_OFFSETS (в пакете — 03-CERTIFICATES/tube/offsets.json).')
    sys.exit(2)
offs = json.load(open(OFFS, encoding='utf-8'))

bad, ok, skipped, clipped = [], 0, [], []
worst = None
worst_raw = None
# glob.glob возвращает порядок файловой системы; от него зависели и
# выбор «худшего» при равенстве маржи, и то, какие именно 20
# нарушений попадут в печать. sorted() делает отчёт воспроизводимым.
for f in sorted(glob.glob(os.path.join(TUBE, 'box_*.json'))):
    j = json.load(open(f, encoding='utf-8'))
    if not j.get('pass'):
        continue
    br = j.get('branch', '')
    tag = br[len('branch_'):-4] if br.startswith('branch_') else None
    v = offs.get(tag)
    if v is None:
        bad.append((j['tag'], 'нет данных о боксе существования %s' % tag))
        continue
    # Сначала — бокс ЦЕЛИКОМ.  Если он и так лежит в своём боксе
    # существования, обрезать нечего: `extra` обоснован на всём боксе.
    # Обе стороны — точные концы, а не их печать (см. _cert_ends).
    v_lo, v_hi = _cert_ends(v['ell0'], v['w'])
    j_lo, j_hi = _cert_ends(j['ell0'], j['w'])
    slack_lo = j_lo - v_lo
    slack_hi = v_hi - j_hi
    m_raw = min(slack_lo, slack_hi)
    if worst_raw is None or m_raw < worst_raw[1]:
        worst_raw = (j['tag'], m_raw, tag)
    if slack_lo < 0 or slack_hi < 0:
        # Бокс выступает за свой бокс существования.  Важна тогда только
        # та часть, что лежит в целевом отрезке [2,4]: за его пределами
        # утверждение и не формулируется.
        # Прежде обрезка стояла ПЕРЕД сравнением и применялась ко всем
        # боксам подряд.  Из-за этого `t0695` = [4.0000, 4.0012], чьё
        # пересечение с [2,4] вырождено в точку, уходил в `skipped` —
        # хотя целиком лежит в `gtop` = [3.9775, 4.0075] с запасом
        # 6.3e-3, и проверять у него было что.
        # Обрезка тоже точная: клип на double `2.0`/`4.0` возвращал бы ту же
        # подмену печатью, от которой уводит _cert_ends.
        lo, hi = max(j_lo, Fraction(2)), min(j_hi, Fraction(4))
        if lo >= hi:
            # пересечение бокса с [2,4] пусто или вырождено в точку,
            # и вне [2,4] бокс не вложен — утверждение на нём не делается
            skipped.append(j['tag'])
            continue
        slack_lo = lo - v_lo
        slack_hi = v_hi - hi
        clipped.append(j['tag'])
    if slack_lo < 0 or slack_hi < 0:
        bad.append((j['tag'], 'выступает: lo на %.2e, hi на %.2e'
                    % (float(min(slack_lo, 0)), float(min(slack_hi, 0)))))
    elif slack_lo == 0 or slack_hi == 0:
        # Нулевой запас на ТОЧНЫХ концах — это уже не артефакт печати, а
        # касание: на границе `extra` обоснован ровно в одной точке, и
        # утверждение о вложенности вырождается.  Раньше такой ноль был
        # неотличим от успеха.
        bad.append((j['tag'], 'нулевой запас (касание) в %s: lo %s, hi %s'
                    % (tag, slack_lo == 0, slack_hi == 0)))
    else:
        ok += 1
        m = min(slack_lo, slack_hi)
        if worst is None or m < worst[1]:
            worst = (j['tag'], m, tag)

# Раньше при пустом входе (например, HYP_TUBE_OUT
# не задан, и каталог по умолчанию пуст или отсутствует) скрипт печатал
# «вложено 0, нарушений 0» и выходил с кодом 0.  Это вакуумный успех:
# проверка, которая не может упасть, потому что ей нечего проверять.
# Ровно тот класс, что объявлен дефектом в дисциплине проекта.
if ok == 0 and not bad and not skipped and not clipped:
    print('НЕЧЕГО ПРОВЕРЯТЬ: в %s не найдено ни одного box_*.json.' % TUBE)
    print('Задайте HYP_TUBE_OUT на каталог с боксами трубки '
          '(в пакете — 03-CERTIFICATES/tube).')
    sys.exit(2)

print('боксов трубки вложено полностью: %d' % ok)
if clipped:
    print('из них по пересечению с [2,4] (бокс выступает за целевой отрезок): '
          '%d %s' % (len(clipped), sorted(clipped)))
if skipped:
    print('вне [2,4] (пересечение пусто или точка), проверка не нужна: %d %s'
          % (len(skipped), sorted(skipped)))
print('нарушений: %d' % len(bad))
for t, why in bad[:20]:
    print('   %s: %s' % (t, why))
if worst:
    print('минимальный запас вложенности: %.3e (бокс %s в %s)'
          % (float(worst[1]), worst[0], worst[2]))
if worst_raw:
    # Запас ДО обрезки. У обрезанного бокса напечатанный выше минимум равен
    # ровно нулю по построению (обрезка сажает конец на границу [2,4]), и
    # «0.000e+00» читается как граничный случай, хотя граничен он у проверки,
    # а не у математики. Печатаем и необрезанный запас, чтобы было видно,
    # какой из двух нулей чей.
    print('минимальный запас ДО обрезки на [2,4]: %.3e (бокс %s в %s)'
          % (float(worst_raw[1]), worst_raw[0], worst_raw[2]))
sys.exit(0 if not bad else 2)
