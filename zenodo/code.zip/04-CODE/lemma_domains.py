"""
lemma_domains.py — RIGOROUS Lemma 1: margin_a, |U|min, margin_c, M_W for Cauchy tail.

Cover the circles |t-c| = r and |t-c| = R with M=256 arcs (each arc is a small acb box).
Compute rigorously:
  - (a) max |t/α^ℓ - c| on |t-c| ≤ r   →   margin_a = r - max |t/α^ℓ - c|
  - (b) min |U| on |t-c| ≤ r, where U = G(t/α^ℓ)   →   |U|min
  - (c) max |W - c| on |t-c| ≤ r, where W = U^ℓ   →   margin_c = r - max |W - c|
  - max |U^ℓ| on |t-c| = R  →  M_W_R (for Cauchy tail on W)

All arithmetic uses python-flint arb (directed) / acb.
"""

import flint
from flint import arb, acb
import math

PI = arb.pi()
TAU = 2 * PI


def poly_eval_at_acb(coeffs: list, z: acb) -> acb:
    """Horner evaluation of Σ coeffs[k] (z - c)^k where c is in coeffs? NO: coeffs are at c.

    Actually coeffs are the polynomial at center c. So:
    P(t) = Σ coeffs[k] (t - c)^k.
    P(z) = coeffs[N] + (z - c) * (coeffs[N-1] + (z - c) * (coeffs[N-2] + ...))
    """
    if not coeffs:
        return acb(0)
    N = len(coeffs) - 1
    val = acb(coeffs[N])
    for k in range(N - 1, -1, -1):
        val = val * (z - acb(coeffs[0].c if hasattr(coeffs[0], 'c') else 0)) + acb(coeffs[k])
    return val


def poly_eval_at_acb_centered(coeffs: list, c_center, z: acb) -> acb:
    """Horner evaluation of Σ coeffs[k] (z - c_center)^k."""
    if not coeffs:
        return acb(0)
    N = len(coeffs) - 1
    val = acb(coeffs[N])
    z_minus_c = z - acb(c_center)
    for k in range(N - 1, -1, -1):
        val = val * z_minus_c + acb(coeffs[k])
    return val


def arc_to_acb_box(c_center, R: arb, theta_lo: arb, theta_hi: arb) -> acb:
    """Construct acb box containing the arc {c + R e^{iθ} : θ ∈ [theta_lo, theta_hi]}.

    Returns: acb box (rectangle [Re_lo, Re_hi] + i [Im_lo, Im_hi]) covering the arc.

    FIX: вычисляем cos/sin на ИНТЕРВАЛЕ θ, а не в
    его концах.  Дуги центрированы на углах θ_m = m·2π/M, и в четырёх
    из них (m=0, M/4, M/2, 3M/4) на [θ_lo, θ_hi] есть внутренний
    экстремум cos или sin; старая версия брала значения только в
    концах и для m=0, например, давала re-интервал, вырожденный в
    точку R·cos(π/M) — и точка c+R оказывалась ВНЕ коробки.
    flint arb корректно обрабатывает внутренние экстремумы при
    подаче интервального аргумента (.union(...).cos()).
    """
    # Interval sin/cos: works correctly for arcs that contain 0, π/2, π, 3π/2.
    theta_int = theta_lo.union(theta_hi)
    cos_int = theta_int.cos()
    sin_int = theta_int.sin()
    re_lo = cos_int.lower()
    re_hi = cos_int.upper()
    im_lo = sin_int.lower()
    im_hi = sin_int.upper()
    c_real = c_center.real if isinstance(c_center, acb) else c_center
    z_re = (c_real + R * re_lo).union(c_real + R * re_hi)
    z_im = (R * im_lo).union(R * im_hi)
    return acb(z_re, z_im)


def verify_lemma_1(G_poly_coeffs: list, alpha: arb, ell: arb, c: arb, r: arb, R: arb, M: int = 256):
    """
    RIGOROUS verification of Lemma 1 on D_r and D_R.

    Returns:
        dict with:
            margin_a: strict lower bound on r - max_{|t-c|≤r} |t/α^ℓ - c|
            U_min: strict lower bound on min_{|t-c|≤r} |U|.
                   ВЫЧИСЛЯЕТСЯ на окружности |t-c| = r, а на круг
                   переносится не принципом минимума модуля (он
                   требует отсутствия нулей — то есть того, что
                   доказывается), а через Re U: она гармоническая,
                   минимум на замкнутом круге достигается на границе,
                   значит Re U > 0 на окружности влечёт Re U > 0 в
                   круге, отсюда отсутствие нулей, и только после
                   этого |U| >= U_min по кругу. Порядок существен,
                   подробнее — комментарий NONZERO ниже
            margin_c: strict lower bound on r - max_{|t-c|≤r} |W - c|
            M_W_R: strict upper bound on max_{|t-c|≤R} |U^ℓ|
            arcs_checked: M
            OK: True if all margins are positive and (U_min ≥ 0.5)
    """
    # (a) max |t/α^ℓ - c| on |t-c| ≤ r
    # t/α^ℓ - c = (c + h)/α^ℓ - c = c/α^ℓ + h/α^ℓ - c = c · (1/α^ℓ - 1) + h/α^ℓ
    # |t/α^ℓ - c| ≤ |c| · |1/α^ℓ - 1| + |h|/|α^ℓ| ≤ |c| · |1/α^ℓ - 1| + r/|α^ℓ|
    # (Strict ball arithmetic)
    alpha_ell = alpha ** ell
    inv_alpha_ell = 1 / alpha_ell
    inv_alpha_ell_abs = abs(inv_alpha_ell)
    one_minus_ell = inv_alpha_ell - 1
    one_minus_ell_abs = abs(one_minus_ell)
    abs_c = abs(c)
    c_part = abs_c * one_minus_ell_abs
    r_part = r * inv_alpha_ell_abs
    max_tc_bound = c_part + r_part  # strict upper bound on max |t/α^ℓ - c|
    margin_a = r - max_tc_bound  # strict lower bound on r - max

    # Set up: precompute G(z) for the polynomial part
    # Use polynomial at center c: G(t) = Σ g_k (t - c)^k

    # (b), (c), M_W: cover the boundary with M arcs
    arcs = []
    arc_w = TAU / M
    for m in range(M):
        th_m = arb(m) * arc_w
        th_lo = th_m - arc_w / 2
        th_hi = th_m + arc_w / 2
        arcs.append((th_m, th_lo, th_hi))

    # Compute on |t-c| = r (for (b), (c))
    U_min = None  # arb lower bound on |U|
    Wc_max = arb(0)  # arb upper bound on |W - c|
    cut_ok = True
    # NONZERO: Re U — ГАРМОНИЧЕСКАЯ функция, поэтому её минимум на
    # замкнутом круге достигается на границе.  Значит положительность Re U на
    # окружности влечёт Re U > 0 во всём круге, а отсюда сразу: U не имеет
    # нулей внутри (значит рекуррентность Миллера для W = U^ell не встречает
    # особенности и ряд сходится в круге) и образ U лежит в правой
    # полуплоскости (значит главная ветвь Log U однозначна и согласована с
    # затравкой в вещественной положительной точке).
    #
    # Это заменяет прежнюю проверку «U не задевает разрез»: у неё была не та
    # посылка.  Отдельно закрывается дыра прежней редакции — U_min считался
    # по ОКРУЖНОСТИ, а в docstring объявлялся минимумом по КРУГУ; мостом
    # служил принцип минимума модуля, применимый лишь к функции без нулей,
    # то есть ровно к тому, что требовалось доказать.  Теперь порядок верный:
    # сначала Re U > 0 (гармонично, граница достаточна), затем отсутствие
    # нулей, и только затем |U| >= U_min по кругу.
    ReU_min_r = None
    ReU_min_R = None
    failures = []
    for idx, (th_m, th_lo, th_hi) in enumerate(arcs):
        # arc on |t-c| = r
        z_arc = arc_to_acb_box(c, r, th_lo, th_hi)
        # t/α^ℓ on the arc
        z_alpha = z_arc / acb(alpha_ell)
        # U = G(z_alpha)
        U_box = poly_eval_at_acb_centered(G_poly_coeffs, c, z_alpha)
        # |U| lower bound
        U_abs_lower = U_box.abs_lower()
        if U_min is None or U_abs_lower < U_min:
            U_min = U_abs_lower
        # Check: does U_box cross (-∞, 0]?
        # Heuristic: if U_box.real.upper() < 0 and U_box.imag contains 0.
        # More carefully: a point z is in (-∞, 0] iff z.real < 0 and z.imag = 0.
        # U-box crosses (-∞, 0] iff there exists z ∈ U-box with z.real < 0 and z.imag = 0.
        # In particular: if U_box.imag contains 0 (overlaps [0, 0]) AND U_box.real overlaps (-∞, 0), then yes.
        # Conservative: if U_box.real.upper() < 0, then all U are negative real (or all negative).
        #               Wait, no, U_box could have imag > 0 but real < 0.
        # Define: check if U_box overlaps {z : z.real < 0 and z.imag = 0}.
        # The interval for z.real < 0 ∩ U_box is: U_box.real ∩ (-∞, 0). If this is non-empty
        # AND U_box.imag contains 0, then the box crosses (-∞, 0].
        # CUT-CHECK: разрез ветви W = U^ℓ.
        # W однозначно определена на ℂ \ (-∞, 0]; поэтому ОБЯЗАНЫ
        # проверить, что образ U-коробки не задевает разрез.  Коробка
        # пересекает (-∞, 0]  ⇔  ∃z ∈ U_box: z.real < 0  И  z.imag = 0
        # ⇔  (U_box.real.lower() < 0)  И  (U_box.imag.lower() ≤ 0)  И
        #     (U_box.imag.upper() ≥ 0).  Эта проверка была закомментирована;
        # вторая её реализация жила в rig_lib.build_majorants, которую никто
        # не вызывал; позже весь тот мёртвый блок удалён (он содержал
        # максимум нижних границ Re U вместо минимума и float-арифметику,
        # то есть проходил бы и при Re U < 0 на какой-то дуге).  После
        # правки arc_to_acb_box
        # коробки корректно накрывают дугу, и проверка осмысленна.
        Re_lo = U_box.real.lower()
        Im_lo = U_box.imag.lower()
        Im_hi = U_box.imag.upper()
        if (Re_lo < 0) and (Im_lo <= 0) and (Im_hi >= 0):
            cut_ok = False
        if ReU_min_r is None or Re_lo < ReU_min_r:
            ReU_min_r = Re_lo
        # For our case, we expect U to be in the right half plane, so this shouldn't happen.

        # W = U^ℓ (acb_pow)
        W_box = U_box ** ell  # may pick any branch
        # Check W_box doesn't cross the negative real axis... actually for (c) we just need |W - c| upper bound
        # |W - c| upper bound: take acb box (W_box - c), then |W_box - c|_upper
        W_minus_c = W_box - acb(c)
        # v6/F2: abs(acb) is a BALL — the certified `>` fold could silently
        # drop candidates on wide balls (interval ℓ). Use the exact upper
        # endpoint (.abs_upper(), rad = 0, comparisons decidable).
        Wc_abs_upper = W_minus_c.abs_upper()
        if Wc_abs_upper > Wc_max:
            Wc_max = Wc_abs_upper

    margin_c = r - Wc_max

    # Compute M_W_R: max |U^ℓ| on |t-c| = R
    M_W_R = arb(0)
    for idx, (th_m, th_lo, th_hi) in enumerate(arcs):
        z_arc = arc_to_acb_box(c, R, th_lo, th_hi)
        z_alpha = z_arc / acb(alpha_ell)
        U_box = poly_eval_at_acb_centered(G_poly_coeffs, c, z_alpha)
        rl_ = U_box.real.lower()
        if ReU_min_R is None or rl_ < ReU_min_R:
            ReU_min_R = rl_
        # |U| upper bound
        U_abs_upper = U_box.abs_upper()
        # |U^ℓ| upper bound: |U|^ℓ — v6/F2: interval ℓ makes this a ball;
        # fold the exact upper endpoints (directed max, no dropped candidates)
        M_W_arc_up = (U_abs_upper ** ell).upper()
        if M_W_arc_up > M_W_R:
            M_W_R = M_W_arc_up

    nonzero_ok = bool(ReU_min_r > 0 and ReU_min_R > 0)

    return {
        "margin_a": margin_a,
        "U_min": U_min,
        "ReU_min_r": ReU_min_r,
        "ReU_min_R": ReU_min_R,
        "nonzero_ok": nonzero_ok,
        "margin_c": margin_c,
        "M_W_R": M_W_R,
        "arcs_checked": M,
        "cut_ok": cut_ok,
        "max_tc_bound": max_tc_bound,
        "Wc_max": Wc_max,
    }


def strict_arc_to_acb_box(c_center, R: arb, theta_lo: arb, theta_hi: arb) -> acb:
    """Slightly tighter version using midpoint radius."""
    # midpoint and radius
    th_m = (theta_lo + theta_hi) / 2
    dth = (theta_hi - theta_lo) / 2
    # cos([θ_m - dθ, θ_m + dθ]) ⊆ [cos(θ_m) - dth, cos(θ_m) + dth] (loose: |cos changes by ≤ dth|)
    # sin same
    # Actually we want the BANDING box. Use exact cos(θ_lo), cos(θ_hi) bounds.
    # Above implementation is correct.
    return arc_to_acb_box(c_center, R, theta_lo, theta_hi)
