# -*- coding: utf-8 -*-
"""
op_sig.py — sigma-Taylor assembly of F~ and M' around the center P(l0),
in bivariate (t, sigma) arb series with tail-mass bookkeeping (sig_lib.Sig).

Mirrors tube_lib formulas exactly; the sigma-structure:
  alpha(l) = -1/P(1)(l)               scalar sigma-series
  s(l)    = t*alpha(l)^{-l}           scalar c1 = exp(-(l0+sigma)Log alpha)
  U(l)    = P(l) o s(l)               bivariate Horner (t-cap NG)
  LogU(l) = L(sigma)                  recursion  i U0 * L_i = i U_i - sum ...
  W(l)    = exp(l LogU(l))            seeded bivariate exp (seed = Miller W0)
  Ulm(l)  = U^{l-1}                   seeded exp (seed = Miller at l0-1)
  M'(l)   columns                     DF(psi_k) sigma-slices, t-cap NP
"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from flint import arb, ctx
import tube_lib as tl
import sig_lib as sl

NP = tl.N_p
NG = tl.N_G
NW = tl.N_W
C = tl.c_arb
R = tl.r_arb


def _smul(a, b, D):
    """scalar sigma-series product."""
    out = [arb(0)] * (D + 1)
    for i in range(D + 1):
        for j in range(0, i + 1):
            if j < len(a) and (i - j) < len(b):
                out[i] = out[i] + a[j] * b[i - j]
    return out


def _sconv(a, b, D, smax):
    """CONV-FIX.

    `_smul` обрезает произведение на степени D и МОЛЧА теряет члены
    head x head степеней D+1..2D.  Их масса в tau не входила ни в одном из
    пяти мест, где произведение считается вручную (c2, Da, lc2, coef0,
    coef), поэтому tau там не был мажорантой: прямой замер на tau_Da дал
    истинный хвост 1.044e-14 против заявленного 3.904e-15 (занижение 2.67x).

    Здесь произведение возвращается вместе с ТОЧНОЙ массой отброшенного:
    sum_{i+j>D} |a_i b_j| smax^{i+j}.
    """
    out = [arb(0)] * (D + 1)
    dropped = arb(0)
    for i in range(len(a)):
        ai = a[i]
        if ai == 0:
            continue
        for j in range(len(b)):
            if b[j] == 0:
                continue
            t = ai * b[j]
            if i + j <= D:
                out[i + j] = out[i + j] + t
            else:
                dropped = dropped + abs(t) * (smax ** (i + j))
    return out, dropped.upper()


def _log_tail(Uslices, norm_Uinv0, D, smax, R):
    """LOG-TAIL-FIX.

    `tauL` покрывал только снос собственного tau от U, но не sigma-хвост
    самого Log(U): даже если U — многочлен по sigma, его логарифм им не
    является, и члены степеней > D в tau не входили.

    Мажоранта: U = U0(1 + H), H = U0^{-1}(U − U0);  |[Log(1+H)]_i| <= v_i,
    где v — коэффициенты −log(1−H_maj), H_maj(s) = sum ||H_i|| s^i.
    Хвост = замкнутое значение минус посчитанная голова (t-ряды образуют
    банахову алгебру с весами r^k, поэтому скалярная мажоранта законна)."""
    hk = [arb(0)]
    for i in range(1, len(Uslices)):
        hk.append((norm_Uinv0 * sl.xnorm(Uslices[i], R) * (smax ** i)).upper())
    h_abs = arb(0)
    for x in hk[1:]:
        h_abs = h_abs + x
    if not (h_abs < 1):
        raise RuntimeError('_log_tail: |H| >= 1 (%s)' % h_abs)
    v = [arb(0)] * (D + 1)
    for n in range(1, D + 1):
        acc = (hk[n] if n < len(hk) else arb(0)) * arb(n)
        for k in range(1, n):
            acc = acc + arb(k) * v[k] * (hk[n - k] if n - k < len(hk) else arb(0))
        v[n] = acc / arb(n)
    head = arb(0)
    for x in v:
        head = head + x
    closed = -((1 - h_abs).log())
    t = closed - head
    if not (t >= 0):
        t = closed
    return t.upper()


def _smass(a, smax):
    s = arb(0)
    for i, x in enumerate(a):
        s = s + abs(x) * (smax ** i)
    return s.upper()


def build_operator_sigma(P0_list, tay, m, ell0, w, D, prec=256):
    ctx.prec = prec
    ell0_a = arb('%.17e' % ell0)
    smax = arb('%.17e' % (w / 2.0))

    # ---------- base pkg at sigma=0 (engine reuse) ----------
    pkg = tl.build_pkg_fast(P0_list, ell0_a)
    W0 = list(pkg['W_P'])
    Ulm0 = list(pkg['U_pow_lm1'])
    U0_pad = list(pkg['Ubar_u_coeffs']) + [arb(0)] * (NW - NG)

    # ---------- center sigma-slices (u-coords) ----------
    Pc = [tl.reexpand_fast([arb(x) for x in tay[i]], C, R, NP) for i in range(m + 1)]
    Pcp = [[(arb(k + 1) * Pc[i][k + 1] if k + 1 <= NP else arb(0))
            for k in range(NP + 1)] for i in range(m + 1)]

    # ---------- scalar sigma-series ----------
    G1 = [sum((Pc[i][k] * ((1 - C) ** k) for k in range(NP + 1)), arb(0))
          for i in range(m + 1)]
    recip, tau_recip, _ = sl.scalar_recip(G1, D, smax)       # 1/G1
    alpha_s = [-a for a in recip]                            # -1/G1 > 0
    tau_alpha = tau_recip
    # LOG-ARG-FIX.  Здесь стояло
    #     loga_s, tau_loga = sl.scalar_log_from_recip(alpha_s, D, smax)
    # — разрыв цепочки того же рода, что EXP-ARG-FIX ниже: scalar_log_from_recip
    # мажорирует хвост Log КОНЕЧНОГО многочлена, который ей дали, а alpha_s —
    # усечение со своим хвостом tau_alpha; в tau_h ниже tau_alpha не входил
    # вовсе (для Da и c2 он передаётся явно, см. строки ниже — пропуск был
    # только на переходе к логарифму).  Чинится не добавкой липшицева члена,
    # а тождеством: alpha = -1/G1, поэтому Log(alpha) = -Log(-G1), а -G1 —
    # точный конечный многочлен, входного хвоста у него нет по построению.
    # Голова та же (коэффициенты 0..D у Log(alpha) определяются коэффициентами
    # 0..D у recip, которые точны), а tau выходит МЕНЬШЕ прежнего — поэтому
    # уже опубликованные сертификаты, построенные на старом tau, остаются
    # верными; отдельный сторож logtail_retro.py проверяет это по всем 46
    # боксам: голова совпадает, а строгая мажоранта хвоста нигде не выше той,
    # на которой построены депонированные сертификаты.
    _logmG1, _tau_logmG1 = sl.scalar_log_from_recip([-g for g in G1], D, smax)
    loga_s = [-x for x in _logmG1]
    tau_loga = _tau_logmG1
    if os.environ.get('HYP_LOGTAIL_DUMP'):
        _old_s, _old_t = sl.scalar_log_from_recip(alpha_s, D, smax)
        _hmax = max([abs(_old_s[i] - loga_s[i]).upper()
                     for i in range(min(len(_old_s), len(loga_s)))])
        sys.stderr.write('LOGTAIL %s new=%s old=%s headdiff=%s\n'
                         % (os.environ.get('HYP_LOGTAIL_TAG', '?'),
                            tau_loga.str(12), _old_t.str(12), _hmax.str(12)))
    # h = -(l0+sigma)*Log alpha
    h = [arb(0)] * (D + 1)
    for i in range(D + 1):
        h[i] = -ell0_a * (loga_s[i] if i < len(loga_s) else arb(0))
    for i in range(D, 0, -1):
        h[i] = h[i] - (loga_s[i - 1] if i - 1 < len(loga_s) else arb(0))
    # SHIFT-FIX-H (18.08): умножение loga_s(sigma) на sigma сдвигает степени:
    # (sigma*loga_s(sigma))_i = loga_s[i-1]. Цикл выше подставляет этот сдвиг
    # только для i = 1..D, то есть переносит в h степени 1..D слагаемого
    # sigma*loga_s(sigma). Коэффициент степени D+1 этого слагаемого —
    # loga_s[D]*sigma^{D+1} — в срез h (степень <= D) не помещается и молча
    # выбрасывается, как и в M-срезах (см. SHIFT-FIX/_LD ниже). tau_h в
    # старом виде, (|l0|+smax)*tau_loga, мажорирует только пронесённый tau
    # самого Log alpha, но не этот отброшенный коэффициент ТОЧНОГО (уже
    # усечённого до D) ряда loga_s — его нужно мажорировать отдельно.
    _hD = abs(loga_s[D]) * (smax ** (D + 1)) if D < len(loga_s) else arb(0)
    tau_h = ((abs(ell0_a) + smax) * tau_loga + _hD).upper()
    c1, tau_c1 = sl.scalar_exp(h, D, smax)                   # alpha^{-l}
    # EXP-ARG-FIX: scalar_exp покрывает
    # только усечение самого экспоненциального ряда, но не хвост своего
    # АРГУМЕНТА.  |exp(h+d) − exp(h)| <= |exp(h)|(e^{|d|} − 1).
    _M_c1 = (_smass(c1, smax) + tau_c1).upper()
    tau_c1 = (tau_c1 + _M_c1 * (tau_h.exp() - 1)).upper()
    M_G1 = _smass([-g for g in G1], smax)
    c2, drop_c2 = _sconv(c1, [-g for g in G1], D, smax)      # -c1*G1 = a^{-(l+1)}
    tau_c2 = (tau_c1 * M_G1 + drop_c2).upper()
    Da, drop_Da = _sconv(alpha_s, alpha_s, D, smax)          # alpha^2
    M_alpha = _smass(alpha_s, smax)
    tau_Da = (2 * M_alpha * tau_alpha + tau_alpha * tau_alpha + drop_Da).upper()

    # ---------- bivariate pieces ----------
    sm_sl = []
    for i in range(D + 1):
        c1_i = c1[i] if i < len(c1) else arb(0)
        sm_sl.append([C * (c1_i - (arb(1) if i == 0 else arb(0))), c1_i])
    sm_sig = sl.Sig(sm_sl, (C + 1) * tau_c1, smax)

    Pc_sig = sl.Sig(Pc, arb(0), smax)
    U_sig = sl.horner_compose(Pc_sig, sm_sig, D, NG, R)

    Uslices = [(u + [arb(0)] * (NW + 1 - len(u)))[:NW + 1] for u in U_sig.slices]
    Lslices = [sl.tlog(Uslices[0], NW)]
    Uinv0 = sl.tinv(Uslices[0], NW)
    varU0 = arb(0)
    for i in range(1, len(Uslices)):
        varU0 = varU0 + abs(Uslices[i][0]) * (smax ** i)
    mU = abs(Uslices[0][0]) - varU0 - U_sig.tau
    if not (mU > arb("0.3")):
        raise RuntimeError('U(0) lower bound weak: %s' % mU)
    norm_Uinv0 = sl.xnorm(Uinv0, R)
    for i in range(1, D + 1):
        rhs = [arb(i) * x for x in Uslices[i]]
        for j in range(1, i):
            wfac = arb(i - j)
            cj = sl.conv(Uslices[j], Lslices[i - j], NW)
            rhs = [(rhs[k] if k < len(rhs) else arb(0)) -
                   wfac * (cj[k] if k < len(cj) else arb(0)) for k in range(NW + 1)]
        Li = sl.conv(rhs, Uinv0, NW)
        Lslices.append([x / arb(i) for x in Li])
    tauL = (U_sig.tau * norm_Uinv0 / mU
            + _log_tail(Uslices, norm_Uinv0, D, smax, R)).upper()

    # M = (l0+sigma) L ; Mlm = (l0-1+sigma) L
    Mslices = []
    for i in range(D + 1):
        base = [ell0_a * x for x in Lslices[i]]
        if i >= 1:
            Lprev = (Lslices[i - 1] + [arb(0)] * (NW + 1))[:NW + 1]
            base = [(base[k] if k < len(base) else arb(0)) + Lprev[k]
                    for k in range(NW + 1)]
        Mslices.append(base)
    # SHIFT-FIX (18.08 01:10): умножение на (l0+sigma) сдвигает степени, и
    # член L_D*sigma^{D+1} обрезается — раньше он в tau не входил.
    _LD = sl.xnorm(Lslices[D], R) * (smax ** (D + 1))
    M_sig = sl.Sig(Mslices, ((abs(ell0_a) + smax) * tauL + _LD).upper(), smax)
    W_sig = sl.t_exp_seed(M_sig, (W0 + [arb(0)] * (NW + 1 - len(W0)))[:NW + 1], D, NW, R)
    Mlm_slices = []
    for i in range(D + 1):
        base = [(ell0_a - 1) * x for x in Lslices[i]]
        if i >= 1:
            Lprev = (Lslices[i - 1] + [arb(0)] * (NW + 1))[:NW + 1]
            base = [(base[k] if k < len(base) else arb(0)) + Lprev[k]
                    for k in range(NW + 1)]
        Mlm_slices.append(base)
    Mlm_sig = sl.Sig(Mlm_slices,
                     ((abs(ell0_a - 1) + smax) * tauL + _LD).upper(), smax)
    Ulm_sig = sl.t_exp_seed(Mlm_sig, (Ulm0 + [arb(0)] * (NW + 1 - len(Ulm0)))[:NW + 1],
                            D, NW, R)

    Wm = [list(s) for s in W_sig.slices]
    Wm[0] = list(Wm[0])
    Wm[0][0] = Wm[0][0] - C
    Wm_sig = sl.Sig(Wm, W_sig.tau, smax)

    # ---------- F~ slices (t-cap NP; k>NP handled by interval w2/Ftail) ----
    GCW = sl.horner_compose(Pc_sig, Wm_sig, D, NP, R)
    F_sig = Pc_sig.add(GCW.smul_sig_with_tau(alpha_s, tau_alpha, D, R))
    Ftilde_slices = []
    for i in range(len(F_sig.slices)):
        Fsl = (F_sig.slices[i] + [arb(0)] * (NP + 1))[:NP + 1]
        Ftilde_slices.append([Fsl[k] * (R ** k) for k in range(1, NP + 1)])

    # ---------- M' columns ----------
    powW = [None] * (NP + 1)
    one = sl.Sig([[arb(1)]], arb(0), smax)
    powW[0] = one
    for k in range(1, NP + 1):
        powW[k] = powW[k - 1].mul(Wm_sig, D, NP, R)
    GPW = sl.horner_compose(sl.Sig(Pcp, arb(0), smax), Wm_sig, D, NP, R)
    GCW_np = GCW
    powS = [None] * (NP + 1)
    powS[0] = one
    for k in range(1, NP + 1):
        powS[k] = powS[k - 1].mul(sm_sig, D, NP, R)
    GPS = sl.horner_compose(sl.Sig(Pcp, arb(0), smax), sm_sig, D, NP, R)

    lc2, drop_lc2 = _sconv([ell0_a, arb(1)], c2, D, smax)     # (l0 + sigma) * c2
    M_lc2 = _smass(lc2, smax)
    M_Da = _smass(Da, smax)
    tau_lc2 = ((abs(ell0_a) + smax) * tau_c2 + drop_lc2).upper()

    mprime_slices = [[None] * NP for _ in range(D + 1)]
    taus_cols = []
    crk = C / R
    l_scalar = [ell0_a, arb(1)] + [arb(0)] * (D - 1)
    # ---- k = 0 column: DF(phi_0), phi_0 = 1 (for beta_0^* of Z1c) ----
    one_sig = one
    _c0, drop_c0 = _sconv(lc2, Da, D, smax)
    coef0 = [-x for x in _c0]
    tau_coef0 = (M_lc2 * tau_Da + M_Da * tau_lc2 + tau_Da * tau_lc2
                 + drop_c0).upper()
    Ds0 = sl.Sig([[C * coef0[i], coef0[i]] for i in range(D + 1)],
                 (C + 1) * tau_coef0, smax)
    inner0 = one_sig.add(GPS.mul(Ds0, D, NP, R))
    DW0 = Ulm_sig.smul_sig_with_tau(l_scalar, arb(0), D, R).mul(inner0, D, NP, R)
    term2_0 = GCW_np.smul_sig_with_tau(Da, tau_Da, D, R)
    term3_0 = GPW.mul(DW0, D, NP, R).add(one_sig).smul_sig_with_tau(
        alpha_s, tau_alpha, D, R)
    DF0 = one_sig.add(term2_0).add(term3_0)
    mprime0_slices = []
    for i in range(D + 1):
        sl_k = (DF0.slices[i] if i < len(DF0.slices) else [arb(0)])
        sl_k = (sl_k + [arb(0)] * (NP + 1))[:NP + 1]
        mprime0_slices.append([sl_k[jj] * (R ** jj) for jj in range(1, NP + 1)])
    for k in range(1, NP + 1):
        rk = R ** k
        v_at_1 = ((1 - C) ** k) / rk - (-crk) ** k      # psi_k(1)
        Da_k = [v_at_1 * a for a in Da]                  # v(1)/G1^2
        tau_Da_k = (abs(v_at_1) * tau_Da).upper()
        _ck, drop_ck = _sconv(lc2, Da_k, D, smax)
        coef = [-x for x in _ck]
        M_Da_k = _smass(Da_k, smax)
        tau_coef = (M_lc2 * tau_Da_k + M_Da_k * tau_lc2 + tau_Da_k * tau_lc2
                    + drop_ck).upper()
        vW = powW[k].scale(arb(1) / rk)
        vW.slices[0] = list(vW.slices[0]) + [arb(0)] * (NP + 1 - len(vW.slices[0]))
        vW.slices[0][0] = vW.slices[0][0] - (-crk) ** k
        vS = powS[k].scale(arb(1) / rk)
        vS.slices[0] = list(vS.slices[0]) + [arb(0)] * (NP + 1 - len(vS.slices[0]))
        vS.slices[0][0] = vS.slices[0][0] - (-crk) ** k
        Ds = sl.Sig([[C * coef[i], coef[i]] for i in range(D + 1)],
                    (C + 1) * tau_coef, smax)
        inner = vS.add(GPS.mul(Ds, D, NP, R))
        lUlm = Ulm_sig.smul_sig_with_tau(l_scalar, arb(0), D, R)
        DW = lUlm.mul(inner, D, NP, R)
        psi_poly = [(-crk) ** k if kk == 0 else ((1 / rk) if kk == k else arb(0))
                    for kk in range(NP + 1)]
        psi_slices = [psi_poly] + [[arb(0)] * (NP + 1) for _ in range(D)]
        psi = sl.Sig(psi_slices, arb(0), smax)
        term2 = GCW_np.smul_sig_with_tau(Da_k, tau_Da_k, D, R)
        prod3 = GPW.mul(DW, D, NP, R)
        term3 = prod3.add(vW).smul_sig_with_tau(alpha_s, tau_alpha, D, R)
        DFk = psi.add(term2).add(term3)
        taus_cols.append(DFk.tau)
        if k == 1:
            _dbg = {'vW': vW, 'vS': vS, 'inner': inner, 'DW': DW, 'Ds': Ds,
                    'coef': coef, 'Da_k': Da_k, 'psi': psi, 'term2': term2,
                    'term3': term3, 'GPW': GPW, 'GPS': GPS, 'Ulm': Ulm_sig,
                    'GCW': GCW_np}
        for i in range(D + 1):
            sl_k = (DFk.slices[i] if i < len(DFk.slices) else [arb(0)])
            sl_k = (sl_k + [arb(0)] * (NP + 1))[:NP + 1]
            mprime_slices[i][k - 1] = [sl_k[jj] * (R ** jj) for jj in range(1, NP + 1)]

    # ---- sigma-sup norms for the tail pieces (Z1b/Z1c/Ftail/w2) ----
    def sig_sup(sigobj):
        return sigobj.supnorm(R)

    norm_W = arb(0)
    for i in range(len(Wm_sig.slices)):
        norm_W = norm_W + sl.xnorm(Wm_sig.slices[i], R) * (smax ** i)
    norm_W = (norm_W + Wm_sig.tau).upper()
    norm_Ulm = arb(0)
    for i in range(len(Ulm_sig.slices)):
        norm_Ulm = norm_Ulm + sl.xnorm(Ulm_sig.slices[i], R) * (smax ** i)
    norm_Ulm = (norm_Ulm + Ulm_sig.tau).upper()
    norm_GpW = sig_sup(GPW)
    norm_GpS = sig_sup(GPS)
    norm_GoW = sig_sup(GCW_np)
    norm_sm = sig_sup(sm_sig)
    G1sq = arb(0)
    for i in range(len(G1)):
        G1sq_t = (sum((abs(G1[j]) * (smax ** j) for j in range(len(G1))), arb(0))) ** 2
    G1_abs_sup = (sum((abs(G1[j]) * (smax ** j) for j in range(len(G1))), arb(0))).upper()
    G1sq = (G1_abs_sup ** 2).upper()
    alpha_sup = (sum((abs(alpha_s[j]) * (smax ** j) for j in range(len(alpha_s))), arb(0))).upper()
    c2_sup = (sum((abs(c2[j]) * (smax ** j) for j in range(len(c2))), arb(0))).upper()
    return {'_dbg': _dbg, 'mprime0_slices': mprime0_slices, 'tau_col0': DF0.tau,
            'norm_W': norm_W, 'norm_Ulm': norm_Ulm, 'norm_GpW': norm_GpW,
            'norm_GpS': norm_GpS, 'norm_GoW': norm_GoW, 'norm_sm': norm_sm,
            'G1_abs_sup': G1_abs_sup, 'G1sq': G1sq, 'alpha_sup': alpha_sup,
            '_c1': c1, 'Pc': Pc,
            'c2_sup': c2_sup, 'smax': smax,
            'Ftilde_slices': Ftilde_slices, 'tau_F': F_sig.tau,
            'Mprime_slices': mprime_slices, 'taus_cols': taus_cols,
            'W_sig': W_sig, 'Ulm_sig': Ulm_sig,
            'alpha_s': alpha_s, 'tau_alpha': tau_alpha,
            'mU': mU, 'pkg0': pkg, 'tauL': tauL,
            'tau_c1': tau_c1, 'tau_Da': tau_Da, 'tau_coef': tau_coef}
