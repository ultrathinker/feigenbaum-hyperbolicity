# -*- coding: utf-8 -*-
"""
glue.py -- acceptance of the parameterized cover of ell in [2, 4].

Three things are checked, and all three must hold:

 1. EVERY box passed its Kantorovich gate.

 2. SOUNDNESS GUARD (introduced by the audit; the parametric method itself
    is section 3 of 01-ARTICLE.md).
    The sigma-model of the operator carries a float64 floor of ~7e-16 that
    tau does NOT describe: the model's center is the float64 Chebyshev->Taylor
    conversion of the branch.  rig2 derives a majorant of that conversion
    error, dchk (DCHK-CONV, section 3.6/3.7 of 01-ARTICLE.md; NOT a direct
    model-vs-engine comparison), at sigma = 0.9*smax.  For the certificate
    to be sound, Y0 must dominate what that discrepancy contributes, i.e.
        B_A * dchk  <=  0.5 * Y0.
    (At w=0.2 this holds with 20-30x room; at narrow boxes tau falls below the
    floor, so the guard is not optional.)

 3. SEAMS.  Neighbouring boxes overlap.  Both boxes certify a UNIQUE zero
    in their respective uniqueness balls B(P_i, 1.75*rho'_i).  Intersection
    of the balls is necessary but not sufficient: balls B(0,2) and B(3,2)
    intersect yet can carry different zeros.  The correct one-sided check
    is: the zero of box i (which lies in B(P_i, 1.75*rho*_i)) must itself
    lie in the uniqueness ball of box j.  At a single rational point ell*
    inside the overlap,
        |P_i(ell*) - P_j(ell*)| + 1.75*rho*_i  <  1.75*rho'_j
    (and symmetric).  Only the DISTANCE term |P_i(ell*)-P_j(ell*)| is
    computed with arb at ell* rational, so it is an inclusion, not a
    float.  rho_star_i/rho_prime_j themselves come from parse_arb() on
    already directionally-rounded decimal strings, via ordinary
    nearest-double float() -- not re-bounded in arb -- so the final
    comparison is float64, not a full arb inclusion.  Immaterial here:
    the resulting slack is at most 1 ulp of rho_star/rho_prime
    (~1e-20..1e-24 absolute), 13-17 orders below the printed worst
    margin (~1e-7), so it cannot flip a verdict.  Worst margin across
    the 45 seams is printed.

Plus: the union of the boxes must cover [2, 4] with no gap.
"""
import os, re, sys, json, glob, math, tempfile
from fractions import Fraction
from decimal import Decimal, getcontext
import numpy as np

getcontext().prec = 60

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import rig_lib as rl
import tube_lib as tl
from flint import arb

CR = float(tl.c_arb) + float(tl.r_arb)
# Чтение и запись разведены: пакет может лежать только на чтение, и тогда
# сводку glue.json надо класть в свой каталог.
#   HYP_CERTS  — где лежат box_*.json  (по умолчанию 03-CERTIFICATES/existence)
#   GLUE_OUT   — куда положить glue.json (по умолчанию во временный
#                каталог ОС, НЕ в пакет: см. примечание ниже)
PKG = os.path.dirname(HERE)
OUTDIR = os.environ.get('HYP_CERTS') or os.environ.get('CERT_OUT')
OUTDIR = (os.path.join(HERE, OUTDIR) if OUTDIR
          else os.path.join(PKG, '03-CERTIFICATES', 'existence'))
# (тот же класс, что hyp_rouche.py -> HYP_LOG, layer/*).  Дефолт НЕ
# ведёт внутрь пакета: запуск «как есть» дописывал файлы в пакет и ломал
# сверку с MANIFEST.sha256.  Пакет обязан оставаться пригодным только на
# чтение; чтобы ПЕРЕсобрать артефакты, CERT_OUT / GLUE_OUT /
# HYP_TUBE_OUT выставляются явно (см. 02-REPRODUCE.md).
GLUE_OUT = os.environ.get('GLUE_OUT',
                          os.path.join(tempfile.gettempdir(), 'renorm_out'))
os.makedirs(GLUE_OUT, exist_ok=True)
# ветки могут лежать отдельно от боксов (в пакете — 03-CERTIFICATES/branches)
BRDIR = os.environ.get('HYP_BRANCHES',
                       os.path.join(PKG, '03-CERTIFICATES', 'branches'))
TARGET_LO, TARGET_HI = 2.0, 4.0
GUARD_FRAC = 0.5


def num(s):
    return float(s.rstrip(',)'))


def scrape_logs():
    """dchk / B_A per box tag, from the cert.py stdout logs"""
    out = {}
    pats = ('lane?.out', 'lane3_*.out', 'f2_*.out', 'top_*.out', '_probe_*.out')
    files = []
    for pat in pats:
        files += sorted(glob.glob(os.path.join(HERE, pat)))
    for f in files:
        cur = {}
        for line in open(f, encoding='utf-8', errors='replace'):
            m = re.search(r'BOX (\S+)\s+ell0=', line)
            if m:
                cur = {'tag': m.group(1)}
            m = re.search(r'B_A=([0-9.eE+-]+)', line)
            if m and cur:
                cur['B_A'] = num(m.group(1))
            m = re.search(r'self-check.*= ([0-9.eE+-]+)', line)
            if m and cur:
                cur['dchk'] = num(m.group(1))
            m = re.search(r'BOX (\S+) -> ', line)
            if m and cur:
                out[m.group(1)] = cur
                cur = {}
    return out


def P_at(z, ell):
    c_a = z['c_a']
    ell0, w, m = float(z['ell0'][0]), float(z['w'][0]), int(z['m'][0])
    x = (ell - ell0) / (w / 2.0)
    v = np.asarray(rl.clenshaw_np(np.transpose(c_a[:m + 1], (1, 0)), x)).reshape(-1)
    v[0] = 1.0
    return v


def P_at_arb(z, ell_arb):
    """Same as P_at, but in arb so the result is an inclusion.  ell_arb is
    an arb value (use Fraction mid for a rational sample)."""
    c_a = z['c_a']
    ell0 = arb(float(z['ell0'][0]))
    w = arb(float(z['w'][0]))
    m = int(z['m'][0])
    x = (ell_arb - ell0) / (w / arb(2))
    rows = c_a[:m + 1]                        # shape (m+1, N_p+1), float64
    coefs = [[arb(float(v)) for v in rows[k]] for k in range(m + 1)]
    out = []
    for j in range(rows.shape[1]):
        # Clenshaw over the j-th coefficient of each Chebyshev row:
        # P_j(ell) = sum_{k=0..m} rows[k][j] * T_k(x).
        b1 = arb(0)
        b2 = arb(0)
        for k in range(m, 0, -1):
            b0 = arb(2) * x * b1 - b2 + coefs[k][j]
            b2, b1 = b1, b0
        out.append(x * b1 - b2 + coefs[0][j] / arb(2))
    out[0] = arb(1.0)                          # G(0)=1 is exact
    return out


def wn(a, b):
    s, wk = 0.0, 1.0
    for k in range(len(a)):
        s += abs(a[k] - b[k]) * wk
        wk *= CR
    return s


def wn_arb_upper(a_arb, b_arb):
    """Strict upper bound on sum |a_k - b_k| * (c+r)^k in arb arithmetic.
    a_arb, b_arb are lists of arb values of the same length."""
    s = arb(0)
    wk = arb(1)
    cr = arb(CR)
    for ak, bk in zip(a_arb, b_arb):
        s += abs(ak - bk) * wk
        wk *= cr
    v = s.upper()
    f = float(v)
    # STRICT-UP: float(arb) округляет к
    # БЛИЖАЙШЕМУ, единственное место в пакете, где не было шага вверх при
    # уходе округления вниз — как в hyp_rouche.up_float.
    if arb(f) < v:
        f = math.nextafter(f, math.inf)
    return f


def parse_arb(s):
    """Parse an arb interval string '[m +/- r]' or plain float to a float
    (the midpoint)."""
    if isinstance(s, (int, float)):
        return float(s)
    t = str(s).strip()
    m = re.search(r'([+\-]?[0-9]+(?:\.[0-9]+)?(?:[eE][+\-]?[0-9]+)?)', t)
    return float(m.group(1)) if m else float(t)


def _up(x):
    """Наименьший double, гарантированно НЕ МЕНЬШИЙ arb-величины x.

    `float(arb)` округляет к БЛИЖАЙШЕМУ, поэтому голое `float(x.upper())`
    может оказаться НИЖЕ настоящей верхней границы — ровно то, из-за чего
    охранный критерий ниже считался не так, как обещает его комментарий.
    """
    v = arb(x).upper()
    f = float(v)
    if arb(f) < v:
        f = math.nextafter(f, math.inf)
    return f


def _dn(x):
    """Наибольший double, гарантированно НЕ БОЛЬШИЙ arb-величины x."""
    v = arb(x).lower()
    f = float(v)
    if arb(f) > v:
        f = math.nextafter(f, -math.inf)
    return f


logs = scrape_logs()
boxes = []
for p in glob.glob(os.path.join(OUTDIR, 'box_*.json')):
    tag = os.path.basename(p)[4:-5]
    j = json.load(open(p, encoding='utf-8'))
    npz = os.path.join(BRDIR, 'branch_%s.npz' % tag)
    boxes.append({'tag': tag, 'j': j,
                  'z': np.load(npz) if os.path.exists(npz) else None,
                  'log': logs.get(tag, {})})
boxes.sort(key=lambda b: b['j']['ell_lo'])

print('=== 1-2. боксы и охранный критерий ===')
print(' %-8s %-7s %-6s %-17s %-5s %-11s %-11s %-9s %s'
      % ('tag', 'ell0', 'w', '[lo, hi]', 'gate', 'Y0', 'B_A*dchk', 'доля Y0', 'guard'))
all_gate = True
all_guard = True
flag_mismatch = []


def gate_recompute(j):
    """Ворота Ньютона-Канторовича, пересчитанные ЗДЕСЬ из полей бокса.

    Раньше стояло `gate = bool(j['passed'])`,
    то есть приёмка сообщала вердикт, которого не проверяла: бокс сам себе
    записывал флаг, а `glue.py` его цитировал.  На испорченном сертификате
    (`Y0 = 5e-7` при пороге ~9e-8, флаг не тронут) скрипт печатал
    «СЕРТИФИЦИРОВАНО».  Проверка, которая не может провалиться на порченых
    данных, — дефект по дисциплине проекта.

    Сравнение идёт в arb: `a <= b` истинно, только если верно НАВЕРНЯКА,
    поэтому неразрешимое сравнение даёт отказ, а не молчаливый пропуск.
    Возвращает (вердикт, причина-или-None).
    """
    best = j.get('best') or {}
    need = {'Y0': j.get('Y0'), 'B_A': j.get('B_A'), 'dchk': j.get('dchk'),
            'Zhat': best.get('Zhat'), 'rho_prime': best.get('rho_prime')}
    missing = [k for k, v in need.items() if v is None]
    if missing:
        return False, 'нет полей для пересчёта: %s' % ','.join(missing)
    y0 = arb(str(need['Y0']))
    ba = arb(str(need['B_A']))
    dc = arb(str(need['dchk']))
    zh = arb(str(need['Zhat']))
    rp = arb(str(need['rho_prime']))
    if not (zh < arb(1)):
        return False, 'Zhat не отделён от 1'
    lhs = y0 + ba * dc + zh * rp
    if not (lhs <= rp):
        return False, 'ворота нарушены: Y0+B_A*dchk+Zhat*rho\' > rho\''
    # `Ẑ` — величина ПРОИЗВОДНАЯ: движок собирает её как
    # `Zhat = Z1 + 3.0625·B_A·L·rho_prime + Z_conv` (`rig2fix3.py`), причём
    # `Z_conv >= 0`.  Ворота выше читают её как первичное поле, поэтому `L` и
    # `ρ′` не ограничены ничем: испортив `best.L` втрое, вердикта не сдвинуть.
    # Одностороннее соотношение `Ẑ >= Z1 + 3.0625·B_A·L·ρ′` восстановимо из
    # отгруженной печати, если брать МИНОРАНТЫ входов: `Z1` и `B_A` напечатаны
    # семью значащими вверх, `L` — пятью, значит минорант каждого = печать
    # минус одно ulp своей разрядности (у `B_A` есть готовое поле `B_A_lo`).
    # Наивная версия (печать как есть) нарушается на всех 46 боксах именно
    # из-за этого округления, строгая — ни на одном, худший запас +7.7e-9
    # (бокс g17).
    #
    # Соотношение ОДНОСТОРОННЕЕ, и надо честно сказать, что оно ловит:
    #   * занижение `Ẑ` — ровно ту порчу, которая делает ворота проходимыми;
    #     мутация ловится уже при 10⁻⁶ относительных, тогда как самим воротам
    #     нужно занижение на 0.83, то есть на шесть порядков больше;
    #   * ЗАВЫШЕНИЕ `L` (мутация ×3 краснеет).
    # Не ловит противоположное направление — занижение `L`, `Z1`, `B_A`:
    # правая часть при этом уменьшается, и неравенство только облегчается
    # (проверено мутациями −0.1 % по `L`, −0.001 % по `Z1`, −0.01 % по `B_A`:
    # все проходят).  Сверху `Ẑ` не ограничить, пока `Z_conv` не публикуется.
    # Согласованное занижение `L` внутри движка не ловится тем более: тогда
    # `Ẑ` занижено вместе с ним — это и сказано в §4.10.
    z1v, lv = j.get('Z1'), best.get('L')
    if z1v is not None and lv is not None:
        def _minorant(sval, digits):
            d = Decimal(str(sval))
            return arb(str(d - Decimal(1).scaleb(d.adjusted() - digits + 1)))

        ba_lo = arb(str(j['B_A_lo'])) if j.get('B_A_lo') is not None \
            else _minorant(need['B_A'], 7)
        low = _minorant(z1v, 7) + arb('3.0625') * ba_lo * _minorant(lv, 5) * rp
        if not (zh >= low):
            return False, ('Ẑ рассогласован с Z1, B_A, L, ρ′: '
                           'Ẑ = %s < %s' % (need['Zhat'], low.str(10)))
    return True, None


for b in boxes:
    j, lg = b['j'], b['log']
    gate, why = gate_recompute(j)
    # расхождение пересчёта с записанным флагом — само по себе отказ:
    # значит артефакт и его собственный вердикт рассинхронизированы
    if gate != bool(j.get('passed')):
        flag_mismatch.append((b['tag'], bool(j.get('passed')), gate, why))
        gate = False
    all_gate &= gate
    y0 = float(j['Y0']) if j.get('Y0') else float('nan')
    # FIX-3: dchk и B_A теперь лежат прямо в json бокса; лог остаётся
    # запасным источником для старых артефактов, где поля ещё нет.
    # Охранный критерий входит в итоговый вердикт (all_guard),
    # но считался обычным float64 round-to-nearest, тогда как основной гейт
    # gate_recompute — в arb. Теперь произведение округляется ВВЕРХ, а Y0 —
    # ВНИЗ, то есть отношение мажорируется: если оно проходит порог, оно
    # проходит его и в точной арифметике.
    if j.get('dchk') is not None:
        bd = _up(arb(str(j['B_A'])) * arb(str(j['dchk'])))
    else:
        bd = _up(arb(str(lg.get('B_A', float('nan'))))
                 * arb(str(lg.get('dchk', float('nan')))))
    y0_dn = _dn(arb(str(j['Y0']))) if j.get('Y0') else float('nan')
    frac = bd / y0_dn if y0_dn == y0_dn and y0_dn > 0 else float('nan')
    g = frac <= GUARD_FRAC
    if gate:
        all_guard &= bool(g)
    print(' %-8s %-7.4f %-6.3g [%.4f, %.4f] %-5s %-11.4e %-11.4e %-9.5f %s'
          % (b['tag'], j['ell0'], j['w'], j['ell_lo'], j['ell_hi'],
             'PASS' if gate else 'FAIL', y0, bd, frac,
             'ok' if g else '*** НАРУШЕН ***'))

def _cert_ends(j):
    """Концы ИМЕННО ТОГО ell-интервала, на котором бокс сертифицирован.

    В json лежат `ell_lo`/`ell_hi` = ПЕЧАТЬ `ell0 -+ w/2`, посчитанная во
    float.  Внутри отрезка разница неважна (запас 0.005), но у левого конца
    решает: `2.025 - 0.025` даёт РОВНО 2.0, и сравнение `2.0 <= 2.0` проходит
    с нулевым запасом, ничего не устанавливая — если бы `'%.17e' % ell0`
    округлилось в другую сторону, сертифицированный бокс начинался бы ВЫШЕ
    двойки, а печать осталась бы прежней, и проверка отказа не заметила бы.
    Движок сертифицирует `arb('%.17e'%ell0) -+ arb('%.17e'%w)/2`
    (`rig2fix3.py`); тот же конец, посчитанный точно, лежит на 9.14e-17 НИЖЕ
    двойки.  Сравниваем с ним, а не с печатью.
    """
    e = Fraction('%.17e' % j['ell0'])
    w = Fraction('%.17e' % j['w'])
    return e - w / 2, e + w / 2


# Печать `ell_lo`/`ell_hi` живёт в json своей жизнью: испортив `w` или
# `ell0` и не тронув их, можно втрое расширить «сертифицированный» бокс, и
# ни одна проверка этого не увидит.  Тождество дешёвое, требуем его явно.
_ends_bad = [b['tag'] for b in boxes
             if b['j']['ell_lo'] != b['j']['ell0'] - b['j']['w'] / 2
             or b['j']['ell_hi'] != b['j']['ell0'] + b['j']['w'] / 2]
print('\n=== 2а. печатные концы согласованы с ell0 и w ===')
print('  боксов проверено: %d, рассогласований: %d %s'
      % (len(boxes), len(_ends_bad), _ends_bad[:5] if _ends_bad else ''))

print('\n=== 3. швы ===')
print(' %-19s %-11s %-13s %-13s %-8s %s'
      % ('пара', 'ell*', '|P_i - P_j|', 'допуск', 'запас', 'вердикт'))
seams_ok = True
gaps = []
worst_margin = float('inf')
ok_boxes = [b for b in boxes if b['j'].get('passed') and b['z'] is not None]
for a, c in zip(ok_boxes, ok_boxes[1:]):
    ja, jc = a['j'], c['j']
    # Разрывы ищем по ТЕМ ЖЕ точным концам, по которым ниже доказывается
    # покрытие [2,4]: конъюнкция «нет разрывов по печати» + «края по
    # сертификату» не влечёт «сертифицированное объединение ⊇ [2,4]» —
    # между печатью и сертификатом до 1 ulp с каждой стороны, и дыра
    # порядка 10⁻¹⁶ была бы невидима.
    a_lo, a_hi = _cert_ends(ja)
    c_lo, c_hi = _cert_ends(jc)
    lo, hi = max(a_lo, c_lo), min(a_hi, c_hi)
    # `hi <= lo`, а не `hi < lo`: КАСАНИЕ — не перекрытие.  §6.6.3 (i)
    # требует непустого открытого пересечения, а при `hi == lo` шов
    # проверялся бы в единственной точке.
    if hi <= lo:
        gaps.append((float(a_hi), float(c_lo)))
        print(' %-19s *** %s [%.17g, %.17g] ***'
              % (a['tag'] + '/' + c['tag'],
                 'КАСАНИЕ' if hi == lo else 'РАЗРЫВ',
                 float(a_hi), float(c_lo)))
        seams_ok = False
        continue
    # Точная середина перекрытия: концы уже рациональны, приближать нечего.
    ell_star = lo + (hi - lo) / 2
    ell_arb = arb(str(ell_star))
    pa = P_at_arb(a['z'], ell_arb)
    pc = P_at_arb(c['z'], ell_arb)
    d_upper = wn_arb_upper(pa, pc)
    rho_star_a = parse_arb(ja['best']['rho_star'])
    rho_star_c = parse_arb(jc['best']['rho_star'])
    rho_prime_a = parse_arb(ja['best']['rho_prime'])
    rho_prime_c = parse_arb(jc['best']['rho_prime'])
    # One-sided uniqueness: zero of i lies in uniqueness ball of j (and vv.)
    m_left  = 1.75 * rho_prime_c - d_upper - 1.75 * rho_star_a   # i in j
    m_right = 1.75 * rho_prime_a - d_upper - 1.75 * rho_star_c   # j in i
    margin = min(m_left, m_right)
    ok = m_left > 0 and m_right > 0
    seams_ok &= ok
    if ok and margin < worst_margin:
        worst_margin = margin
    print(' %-19s %-11.6f %-13.4e %-13.4e %-8.3g %s'
          % (a['tag'] + '/' + c['tag'], float(ell_star), d_upper,
             1.75 * (rho_prime_a + rho_prime_c),
             margin / (1.75 * max(rho_prime_a, rho_prime_c)) if margin > 0 else float('-inf'),
             'ok' if ok else '*** НАРУШЕНО ***'))

lo_all = min(b['j']['ell_lo'] for b in ok_boxes) if ok_boxes else None
hi_all = max(b['j']['ell_hi'] for b in ok_boxes) if ok_boxes else None


lo_cert = min(_cert_ends(b['j'])[0] for b in ok_boxes) if ok_boxes else None
hi_cert = max(_cert_ends(b['j'])[1] for b in ok_boxes) if ok_boxes else None
# Без зазора. Раньше здесь стояло `<= TARGET_LO + 1e-12` и
# `>= TARGET_HI - 1e-12`: необъявленный допуск в решающем утверждении
# «объединение накрывает [2,4]». Двойник в tube_accept.py всегда сравнивал
# строго; приводим к нему.
covers = (lo_cert is not None and lo_cert <= Fraction(TARGET_LO)
          and hi_cert >= Fraction(TARGET_HI))

print('\n=== ИТОГ ===')
print('  боксов                 : %d (прошло %d)' % (len(boxes), len(ok_boxes)))
print('  все ворота пройдены    : %s' % all_gate)
print('  охранный критерий      : %s' % all_guard)
# Худший запас — МИНОРАНТА, и печатать её округлением к ближайшему нельзя:
# `%.3e` от 1.7499893848537e-07 даёт 1.750e-07, то есть БОЛЬШЕ истинного
# минимума, а отношение 0.999993934 в `%.2f` превращается в «1.00» — строка
# утверждала, что запас РАВЕН полному радиусу единственности, хотя он строго
# меньше. Усекаем оба числа ВНИЗ, как и положено миноранте.
def _trunc_down(x, digits):
    """Усечение ВНИЗ без float-кругорейса.

    `math.floor(x*1e13)/1e13` для нашего диапазона работает (0 контрпримеров
    на 200 000 проб в [1e-7, 3e-7]), но в общем виде НЕ гарантирует миноранту:
    умножение на 1e13 само округляется, и floor может уйти вверх. Считаем на
    точном десятичном значении double и печатаем Decimal, а не float, — тогда
    гарантия не зависит от диапазона.
    """
    import decimal
    d = decimal.Decimal(x)
    if d == 0:
        return decimal.Decimal(0)
    q = decimal.Decimal(1).scaleb(d.adjusted() - digits + 1)
    with decimal.localcontext() as c:
        c.prec = 60
        c.rounding = decimal.ROUND_FLOOR
        return d.quantize(q, rounding=decimal.ROUND_FLOOR)


if worst_margin != float('inf'):
    _wm = _trunc_down(worst_margin, 7)
    _ratio = _trunc_down(worst_margin / 1.75e-7, 6)
    print('  швы (one-sided)        : %s   худший запас %s '
          '(= %s·уник. радиуса)' % (seams_ok, _wm, _ratio))
else:
    print('  швы (one-sided)        : %s   худший запас не определён' % seams_ok)
print('  разрывы                : %s' % (gaps or 'нет'))
print('  объединение            : [%s, %s]' % (lo_all, hi_all))
if lo_cert is not None:
    # Печатать через float здесь НЕЛЬЗЯ: ровно этот перевод и скрывает
    # разницу — float(lo_cert) даёт 2.0, то самое число, из-за которого
    # проверка ничего не устанавливала. Печатаем точное десятичное.
    import decimal
    decimal.getcontext().prec = 30

    def _dec(fr):
        return decimal.Decimal(fr.numerator) / decimal.Decimal(fr.denominator)

    print('  оно же по СЕРТИФИЦИРОВАННЫМ концам (не по печати ell_lo/ell_hi):')
    print('     lo = %s  (ниже 2 на %.3e)' % (_dec(lo_cert),
                                              float(Fraction(TARGET_LO) - lo_cert)))
    print('     hi = %s  (выше 4 на %.3e)' % (_dec(hi_cert),
                                              float(hi_cert - Fraction(TARGET_HI))))
print('  покрывает [2, 4]       : %s' % covers)
if flag_mismatch:
    print('\n  *** ФЛАГ `passed` РАСХОДИТСЯ С ПЕРЕСЧЁТОМ ВОРОТ ***')
    for _tag, _saved, _calc, _why in flag_mismatch:
        print('      %-8s в json passed=%s, пересчёт=%s%s'
              % (_tag, _saved, _calc, (' (%s)' % _why) if _why else ''))

ok = bool(all_gate and all_guard and seams_ok and not gaps and covers
          and not flag_mismatch and not _ends_bad)
if _ends_bad:
    print('\n  *** ПЕЧАТНЫЕ КОНЦЫ РАСХОДЯТСЯ С ell0 ∓ w/2: %s ***' % _ends_bad)
print('\n  ==> %s' % ('СУЩЕСТВОВАНИЕ НА [2,4] СЕРТИФИЦИРОВАНО ПАРАМЕТРИЧЕСКИМ МЕТОДОМ'
                      if ok else 'НЕ ЗАКРЫТО — см. выше'))
json.dump({'all_gate': bool(all_gate), 'guard': bool(all_guard),
           'seams_ok': bool(seams_ok), 'gaps': [[float(a), float(b)] for a, b in gaps],
           'union': [float(lo_all), float(hi_all)], 'covers': bool(covers),
           'complete': bool(ok), 'n_boxes': len(boxes),
           'boxes': [{'tag': b['tag'], 'ell0': b['j']['ell0'], 'w': b['j']['w'],
                      'lo': b['j']['ell_lo'], 'hi': b['j']['ell_hi'],
                      'passed': bool(b['j'].get('passed')), 'Y0': b['j'].get('Y0'),
                      'Z1': b['j'].get('Z1'),
                      'Zhat': (b['j'].get('best') or {}).get('Zhat'),
                      'rho_prime': (b['j'].get('best') or {}).get('rho_prime'),
                      'tail_used': b['j'].get('tail_used')} for b in boxes]},
          open(os.path.join(GLUE_OUT, 'glue.json'), 'w'), indent=1)

# Раньше скрипт заканчивался здесь и всегда
# отдавал 0: у провалившейся склейки не было машинно-видимого сигнала, а
# `rerun_all.sh` смотрел только хвост лога.  Теперь код возврата такой же,
# как у остальных приёмочных скриптов пакета: 0 — прошло, 2 — нет.
sys.exit(0 if ok else 2)
