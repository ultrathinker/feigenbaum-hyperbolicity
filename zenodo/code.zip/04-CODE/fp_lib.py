# -*- coding: utf-8 -*-
"""
fp_lib.py — NUMERIC (float64) pipeline for the parameterized-continuation study.

Mirrors _source/engine/tube_lib.py formulas exactly (u-coords at c=0.6, r=0.8,
X-norm |h|_X = sum |h_k| r^k, X0 slice h(0)=0), but in pure numpy float64.
NOT RIGOROUS: exploration only. Calibration vs certified numbers is done in
proto1_calib.py; the float residual floor of this pipeline is measured there.

Conventions:
  a      : G Taylor coefficients at t=0, a[0]=1, length NG+1 (numpy)
  u-coords: polynomial in u = t-c given by coefficient array (index = power)
  Chebyshev: nodes x_j = cos(pi*(j+1/2)/n) on [-1,1], l_j = l0 + (w/2) x_j;
  cheb_fit returns c with p(x) = c_0/2 + sum_{k>=1} c_k T_k(x).
"""
import numpy as np
import math

C = 0.6
R = 0.8
NG = 64      # truncation of G
NW = 192     # truncation of W = U^ell
NP = 80      # X0 system size (unknowns x_1..x_NP)
NALG = 192   # truncation of F series


def reexpand(a, c, N):
    """Taylor shift 0 -> c. a: coeffs at 0 (any length), returns N+1 coeffs at c.
    Mirrors tube_lib.reexpand_fast."""
    n_src = len(a)
    out = np.zeros(N + 1)
    for k in range(N + 1):
        s = 0.0
        binom = 1.0
        for j in range(k, n_src):
            if j > k:
                binom = binom * j / (j - k)   # C(j,k) = C(j-1,k)*j/(j-k)
            s += a[j] * binom * (c ** (j - k))
        out[k] = s
    return out


def miller_power(u, ell, N):
    """W = U^ell (analytic branch, needs u[0]>0.5). Coeffs length N+1.

    Это формула Дж. К. П. Миллера для коэффициентов СТЕПЕНИ ряда
    (прямая, n-членная), а не обратная трёхчленная рекуррентность
    Миллера из обзора Gautschi 1967 — их связывает только имя.
    Условие u[0] > 0.5 — это НЕ условие формулы (той нужно лишь
    u[0] != 0), а условие выбора ветви из §5.3.2, п. 3.
    """
    if not (u[0] > 0.5):
        raise ValueError("branch condition u[0]>0.5 failed (не условие формулы Миллера, а выбор ветви, §5.3.2): %g" % u[0])
    w = np.zeros(N + 1)
    w[0] = u[0] ** ell
    for n in range(1, N + 1):
        s = 0.0
        for k in range(1, n + 1):
            s += ((ell + 1) * k - n) * u[k] * w[n - k]
        w[n] = s / (n * u[0])
    return w


def conv_trunc(p, q, N):
    """(p*q) truncated to degree N."""
    out = np.zeros(N + 1)
    lp, lq = len(p), len(q)
    for i in range(min(lp, N + 1)):
        if p[i] == 0.0:
            continue
        jmax = min(lq, N + 1 - i)
        out[i:i + jmax] += p[i] * q[:jmax]
    return out


def compose_horner(Gc, w_shift, N):
    """Gc composed with (W-c): Horner over coefficients of Gc.
    Gc: u-coeffs (any length); w_shift: u-coeffs of W-c (length NW+1)."""
    dg = len(Gc) - 1
    res = np.zeros(1)
    res[0] = Gc[dg]
    for k in range(dg - 1, -1, -1):
        res = conv_trunc(res, w_shift, N)
        res[0] += Gc[k]
    return res


def compose_linear(v, lin, N):
    """v composed with linear poly lin=[s0,s1] (u -> s0+s1*u), binomial form."""
    s0, s1 = lin
    out = np.zeros(N + 1)
    for k in range(min(len(v), N + 1)):
        if v[k] == 0.0:
            continue
        binom = 1.0
        for i in range(0, min(k, N) + 1):
            if i > 0:
                binom = binom * (k - i + 1) / i
            out[i] += v[k] * binom * (s0 ** (k - i)) * (s1 ** i)
    return out


def xnorm(h):
    return float(np.sum(np.abs(h) * (R ** np.arange(len(h)))))


def eval_series(h, x):
    acc = 0.0
    for k in range(len(h) - 1, -1, -1):
        acc = acc * x + h[k]
    return acc


class Op:
    """Operator pieces at (a, ell), float64, u-coords. Mirrors build_pkg_fast."""

    def __init__(self, a, ell):
        self.a = np.asarray(a, dtype=float)
        self.ell = float(ell)
        self.G_at_1 = float(np.sum(self.a))
        self.abar = -1.0 / self.G_at_1
        if not (self.abar > 0):
            raise ValueError("abar<=0")
        inv_ell = self.abar ** (-self.ell)
        self.inv_ell = inv_ell
        # U uses only the first NG+1 coefficients (mirrors build_pkg_fast)
        U_at_t = self.a[:NG + 1] * (inv_ell ** np.arange(NG + 1))
        self.U_u = reexpand(U_at_t, C, NG)
        if not (self.U_u[0] > 0.5):
            raise ValueError("U_u[0]=%g <= 0.5" % self.U_u[0])
        self.Gc = reexpand(self.a, C, len(self.a) - 1)
        u_pad = np.zeros(NW + 1)
        u_pad[:NG + 1] = self.U_u
        self.W = miller_power(u_pad, self.ell, NW)
        self.W_shift = self.W.copy(); self.W_shift[0] -= C
        self.U_lm1 = miller_power(u_pad, self.ell - 1.0, NW)
        # s(t) = t*alpha^{-ell}; s - c = c*(inv_ell - 1) + inv_ell * u
        self.s_shift = np.array([C * (inv_ell - 1.0), inv_ell])
        self.Gp = np.concatenate([np.arange(1, len(self.Gc)) * self.Gc[1:], [0.0]])

    def F_series(self, N=NALG):
        """F(G)(t) = G + alpha*G(W) in u-coords, truncated to N."""
        comp = compose_horner(self.Gc, self.W_shift, N)
        F = np.zeros(N + 1)
        F[:min(len(self.Gc), N + 1)] = self.Gc[:min(len(self.Gc), N + 1)]
        F[:len(comp)] += self.abar * comp
        return F

    def F_xnorm(self):
        return xnorm(self.F_series())

    def DF_apply(self, v, N=NP):
        """DF at the current point applied to poly v (u-coeffs). Mirrors
        build_pkg_fast.DF_at_ell. Returns u-coeffs length N+1."""
        ell = self.ell
        v = np.asarray(v, dtype=float)
        v_at_1 = eval_series(v, 1.0 - C)
        Da_v = v_at_1 / (self.G_at_1 ** 2)
        inv_ellp1 = self.abar ** (-(ell + 1.0))
        coef = -ell * inv_ellp1 * Da_v
        Ds_v = np.array([C * coef, coef])
        v_of_s = compose_linear(v, self.s_shift, N)
        Gp_s = compose_linear(self.Gp, self.s_shift, N)
        inner = v_of_s + conv_trunc(Gp_s, Ds_v, N)
        DW = conv_trunc(self.U_lm1, inner * ell, N)
        v_of_W = compose_horner(v, self.W_shift, N)
        Gp_W = compose_horner(self.Gp, self.W_shift, N)
        GC_W = compose_horner(self.Gc, self.W_shift, N)
        res = np.zeros(N + 1)
        res[:min(len(v), N + 1)] = v[:min(len(v), N + 1)]
        res += Da_v * GC_W
        res += self.abar * (v_of_W + conv_trunc(Gp_W, DW, N))
        return res


def build_Mprime(op, N=NP):
    """M'[j][k] = M_e[j][k] - (-c/r)^k M_e[j][0] with e_k = u^k/r^k.
    M_e rows scaled by r^j (X-coordinates). Returns (M_e, Mprime)."""
    M = np.zeros((N + 1, N + 1))
    rks = R ** np.arange(N + 1)
    for k in range(N + 1):
        ek = np.zeros(N + 1)
        ek[k] = 1.0 / rks[k]
        col = op.DF_apply(ek, N)
        M[:len(col), k] = col
    M_e = M * (rks[:, None])
    mp = (-C / R) ** np.arange(1, N + 1)
    Mprime = M_e[1:, 1:] - np.outer(M_e[1:, 0], mp)
    return M_e, Mprime


def x0_delta_to_u(dx0, N=NP):
    """delta in X0 coordinates (x_k, k=1..N) -> u-coeffs of the poly
    sum_k x_k*(u^k/r^k - (-c/r)^k)."""
    dv = np.zeros(N + 1)
    for k in range(1, N + 1):
        dv[k] += dx0[k - 1] / (R ** k)
        dv[0] -= dx0[k - 1] * ((-C / R) ** k)
    return dv


def solve_fixed_point(a0, ell, N=NP, tol=3e-15, max_it=30, verbose=False):
    """Full Newton in X0 coords with refreshed inverse. State kept at length
    N+1 in 0-center coords (no lossy roundtrip). Returns (a, info)."""
    a = np.zeros(N + 1)
    src = np.asarray(a0, dtype=float)
    a[:min(len(src), N + 1)] = src[:min(len(src), N + 1)]
    info = {'resid': [], 'iters': 0}
    for it in range(max_it):
        op = Op(a, ell)
        F = op.F_series(N)
        Ft = np.array([F[k] * (R ** k) for k in range(1, N + 1)])
        nrm = float(np.max(np.abs(Ft)))
        info['resid'].append(nrm)
        if verbose:
            print("   it %d: |Ftilde|inf = %.3e" % (it, nrm), flush=True)
        if nrm < tol:
            info['iters'] = it
            return a, info
        _, Mp = build_Mprime(op, N)
        A = np.linalg.inv(Mp)
        dx0 = A @ Ft
        ac = reexpand(a, C, N)
        ac_new = ac - x0_delta_to_u(dx0, N)
        a = reexpand(ac_new, -C, N)
        info['iters'] = it + 1
    return a, info


# ---------------- Chebyshev helpers ----------------

def cheb_nodes(n, l0, w):
    j = np.arange(n)
    x = np.cos(np.pi * (j + 0.5) / n)
    return l0 + (w / 2.0) * x


def cheb_fit(vals):
    """vals: array (n, ...) sampled at cheb_nodes(n, *, *). Returns c with
    p(x) = c_0/2 + sum_{k>=1} c_k T_k(x), c_k = (2/n) sum_j f_j cos(...)."""
    v = np.asarray(vals, dtype=float)
    n = v.shape[0]
    j = np.arange(n)
    c = np.zeros_like(v)
    for k in range(n):
        fac = np.cos(np.pi * (j + 0.5) * k / n)
        if v.ndim == 1:
            c[k] = (2.0 / n) * np.dot(fac, v)
        else:
            c[k] = (2.0 / n) * np.tensordot(fac, v, axes=(0, 0))
    return c


def cheb_eval(c, x):
    """Evaluate p(x) = c_0/2 + sum_{k>=1} c_k T_k(x) via Clenshaw."""
    m = len(c) - 1
    d = np.array(c, dtype=float)
    if m == 0:
        return d[0]
    d0 = d.copy(); d0[0] *= 0.5
    b1 = np.zeros_like(d0[0])
    b2 = np.zeros_like(d0[0])
    for k in range(m, -1, -1):
        b0 = 2.0 * x * b1 - b2 + d0[k]
        b2, b1 = b1, b0
    return b1 - x * b2


def cheb_to_taylor(c, w):
    """Chebyshev coeffs (x in [-1,1], UNHALVED c_0) -> Taylor coeffs in
    sigma = w*x/2. p = c_0/2 + sum_{k>=1} c_k T_k(x)."""
    m = len(c) - 1
    if m < 0:
        return np.zeros(1)
    sc = 2.0 / w
    Tkm2 = np.zeros(m + 1); Tkm2[0] = 1.0            # T_0
    Tkm1 = np.zeros(m + 1)
    if m >= 1:
        Tkm1[1] = sc                                   # T_1 = sc*sigma
    total = 0.5 * c[0] * Tkm2
    for k in range(1, m + 1):
        total = total + c[k] * Tkm1
        if k < m:
            Tnew = np.zeros(m + 1)
            Tnew[1:] += 2.0 * sc * Tkm1[:-1]
            Tnew = Tnew - Tkm2
            Tkm2, Tkm1 = Tkm1, Tnew
    return total
