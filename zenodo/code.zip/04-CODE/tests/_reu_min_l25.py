# -*- coding: utf-8 -*-
"""_reu_min_l25.py — строгая нижняя граница min Re U и min |U| при ℓ = 5/2.

ЗАЧЕМ.  §5.3.2 опирается на гейт «U(D_R) ⊂ {Re>0}, min ≥ …» — на нём стоит
однозначность ветви Миллера при нецелом показателе.  До 23.08.2026 у этого
числа НЕ БЫЛО носителя: `pointwise/xresid_l25.json` хранит постановку счёта
(`M_ARCS = 512`, `R = 1.2`), но не результат, и ни один скрипт пакета его не
считал.  Напечатанное в статье `≥ 0.567` оказалось вдобавок неверным: истинный
минимум равен 0.5665559…, то есть нижняя граница была округлена ВВЕРХ.
Этот файл — недостающий генератор и одновременно ворота.

ЧТО СЧИТАЕТСЯ.  Обозначения §1: `α_G = −1/G(1)`, `s_G(t) = t·α_G^{−ℓ}`,
`U_G(t) = G(s_G(t))`.  Здесь `G = Ḡ` — замороженный сид (`hiprec_seeds.json`,
точка `ell == '2.5'`, 65 коэффициентов Маклорена `a64`), `ℓ = 5/2`.
Область: окружность `|t − c| = R`, `c = 3/5`, `R` берётся из сертификата.

КАК.  Окружность режется на `M` дуг по параметру θ; каждая дуга заключается в
arb-интервал, `sin_cos` от него даёт box, накрывающий дугу, и `G` считается
схемой Горнера в `acb`.  Нижний конец `Re U` по всем боксам — строгая нижняя
граница по всей окружности.  Переход «окружность → круг» законен: `G` — полином,
`s` — линейная замена, значит `U` целая, `Re U` гармонична, и минимум по
замкнутому кругу достигается на границе.

ПОЧЕМУ ЭТО НЕ «ЗЕЛЁНОЕ ПО ПОСТРОЕНИЮ».  Скрипт не читает опубликованное число
как вход: он считает границу заново и лишь СРАВНИВАЕТ с сертификатом.  Если
сертификат заявляет границу выше посчитанной — красное.  Плюс встроенная
проверка происхождения: `U(3/5)` обязано совпасть с `xresid_l25.json::u_0`
(они посчитаны разными людьми и разными путями; расхождение допускается только
на уровне хвоста усечения сида, ~10⁻⁸⁰).

Запуск:
    python -X utf8 _reu_min_l25.py            сверить с сертификатом (ворота)
    python -X utf8 _reu_min_l25.py --обновить  пересчитать и записать сертификат

Коды возврата: 0 — сходится с сертификатом; 2 — расхождение.
"""
import io
import json
import os
import sys
from decimal import Decimal

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import flint

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
ПАКЕТ = os.environ.get('HYP_PKG') or os.path.normpath(os.path.join(ЗДЕСЬ, '..', '..'))
СИД = os.path.join(ПАКЕТ, '04-CODE', 'hiprec_seeds.json')
XRESID = os.path.join(ПАКЕТ, '03-CERTIFICATES', 'pointwise', 'xresid_l25.json')
СЕРТ = os.path.join(ПАКЕТ, '03-CERTIFICATES', 'pointwise', 'reu_min_l25.json')

PREC = 1024
M_ДУГ = 2048
ЗНАКОВ = 6
МИН_ЦИФР = 30          # сколько знаков U(3/5) обязано совпасть с u_0
ОБНОВИТЬ = '--обновить' in sys.argv


def вниз(x, знаков):
    """Направленное округление ВНИЗ: нижнюю границу нельзя округлять вверх."""
    из = flint.arb(10) ** знаков
    return (x * из).floor() / из


def main():
    flint.ctx.prec = PREC
    сид = json.load(io.open(СИД, encoding='utf-8'))
    точка = [p for p in сид['points'] if str(p['ell']) in ('2.5', '2.50')][0]
    xres = json.load(io.open(XRESID, encoding='utf-8'))

    alpha = flint.arb(точка['alpha'])
    a = [flint.acb(flint.arb(s)) for s in точка['a64']]
    if len(a) != 65:
        print('ОШИБКА: ожидалось 65 коэффициентов a64, получено %d' % len(a))
        return 2
    ell = flint.arb(5) / flint.arb(2)
    K = flint.acb(alpha ** (-ell))
    c = flint.arb(3) / flint.arb(5)
    R = flint.arb(xres['R'])

    def G(z):
        r = flint.acb(0)
        for k in reversed(a):
            r = r * z + k
        return r

    # --- происхождение: U(3/5) против u_0 сертификата -----------------------
    U35 = G(K * flint.acb(c))
    u0 = flint.arb(xres['u_0'])
    наше, их = U35.real.str(160, radius=False), u0.str(160, radius=False)
    общих = 0
    for x, y in zip(наше, их):
        if x != y:
            break
        общих += 1
    print('происхождение: U(3/5) совпадает с xresid_l25.json::u_0 на %d знаков' % общих)
    if общих < МИН_ЦИФР:
        print('ОШИБКА: совпало меньше %d знаков — считается НЕ та функция' % МИН_ЦИФР)
        return 2

    # --- строгий минимум по дугам -------------------------------------------
    два_пи = 2 * flint.arb.pi()
    мин_re = мин_abs = None
    for i in range(M_ДУГ):
        th = (flint.arb(i) * два_пи / flint.arb(M_ДУГ)).union(
            flint.arb(i + 1) * два_пи / flint.arb(M_ДУГ))
        sin_t, cos_t = th.sin_cos()
        U = G(K * flint.acb(c + R * cos_t, R * sin_t))
        re_lo, abs_lo = U.real.lower(), U.abs_lower()
        if мин_re is None or re_lo < мин_re:
            мин_re = re_lo
        if мин_abs is None or abs_lo < мин_abs:
            мин_abs = abs_lo

    re_гр, abs_гр = вниз(мин_re, ЗНАКОВ), вниз(мин_abs, ЗНАКОВ)
    print('дуг: %d, prec: %d бит' % (M_ДУГ, PREC))
    print('строгая нижняя граница: min Re U ≥ %s, min |U| ≥ %s'
          % (re_гр.str(ЗНАКОВ + 2, radius=False), abs_гр.str(ЗНАКОВ + 2, radius=False)))

    новый = {
        'oid': 'reu_min_l25',
        'task': 'min Re U и min |U| на |t-c|=R при ell=5/2, строгое включение по дугам',
        'ell': '5/2', 'c': '3/5', 'R': xres['R'], 'M_ARCS': M_ДУГ,
        'prec_bits': PREC, 'flint': str(getattr(flint, '__version__', '?')),
        'ReU_min_lower': re_гр.str(ЗНАКОВ + 2, radius=False),
        'U_abs_min_lower': abs_гр.str(ЗНАКОВ + 2, radius=False),
        'rounding': 'floor (нижнюю границу округляем ВНИЗ)',
        'origin_check': {'U_at_3_5_vs_u_0_matching_digits': общих},
        'note': ('Ḡ — замороженный сид степени 64 (hiprec_seeds.json, ell=2.5). '
                 'Минимум по замкнутому кругу равен минимуму по границе: U целая, '
                 'Re U гармонична.'),
    }
    if ОБНОВИТЬ:
        io.open(СЕРТ, 'w', encoding='utf-8', newline='').write(
            json.dumps(новый, ensure_ascii=False, indent=1) + chr(10))
        print('СЕРТИФИКАТ ЗАПИСАН: %s' % СЕРТ)
        return 0
    if not os.path.exists(СЕРТ):
        print('ОШИБКА: сертификата нет — создай его через --обновить')
        return 2
    ст = json.load(io.open(СЕРТ, encoding='utf-8'))
    плохо = []
    for поле, посчитано in (('ReU_min_lower', re_гр), ('U_abs_min_lower', abs_гр)):
        # Сравнивать надо ДЕСЯТИЧНО, а не arb-шарами: у равных величин шары
        # перекрываются, и `<=` возвращает False (неопределённость), из-за чего
        # первая версия ворот краснела на собственном же сертификате.
        заявлено = Decimal(ст[поле])
        посчитано_d = Decimal(посчитано.str(ЗНАКОВ + 2, radius=False))
        if заявлено > посчитано_d:
            плохо.append('%s: в сертификате %s, посчитано %s — сертификат обещает больше'
                         % (поле, ст[поле], посчитано_d))
    if ст.get('M_ARCS', 0) > M_ДУГ:
        плохо.append('M_ARCS в сертификате (%s) больше, чем в этом прогоне (%d)'
                     % (ст.get('M_ARCS'), M_ДУГ))
    if плохо:
        print('_reu_min_l25: РАСХОЖДЕНИЕ')
        for x in плохо:
            print('  ' + x)
        return 2
    print('_reu_min_l25: ok — сертификат не обещает больше, чем посчитано заново')
    return 0


if __name__ == '__main__':
    sys.exit(main())
