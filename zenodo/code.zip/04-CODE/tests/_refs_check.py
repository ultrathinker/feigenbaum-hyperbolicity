# -*- coding: utf-8 -*-
"""
_refs_check.py — сторож ВИСЯЧИХ ССЫЛОК: имя в документации против кода.

Зачем.  Дисциплина проекта называет отдельным классом дефектов «несвежая
ссылка после точечной правки»: правку делают в одном месте, а текст,
ссылавшийся на прежнее устройство, остаётся.  Этот класс встречался в
работе трижды — §6.7 ссылался на калитку `dP ≥ 1.3125ρ′`, к тому моменту
уже убранную; посылка а6 ссылалась на поле `lemma1_cut_ok`, которого нет ни в
одном json; докстринг `tube_run.py` объяснял цепочку критерием, который сам
же пакет числит отброшенным.  Каждый раз находил человек.  Здесь этот поиск
машинный.

Что проверяется — только то, у чего есть однозначная машинная форма:

  1. пути к файлам (`04-CODE/glue.py`, `03-CERTIFICATES/tube/offsets.json`,
     в т.ч. с шаблоном `box_g*.json`) — файл должен существовать;
  2. ссылки `файл.py:НОМЕР` — файл существует И в нём столько строк;
  3. поля json в форме `что-то.json::поле` — поле должно реально быть
     хотя бы в одном подходящем json;
  4. переменные окружения `HYP_*`, `CERT_*`, `GLUE_*` — должны читаться
     где-то в коде;
  5. идентификаторы-с-подчёркиванием в обратных кавычках (`nonzero_ok`,
     `rho_star_new`, `_compute_L`) — должны встречаться в коде или в json.

Отношение к разделу H в `_numbers_check.py`: тот тоже ищет битые ссылки на
файлы, но сверяет по имени файла без каталога, поэтому неверный КАТАЛОГ для
него не ошибка.  Здесь путь со слэшем проверяется точно.

Чего сторож НЕ делает: не проверяет, что ссылка ведёт в ПРАВИЛЬНОЕ место —
только что названное вообще существует.  §6.7 он бы поймал (`deltaP` в коде
нет), а вот подмену «§6.3.1» на «§6.3.2» — нет.

Умолчания: пакет — на два уровня выше этого файла; `HYP_ARTICLE` заменяет
`01-ARTICLE.md` копией (для фальсификации).

Коды возврата: 0 — висячих ссылок нет, 2 — есть.
"""
import os, re, sys, json, glob, fnmatch

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('HYP_PKG', os.path.dirname(os.path.dirname(HERE)))
ART = os.environ.get('HYP_ARTICLE', os.path.join(PKG, '01-ARTICLE.md'))

# Документы пакета.  СОСТОЯНИЕ.md — рабочая записка автора, в пакет и в
# манифест не входит (та же оговорка, что в _numbers_check.py).
_docs = sorted(f for f in glob.glob(os.path.join(PKG, '**', '*.md'), recursive=True)
               if os.path.basename(f) != 'СОСТОЯНИЕ.md')
_art_pkg = os.path.join(PKG, '01-ARTICLE.md')
if os.path.abspath(ART) != os.path.abspath(_art_pkg):
    _docs = [ART if os.path.abspath(f) == os.path.abspath(_art_pkg) else f
             for f in _docs]

# Исходники, в которых ищем упомянутые имена.
_code = []
for ext in ('*.py', '*.sh'):
    _code += glob.glob(os.path.join(PKG, '**', ext), recursive=True)
_code = [f for f in _code if '__pycache__' not in f]
_code_text = {}
for f in _code:
    try:
        _code_text[f] = open(f, encoding='utf-8', errors='replace').read()
    except OSError:
        pass
def _strip_prose(path, src):
    """Код без комментариев и строковых литералов.

    Имя, встречающееся только в комментарии, — это упоминание, а не
    определение, и считать его доказательством существования нельзя:
    иначе достаточно один раз написать про несуществующее поле в
    докстринге, чтобы ссылка на него навсегда стала «проверенной».
    """
    if not path.endswith('.py'):
        return re.sub(r'#.*', '', src)
    import io as _io
    import tokenize as _tk
    out = []
    try:
        for tok in _tk.generate_tokens(_io.StringIO(src).readline):
            if tok.type == _tk.COMMENT:
                continue
            # Тройные кавычки — проза (докстринг), одиночные — данные:
            # имя env-переменной живёт в коде именно литералом
            # os.environ.get('HYP_ENG'), и вырезать его нельзя.
            if tok.type == _tk.STRING and tok.string.lstrip('rbufRBUF')[:3] \
                    in ('\'\'\'', '"""'):
                continue
            out.append(tok.string)
    except (_tk.TokenError, IndentationError, SyntaxError):
        return re.sub(r'#.*', '', src)
    return ' '.join(out)


_ALL_CODE = '\n'.join(_strip_prose(f, s) for f, s in _code_text.items())

# Ключи всех json пакета — по имени файла и общим множеством.
_json_keys_by_name = {}
_ALL_JSON_KEYS = set()


def _collect(obj, acc):
    if isinstance(obj, dict):
        for k, v in obj.items():
            acc.add(k)
            _collect(v, acc)
    elif isinstance(obj, list):
        for v in obj[:50]:
            _collect(v, acc)


for f in glob.glob(os.path.join(PKG, '**', '*.json'), recursive=True):
    try:
        acc = set()
        _collect(json.load(open(f, encoding='utf-8')), acc)
    except Exception:
        continue
    _json_keys_by_name.setdefault(os.path.basename(f), set()).update(acc)
    _ALL_JSON_KEYS |= acc

# Основы имён всех файлов пакета: `branch_g11` в тексте — это
# `03-CERTIFICATES/branches/branch_g11.npz`, а не висячий идентификатор.
_FILE_STEMS = set()
_ALL_RELPATHS = set()
_ALL_ABSPATHS = []
for _f in glob.glob(os.path.join(PKG, '**', '*'), recursive=True):
    if os.path.isfile(_f) and '__pycache__' not in _f:
        _FILE_STEMS.add(os.path.splitext(os.path.basename(_f))[0])
        _ALL_RELPATHS.add(os.path.relpath(_f, PKG).replace(os.sep, '/'))
        _ALL_ABSPATHS.append(_f)

# ЯВНЫЙ СПИСОК ИСКЛЮЧЕНИЙ.  Каждая строка — с причиной; это не «замести под
# ковёр», а зафиксировать, что ссылка ведёт наружу пакета СОЗНАТЕЛЬНО и что
# сам документ это оговаривает.  Добавлять сюда — только вместе с такой
# оговоркой в самом документе.
_ALLOWED_MISSING = {
    # REPORT-ANCHOR прямо пишет, что скрипт приёмки поставляется
    # передаётся отдельно и в пакет не входит
    'verify_pkg.sh': 'скрипт приёмки живёт вне пакета, документ это оговаривает',
    # COVERAGE.md сам пишет: «в пакет не входят» (банк сырых прогонов)
    'results.json': 'COVERAGE.md прямо оговаривает, что сырые файлы не входят',
    'xcheck_scale.log': 'то же — сырой выход, не входит',
    'xcheck_scale.json': 'то же — сырой выход, не входит',
    # 05-DATA-INDEX §«рабочий каталог» описывает НЕ пакет, а каталог сборки
    'BRIEF-*.md': 'описание рабочего каталога сборки, не пакета',
    'REPORT.md': 'то же',
    # REPORT-ANCHOR.md описывает свой рабочий каталог якорного прогона
    'BRIEF.md': 'рабочий каталог якорного прогона, оговорено в REPORT-ANCHOR.md',
    'work/_LOG.md': 'то же',
    '_LOG.md': 'то же',
    'work/_s3s4_result.json': 'то же',
    '_s3s4_result.json': 'то же',
    # rerun_all.sh пишет прогресс во временный каталог ОС (HYP_RERUN);
    # 02-REPRODUCE.md это прямо оговаривает в таблице переменных.
    'rerun_progress.log': 'создаётся при запуске rerun_all.sh, в пакет не входит',
}

bad = []
seen = 0


def fail(doc, kind, token, why):
    bad.append((os.path.relpath(doc, PKG).replace(os.sep, '/')
                if doc.startswith(PKG) else doc, kind, token, why))


# Обратные кавычки — единственный источник токенов: голый текст статьи
# полон математики, и ловить имена в нём — гарантированный шум.
_TICK = re.compile(r'`([^`\n]{1,120})`')

_EXT = ('.py', '.sh', '.json', '.npz', '.md', '.sha256', '.out', '.log')
_PATHLIKE = re.compile(r'^[\w*-][\w./*-]*$')  # имя до расширения непустое
_FILELINE = re.compile(r'^([\w./-]+\.(?:py|sh))[:](\d+)(?:[-–]\d+)?(?:\s*,\s*\d+(?:[-–]\d+)?)*$')
_JSONFIELD = re.compile(r'^([\w./*-]+\.json)::([\w{}., \[\]"-]+)$')
_PYSYM = re.compile(r'^([\w./-]+\.py)::([\w.]+)$')
_NPZFIELD = re.compile(r'^([\w./*-]+\.npz)::([\w.]+)$')
_ENVVAR = re.compile(r'^(HYP_[A-Z0-9_]+|CERT_OUT|GLUE_OUT|PYTHONIOENCODING)$')
_IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

# Имена, которые заведомо не про этот пакет (внешние библиотеки, команды).
_EXTERNAL = {
    'python_flint', 'numpy', 'mpmath', 'arb_mat', 'acb_mat', 'arb_poly',
    'python3', 'sha256sum', 'utf_8', 'core_audio',
}


def _exists_path(tok):
    """Существует ли путь внутри пакета.

    ВАЖНО про строгость.  Раздел H в `_numbers_check.py` делает похожую
    проверку, но сверяет по BASENAME: `04-CODE/offsets.json` он принимал,
    потому что файл с таким именем в пакете есть — пусть и в другом
    каталоге.  Эта поблажка и пропустила мёртвое умолчание, найденное в
    круге 3.

    Здесь путь должен быть СУФФИКСОМ реального пути в пакете.  Документы
    законно пишут пути относительно каталога запуска
    (`tests/_numbers_check.py` — от `04-CODE/`), и суффиксное сравнение это
    принимает; а вот выдуманный каталог (`04-CODE/offsets.json`) суффиксом
    ничему не является и ловится.
    """
    tok = tok.strip('/')
    if any(ch in tok for ch in '*?'):
        pats = [os.path.join(PKG, tok.replace('/', os.sep)),
                os.path.join(PKG, '**', tok.replace('/', os.sep))]
        return any(glob.glob(x, recursive=True) for x in pats)
    if os.path.exists(os.path.join(PKG, tok.replace('/', os.sep))):
        return True
    suffix = '/' + tok
    return any(rp == tok or rp.endswith(suffix) for rp in _ALL_RELPATHS)


_JSON_CACHE = {}          # разбор json один раз на прогон
_JSON_MISS = object()


def _resolves_nested(fname, path):
    """Резолвится ли `a.b.c` в каком-нибудь из файлов, подходящих под имя.

    Имя файла может быть шаблоном (`box_g*.json`): достаточно, чтобы путь
    разрешился хотя бы в одном подходящем файле — так написана и сама
    документация («поле `best.L` в `box_g*.json`»).
    """
    import json as _json
    pat = fname if any(ch in fname for ch in '*?') else '*' + fname
    # Здесь стоял срез `cands[:200]` в порядке обхода файловой
    # системы.  Вызов ниже подставляет шаблон `*.json`, то есть кандидатов 789:
    # на Windows нужные `box_g*.json` попадали в первые двести и сторож зеленел,
    # на Linux они идут с 709-й позиции — и те же 11 ссылок на `best.*`
    # объявлялись висячими (прогон на T480, пункт 1.6 финального ревью).
    # Вердикт сторожа зависел от порядка каталога, а значит по той же причине
    # мог и ПРОПУСТИТЬ настоящую висячую ссылку.  Срез убран, порядок
    # зафиксирован сортировкой, разбор кэшируется — 789 файлов на 3.2 МБ
    # читаются один раз на весь прогон.
    cands = sorted(p for p in _ALL_ABSPATHS
                   if p.endswith('.json') and fnmatch.fnmatch(
                       os.path.basename(p), os.path.basename(pat)))
    for p in cands:
        obj = _JSON_CACHE.get(p, _JSON_MISS)
        if obj is _JSON_MISS:
            try:
                obj = _json.load(open(p, encoding='utf-8'))
            except Exception:                              # noqa: BLE001
                obj = None
            _JSON_CACHE[p] = obj
        if obj is None:
            continue
        cur, ok = obj, True
        for part in path.split('.'):
            part = part.strip().strip('"[]')
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                ok = False
                break
        if ok:
            return True
    return False


# Токен, похожий на ссылку, обязан подойти под какое-то правило.  Молчаливый
# пропуск — это и есть механизм, которым жил дефект круга 4: `best.L` не
# подходил ни под что и потому считался «не ссылкой».
_LOOKS_REF = re.compile(r'::|\.json\b|\.py:\d|\.sh:\d')

_LINE_HAS_CONTENT = re.compile(r'^\s*[^\s)\]},]')

# Идентификатор в обратных кавычках непосредственно перед ссылкой — якорь,
# по которому видно, туда ли ещё показывает номер строки.  Берём последний
# в пределах 300 символов слева; пути и голые слова не годятся.
_ANCH = re.compile(r'`([A-Za-z_][\w.-]*(?:_[\w.-]+|\.[A-Za-z_][\w]*))`')


def _anchor_before(txt, pos):
    seg = txt[max(0, pos - 300):pos]
    best = None
    for a in _ANCH.finditer(seg):
        cand = a.group(1)
        if '/' in cand or cand.endswith(('.py', '.json', '.md', '.sh',
                                         '.npz')):
            continue
        best = cand
    return best


_unmatched = []
_skipped = []

# Формы, которые похожи на ссылку, но проверять в них нечего.
# Каждая — с причиной, и все они считаются: см. итоговую строку.
_NOT_A_REF = (
    (re.compile(r'[<>]'),        'шаблон с плейсхолдером'),
    (re.compile(r'^\$\w+/'),     'путь через переменную окружения'),
    (re.compile(r'\s'),          'командная строка, а не ссылка'),
)

for doc in _docs:
    try:
        txt = open(doc, encoding='utf-8', errors='replace').read()
    except OSError:
        continue
    for m in _TICK.finditer(txt):
        tok = m.group(1).strip()
        if not tok:
            continue

        # --- (3) поле json ------------------------------------------------
        jm = _JSONFIELD.match(tok)
        if jm:
            seen += 1
            fname, fields = jm.group(1), jm.group(2)
            # форма `lemma1_{U_min,margin_a}` — раскрываем в набор имён
            grp = re.match(r'^([\w.]*)\{([^}]*)\}$', fields.strip())
            names = ([grp.group(1) + p.strip() for p in grp.group(2).split(',')]
                     if grp else [fields.strip()])
            # Путь с точкой (`best.L`, `inner_product.abs_min`) до круга 4
            # не подходил под регулярку и МОЛЧА не проверялся.  Теперь
            # вложенные пути резолвятся в реальной структуре json: плоское
            # множество ключей на такой вопрос ответить не может — оно не
            # знает, что под чем лежит.
            miss = []
            for nm in names:
                if not nm:
                    continue
                if '.' in nm:
                    if not _resolves_nested(fname, nm):
                        miss.append(nm)
                    continue
                keys = set()
                for jn, ks in _json_keys_by_name.items():
                    if fname.replace('*', '') in jn or jn in fname                             or '*' in fname:
                        keys |= ks
                keys = keys or _ALL_JSON_KEYS
                if nm not in keys:
                    miss.append(nm)
            if miss:
                fail(doc, 'поле json', tok, 'нет ключей: %s' % ', '.join(miss))
            continue

        # --- (3б) символ в .py --------------------------------------------
        pm = _PYSYM.match(tok)
        if pm:
            seen += 1
            rel, sym = pm.group(1), pm.group(2)
            if rel.startswith('work/'):
                continue          # архивное рабочее дерево, см. REPORT-ANCHOR
            hits = [p for p in _ALL_ABSPATHS
                    if p.replace(os.sep, '/').endswith('/' + rel)
                    or os.path.basename(p) == os.path.basename(rel)]
            if not hits:
                fail(doc, 'символ в .py', tok, 'файла нет в пакете')
            else:
                src = open(hits[0], encoding='utf-8', errors='replace').read()
                leaf = sym.split('.')[-1]
                if not re.search(r'\b%s\b' % re.escape(leaf), src):
                    fail(doc, 'символ в .py', tok,
                         'в %s нет такого имени' % os.path.basename(hits[0]))
            continue

        # --- (3в) поле в .npz ----------------------------------------------
        nm_ = _NPZFIELD.match(tok)
        if nm_:
            seen += 1
            patt, field = nm_.group(1), nm_.group(2)
            cands = [p for p in _ALL_ABSPATHS if p.endswith('.npz')
                     and fnmatch.fnmatch(os.path.basename(p),
                                         os.path.basename(patt))]
            if not cands:
                fail(doc, 'поле npz', tok, 'нет подходящих .npz в пакете')
            else:
                ok = False
                try:
                    import numpy as _np
                    for p in cands[:20]:
                        with _np.load(p, allow_pickle=False) as z:
                            if field in z.files:
                                ok = True
                                break
                except Exception as _exc:                  # noqa: BLE001
                    fail(doc, 'поле npz', tok, 'не читается: %s' % _exc)
                    continue
                if not ok:
                    fail(doc, 'поле npz', tok,
                         'ни в одном из %d файлов нет такого массива'
                         % len(cands))
            continue

        # --- (2) файл:строка ----------------------------------------------
        fm = _FILELINE.match(tok)
        if fm:
            seen += 1
            rel, ln = fm.group(1), int(fm.group(2))
            # `file.py:291,794,864` — в токене может стоять несколько
            # номеров; якорю достаточно оказаться рядом с любым.
            _lns = [int(x) for x in re.findall(r'\d+', tok[len(rel):])]
            hits = glob.glob(os.path.join(PKG, '**', os.path.basename(rel)),
                             recursive=True)
            hits = [h for h in hits if '__pycache__' not in h]
            if not hits:
                fail(doc, 'файл:строка', tok, 'файла нет в пакете')
            else:
                _src = open(hits[0], encoding='utf-8',
                            errors='replace').read().split('\n')
                n = len(_src)
                if ln > n:
                    fail(doc, 'файл:строка', tok,
                         'в файле %d строк, ссылка на %d' % (n, ln))
                elif not _LINE_HAS_CONTENT.match(_src[ln - 1]):
                    fail(doc, 'файл:строка', tok,
                         'строка %d пуста или состоит из одной скобки: %r'
                         % (ln, _src[ln - 1].strip()[:40]))
                else:
                    _anch = _anchor_before(txt, m.start())
                    if _anch:
                        _at = [i for i, L in enumerate(_src, 1)
                               if _anch in L]
                        if _at and not any(abs(i - j) <= 12
                                          for i in _at for j in _lns):
                            fail(doc, 'файл:строка', tok,
                                 'рядом в тексте стоит `%s`, а в файле оно '
                                 'на строках %s — ссылка уехала'
                                 % (_anch, ', '.join(map(str, _at[:6]))))
            continue

        # --- (1) путь к файлу ---------------------------------------------
        if tok.endswith(_EXT) and _PATHLIKE.match(tok):
            seen += 1
            if tok in _ALLOWED_MISSING:
                continue
            # `work/...` — рабочий каталог якорного прогона, а не каталог
            # пакета; REPORT-ANCHOR.md это прямо оговаривает во врезке.
            if tok.startswith('work/'):
                continue
            if not _exists_path(tok):
                fail(doc, 'файл', tok, 'нет такого файла в пакете')
            continue

        # --- (4) переменная окружения ---------------------------------------
        if _ENVVAR.match(tok):
            seen += 1
            if tok not in _ALL_CODE:
                fail(doc, 'env', tok, 'ни один скрипт её не читает')
            continue

        # --- (5) идентификатор с подчёркиванием ------------------------------
        if _IDENT.match(tok) and '_' in tok and len(tok) >= 4 \
                and tok.lower() not in _EXTERNAL:
            seen += 1
            if tok not in _ALL_CODE and tok not in _ALL_JSON_KEYS                     and tok not in _FILE_STEMS:
                fail(doc, 'идентификатор', tok,
                     'не встречается ни в коде, ни в ключах json, ни в '
                     'именах файлов')
            continue

        # --- (5б) поле json без имени файла (`best.rho_star_b`) ------------
        if re.match(r'^[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+$', tok) \
                and not tok.endswith(('.py', '.sh', '.json', '.npz', '.md')) \
                and tok.split('.')[0] in _ALL_JSON_KEYS:
            seen += 1
            if not _resolves_nested('*.json', tok):
                fail(doc, 'поле json', tok,
                     'путь не разрешается ни в одном json пакета')
            continue

        # --- (6) ничего не подошло -----------------------------------------
        if _LOOKS_REF.search(tok):
            why = next((w for rx, w in _NOT_A_REF if rx.search(tok)), None)
            if why:
                _skipped.append((doc, tok, why))
            else:
                _unmatched.append((doc, tok))

for doc, tok in _unmatched:
    fail(doc, 'не разобрано', tok,
         'похоже на ссылку, но не подошло ни под одно правило — сторож '
         'обязан либо проверять такую форму, либо не делать вид, что проверил')

print('_refs_check: проверено ссылок %d в %d документах' % (seen, len(_docs)))
if _skipped:
    from collections import Counter as _C
    _cnt = _C(w for _, _, w in _skipped)
    print('  не ссылки (проверять нечего): %s'
          % ', '.join('%s - %d' % (w, n) for w, n in sorted(_cnt.items())))
if bad:
    print('\nВИСЯЧИЕ ССЫЛКИ (%d):' % len(bad))
    for doc, kind, tok, why in bad:
        print('  %-22s %-14s `%s` — %s' % (doc, kind, tok, why))
    print('\nСсылка, ведущая в никуда, — дефект: читатель проверяет по ней и '
          'не находит проверки.')
    sys.exit(2)
print('висячих ссылок нет.')
sys.exit(0)
