# -*- coding: utf-8 -*-
"""
_dchk_bound_test.py — фальсифицирующая проверка выведенной границы d_chk.

Величина d_chk в воротах обязана мажорировать расхождение σ-модели
оператора с прямым движком по всему боксу.  С 18.08 она не измеряется, а
ВЫВОДИТСЯ (см. блок DCHK-CONV в rig2fix3.py):

    ‖F(P_tay(σ)) − F(P_cheb(σ))‖ ≤ sup‖M′‖₁ · ‖P_tay(σ) − P_cheb(σ)‖ ,

где ‖ΔP‖ — погрешность float64-конверсии чебышёв→тейлор, посчитанная
точно (та же рекуррентность в arb минус float-результат).

Этот тест не является частью доказательства: он ловит ошибку в самом
выводе.  В наборе точек σ считается фактическое расхождение — В ПРАВИЛЬНОМ
СОГЛАШЕНИИ ПО ВЕСУ, R^(k+1), как в rig_lib.point_eval и op_sig.py:152 (в
до-исправленной самопроверке стоял R^k, из-за чего она мерила не
расхождение, а ~(1−R)/R·‖F̃‖₁; см. _dchk_check.py).  Если хоть в одной
точке фактическое расхождение превышает выведенную границу — вывод неверен,
и тест обязан упасть.
"""
import os, sys, math
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)

import rig_lib as rl
import tube_lib as tl
import op_sig as osig
import fp_lib as fl
import hyp_rouche as hr
from flint import arb, ctx

ctx.prec = 256
NP, R, C = tl.N_p, tl.r_arb, tl.c_arb

BR = os.environ.get('HYP_BRANCHES',
                    os.path.join(PARENT, '..', '03-CERTIFICATES', 'branches'))
TAG, ELL0, W, M, D = 'g01', 2.07, 0.05, 6, 8

z = np.load(os.path.join(BR, 'branch_%s.npz' % TAG))
c_a = z['c_a']
w_a = arb('%.17e' % W)
ell0_a = arb('%.17e' % ELL0)
smax = w_a / 2

tay = np.zeros((M + 1, NP + 1))
for k in range(NP + 1):
    tay[:, k] = fl.cheb_to_taylor(c_a[:M + 1, k], W)
tay[0, 0] = 1.0
tay[1:, 0] = 0.0
P0 = [arb(float(x)) for x in tay[0]]
P0[0] = arb(1)
ops = osig.build_operator_sigma(P0, tay, M, ELL0, W, D, prec=256)


def cheb_to_taylor_arb(cvec, w_a_):
    n = len(cvec) - 1
    sc = arb(2) / w_a_
    Tkm2 = [arb(0)] * (n + 1); Tkm2[0] = arb(1)
    Tkm1 = [arb(0)] * (n + 1)
    if n >= 1:
        Tkm1[1] = sc
    total = [arb('0.5') * cvec[0] * Tkm2[i] for i in range(n + 1)]
    for k in range(1, n + 1):
        for i in range(n + 1):
            total[i] = total[i] + cvec[k] * Tkm1[i]
        if k < n:
            Tnew = [arb(0)] * (n + 1)
            for i in range(1, n + 1):
                Tnew[i] = 2 * sc * Tkm1[i - 1]
            for i in range(n + 1):
                Tnew[i] = Tnew[i] - Tkm2[i]
            Tkm2, Tkm1 = Tkm1, Tnew
    return total


# --- выведенная граница, ровно как в rig2fix3.py ---
dtay = [[arb(0)] * (NP + 1) for _ in range(M + 1)]
for k in range(NP + 1):
    ex = cheb_to_taylor_arb([arb(float(x)) for x in c_a[:M + 1, k]], w_a)
    for i in range(M + 1):
        dtay[i][k] = ex[i] - arb(float(tay[i][k]))
s_full = (-smax).union(smax)
dcoef = []
for k in range(NP + 1):
    acc, sp = arb(0), arb(1)
    for i in range(M + 1):
        acc = acc + dtay[i][k] * sp
        sp = sp * s_full
    dcoef.append(acc)
Dc = tl.reexpand_fast(dcoef, C, R, NP)
dP, rk = arb(0), arb(1)
for k in range(NP + 1):
    dP = dP + abs(Dc[k]) * rk
    rk = rk * R
dP = dP.upper()

M1box = arb(0)
for s_ in range(2):
    xlo, xhi = -1.0 + s_, 0.0 + s_
    elo = ell0_a - smax + w_a * arb(s_) / 2
    ehi = ell0_a - smax + w_a * arb(s_ + 1) / 2
    Pint = rl.P_at_interval(c_a, M, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
    pkg = tl.build_pkg_fast(Pint, elo.union(ehi))
    DT = hr.dt_from_pkg(pkg)
    for kk in range(NP):
        cs = arb(0)
        for jj in range(NP):
            mjk = (arb(1) - DT[jj][kk]) if jj == kk else -DT[jj][kk]
            cs = cs + abs(mjk)
        cu = cs.upper()
        if cu > M1box:
            M1box = cu
bound = (M1box * dP).upper()


def up_float(x):
    """Наименьший double, гарантированно не меньший x (см. hyp_rouche.py::up_float)."""
    v = arb(x).upper()
    f = float(v)
    if arb(f) < v:
        f = math.nextafter(f, math.inf)
    return f


def dn_float(x):
    """Наибольший double, гарантированно не больший x (см. rig2fix3.py::dn_float)."""
    v = arb(x).lower()
    f = float(v)
    if arb(f) > v:
        f = math.nextafter(f, -math.inf)
    return f


bound_f = dn_float(bound)
print('выведенная граница d_chk = %.6e  (‖ΔP‖=%.6e, sup‖M′‖₁=%.6e)'
      % (float(bound), float(dP), float(M1box)))


def measured(xv):
    """фактическое расхождение в ПРАВИЛЬНОМ соглашении по весу"""
    sv = xv * (W / 2)
    P_sv = rl.P_at(c_a, M, arb('%.17e' % xv))
    F_ref = tl.compute_F_poly(P_sv, ell0_a + arb('%.17e' % sv))
    F_list = list(F_ref.coeffs())
    while len(F_list) < NP + 2:
        F_list.append(arb(0))
    d = arb(0)
    for k in range(NP):
        mine = arb(0)
        for i, sl_ in enumerate(ops['Ftilde_slices']):
            if k < len(sl_):
                mine = mine + sl_[k] * (arb('%.17e' % sv) ** i)
        d = d + abs(mine - F_list[k + 1] * (R ** (k + 1)))
    return up_float(d)


print()
print('  x        расхождение (R^(k+1))     доля границы')
bad = 0
n_meas = 0
n_zero = 0
for i in range(21):
    xv = -1.0 + 2.0 * i / 20
    mv = measured(xv)
    n_meas += 1
    if not (mv > 0.0):
        n_zero += 1
    frac = mv / bound_f
    flag = ''
    if mv > bound_f:
        flag = '   <<< ПРЕВЫШЕНИЕ'
        bad += 1
    print('%6.2f   %.10e        %.4f%s' % (xv, mv, frac, flag))

print()
# --- защита от fail-open: счётчик выполненных замеров ---
# Без этих двух строк ворот был fail-open: если тело measured() обнулить
# (return 0.0), то mv = 0 <= bound_f во всех 21 точках, печаталось
# «ok: во всех 21 точках расхождение ниже выведенной границы» и exit 0.
# Обнулённое измерение было неотличимо от успешного, потому что скрипт не
# печатал ни счётчика замеров, ни признака невырожденности. Фактическое
# расхождение строго положительно в каждой точке (эталон: ~5.65e-16).
print('  замеров выполнено: %d, из них нулевых: %d' % (n_meas, n_zero))
if n_meas != 21 or n_zero:
    print('ПРОВАЛ ВЫРОЖДЕНИЯ: замеров %d (ожидалось 21), нулевых %d — '
          'измерение не состоялось, ворот не имеет силы' % (n_meas, n_zero))
    sys.exit(2)
if bad:
    print('ПРОВАЛ: в %d точках фактическое расхождение выше выведенной '
          'границы — вывод неверен.' % bad)
    sys.exit(1)
print('ok: во всех 21 точках расхождение ниже выведенной границы')
