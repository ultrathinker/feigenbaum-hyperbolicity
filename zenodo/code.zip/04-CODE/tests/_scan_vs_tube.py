# -*- coding: utf-8 -*-
"""
_scan_vs_tube.py — сверка двух независимых счётов δ(ℓ) и λ₂(ℓ).

Источник 1: `05-DATA/delta_scan.json` — скан по 101 точке, спектр строился
из `fp_lib.build_Mprime` по решению неподвижной точки в каждой точке.
Источник 2: центры 697 боксов трубки — спектр строился из `tube_lib`-пакета
по ПАРАМЕТРИЗОВАННОМУ центру `P(ℓ)`, другой код и другой путь к матрице.

Совпадение — независимое подтверждение обоих; расхождение — находка.
"""
import os, sys, json, glob
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

PKG = os.path.dirname(ROOT)
SCAN = os.environ.get('HYP_SCAN',
                      os.path.join(PKG, '05-DATA', 'delta_scan.json'))
scan = json.load(open(SCAN, encoding='utf-8'))
rows = scan['rows'] if isinstance(scan, dict) and 'rows' in scan else scan
pts = []
for r in rows:
    if isinstance(r, dict):
        ell = r.get('ell')
        d = r.get('delta') or r.get('delta_mid')
        l2 = r.get('lam2') or r.get('lambda2')
        if ell is not None and d is not None:
            pts.append((float(ell), float(d), float(l2) if l2 is not None else None))
pts.sort()
print('точек в скане: %d' % len(pts))

tube = []
TUBE = os.environ.get('HYP_TUBE_OUT',
                      os.path.join(PKG, '03-CERTIFICATES', 'tube'))
for f in glob.glob(os.path.join(TUBE, 'box_*.json')):
    j = json.load(open(f, encoding='utf-8'))
    if j.get('pass'):
        tube.append((j['ell0'], j['delta_mid'], j['lam2_mid']))
tube.sort()
te = np.array([t[0] for t in tube])
td = np.array([t[1] for t in tube])
tl2 = np.array([t[2] for t in tube])
print('центров трубки: %d' % len(tube))

print('\n%-9s %-16s %-16s %-11s %-11s' %
      ('ell', 'δ скан', 'δ трубка (интерп)', 'разница', 'λ₂ разница'))
worst_d = worst_l = 0.0
for ell, d, l2 in pts:
    if ell < te[0] or ell > te[-1]:
        continue
    di = float(np.interp(ell, te, td))
    li = float(np.interp(ell, te, tl2))
    dd = abs(di - d)
    dl = abs(li - l2) if l2 is not None else 0.0
    worst_d = max(worst_d, dd)
    worst_l = max(worst_l, dl)
    if abs(ell * 10 - round(ell * 10)) < 1e-9:      # печатаем каждые 0.1
        print('%-9.4f %-16.9f %-16.9f %-11.2e %-11.2e' % (ell, d, di, dd, dl))
print('\nхудшая разница δ: %.2e,  λ₂: %.2e' % (worst_d, worst_l))
print('(разница включает ошибку линейной интерполяции между центрами боксов,')
print(' шаг которых 0.0012…0.007, поэтому ~1e-3 для δ — это норма)')

# Скрипт печатал числа, но не проверял порог, который
# статья с него цитирует (§7.4: «разница не превосходит 1.7·10⁻⁶»).
# Теперь проверяет и возвращает ненулевой код при нарушении.
import sys as _sys
_LIM_D, _LIM_L = 1.7e-6, 1.0e-6
_bad = []
if worst_d > _LIM_D:
    _bad.append('δ: %.3e > порога %.1e' % (worst_d, _LIM_D))
if worst_l > _LIM_L:
    _bad.append('λ2: %.3e > порога %.1e' % (worst_l, _LIM_L))
if _bad:
    print('*** FAIL: ' + '; '.join(_bad))
    _sys.exit(1)
print('СКАН vs ТРУБКА: ok (δ %.2e ≤ %.1e, λ2 %.2e ≤ %.1e)'
      % (worst_d, _LIM_D, worst_l, _LIM_L))
