# -*- coding: utf-8 -*-
"""_all_gates.py — прогнать ВСЕ проверки пакета и назвать красные.

Зачем отдельный скрипт. Приёмка перечисляла ворота по памяти, и
`tests/_appendix_check.py` возвращал код 2 неизвестно сколько кругов: его
просто не было в списке. Список ворот — сам по себе объект, который надо
сверять с папкой, а не помнить. Здесь он СТРОИТСЯ из папки, поэтому новая
проверка попадает в прогон в тот же день, когда появляется, а исчезнувшая —
исчезает заметно.

Что считается воротами: всё в `04-CODE/tests/*.py` кроме перечисленных ниже
библиотек и генераторов, плюс `04-CODE/_containment.py`, `04-CODE/glue.py`,
`04-CODE/tube_accept.py`, `03-CERTIFICATES/anchor-inertia/_anchor_check.py`
и `_manifest.py verify`.

Отдельно печатается расхождение с `02-REPRODUCE.md`: ворота, которых документ
не называет, при воспроизведении по инструкции никто не запустит, и их
зелёность о пакете ничего не сообщает.

Код возврата: 0 — все зелёные; 1 — есть красные; 2 — отказ самого прогона
(не нашлось ни одного кандидата: пустой список неотличим от «все прошли»).

Долго: полный прогон около 20 минут, дороже всех `_crosscheck.py` (~5 мин),
`_holo_radius.py` (~3 мин) и `_layer_invariance.py` (~2 мин).
"""
import glob
import io
import os
import re
import subprocess
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8',
                              errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.dirname(HERE)
PKG = os.environ.get('HYP_PKG', os.path.dirname(CODE))
DOC = os.path.join(PKG, '02-REPRODUCE.md')
PY = os.environ.get('HYP_PYTHON', sys.executable)

# Не ворота: библиотеки, генераторы и до-исправленные копии — они ничего не
# проверяют, а служат материалом для проверок. Каждое исключение с причиной:
# исключение без причины — это дыра, а не решение.
NOT_A_GATE = {
    '_all_gates.py': 'этот самый прогон',
    'pure_interval.py': 'генератор сертификата, не проверка',
    'sanity_miller.py': 'запускается с аргументом, отдельный шаг',
    'sig_lib_pre_taufix.py': 'до-исправленная библиотека, материал '
                             'для _tau_test',
    # Эти трое возвращали 0 при ЛЮБЫХ значениях и потому попадали
    # в итог «все ворота зелёные», ничего не проверяя.  Проверено чтением
    # всех веток выхода: у `_tau_share.py` нет ни `sys.exit`, ни `assert`,
    # ни `raise`; единственный `sys.exit` в `_stats.py` срабатывает на
    # ОТСУТСТВИЕ входных боксов, то есть на проблему входа, а не на вердикт;
    # `_z1bc_sub.py` ловит исключение внутри цикла по K, печатает его и
    # продолжает, после чего процесс всё равно заканчивается нулём.
    # Зелёный ворот, неспособный покраснеть, хуже отсутствующего: он
    # добавляет уверенности, ничего не проверив.
    '_stats.py': 'печатает диапазоны по боксам, вердикта не выносит',
    '_tau_share.py': 'генератор tau_share.json, вердикта не выносит',
    '_z1bc_sub.py': 'замер падения Z1c по K для таблицы §3.2, '
                    'вердикта не выносит',
}

TIMEOUT = int(os.environ.get('HYP_GATE_TIMEOUT', '1800'))


def candidates():
    out = []
    for p in sorted(glob.glob(os.path.join(HERE, '*.py'))):
        if os.path.basename(p) in NOT_A_GATE:
            continue
        out.append(p)
    for rel in ('_containment.py', 'glue.py', 'tube_accept.py'):
        p = os.path.join(CODE, rel)
        if os.path.isfile(p):
            out.append(p)
    p = os.path.join(PKG, '03-CERTIFICATES', 'anchor-inertia',
                     '_anchor_check.py')
    if os.path.isfile(p):
        out.append(p)
    p = os.path.join(PKG, '_manifest.py')
    if os.path.isfile(p):
        out.append(p)
    return out


def main():
    cands = candidates()
    if not cands:
        print('ПРОВАЛ ПРОГОНА: не нашлось ни одного кандидата в ворота — '
              'пустой список неотличим от «все прошли»')
        return 2

    print('ворот к прогону: %d (список построен из папки, а не из памяти)'
          % len(cands))
    print('не ворота: %s'
          % '; '.join('%s — %s' % kv for kv in sorted(NOT_A_GATE.items())))
    print()
    print('%-32s %-7s %-8s %s'
          % ('скрипт', 'код', 'сек', 'последняя содержательная строка'))
    print('-' * 108)

    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    red = []
    for p in cands:
        name = os.path.basename(p)
        args = [PY, p] + (['verify'] if name == '_manifest.py' else [])
        t0 = time.time()
        try:
            r = subprocess.run(args, capture_output=True, cwd=PKG, env=env,
                               timeout=TIMEOUT)
            rc = r.returncode
            out = (r.stdout or b'').decode('utf-8', 'replace')
            err = (r.stderr or b'').decode('utf-8', 'replace')
            lines = [l.strip() for l in out.splitlines() if l.strip()]
            tail = lines[-1][:66] if lines else \
                (err.strip().splitlines() or [''])[-1][:66]
        except subprocess.TimeoutExpired:
            rc, tail = 'TIMEOUT', 'не уложился в %d с' % TIMEOUT
        if rc != 0:
            red.append((name, rc, tail))
        print('%-32s %-7s %-8.1f %s' % (name, rc, time.time() - t0, tail))

    print()
    if red:
        print('*** КРАСНЫХ ВОРОТ: %d' % len(red))
        for n, rc, tail in red:
            print('  %-30s код %s   %s' % (n, rc, tail))
    else:
        print('все %d ворот зелёные' % len(cands))

    print()
    print('=== чего нет в 02-REPRODUCE.md ===')
    if not os.path.isfile(DOC):
        print('  НЕТ ДОКУМЕНТА — сверить не с чем')
    else:
        doc = io.open(DOC, encoding='utf-8').read()
        named = {os.path.basename(m.group(1))
                 for m in re.finditer(r'([A-Za-z0-9_./\\-]*\.py)', doc)}
        unnamed = [os.path.basename(p) for p in cands
                   if os.path.basename(p) not in named]
        print('  ворот не названо документом: %d' % len(unnamed))
        for b in unnamed:
            print('    %s' % b)
        if unnamed:
            print('  (не провал: проверка работает. Но при воспроизведении '
                  'по инструкции она не запускается)')

    return 1 if red else 0


if __name__ == '__main__':
    sys.exit(main())
