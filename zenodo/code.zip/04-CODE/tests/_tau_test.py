# -*- coding: utf-8 -*-
"""
_tau_test.py — фальсифицирующий тест tau-оценок sig_lib.

Для каждой скалярной операции считаем ИСТИННЫЙ хвост
    T = sum_{D < i <= D_hi} |c_i| smax^i
разложением до высокой степени D_hi (остаток за D_hi ничтожен, когда
h_abs мал), и требуем tau >= T.  Прогоняем и старую версию
(sig_lib_pre_taufix), и новую — старая обязана падать хотя бы на одном
примере, иначе тест ничего не проверяет.

Запуск: python _tau_test.py
"""
import sys, os
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)          # движок лежит уровнем выше
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)

from flint import arb, ctx
import sig_lib as new
import sig_lib_pre_taufix as old

ctx.prec = 300
D_HI = 80


def series_recip(g, N):
    out = [arb(0)] * (N + 1)
    out[0] = 1 / g[0]
    for n in range(1, N + 1):
        s = arb(0)
        for k in range(n):
            gk = g[n - k] if n - k < len(g) else arb(0)
            s = s + gk * out[k]
        out[n] = -s / g[0]
    return out


def series_log(g, N):
    """Log(g) через L' = g'/g."""
    inv = series_recip(g, N)
    out = [arb(0)] * (N + 1)
    out[0] = g[0].log()
    for n in range(1, N + 1):
        # (n) L_n = [g' * inv]_{n-1}
        s = arb(0)
        for k in range(0, n):
            gk = arb(k + 1) * (g[k + 1] if k + 1 < len(g) else arb(0))
            s = s + gk * inv[n - 1 - k]
        out[n] = s / arb(n)
    return out


def series_exp(M, N):
    E = [arb(0)] * (N + 1)
    E[0] = M[0].exp()
    for n in range(1, N + 1):
        s = arb(0)
        for j in range(1, n + 1):
            Mj = M[j] if j < len(M) else arb(0)
            s = s + arb(j) * Mj * E[n - j]
        E[n] = s / arb(n)
    return E


def true_tail(coefs, D, smax):
    t = arb(0)
    for i in range(D + 1, len(coefs)):
        t = t + abs(coefs[i]) * (smax ** i)
    return t


CASES = [
    # (имя, g-коэффициенты, D, smax) — включая адверсариальный
    ('adversarial h=0.1s+0.1s^2', ['1', '0.1', '0.1'], 1, '1.0'),
    ('adversarial deg4',          ['1', '0.05', '0.2', '0.1', '0.15'], 2, '1.0'),
    ('realistic D=8',             ['1.3', '0.4', '-0.2', '0.11', '-0.06',
                                   '0.03', '-0.02', '0.01', '-0.005'], 8, '0.5'),
    ('slow decay D=4',            ['2.0', '0.5', '0.4', '0.3', '0.25',
                                   '0.2', '0.15', '0.1'], 4, '0.35'),
]

fails_old = 0
fails_new = 0
_n_log_cases = 0        # сколько случаев Log действительно проверено, а не пропущено
print('%-28s %-8s %-12s %-12s %-12s %s' %
      ('случай', 'что', 'истинный', 'tau старый', 'tau новый', 'вердикт'))
print('-' * 92)

for name, gs, D, ss in CASES:
    g = [arb(x) for x in gs]
    smax = arb(ss)

    # --- 1/g ---
    c = series_recip(g, D_HI)
    T = true_tail(c, D, smax)
    _, t_old, _ = old.scalar_recip(list(g), D, smax)
    _, t_new, _ = new.scalar_recip(list(g), D, smax)
    ok_o = bool(arb(t_old) >= T)
    ok_n = bool(arb(t_new) >= T)
    fails_old += (not ok_o)
    fails_new += (not ok_n)
    print('%-28s %-8s %-12.4e %-12.4e %-12.4e %s / %s' %
          (name, '1/g', float(T), float(t_old), float(t_new),
           'OK' if ok_o else 'ПРОВАЛ', 'OK' if ok_n else 'ПРОВАЛ'))

    # --- Log(g) ---
    cl = series_log(g, D_HI)
    Tl = true_tail(cl, D, smax)
    try:
        _, tl_old = old.scalar_log_from_recip(list(g), D, smax)
        _, tl_new = new.scalar_log_from_recip(list(g), D, smax)
        ok_o = bool(arb(tl_old) >= Tl)
        ok_n = bool(arb(tl_new) >= Tl)
        fails_old += (not ok_o)
        fails_new += (not ok_n)
        _n_log_cases += 1
        print('%-28s %-8s %-12.4e %-12.4e %-12.4e %s / %s' %
              ('', 'Log g', float(Tl), float(tl_old), float(tl_new),
               'OK' if ok_o else 'ПРОВАЛ', 'OK' if ok_n else 'ПРОВАЛ'))
    except RuntimeError as e:
        print('%-28s %-8s (пропуск: %s)' % ('', 'Log g', e))

    # --- exp(M) ---  M := g как ряд
    ce = series_exp(g, D_HI)
    Te = true_tail(ce, D, smax)
    _, te_old = old.scalar_exp(list(g), D, smax)
    _, te_new = new.scalar_exp(list(g), D, smax)
    ok_o = bool(arb(te_old) >= Te)
    ok_n = bool(arb(te_new) >= Te)
    fails_old += (not ok_o)
    fails_new += (not ok_n)
    print('%-28s %-8s %-12.4e %-12.4e %-12.4e %s / %s' %
          ('', 'exp M', float(Te), float(te_old), float(te_new),
           'OK' if ok_o else 'ПРОВАЛ', 'OK' if ok_n else 'ПРОВАЛ'))

# --- t_exp_seed: t-ряды длины 1 вырождаются в скаляры, сверяем с exp ---
print('-' * 92)
r = arb('0.8')
for name, gs, D, ss in CASES[:3]:
    smax = arb(ss)
    Msl = [[arb(x)] for x in gs]          # slices: каждый — t-ряд длины 1
    Msig_old = old.Sig(Msl, arb(0), smax)
    Msig_new = new.Sig(Msl, arb(0), smax)
    X0 = [arb('1.0')]
    so = old.t_exp_seed(Msig_old, X0, D, 0, r)
    sn = new.t_exp_seed(Msig_new, X0, D, 0, r)
    ce = series_exp([arb(x) for x in gs], D_HI)
    e0 = ce[0]
    Te = arb(0)
    for i in range(D + 1, D_HI + 1):
        Te = Te + abs(ce[i] / e0) * (smax ** i)   # X0=1, exp(M-M0)
    ok_o = bool(arb(so.tau) >= Te)
    ok_n = bool(arb(sn.tau) >= Te)
    fails_old += (not ok_o)
    fails_new += (not ok_n)
    print('%-28s %-8s %-12.4e %-12.4e %-12.4e %s / %s' %
          (name, 't_exp', float(Te), float(so.tau), float(sn.tau),
           'OK' if ok_o else 'ПРОВАЛ', 'OK' if ok_n else 'ПРОВАЛ'))

# --- КОМПОЗИЦИЯ  Log(recip(g))  при НЕНУЛЕВОМ хвосте входа -----------------
#
# Тест выше проверял 1/g и Log(g) ПОРОЗНЬ, каждый раз на конечном многочлене.
# Именно поэтому он не ловил дефект op_sig.py: там Log звали ОТ УСЕЧЕНИЯ 1/g,
# у которого есть свой хвост tau_recip, а scalar_log_from_recip мажорирует
# только хвост Log того конечного многочлена, который ей дали.  Ниже —
# фальсифицирующая пара: наивная композиция против тождества Log(1/g) = -Log(g).
print('-' * 92)
print('%-28s %-8s %-12s %-12s %-12s %s' %
      ('композиция Log(1/g)', 'что', 'истинный', 'tau наивный', 'tau по тожд.',
       'вердикт'))
fails_comp_naive = 0
for name, gs, D, ss in CASES:
    g = [arb(x) for x in gs]
    smax = arb(ss)
    # истинный хвост Log(1/g) = -Log(g): коэффициенты те же по модулю
    cl = series_log(g, D_HI)
    T = true_tail(cl, D, smax)
    try:
        recip, _tau_recip, _ = new.scalar_recip(list(g), D, smax)
        _, tau_naive = new.scalar_log_from_recip(list(recip), D, smax)
        _, tau_ident = new.scalar_log_from_recip(list(g), D, smax)
    except RuntimeError as e:
        print('%-28s %-8s (пропуск: %s)' % (name, 'Log 1/g', e))
        continue
    ok_naive = bool(arb(tau_naive) >= T)
    ok_ident = bool(arb(tau_ident) >= T)
    fails_comp_naive += (not ok_naive)
    fails_new += (not ok_ident)
    print('%-28s %-8s %-12.4e %-12.4e %-12.4e %s / %s' %
          (name, 'Log 1/g', float(T), float(tau_naive), float(tau_ident),
           'OK' if ok_naive else 'ПРОВАЛ', 'OK' if ok_ident else 'ПРОВАЛ'))
print('наивная композиция провалилась %d раз(а) из %d; маршрут по тождеству '
      '(op_sig LOG-ARG-FIX) — 0' % (fails_comp_naive, len(CASES)))
if fails_comp_naive == 0:
    print('ВНИМАНИЕ: наивная композиция не провалилась ни разу — '
          'этот блок не доказателен')

print('-' * 92)
print('провалов: старая версия %d, новая версия %d' % (fails_old, fails_new))

# Здесь тест ПЕЧАТАЛ «не доказателен» и возвращал 0.  То есть если подменить
# старую библиотеку новой (или заставить Log бросать, и тогда вся
# логарифмическая половина «пропускается»), фальсифицирующий тест перестаёт
# фальсифицировать — и молчит об этом кодом возврата.  Сторож, который сам
# сообщает, что ничего не доказывает, обязан быть красным.
_nonprobative = []
if fails_old == 0:
    _nonprobative.append('старая версия не провалилась ни разу')
if fails_comp_naive == 0:
    _nonprobative.append('наивная композиция не провалилась ни разу')
if _n_log_cases == 0:
    _nonprobative.append('ни один случай Log не проверен (все пропущены)')
if _nonprobative:
    print('ВНИМАНИЕ: тест не доказателен — %s' % '; '.join(_nonprobative))
sys.exit(1 if (fails_new or _nonprobative) else 0)
