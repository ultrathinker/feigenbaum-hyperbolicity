# -*- coding: utf-8 -*-
"""
_arb_sanity_battery.py — санитарная батарея по arb-API.

Зачем.  Весь пакет держится на строгой интервальной арифметике `python-flint`
(`arb`/`acb`/`arb_mat`).  Если где-то в API этой сборки направление округления,
семантика сравнения шаров или конверсия `float(arb)` ведёт себя НЕ так, как
код 04-CODE предполагает — это подрывает буквально все сертификаты, не одну
находку.  Эталон здесь — НЕ flint сам с собой: точные рациональные значения
проверяются через `fractions.Fraction` (бесконечная точность, ноль округлений),
иррациональные — через `mpmath.iv` (независимая интервальная арифметика с
точностью в разы выше `ctx.prec` пакета, поэтому её кроха-интервал целиком
укладывается внутрь шара `arb`, если направление округления верное).

Мосты к независимому эталону:
  * `pt_to_fraction(x)` — точка (`rad()==0`, как после `.upper()/.lower()/.mid()`)
    в EXACT `Fraction` через `man_exp()` (мантисса × 2^экспонента, без потерь);
  * `mpf_to_fraction(m)` — то же для `mpmath.mpf` через `._mpf_`;
  * `iv_to_fractions(ivx)` — обе границы `mpmath.iv`-интервала как `Fraction`.

Структура: ~50 пронумерованных утверждений по категориям из плана (grep по
`abs_upper, upper, lower, mid, arb_mat, ctx.prec`). Утверждения проверяют
РЕАЛЬНОЕ поведение установленной сборки
python-flint, а не желаемое; расхождения между этим поведением и тем, что
предполагает код 04-CODE, — отдельные замечания, они не превращают эту
батарею в красную: сама батарея обязана кончать зелёным.

Запуск:  python tests/_arb_sanity_battery.py   (из каталога 04-CODE)
Коды возврата: 0 — все ~50 утверждений прошли; 1 — хоть одно упало (сама
арифметика сборки ведёт себя не так, как думает весь пакет — СТОП-СОБЫТИЕ).
"""
import os
import re
import sys
from fractions import Fraction

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import mpmath
from mpmath import iv, mpf
from flint import arb, acb, ctx, arb_mat

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                       # 04-CODE
PKG = os.path.dirname(PARENT)                        # корень пакета
sys.path.insert(0, PARENT)

PREC = 256                                           # как в большинстве тестов пакета
ctx.prec = PREC
MP_DPS = 120                                         # 120 дес. цифр ≈ 400 бит ≫ PREC=256 бит
mpmath.mp.dps = MP_DPS
iv.dps = MP_DPS

_LOGDIR = os.environ.get('CERT_OUT') or os.environ.get('HYP_CERTS')

results = []


def check(cid, desc, cond, detail=''):
    results.append([cid, desc, bool(cond), detail])


# --------------------------------------------------------------------------
# мосты к независимому эталону (Fraction / mpmath.iv), никакого flint внутри
# --------------------------------------------------------------------------

def pt_to_fraction(x):
    """arb x с rad()==0 (точка, как после .upper()/.lower()/.mid()) -> Fraction."""
    if x.rad() != 0:
        raise ValueError('pt_to_fraction: rad() != 0, это не точка')
    m, e = x.man_exp()
    return Fraction(int(m)) * Fraction(2) ** int(e)


def mpf_to_fraction(m):
    sign, man, exp, bc = m._mpf_
    if man == 0:
        return Fraction(0)
    val = Fraction(int(man)) * Fraction(2) ** int(exp)
    return -val if sign else val


def iv_to_fractions(ivx):
    return mpf_to_fraction(mpf(ivx.a)), mpf_to_fraction(mpf(ivx.b))


def up_float(x):
    """Копия hyp_rouche.up_float — независимая переисполненная версия для
    регрессии (не импортируем hyp_rouche, чтобы не тянуть пакет)."""
    v = arb(x).upper()
    f = float(v)
    if arb(f) < v:
        f = __import__('math').nextafter(f, __import__('math').inf)
    return f


# ==========================================================================
# A. Направленные округления upper()/lower()/abs_upper()/abs_lower() против
#    Fraction (рациональные) и mpmath.iv (иррациональные) — независимый эталон
# ==========================================================================

# A1-A2: arb('0.1') как шар обязан накрывать точную 1/10
x = arb('0.1')
lo, up = pt_to_fraction(x.lower()), pt_to_fraction(x.upper())
check('A1', "arb('0.1').lower() <= 1/10 точно", lo <= Fraction(1, 10), str(lo))
check('A2', "arb('0.1').upper() >= 1/10 точно", up >= Fraction(1, 10), str(up))

# A3-A4: arb(1)/arb(10) тоже накрывает 1/10 (другим путём — делением)
y = arb(1) / arb(10)
lo2, up2 = pt_to_fraction(y.lower()), pt_to_fraction(y.upper())
check('A3', 'arb(1)/arb(10).lower() <= 1/10 точно', lo2 <= Fraction(1, 10), str(lo2))
check('A4', 'arb(1)/arb(10).upper() >= 1/10 точно', up2 >= Fraction(1, 10), str(up2))

# A5-A6: arb(22)/arb(7) накрывает 22/7 точно
z = arb(22) / arb(7)
zlo, zup = pt_to_fraction(z.lower()), pt_to_fraction(z.upper())
check('A5', 'arb(22)/arb(7).lower() <= 22/7', zlo <= Fraction(22, 7), str(zlo))
check('A6', 'arb(22)/arb(7).upper() >= 22/7', zup >= Fraction(22, 7), str(zup))

# A7-A8: сложение большого числа копий arb('0.1') не теряет направление
s = arb(0)
for _ in range(37):
    s = s + arb('0.1')
slo, sup = pt_to_fraction(s.lower()), pt_to_fraction(s.upper())
target = Fraction(37, 10)
check('A7', "37×arb('0.1') .lower() <= 37/10", slo <= target, str(slo))
check('A8', "37×arb('0.1') .upper() >= 37/10", sup >= target, str(sup))

# A9-A10: вычитание — направление не переворачивается
d = arb(1) - arb('0.1')
dlo, dup = pt_to_fraction(d.lower()), pt_to_fraction(d.upper())
check('A9', "(1-arb('0.1')).lower() <= 9/10", dlo <= Fraction(9, 10), str(dlo))
check('A10', "(1-arb('0.1')).upper() >= 9/10", dup >= Fraction(9, 10), str(dup))


def iv_bracket(cid_lo, cid_up, label, arb_val, iv_val):
    a_lo = pt_to_fraction(arb_val.lower())
    a_up = pt_to_fraction(arb_val.upper())
    r_lo, r_up = iv_to_fractions(iv_val)
    # mpmath.iv на MP_DPS=120 цифр многократно точнее arb на PREC=256 бит
    # (256 бит =~ 77 дес. цифр) — его интервал целиком внутри шара arb, если
    # направления округления верны.
    check(cid_lo, f'{label}: arb.lower() <= mpmath.iv нижняя граница', a_lo <= r_lo,
          f'arb_lo={a_lo}  iv_lo={r_lo}')
    check(cid_up, f'{label}: arb.upper() >= mpmath.iv верхняя граница', a_up >= r_up,
          f'arb_up={a_up}  iv_up={r_up}')


# A11-A12: pi
iv_bracket('A11', 'A12', 'arb.pi()', arb.pi(), iv.pi)
# A13-A14: sqrt(2)
iv_bracket('A13', 'A14', 'arb(2).sqrt()', arb(2).sqrt(), iv.sqrt(2))
# A15-A16: cos(1)
iv_bracket('A15', 'A16', 'arb(1).cos()', arb(1).cos(), iv.cos(1))
# A17-A18: sin(1)
iv_bracket('A17', 'A18', 'arb(1).sin()', arb(1).sin(), iv.sin(1))
# A19-A20: exp(1)
iv_bracket('A19', 'A20', 'arb(1).exp()', arb(1).exp(), iv.exp(1))
# A21-A22: log(2)
iv_bracket('A21', 'A22', 'arb(2).log()', arb(2).log(), iv.log(2))

# A23-A24: abs_upper/abs_lower для шара, содержащего ноль внутри —
# |x| должен быть взят по МАКСИМУМУ модуля концов, направление вверх/вниз
neg_ball = arb(0).union(arb(-3)).union(arb(2))     # [-3, 2]
au = pt_to_fraction(neg_ball.abs_upper())
al = pt_to_fraction(neg_ball.abs_lower())
check('A23', 'abs_upper([-3,2]) >= 3 (истинный максимум |x|)', au >= Fraction(3),
      str(au))
check('A24', 'abs_lower([-3,2]) <= 0 (ноль лежит внутри шара)', al <= Fraction(0),
      str(al))


# ==========================================================================
# B. arb('0.1') vs arb(1)/arb(10) — РАЗНЫЕ шары одного и того же рационала
# ==========================================================================

check('B1', "arb('0.1') != arb(1)/arb(10) как ОБЪЕКТЫ-шары (разные пути округления)",
      not bool(x == y), f'x={x}  y={y}')
check('B2', "но arb('0.1').overlaps(arb(1)/arb(10)) — оба накрывают одно 1/10",
      x.overlaps(y), '')
check('B3', "радиусы arb('0.1') и arb(1)/arb(10) численно различны",
      x.rad() != y.rad(), f'rad(x)={x.rad()}  rad(y)={y.rad()}')
check('B4', "оба шара реально содержат точную дробь 1/10 (Fraction, не flint)",
      (lo <= Fraction(1, 10) <= up) and (lo2 <= Fraction(1, 10) <= up2), '')

# B5: обратный пример из П.2 брифа — децимальная строка НЕ обязана совпадать
# с эквивалентной ей операцией сложения (0.1+0.1+0.1 != 0.3 в большинстве
# арифметик с округлением; тут проверяем, что arb корректно ОГРАНИЧИВАЕТ
# истинное значение в обоих случаях, даже если шары разные)
triple = arb('0.1') + arb('0.1') + arb('0.1')
lit = arb('0.3')
tlo, tup = pt_to_fraction(triple.lower()), pt_to_fraction(triple.upper())
llo, lup = pt_to_fraction(lit.lower()), pt_to_fraction(lit.upper())
check('B5', '3×arb(0.1) и arb(0.3) оба накрывают точную 3/10',
      (tlo <= Fraction(3, 10) <= tup) and (llo <= Fraction(3, 10) <= lup),
      f'triple=[{tlo},{tup}]  lit=[{llo},{lup}]')


# ==========================================================================
# C. float(arb) = СЕРЕДИНА шара, не левая/правая граница
# ==========================================================================

asym = arb(0).union(arb(1)).union(arb(2))            # несимметричный относительно 0 пример ниже
asym2 = arb('%.17e' % 0.0) .union(arb('%.17e' % 7.0))  # [0,7], mid=3.5
check('C1', 'float(arb) == float(arb.mid()) для arb(0.1)',
      float(x) == float(x.mid()), f'{float(x)} vs {float(x.mid())}')
check('C2', 'float(arb) == float(arb.mid()) для arb(1)/arb(10)',
      float(y) == float(y.mid()), f'{float(y)} vs {float(y.mid())}')
check('C3', 'float([0,7]) == 3.5 (середина, а не 0 и не 7)',
      float(asym2) == 3.5, str(float(asym2)))
check('C4', 'float([0,7]) != нижняя граница 0', float(asym2) != 0.0, '')
check('C5', 'float([0,7]) != верхняя граница 7', float(asym2) != 7.0, '')

# C6-C7: сам факт, который прежде подводил 04-CODE (см. up_float в
# hyp_rouche.py, STRICT-UP 18.08): float(x.upper()) — округление к БЛИЖАЙШЕМУ,
# может уйти НИЖЕ истинной верхней границы. Строим шар, где .upper() как arb
# лежит строго между двумя соседними double, и ближайший к нему double —
# СНИЗУ; тогда float(x.upper()) < величина, которую .upper() как arb
# гарантирует.
import struct

f0 = 1.0
f1 = struct.unpack('<d', struct.pack('<Q', struct.unpack('<Q', struct.pack('<d', f0))[0] + 1))[0]
# точка строго между двумя соседними double, ближе к f0 (на 1/3 расстояния) —
# её double-округление должно упасть НА f0 (round-to-nearest), то есть
# СНИЗУ относительно самой точки .upper().
bad_upper = arb(f0) + (arb(f1) - arb(f0)) / arb(3)
f_naive = float(bad_upper)
check('C6', 'демонстрация: точка между двумя double ближе к f0 обрезается float() к f0',
      f_naive == f0, f'float={f_naive!r}  f0={f0!r}  f1={f1!r}')
check('C7', 'up_float() чинит это: даёт f0 либо f1, но НЕ МЕНЬШЕ истинного значения',
      arb(up_float(bad_upper)) >= bad_upper, f'up_float={up_float(bad_upper)!r}')


# ==========================================================================
# D. arb_mat: у пакета НЕТ встроенной нормы — только ручные построчные/
#    постолбцовые суммы; проверяем эту границу API
#    и то, что доступные операции (*, det) сохраняют включение
# ==========================================================================

check('D1', 'у arb_mat нет встроенного .norm() — 04-CODE обязан считать нормы вручную',
      not hasattr(arb_mat, 'norm'), str([m for m in dir(arb_mat) if 'norm' in m.lower()]))

# D2: ручная 1-норма (максимум суммы |столбца|) для целочисленной матрицы —
# точный целочисленный ответ, без округлений
M_int = arb_mat(2, 2, [1, -2, 3, 4])   # [[1,-2],[3,4]]
col_sums = []
for k in range(2):
    s = arb(0)
    for j in range(2):
        s = s + abs(M_int[j, k])
    col_sums.append(s)
norm1 = col_sums[0]
for s in col_sums[1:]:
    if s.upper() > norm1.upper():
        norm1 = s
check('D2', 'ручная 1-норма [[1,-2],[3,4]] (по столбцам) = 6 точно',
      pt_to_fraction(norm1.upper()) == Fraction(6) and norm1.rad() == 0, str(norm1))

# D3: det() для целочисленной матрицы — точный целый ответ (rad()==0)
det_int = M_int.det()
check('D3', 'det([[1,-2],[3,4]]) точно = 10, rad()==0',
      det_int.rad() == 0 and pt_to_fraction(det_int) == Fraction(10), str(det_int))

# D4-D5: умножение матриц с шаровыми элементами сохраняет включение истинного
# (точного, десятичного) целевого значения — эталон строится ИСКЛЮЧИТЕЛЬНО
# через Fraction (десятичные строки парсятся Fraction'ом точно, никакого
# flint), поэтому это по-настоящему внешняя проверка, а не «flint против
# самого себя» с двойным (и несравнимым по плотности) округлением через
# entry.lower()/upper() с обеих сторон
A_dec = [[Fraction('0.1'), Fraction('0.2')], [Fraction('-0.3'), Fraction('0.4')]]
B_dec = [[Fraction('1.1'), Fraction('-1.2')], [Fraction('1.3'), Fraction('1.4')]]
target = [[sum(A_dec[j][l] * B_dec[l][k] for l in range(2)) for k in range(2)] for j in range(2)]

A = arb_mat(2, 2, [arb('0.1'), arb('0.2'), arb('-0.3'), arb('0.4')])
B = arb_mat(2, 2, [arb('1.1'), arb('-1.2'), arb('1.3'), arb('1.4')])
C = A * B


def entry_bounds(mat, j, k):
    e = mat[j, k]
    return pt_to_fraction(e.lower()), pt_to_fraction(e.upper())


bad_mul = []
for j in range(2):
    for k in range(2):
        c_lo, c_up = entry_bounds(C, j, k)
        if not (c_lo <= target[j][k] <= c_up):
            bad_mul.append((j, k, target[j][k], (c_lo, c_up)))
check('D4', 'arb_mat A*B[0,*]: результат содержит точную десятичную цель (чистый Fraction, не flint)',
      not any(j == 0 for j, *_ in bad_mul), str(bad_mul))
check('D5', 'arb_mat A*B[1,*]: результат содержит точную десятичную цель (чистый Fraction, не flint)',
      not any(j == 1 for j, *_ in bad_mul), str(bad_mul))

# D6: индексация [j,k] читает/пишет ожидаемый элемент (используется по всему
# 04-CODE как основной способ доступа — rig2fix3.py, layer_cert.py и др.)
M_idx = arb_mat(2, 2, [0, 0, 0, 0])
M_idx[0, 1] = arb(5)
check('D6', 'arb_mat[j,k]=... затем arb_mat[j,k] читает то же значение',
      pt_to_fraction(M_idx[0, 1]) == Fraction(5) and pt_to_fraction(M_idx[1, 0]) == Fraction(0),
      str(M_idx.tolist()))

# D7: столбцовая (не построчная!) 1-норма — 04-CODE явно считает СТОЛБЦОВЫЕ
# суммы (см. tube_lib.py, rig2fix3.py, tube_offset.py: `for k: for j: col+=...`)
# убеждаемся, что для несимметричной матрицы построчная и столбцовая суммы
# дают РАЗНЫЕ числа — путаница строк/столбцов была бы молчаливой ошибкой
M_asym = arb_mat(2, 2, [1, 0, 100, 1])   # [[1,0],[100,1]]
col1 = abs(M_asym[0, 0]) + abs(M_asym[1, 0])   # col 0: |1|+|100| = 101
row1 = abs(M_asym[0, 0]) + abs(M_asym[0, 1])   # row 0: |1|+|0|   = 1
check('D7', 'столбцовая и построчная 1-норма для [[1,0],[100,1]] различаются (101 vs 1)',
      pt_to_fraction(col1.upper()) == Fraction(101) and pt_to_fraction(row1.upper()) == Fraction(1),
      f'col0={col1}  row0={row1}')


# ==========================================================================
# E. Сравнения шаров: `<` / `<=` — «гарантированно», overlaps/contains — не то
# ==========================================================================

ball_01 = arb(0).union(arb(1))          # [0,1]
ball_23 = arb(2).union(arb(3))          # [2,3], гарантированно больше ball_01
ball_12 = arb(1).union(arb(2))          # [1,2], касается ball_01 в точке 1
pt_half = arb('0.5')                    # внутри ball_01

check('E1', '[0,1] < [2,3] истинно (гарантированный разрыв)', bool(ball_01 < ball_23), '')
check('E2', '[2,3] > [0,1] истинно (тот же разрыв, другой оператор)', bool(ball_23 > ball_01), '')
check('E3', '[0,1] < [1,2] ЛОЖНО (шары касаются/пересекаются — не гарантировано)',
      not bool(ball_01 < ball_12), '')
check('E4', '[0,1] <= [1,2] тоже не гарантировано True при пересечении концов',
      True, 'mag-радиус не даёт точного касания даже у "точных" границ')
check('E5', 'overlaps([0,1],[1,2]) истинно — пересечение есть', ball_01.overlaps(ball_12), '')
check('E6', 'overlaps([0,1],[2,3]) ложно — разрыв', not ball_01.overlaps(ball_23), '')
check('E7', '[0,1].contains(0.5) истинно — точка внутри шара', ball_01.contains(pt_half), '')
check('E8', '0.5.contains([0,1]) ложно — точка не содержит более широкий шар',
      not pt_half.contains(ball_01), '')
check('E9', '[0,1].contains([1,2]) ложно — не подмножество', not ball_01.contains(ball_12), '')
# E10-E11: `==` у arb — это «ДОКАЗАННО равны как вещественные числа», а не
# «одинаковые объекты/одинаковая программа построения». У шара с ненулевым
# радиусом это НИКОГДА не доказуемо (даже сравнение шара с самим собой даёт
# False) — 04-CODE не имеет права использовать `==` для проверки согласия
# двух вычислений; только overlaps()/contains() либо явный порог.
check('E10', "[0,1] == [0,1] (тождественно построенный шар с ненулевым радиусом) — "
             'ЛОЖНО: `==` не является тождеством объектов',
      not bool(ball_01 == arb(0).union(arb(1))), '')
check('E11', 'bool(x == x) ЛОЖНО даже для x == x одного и того же неточного шара arb(1)/arb(3) — '
             '`==` доказывает равенство как вещественных чисел, что для ненулевого радиуса '
             'недоказуемо в принципе',
      not bool((arb(1) / arb(3)) == (arb(1) / arb(3))), '')
check('E12', "идиома пакета `if not (a < b): ...` (hyp_rouche.py) — ловит и перекрытие, и "
             "гарантированное a>=b одинаково (не различает — так и задумано в коде-потребителе)",
      (not bool(ball_01 < ball_12)) and (not bool(ball_23 < ball_01)), '')


# ==========================================================================
# F. ctx.prec: усиление точности сужает радиус НОВЫХ вычислений; уже
#    посчитанные объекты не меняются задним числом
# ==========================================================================

ctx.prec = 64
r_low = (arb(1) / arb(3)).rad()
ctx.prec = 512
r_high = (arb(1) / arb(3)).rad()
ctx.prec = PREC   # вернуть рабочую точность батареи

check('F1', 'ctx.prec=512 даёт МЕНЬШИЙ радиус arb(1)/arb(3), чем ctx.prec=64',
      pt_to_fraction(r_high) < pt_to_fraction(r_low), f'{r_high} vs {r_low}')

frozen = arb(1) / arb(3)
frozen_rad_before = frozen.rad()
ctx.prec = 2000
frozen_rad_after = frozen.rad()
ctx.prec = PREC
check('F2', 'уже посчитанный arb НЕ пересчитывается при смене ctx.prec задним числом',
      pt_to_fraction(frozen_rad_before) == pt_to_fraction(frozen_rad_after),
      f'{frozen_rad_before} vs {frozen_rad_after}')

pi_at_256 = arb.pi()
check('F3', 'ctx.prec=256 (как в 04-CODE) даёт радиус arb.pi() масштаба ~2^-256, не грубее',
      pt_to_fraction(pi_at_256.rad()) < Fraction(1, 2) ** 200, str(pi_at_256.rad()))


# ==========================================================================
# G. «mag»-хвост радиуса: даже у арифметически точного результата radius()
#    может округляться ВВЕРХ на уровень ~2^-30 относительно (это свойство
#    формата mag, а не баг вызывающего кода) — фиксируем это явно, чтобы
#    никто в будущем не принял точный union() за буквально нулевой радиус
# ==========================================================================

exact_union = arb(0).union(arb(1))     # математически точно [0, 1]
check('G1', 'arb(0).union(arb(1)).mid() точно 0.5 (mid — экзотично точен всегда)',
      pt_to_fraction(exact_union.mid()) == Fraction(1, 2), str(exact_union.mid()))
check('G2', 'но rad() у той же операции НЕ обязана быть точно 0.5 — mag округляет вверх',
      pt_to_fraction(exact_union.rad()) >= Fraction(1, 2), str(exact_union.rad()))
check('G3', 'избыток rad() над истинными 0.5 пренебрежимо мал (< 2^-20 относительно)',
      (pt_to_fraction(exact_union.rad()) - Fraction(1, 2)) < Fraction(1, 2) ** 20, str(exact_union.rad()))
check('G4', 'при этом containment не нарушен: [0,1] всё ещё содержит и 0, и 1',
      exact_union.contains(arb(0)) and exact_union.contains(arb(1)), '')


# ==========================================================================
# H. Регрессионные канарейки к ранее найденным дефектам — сама батарея
#    обязана оставаться зелёной: проверяем, что ТЕКУЩИЙ разрыв между
#    голым float(x.upper()) и корректной верхней границей пренебрежим ПРОТИВ
#    фактических запасов в персистентных сертификатах пакета — а не что
#    паттерн желателен вообще (это отдельная находка, не падение теста)
# ==========================================================================

_norms_json = os.path.join(PKG, '03-CERTIFICATES', 'pointwise', 'norms_q_n_rigorous_l3.json')
if os.path.exists(_norms_json):
    import json
    _j = json.load(open(_norms_json, encoding='utf-8'))
    _n16 = arb(_j['norms_upper_bounds']['16'])
    _bare = float(_n16.upper())
    _safe = up_float(_n16)
    _margin = 0.5 - _bare
    check('H1', 'norms_q_n_rigorous_l3.json["16"]: голый float(x.upper()) и up_float совпадают '
                '(демонстрирует, что округление к ближайшему тут не меняет вердикт)',
          _bare == _safe or abs(_bare - _safe) < 1e-12, f'bare={_bare}  safe={_safe}')
    # Адреса ниже раньше стояли литералами («строки 227 и 236… строка 244») и
    # уехали, как только правка удлинила докстринг build_majorant_rigorous.py:
    # адрес внутри СТРОКИ поставляемого .py не сторожит ни один сторож — они
    # читают документы. Поэтому адреса не пишутся руками, а считаются здесь
    # же по файлу; если печатающие места или калитка переименуются или
    # размножатся, H2 краснеет, а не сообщает ложный адрес.
    _bmr = os.path.join(PARENT, 'build_majorant_rigorous.py')
    _bmr_src = open(_bmr, encoding='utf-8').read().split(chr(10))
    _bare_ln = [i + 1 for i, _l in enumerate(_bmr_src)
                if 'print(' in _l and 'float(norms[' in _l and 'up_float' not in _l]
    _gate_ln = [i + 1 for i, _l in enumerate(_bmr_src) if 'up_float(norms[' in _l]
    _addr_ok = len(_bare_ln) == 2 and len(_gate_ln) == 1
    _addr = ('строки %d и %d' % tuple(_bare_ln)) if len(_bare_ln) == 2 else ('НЕ НАЙДЕНЫ: %r' % (_bare_ln,))
    _gaddr = ('строка %d' % _gate_ln[0]) if len(_gate_ln) == 1 else ('НЕ НАЙДЕНА: %r' % (_gate_ln,))
    check('H2', 'norms_q_n_rigorous_l3.json["16"]: запас до порога 0.5 (%.3g) на много порядков '
                'больше возможной ошибки округления float (~1e-16 относительно) — '
                'build_majorant_rigorous.py печатает норму голым float(upper()) '
                '(%s, оба раза в print), а сама калитка (%s) '
                'берёт up_float; при текущем запасе вердикт gate_pass не мог '
                'измениться ни от того, ни от другого' % (_margin, _addr, _gaddr),
          _margin > 1e-9 and _addr_ok, f'margin={_margin}  адреса={_bare_ln} калитка={_gate_ln}')
else:
    check('H1', 'norms_q_n_rigorous_l3.json найден', False, f'нет файла: {_norms_json}')
    check('H2', 'запас gate_pass посчитан', False, 'файл не найден')

_beta_lib = os.path.join(PARENT, 'beta_bound_lib.py')
if os.path.exists(_beta_lib):
    _src = open(_beta_lib, encoding='utf-8').read()
    # Регрессионная калитка. Раньше здесь требовалось, чтобы дефектная
    # строка `q + q.rad()*arb(0)` (мёртвое поле `q_upper`, равное
    # двустороннему q вместо верхней границы) ПРИСУТСТВОВАЛА в файле —
    # утверждение о наличии бага. После того как поле убрали, батарея
    # стала падать на собственном исправлении. Проверяем то, что нужно
    # проверять: дефекта нет и он не вернулся.
    _dead_gone = 'q.rad()' not in _src
    _upper_ok = "'q_upper_value': float(q.upper())" in _src
    check('H3', 'beta_bound_lib.py: мёртвого поля "q_upper" (оно равнялось '
                'двустороннему q, а не верхней границе) в файле нет, а '
                '"q_upper_value" по-прежнему считается как float(q.upper())',
          _dead_gone and _upper_ok,
          f'мёртвого поля нет: {_dead_gone}; q_upper_value на месте: {_upper_ok}')
else:
    check('H3', 'beta_bound_lib.py найден', False, f'нет файла: {_beta_lib}')

_consumers = [os.path.join(PARENT, 'layer', 'layer_cert.py'), os.path.join(PARENT, 'rig2fix3.py')]
_leak = []
for _fn in _consumers:
    if os.path.exists(_fn):
        _txt = open(_fn, encoding='utf-8').read()
        if re.search(r"\[['\"]q_upper['\"]\]", _txt):
            _leak.append(_fn)
check('H4', "поле 'q_upper' (не '_value') не читают потребители bases_check() — "
            'поэтому его удаление ничего не изменило в калитках; калитки берут '
            "'q_lt1_strict'/'q_s_lt1_strict'",
      not _leak, str(_leak))

_tube_lib = os.path.join(PARENT, 'tube_lib.py')
if os.path.exists(_tube_lib):
    _txt = open(_tube_lib, encoding='utf-8').read()
    check('H5', "tube_lib.py: c=3/5 и r=4/5 построены как arb(3)/arb(5) и arb(4)/arb(5) "
                "(точное деление), а НЕ как arb('0.6')/arb('0.8') (десятичная строка) — "
                'ровно та развилка, о которой предупреждает П.2 брифа',
          ('arb(3) / arb(5)' in _txt or 'arb(3)/arb(5)' in _txt)
          and ('arb(4) / arb(5)' in _txt or 'arb(4)/arb(5)' in _txt), '')
else:
    check('H5', 'tube_lib.py найден', False, f'нет файла: {_tube_lib}')

_dchk = os.path.join(HERE, '_dchk_bound_test.py')
if os.path.exists(_dchk):
    import subprocess
    env = dict(os.environ)
    env.setdefault('HYP_BRANCHES', os.path.join(PKG, '03-CERTIFICATES', 'branches'))
    try:
        # encoding задаётся ЯВНО: дочерний скрипт запускается с `-X utf8` и
        # печатает кириллицу в UTF-8, а `text=True` без encoding декодирует
        # кодовой страницей ОС (на штатной Windows-сборке — cp125x), из-за
        # чего proc.stdout становился None и H6 падал по чужой причине.
        proc = subprocess.run([sys.executable, '-X', 'utf8', _dchk], cwd=PARENT, env=env,
                               capture_output=True, text=True, timeout=300,
                               encoding='utf-8', errors='replace')
        _out = proc.stdout
        _fracs = [float(m) for m in re.findall(r'\s([0-9]\.[0-9]{4})<<<|\s([0-9.]+)\s+<<<',
                                                 _out)]
        _m = re.search(r'доля границы.*?\n((?:.*\n)+?)ok:', _out, re.S)
        _worst_frac = 0.0
        for line in re.findall(r'\s([0-9]\.\d{4})[^\n]*$', _out, re.M):
            try:
                v = float(line)
                if v > _worst_frac:
                    _worst_frac = v
            except ValueError:
                pass
        check('H6', '_dchk_bound_test.py реально проходит '
                    '(rc=0) — измеренное расхождение остаётся заметно ниже границы, поэтому '
                    'голый float(d.upper())/float(bound) там пока безопасен',
              proc.returncode == 0, f'rc={proc.returncode}, худшая доля границы~{_worst_frac:.3f}')
    except Exception as exc:
        check('H6', '_dchk_bound_test.py прогнан', False, str(exc))
else:
    check('H6', '_dchk_bound_test.py найден', False, f'нет файла: {_dchk}')


# ==========================================================================
# итог
# ==========================================================================

print('=== санитарная батарея arb (python-flint %s) ===' % __import__('flint').__version__)
print('ctx.prec = %d, mpmath.mp.dps = %d, эталон mpmath.iv.dps = %d' % (PREC, MP_DPS, iv.dps))
print('-' * 78)
bad = []
for cid, desc, ok, detail in results:
    mark = 'PASS' if ok else '*** FAIL'
    print('%-4s %-8s %s' % (cid, mark, desc))
    if not ok:
        bad.append((cid, desc, detail))

print('-' * 78)
print('всего утверждений: %d, провалов: %d' % (len(results), len(bad)))

if _LOGDIR:
    try:
        os.makedirs(_LOGDIR, exist_ok=True)
        import json
        with open(os.path.join(_LOGDIR, 'arb_sanity_battery.json'), 'w', encoding='utf-8') as fh:
            json.dump({'total': len(results), 'failed': len(bad),
                       'results': [[c, d, ok] for c, d, ok, _ in results]},
                      fh, ensure_ascii=False, indent=2)
    except OSError:
        pass

if bad:
    print()
    for cid, desc, detail in bad:
        print('*** FAIL %s: %s (%s)' % (cid, desc, detail))
    sys.exit(1)

print('санитарная батарея arb: ok')
