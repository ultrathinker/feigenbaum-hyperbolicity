# -*- coding: utf-8 -*-
"""
_dchk_check.py — что на самом деле меряет встроенная самопроверка dchk.

Была заявлена ошибку на единицу в степени R. Проверка соглашения:

  rig_lib.point_eval:      Ftilde[j] = F_poly[j+1] * R^(j+1)
  op_sig.py:152            Ftilde_slices[i][j] = Fsl[j+1] * R^(j+1)   -- то же
  rig2fix*.py (самопроверка) сравнивает mine[k] с F_ref[k+1] * R^k    -- на R меньше

Если это так, dchk меряет не расхождение модели с движком, а примерно
(1-R)/R * ||F~||_1, то есть просто масштаб невязки. Здесь считаются ОБА
варианта плюс ||F~||_1, чтобы увидеть, что именно доминирует.

Побочно проверяется, что вывод годится для охранного критерия:
он безопасен только если ошибочный dchk БОЛЬШЕ настоящего расхождения.
"""
import os, sys, time
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)          # движок лежит уровнем выше
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)

import rig_lib as rl
import tube_lib as tl
import op_sig as osig
import fp_lib as fl
from flint import arb, ctx

ctx.prec = 256
NP, R = tl.N_p, tl.r_arb

ELL0, W, M, D = 2.025, 0.05, 6, 8
BRANCH_DIR = os.environ.get('HYP_BRANCHES',
    os.path.join(os.path.dirname(PARENT), '03-CERTIFICATES', 'branches'))
z = np.load(os.path.join(BRANCH_DIR, 'branch_g00.npz'))
c_a = z['c_a']

print('бокс ell0=%.4f w=%.3f m=%d D=%d' % (ELL0, W, M, D), flush=True)
tay = np.zeros((M + 1, NP + 1))
for k in range(NP + 1):
    tay[:, k] = fl.cheb_to_taylor(c_a[:M + 1, k], W)
P0 = [arb(float(x)) for x in tay[0]]
P0[0] = arb(1)

t0 = time.time()
ops = osig.build_operator_sigma(P0, tay, M, ELL0, W, D, prec=256)
print('sigma-оператор собран за %.1f с' % (time.time() - t0), flush=True)

sv = 0.9 * (W / 2)
P_sv = rl.P_at(c_a, M, arb('0.9'))
ell_pt = arb('%.17e' % ELL0) + arb('%.17e' % sv)
F_ref = tl.compute_F_poly(P_sv, ell_pt)

mine = [arb(0)] * NP
for i, sl_ in enumerate(ops['Ftilde_slices']):
    for k in range(NP):
        mine[k] = mine[k] + sl_[k] * (arb('%.17e' % sv) ** i)

d_old = arb(0)      # как в коде: F_ref[k+1] * R^k
d_new = arb(0)      # согласованно с point_eval: F_ref[k+1] * R^(k+1)
nF = arb(0)         # ||F~||_1 движка = sum_k |F_{k+1}| R^(k+1)
for k in range(NP):
    d_old = d_old + abs(mine[k] - F_ref[k + 1] * (R ** k))
    d_new = d_new + abs(mine[k] - F_ref[k + 1] * (R ** (k + 1)))
    nF = nF + abs(F_ref[k + 1]) * (R ** (k + 1))

print()
print('  dchk как в коде   (R^k)      = %.6e' % float(d_old))
print('  dchk согласованно (R^(k+1))  = %.6e' % float(d_new))
print('  ||F~||_1 движка              = %.6e' % float(nF))
print('  (1-R)/R * ||F~||_1           = %.6e   <- чем должен быть dchk при ошибке'
      % float(nF * (1 - R) / R))
print()
print('  отношение старый/новый       = %.3e' % (float(d_old) / float(d_new)))
print('  старый / ((1-R)/R*||F~||)    = %.6f  <- близко к 1 => старый меряет масштаб невязки'
      % (float(d_old) / float(nF * (1 - R) / R)))
print()
safe = float(d_old) > float(d_new)
print('  охранный критерий: ошибочный dchk %s настоящего расхождения => %s'
      % ('БОЛЬШЕ' if safe else 'МЕНЬШЕ',
         'приёмка была КОНСЕРВАТИВНА, вывод не пострадал'
         if safe else 'приёмка была НЕ консервативна, пересматривать'))

# Вердикт считался, но код возврата был всегда 0.
import sys as _sys
if not safe:
    print('*** FAIL: охранный критерий не консервативен — пересматривать')
    _sys.exit(1)
print('DCHK-СВЕРКА: ok (охранный критерий консервативен)')
