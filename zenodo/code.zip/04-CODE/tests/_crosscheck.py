# -*- coding: utf-8 -*-
"""
_crosscheck.py — независимая проверка двух несущих величин трубки.

Смысл: строгие оценки `R` и `‖Δ‖` считаются интервально и обязаны быть
ВЕРХНИМИ границами. Значит выборочный максимум тех же величин, посчитанный
совсем другим способом (float, numpy, много точек), обязан быть НЕ БОЛЬШЕ.
Если выборка превысит строгую оценку — строгая оценка неверна.
Если строгая оценка окажется на порядки больше выборочной — она верна, но
рыхлая, и это тоже полезно знать.

Проверка умеет провалиться: то же сравнение делается с намеренно испорченной
величиной (R, делённое на 3) — там выборка обязана превысить.

Боксы берутся из $HYP_TUBE_OUT, по умолчанию — 03-CERTIFICATES/tube.
При пустой выборке тест ПАДАЕТ, а не проходит: проверка без данных
неотличима от успешной проверки.

Запуск: python _crosscheck.py [сколько боксов] [точек по ℓ] [точек по кругу]
"""
import os, sys, json, glob, random
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)          # 04-CODE — движок лежит здесь
sys.path.insert(0, PARENT)

import rig_lib as rl
import tube_lib as tl
from flint import arb, ctx
import hyp_rouche as hr

ctx.prec = 256
NP = tl.N_p


def dt_float(c_a, m, e0b, wb, ell):
    x = 2.0 * (ell - e0b) / wb
    P = rl.P_at(c_a, m, arb('%.17e' % x))
    pkg = tl.build_pkg_fast(P, arb('%.17e' % ell))
    DT = hr.dt_from_pkg(pkg)
    return np.array([[float(DT[j][k]) for k in range(NP)] for j in range(NP)])


def col1(M):
    return float(np.max(np.sum(np.abs(M), axis=0)))


def main():
    nbox = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    npts = int(sys.argv[2]) if len(sys.argv) > 2 else 21
    ncir = int(sys.argv[3]) if len(sys.argv) > 3 else 720
    # nbox=0 -> пустая выборка -> bad=0 -> ложный PASS без единой проверки
    # (тот самый класс, от которого выше защищает `if not recs`, но она
    # ловит пустой recs, не нулевой nbox). npts<2 -> деление на
    # (npts-1)=0 либо dmax остаётся 0.0 -> ложное ok_d. ncir<1 -> rmax
    # остаётся 0.0 -> ложное ok_r.
    if nbox < 1:
        raise SystemExit('nbox должен быть >= 1 (получено %d)' % nbox)
    if npts < 2:
        raise SystemExit('npts должен быть >= 2 (получено %d)' % npts)
    if ncir < 1:
        raise SystemExit('ncir должен быть >= 1 (получено %d)' % ncir)

    tube = os.environ.get('HYP_TUBE_OUT') or os.path.join(
        os.path.dirname(PARENT), '03-CERTIFICATES', 'tube')
    files = sorted(glob.glob(os.path.join(tube, 'box_*.json')))
    recs = [json.load(open(f, encoding='utf-8')) for f in files]
    recs = [r for r in recs if r.get('pass')]
    # Тест, который проходит на пустой выборке, не проверяет ничего —
    # именно так он и молчал, пока путь был захардкожен в tests/tube_out.
    if not recs:
        print('НЕТ БОКСОВ в %s — тест не может ничего проверить' % tube)
        return 2
    random.seed(20260818)
    sample = random.sample(recs, min(nbox, len(recs)))
    sample.sort(key=lambda r: r['ell0'])

    print('%-9s %-9s %-12s %-12s %-7s %-12s %-12s %-7s'
          % ('бокс', 'ell0', '‖Δ‖ выборка', '‖Δ‖ строго', 'ок?',
             'R выборка', 'R строго', 'ок?'))
    bad = 0
    for r in sample:
        c_a, m, e0b, wb, _ = hr.load_box(r['ell0'], 0.0)
        DT0 = dt_float(c_a, m, e0b, wb, r['ell0'])

        # --- ‖Δ‖: максимум по точкам бокса ---
        dmax = 0.0
        for i in range(npts):
            ell = r['lo'] + (r['hi'] - r['lo']) * i / (npts - 1)
            dmax = max(dmax, col1(dt_float(c_a, m, e0b, wb, ell) - DT0))

        # --- R: максимум по окружности (float-обратный) ---
        rmax = 0.0
        I = np.eye(NP)
        for i in range(ncir):
            z = np.exp(2j * np.pi * i / ncir)
            rmax = max(rmax, col1(np.linalg.inv(DT0 - z * I)))

        ok_d = dmax <= r['delta_norm']
        ok_r = rmax <= r['R']
        bad += (not ok_d) + (not ok_r)
        print('%-9s %-9.5f %-12.6e %-12.6e %-7s %-12.6f %-12.6f %-7s'
              % (r['tag'], r['ell0'], dmax, r['delta_norm'],
                 'да' if ok_d else 'НЕТ', rmax, r['R'],
                 'да' if ok_r else 'НЕТ'))
        print('           отношение строгая/выборка:  ‖Δ‖ ×%.3f   R ×%.3f'
              % (r['delta_norm'] / dmax if dmax else float('inf'),
                 r['R'] / rmax if rmax else float('inf')))
        # контроль: испорченная оценка обязана провалиться
        if not (rmax <= r['R'] / 3.0):
            pass
        else:
            print('           ⚠ контроль не сработал: выборка не ловит даже R/3')
            bad += 1

    print('\nнарушений: %d' % bad)
    return 0 if bad == 0 else 2


if __name__ == '__main__':
    sys.exit(main())
