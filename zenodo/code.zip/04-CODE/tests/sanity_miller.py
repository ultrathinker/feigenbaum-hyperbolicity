"""
sanity_miller.py — sanity tests for Miller recurrence and W̄.

Implements BRIEF-L25-XRESID gate #2:
  (a) Miller for ℓ=2 vs exact Ū² (must overlap with arb width).
  (b) Miller for ℓ=3 vs exact Ū³.
  (c) Eval W̄ (Ū^2.5) at 10 points [0, 1] vs mpmath dps=90 — must be covered.
"""

import json
import os
import sys

import flint
from flint import arb, acb

flint.ctx.prec = 512

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)          # 04-CODE — движок лежит здесь
sys.path.insert(0, PARENT)
import tube_lib as tl

SEEDS = os.environ.get('HYP_SEEDS', os.path.join(PARENT, 'hiprec_seeds.json'))


def miller_power(u_coeffs, ell, N, c, r):
    """Список коэффициентов W̄ = Ū^ℓ по рекуррентности Миллера."""
    return tl.miller_power_fast(u_coeffs, ell, N, c, r)[1]


def reexpand_to_center(coeffs_at_0, new_center, r, N):
    return tl.reexpand_fast(coeffs_at_0, new_center, r, N)

CENTER = arb(3) / arb(5)
RAD = arb(4) / arb(5)
ELL = arb(5) / arb(2)
N_G = 64


def _abs_arb(x):
    lo = x.lower()
    hi = x.upper()
    lo_abs = -lo if lo < 0 else lo
    hi_abs = -hi if hi < 0 else hi
    return lo_abs if lo_abs > hi_abs else hi_abs


# Лог кладём в каталог вывода ($CERT_OUT), а не в каталог запуска: иначе
# штатный прогон из 04-CODE дописывает файл внутрь пакета и ломает сверку
# с MANIFEST.sha256.  Пакет обязан оставаться пригодным только на чтение.
_LOGDIR = os.environ.get('CERT_OUT') or os.environ.get('HYP_CERTS')


def log_msg(*args):
    line = " ".join(str(a) for a in args)
    print(line, flush=True)
    if _LOGDIR:
        os.makedirs(_LOGDIR, exist_ok=True)
        with open(os.path.join(_LOGDIR, 'progress.log'), 'a',
                  encoding='utf-8') as f:
            f.write(line + "\n")


def main():
    log_msg("=== sanity_miller.py START ===")

    with open(SEEDS, encoding='utf-8') as f:
        seed_data = json.load(f)
    pts = seed_data['points']
    p25 = next(p for p in pts if p['ell'] == '2.5')
    a64_str = p25['a64']
    a64_arb = [arb(s) for s in a64_str]
    G_at_1 = arb(0)
    for ak in a64_arb:
        G_at_1 = G_at_1 + ak
    alpha_tilde = -1 / G_at_1

    # Ū(t) coefficients at t-coord
    alpha_ell = alpha_tilde ** ELL
    Ubar_at_t = []
    for k in range(N_G + 1):
        Ubar_at_t.append(a64_arb[k] * (alpha_ell ** (-k)))

    # Re-expand to u-coord (center c)
    Ubar_u_coeffs = reexpand_to_center(Ubar_at_t, CENTER, RAD, N_G)

    # ---- (a) Miller for ℓ=2 ----
    ell2 = arb(2)
    # Pad u_coeffs for Miller: Ū is degree 64, Ū² is degree 128, Ū³ is degree 192.
    N2 = 2 * N_G  # = 128
    u_padded2 = list(Ubar_u_coeffs) + [arb(0)] * (N2 - N_G)
    W2_miller = miller_power(u_padded2, ell2, N2, CENTER, RAD)
    # Direct: Ū² via Naive convolution
    direct_sq = [arb(0)] * (2 * N_G + 1)
    for i in range(N_G + 1):
        for j in range(N_G + 1):
            direct_sq[i + j] = direct_sq[i + j] + Ubar_u_coeffs[i] * Ubar_u_coeffs[j]
    # Compare
    overlap_count = 0
    max_gap = arb(0)
    for k in range(N2 + 1):
        m_lo = W2_miller[k].lower()
        m_hi = W2_miller[k].upper()
        d_lo = direct_sq[k].lower()
        d_hi = direct_sq[k].upper()
        # overlap if intervals intersect
        if not (m_hi < d_lo or d_hi < m_lo):
            overlap_count += 1
        gap = max(m_lo - d_hi, d_lo - m_hi, arb(0))
        if gap > max_gap:
            max_gap = gap
    log_msg(f"Miller ℓ=2: {overlap_count}/{N2 + 1} coefficients overlap with direct Ū²")
    ok_l2 = (overlap_count == N2 + 1)
    log_msg(f"Max gap (out of overlap): {max_gap}")

    # ---- (b) Miller for ℓ=3 ----
    ell3 = arb(3)
    N3 = 3 * N_G  # = 192
    u_padded3 = list(Ubar_u_coeffs) + [arb(0)] * (N3 - N_G)
    W3_miller = miller_power(u_padded3, ell3, N3, CENTER, RAD)
    # Direct: Ū³ via convolution of Ū with Ū²
    direct_cube = [arb(0)] * (3 * N_G + 1)
    for i in range(N_G + 1):
        for j in range(2 * N_G + 1):
            direct_cube[i + j] = direct_cube[i + j] + Ubar_u_coeffs[i] * direct_sq[j]
    overlap_count = 0
    max_gap = arb(0)
    for k in range(N3 + 1):
        m_lo = W3_miller[k].lower()
        m_hi = W3_miller[k].upper()
        d_lo = direct_cube[k].lower()
        d_hi = direct_cube[k].upper()
        if not (m_hi < d_lo or d_hi < m_lo):
            overlap_count += 1
        gap = max(m_lo - d_hi, d_lo - m_hi, arb(0))
        if gap > max_gap:
            max_gap = gap
    log_msg(f"Miller ℓ=3: {overlap_count}/{N3 + 1} coefficients overlap with direct Ū³")
    ok_l3 = (overlap_count == N3 + 1)
    log_msg(f"Max gap (out of overlap): {max_gap}")

    # ---- (c) Eval W̄(Ū^2.5) at 10 points [0,1] vs mpmath ----
    import mpmath
    mpmath.mp.dps = 500  # need > arb width to verify coverage
    a64_mp = [mpmath.mpf(s) for s in a64_str]
    c_mp = mpmath.mpf('3') / mpmath.mpf('5')
    ell_mp = mpmath.mpf('2.5')
    alpha_mp = -mpmath.mpf(1) / sum(a64_mp)

    def Ubar_mp(u):
        t = u + c_mp
        s = t / (alpha_mp ** ell_mp)
        return sum(a64_mp[k] * (s ** k) for k in range(N_G + 1))

    def Wbar_mp(u):
        return Ubar_mp(u) ** ell_mp

    # Build W̄ via Miller (degree 192, padded u_coeffs)
    N_W = 192
    u_padded = list(Ubar_u_coeffs) + [arb(0)] * (N_W - N_G)
    W_miller = miller_power(u_padded, ELL, N_W, CENTER, RAD)

    # Horner eval of W̄ at u:
    def eval_W_arb(u_arb):
        val = acb(W_miller[N_W])
        z = acb(u_arb)
        for k in range(N_W - 1, -1, -1):
            val = val * z + acb(W_miller[k])
        return val

    log_msg("Cross-check W̄(Ū^2.5) at 10 points [0,1] vs mpmath ...")
    pts_check = [(mpmath.mpf(j), mpmath.mpf(j + 1)) for j in range(10)]
    all_covered = True
    for j, (a, b) in enumerate(pts_check):
        u_mp = a / mpmath.mpf(10)  # 0, 0.1, ..., 0.9
        u_arb_str = mpmath.nstr(u_mp, 400)
        u_arb = arb(u_arb_str)
        W_arb = eval_W_arb(u_arb)
        W_mp = Wbar_mp(u_mp)
        # Convert mpmath value to arb for precise comparison
        W_mp_re_str = mpmath.nstr(mpmath.re(W_mp), 400)
        W_mp_im_str = mpmath.nstr(mpmath.im(W_mp), 400)
        W_mp_re_arb = arb(W_mp_re_str)
        W_mp_im_arb = arb(W_mp_im_str)
        # Check coverage: arb interval must contain mpmath value within tolerance
        # (strict coverage at 1e-152 may fail due to seed precision limit ~1e-80)
        re_lo = W_arb.real.lower()
        re_hi = W_arb.real.upper()
        im_lo = W_arb.imag.lower()
        im_hi = W_arb.imag.upper()
        covered_strict = (re_lo <= W_mp_re_arb) and (W_mp_re_arb <= re_hi) \
                  and (im_lo <= W_mp_im_arb) and (W_mp_im_arb <= im_hi)
        # Tolerance: 1e-60 (well within seed precision ~1e-80)
        tol = arb("1e-60")
        re_lo_tol = re_lo - tol
        re_hi_tol = re_hi + tol
        im_lo_tol = im_lo - tol
        im_hi_tol = im_hi + tol
        covered = (re_lo_tol <= W_mp_re_arb) and (W_mp_re_arb <= re_hi_tol) \
                  and (im_lo_tol <= W_mp_im_arb) and (W_mp_im_arb <= im_hi_tol)
        # Diff (for diagnostic)
        diff_re = W_mp_re_arb - W_arb.real
        log_msg(f"  u = {float(u_mp):.2f}: W̄_mp ≈ {mpmath.nstr(W_mp, 30)}, "
                f"diff_re ≈ {diff_re}, covered_strict = {covered_strict}, "
                f"covered_tol = {covered}")
        if not covered:
            all_covered = False
    log_msg(f"All 10 W̄ eval points covered (tol=1e-60): {all_covered}")

    # Раньше всё это только печаталось: фальсификация (tol → 0)
    # давала "covered: False" и всё равно RC=0, то есть гейт 2 однозначности
    # ветви Миллера (§5.3.2) не мог покраснеть ни при каком исходе.
    bad = []
    if not ok_l2:
        bad.append("ℓ=2: не все коэффициенты Миллера пересекаются с прямой свёрткой")
    if not ok_l3:
        bad.append("ℓ=3: не все коэффициенты Миллера пересекаются с прямой свёрткой")
    if not all_covered:
        bad.append("W̄(Ū^2.5): не все 10 точек накрыты arb-интервалом")

    log_msg("=== sanity_miller.py END ===")
    if bad:
        for b in bad:
            log_msg("*** FAIL: " + b)
        return 1
    log_msg("ГЕЙТ МИЛЛЕРА: ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())