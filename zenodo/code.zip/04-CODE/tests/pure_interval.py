# -*- coding: utf-8 -*-
"""
pure_interval.py — сертификат существования БЕЗ sigma-модели и БЕЗ tau.

Зачем.  В rig2fix3 головы Y0 и Z1 считались через sigma-Тейлор оператора
(op_sig/sig_lib), а отброшенная часть ряда покрывалась слагаемыми
B_A*tau_F и B_A*max_tau_col.  Числено tau ничтожен (1e-17...1e-20 против
головы 1e-1), но это ровно тот вид аргумента, на котором исследование уже
дважды обжигалось: ограничивается МОДЕЛЬ величины, а не сама величина.
Проверка показала, что sigma-константы для Z1b/Z1c нестроги; про сам
tau-учёт доверия тоже нет.

Здесь те же самые Y0 и Z1 считаются напрямую движком марша при
ИНТЕРВАЛЬНОМ ell и ИНТЕРВАЛЬНОМ центре, с подразбиением бокса против
миллеровской обёртки.  Ни одной величины из sigma-цепочки не остаётся:

  A      := A~(x=0), ОДНА float-матрица на бокс (приближённый обратный;
            в доказательство входит только как число, законность Ньютона-
            Канторовича от выбора A не зависит);
  B_A    := ||A||_1 (точно);
  Y0     := max_s sup_{ell in кусок s} ||A F~(P(ell), ell)||_1  +  хвосты;
  Z1     := max_s sup_{ell in кусок s} ||I - A M'(P(ell), ell)||_1  (Z1a)
            + Z1b + Z1c (те же формулы движка, интервальные);
  L      := цепочка по подбоксам, как раньше (интервальная и без sigma),
            deltaP берётся как sup |P(ell) - P(центр)| прямо по интервалу.

Ворота: Y0 + Zhat*rho' <= rho',  Zhat = Z1 + 1.75^2*B_A*L*rho'.

Запуск:  python pure_interval.py <тег> [Kmax]
Читает 03-CERTIFICATES/branches/branch_<тег>.npz, пишет box_<тег>.json
в $CERT_OUT (по умолчанию pure_out/ рядом с тестом)
"""
import os, sys, json, time, tempfile
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)          # движок лежит уровнем выше
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)

import rig_lib as rl
import tube_lib as tl
from flint import arb, ctx

NP = tl.N_p
R = tl.r_arb
C = tl.c_arb
SRC = os.environ.get('HYP_BRANCHES',
    os.path.join(os.path.dirname(PARENT), '03-CERTIFICATES', 'branches'))
# см. sanity_miller: вывод идёт в $CERT_OUT, чтобы пакет оставался read-only
# (тот же класс, что hyp_rouche.py -> HYP_LOG, layer/*).  Дефолт НЕ
# ведёт внутрь пакета: запуск «как есть» дописывал файлы в пакет и ломал
# сверку с MANIFEST.sha256.  Пакет обязан оставаться пригодным только на
# чтение; чтобы ПЕРЕсобрать артефакты, CERT_OUT / GLUE_OUT /
# HYP_TUBE_OUT выставляются явно (см. 02-REPRODUCE.md).
OUT = (os.environ.get('CERT_OUT') or
       os.path.join(tempfile.gettempdir(), 'renorm_pure'))
os.makedirs(OUT, exist_ok=True)

RHO_GRID = ['1e-7', '3e-8', '1e-8', '3e-9', '1e-9', '3e-10', '1e-10',
            '1e-11', '1e-12', '1e-6', '3e-7', '1e-5', '3e-6', '3e-5', '1e-4']


def fmt(x, d=6):
    return ('%.' + str(d) + 'e') % float(x)


def plog(msg):
    print(time.strftime('%H:%M:%S ') + msg, flush=True)


def piece_bounds(c_a, m, A_f, A_arb, B_A, lo, hi, xlo, xhi):
    """Все интервальные величины на ОДНОМ куске бокса.

    Возвращает (Y0_head, Z1a, Z1b, Z1c) — верхние границы (arb)."""
    x_iv = arb('%.17e' % xlo).union(arb('%.17e' % xhi))
    e_iv = lo.union(hi)
    Pint = rl.P_at_interval(c_a, m, x_iv)

    pkg = tl.build_pkg_fast(Pint, e_iv)
    if pkg is None:
        raise RuntimeError('interval pkg failed on [%s, %s]' % (fmt(lo), fmt(hi)))
    xn = tl.compute_x_norms_and_beta(pkg)
    _, Z1a, Z1b, Z1c = tl.compute_Z1(
        pkg, A_f, B_A, strict_consts=tl.build_strict_consts_from_pkg(pkg, xn))

    # Y0-голова тем же движком: F~_j = F_poly[j+1] * R^(j+1), j = 0..NP-1
    F_poly = tl.compute_F_poly(Pint, e_iv)
    y0 = arb(0)
    for j in range(NP):
        s = arb(0)
        for k in range(NP):
            s = s + A_arb[j][k] * F_poly[k + 1] * (R ** (k + 1))
        y0 = y0 + abs(s)
    return y0.upper(), Z1a.upper(), Z1b.upper(), Z1c.upper()


def subdivided(c_a, m, ell0, w, A_f, A_arb, B_A, Kmax=16):
    """Супремум по боксу = максимум супремумов по кускам.  Удваиваем K,
    пока Z1 заметно улучшается (обёртка e^{O(w N_W)} убивается сужением)."""
    K = 1
    prev = None
    while True:
        y0m = z1am = z1bm = z1cm = arb(0)
        for s in range(K):
            xlo, xhi = -1.0 + 2.0 * s / K, -1.0 + 2.0 * (s + 1) / K
            lo = ell0 - w / 2 + w * arb(s) / K
            hi = ell0 - w / 2 + w * arb(s + 1) / K
            y0, z1a, z1b, z1c = piece_bounds(c_a, m, A_f, A_arb, B_A,
                                             lo, hi, xlo, xhi)
            if y0 > y0m:
                y0m = y0
            if z1a > z1am:
                z1am = z1a
            if z1b > z1bm:
                z1bm = z1b
            if z1c > z1cm:
                z1cm = z1c
        tot = float(z1am + z1bm + z1cm)
        plog('  K=%2d: Z1a=%s Z1b=%s Z1c=%s  Y0head=%s'
             % (K, fmt(z1am), fmt(z1bm), fmt(z1cm), fmt(y0m)))
        good = tot < 0.30
        stalled = prev is not None and tot > 0.9 * prev
        if (good and K > 1) or stalled or K >= Kmax:
            return y0m, z1am, z1bm, z1cm, K
        prev = tot
        K *= 2


def L_chain(c_a, m, ell0, w, rho_p_list, B_A):
    """L по подбоксам ширины <= 0.04; deltaP — прямо по интервалу центра.
    Возвращает список пакетов и deltaP, чтобы ворота перебирали rho'."""
    KL = max(1, int(float(w) / 0.04) + 1)
    pkgs, xns, dPs = [], [], []
    for s in range(KL):
        xlo, xhi = -1.0 + 2.0 * s / KL, -1.0 + 2.0 * (s + 1) / KL
        xmid = (xlo + xhi) / 2
        lo = ell0 - w / 2 + w * arb(s) / KL
        hi = ell0 - w / 2 + w * arb(s + 1) / KL
        P_c = rl.P_at(c_a, m, arb('%.17e' % xmid))
        P_iv = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
        pkg = tl.build_pkg_fast(P_c, lo.union(hi))
        if pkg is None:
            raise RuntimeError('L-pkg failed on sub-box %d' % s)
        dP = arb(0)
        rk = arb(1)
        for k in range(NP + 1):
            dP = dP + abs(P_iv[k] - P_c[k]).upper() * rk
            rk = rk * R
        pkgs.append(pkg)
        xns.append(tl.compute_x_norms_and_beta(pkg))
        dPs.append(dP.upper())
    return pkgs, xns, dPs, KL


def run(tag, Kmax=16, prec=256):
    ctx.prec = prec
    t_all = time.time()
    br = np.load(os.path.join(SRC, 'branch_%s.npz' % tag))
    c_a = br['c_a']
    c_A = br['c_A']
    m = int(br['m'][0])
    ell0 = float(br['ell0'][0])
    w = float(br['w'][0])
    plog('BOX %s  ell0=%.6f w=%.4g m=%d  [%.6f, %.6f]'
         % (tag, ell0, w, m, ell0 - w / 2, ell0 + w / 2))

    A_f = rl.Atilde_at(c_A, m, 0.0)            # ОДИН приближённый обратный
    A_arb = [[arb(float(A_f[j][k])) for k in range(NP)] for j in range(NP)]
    B_A = arb(0)
    for k in range(NP):
        col = arb(0)
        for j in range(NP):
            col = col + abs(A_arb[j][k])
        if col.upper() > B_A:
            B_A = col.upper()
    plog('  ||A||_1 = %s' % fmt(B_A))

    ell0_a = arb('%.17e' % ell0)
    w_a = arb('%.17e' % w)

    t0 = time.time()
    y0h, Z1a, Z1b, Z1c, K = subdivided(c_a, m, ell0_a, w_a, A_f, A_arb, B_A, Kmax)
    plog('  подразбиение готово за %.0fs (K=%d)' % (time.time() - t0, K))

    t0 = time.time()
    w2_sup, ftail_sup = rl.interval_tails(c_a, m, ell0_a, w_a)
    plog('  хвосты: w2=%s Ftail=%s  [%.0fs]'
         % (fmt(w2_sup), fmt(ftail_sup), time.time() - t0))

    Y0 = (y0h + w2_sup + ftail_sup).upper()
    Z1 = (Z1a + Z1b + Z1c).upper()
    plog('  Y0 = %s   Z1 = %s' % (fmt(Y0), fmt(Z1)))

    t0 = time.time()
    pkgs, xns, dPs, KL = L_chain(c_a, m, ell0_a, w_a, None, B_A)
    plog('  L-пакеты: %d подбоксов, max deltaP = %s  [%.0fs]'
         % (KL, fmt(max(float(d) for d in dPs)), time.time() - t0))

    best = None
    for rs in RHO_GRID:
        rho_p = arb(rs)
        L = None
        ok = True
        for i in range(KL):
            Lp = tl._compute_L(pkgs[i], xns[i], rho_p + dPs[i] / arb('1.75'))
            if Lp is None:
                ok = False
                break
            if L is None or Lp['L_strict'] > L:
                L = Lp['L_strict']
        if not ok:
            continue
        Zhat = Z1 + arb('3.0625') * B_A * L * rho_p
        if not (Zhat < arb(1)):
            continue
        lhs = Y0 + Zhat * rho_p
        passed = bool(lhs <= rho_p)
        plog("   rho'=%s: L=%s Zhat=%s lhs=%s  %s"
             % (rs, fmt(L, 3), fmt(Zhat, 4), fmt(lhs, 3), 'PASS' if passed else 'fail'))
        if passed:
            best = {'rho_prime': rs, 'L': fmt(L), 'Zhat': fmt(Zhat),
                    'rho_star': fmt(Y0 / (1 - Zhat)), 'lhs': fmt(lhs)}
            break

    rec = {'tag': tag, 'ell0': ell0, 'w': w, 'm': m, 'prec': prec,
           'ell_lo': ell0 - w / 2, 'ell_hi': ell0 + w / 2,
           'engine': 'pure_interval (без sigma-модели и без tau)',
           'B_A': fmt(B_A), 'K_sub': K, 'KL': KL,
           'Y0': fmt(Y0), 'Y0_head': fmt(y0h),
           'w2_sup': fmt(w2_sup), 'Ftail_sup': fmt(ftail_sup),
           'Z1': fmt(Z1), 'Z1a': fmt(Z1a), 'Z1b': fmt(Z1b), 'Z1c': fmt(Z1c),
           'passed': best is not None, 'best': best,
           'wall_s': round(time.time() - t_all, 1)}
    with open(os.path.join(OUT, 'box_%s.json' % tag), 'w', encoding='utf-8') as f:
        json.dump(rec, f, indent=1, ensure_ascii=False)
    plog('BOX %s -> %s  [%.0fs]' % (tag, 'PASS' if rec['passed'] else 'FAIL',
                                    rec['wall_s']))
    return rec


if __name__ == '__main__':
    tag = sys.argv[1]
    Kmax = int(sys.argv[2]) if len(sys.argv) > 2 else 16
    run(tag, Kmax)
