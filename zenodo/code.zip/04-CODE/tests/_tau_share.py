# -*- coding: utf-8 -*-
"""
_tau_share.py — какая доля Y0 и Z1 держится на τ-бухгалтерии sig_lib.

После перехода на rig2fix3 σ-путь выброшен из хвоста Y0 и из Z1b/Z1c — там
теперь интервальные величины. Но Z1_head и Y0_head по-прежнему строятся из
σ-МОДЕЛИ оператора (Fslices/Mslices), а отброшенная масса этой модели
описывается величинами tau_F и taus_cols из sig_lib, дефект которых известен
(занижение в 2.7-4.4 раза; формула не того класса).

Значит честный вопрос не «есть ли зависимость от τ» (она есть), а «во сколько
раз должна вырасти τ, чтобы ворота перестали проходить». Здесь это меряется
на трёх представительных боксах: нижний конец, середина, верхний конец.
"""
import os, sys, time, json, tempfile
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)          # движок лежит уровнем выше
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)
BRANCH_DIR = os.environ.get('HYP_BRANCHES',
    os.path.join(os.path.dirname(PARENT), '03-CERTIFICATES', 'branches'))

import rig_lib as rl
import tube_lib as tl
import fp_lib as fl
import op_sig as osig
from flint import arb, ctx

ctx.prec = 256
NP, R, C = tl.N_p, tl.r_arb, tl.c_arb

BOXES = [('g00', 2.025, 0.05, 6, 8), ('ganchor', 3.0, 0.05, 6, 8),
         ('g43', 3.96, 0.05, 6, 8)]
RHO = 1e-7

print('%-9s %-9s %-11s %-11s %-11s %-11s %-11s' %
      ('бокс', 'ell0', 'Y0_head', 'Y0_tau', 'Z1_head', 'Z1_tau', 'Z1_tau/Z1'), flush=True)

# Таблица §3.7 («ворота ломаются при росте τ в ... раз») до сих пор
# существовала только в stdout этой диагностики: ни артефакта, ни сторожа.
# Теперь пишем протокол — его стережёт _numbers_check.
_REC = {'task': 'tau_share', 'rho_prime': RHO, 'boxes': {}}

for tag, ell0, w, m, D in BOXES:
    z = np.load(os.path.join(BRANCH_DIR, 'branch_%s.npz' % tag))
    c_a, c_A = z['c_a'], z['c_A']
    tay = np.zeros((m + 1, NP + 1))
    for k in range(NP + 1):
        tay[:, k] = fl.cheb_to_taylor(c_a[:m + 1, k], w)
    P0 = [arb(float(x)) for x in tay[0]]
    P0[0] = arb(1)
    ops = osig.build_operator_sigma(P0, tay, m, ell0, w, D, prec=256)

    tay_A = np.zeros((m + 1, NP, NP))
    for j in range(NP):
        for k in range(NP):
            tay_A[:, j, k] = fl.cheb_to_taylor(c_A[:m + 1, j, k], w)
    colsums = np.zeros(NP)
    for p in range(m + 1):
        colsums += np.sum(np.abs(tay_A[p]), axis=0) * (w / 2) ** p
    B_A = float(np.max(colsums))

    # Y0_head: sum_i ||A~_p F_l||_1 * smax^i  (как в rig2fix3)
    Fsl = [np.array([float(x) for x in s]) for s in ops['Ftilde_slices']]
    tot = m + D
    v1 = np.zeros(tot + 1)
    for p in range(m + 1):
        for l in range(D + 1):
            v1[p + l] += float(np.sum(np.abs(tay_A[p] @ Fsl[l])))
    Y0_head = sum(v1[i] * (w / 2) ** i for i in range(tot + 1))
    Y0_tau = B_A * float(ops['tau_F'])

    # Z1_head: max_k sum_i colnorm_i[k] * smax^i
    Msl = []
    for l in range(D + 1):
        M_l = np.zeros((NP, NP))
        for k in range(NP):
            col = ops['Mprime_slices'][l][k]
            for j in range(NP):
                M_l[j, k] = float(col[j])
        Msl.append(M_l)
    Zc = np.zeros((tot + 1, NP))
    for p in range(m + 1):
        for l in range(D + 1):
            Zpl = tay_A[p] @ Msl[l]
            if p + l == 0:
                Zpl = np.eye(NP) - Zpl
            Zc[p + l] += np.sum(np.abs(Zpl), axis=0)
    percol = np.zeros(NP)
    for i in range(tot + 1):
        percol += Zc[i] * (w / 2) ** i
    Z1_head = float(np.max(percol))
    Z1_tau = B_A * max(float(t) for t in ops['taus_cols'])
    Z1_tot = Z1_head + Z1_tau
    print('%-9s %-9.4f %-11.4e %-11.4e %-11.4e %-11.4e %-11.4e'
          % (tag, ell0, Y0_head, Y0_tau, Z1_head, Z1_tau, Z1_tau / Z1_tot), flush=True)

    # во сколько раз должна вырасти tau, чтобы ворота сломались
    # ворота: Y0 + Zhat*rho' <= rho',  Zhat ~ Z1 (+ малый член)
    # запас по Z1: (1 - ...) ; ищем множитель f: Y0 + f*Y0_tau + (Z1+f*Z1_tau)*rho' = rho'
    slack = RHO - (Y0_head + Y0_tau) - Z1_tot * RHO
    denom = Y0_tau + Z1_tau * RHO
    f = slack / denom if denom > 0 else float('inf')
    print('           запас: ворота ломаются при росте τ в %.3e раз' % (1.0 + f), flush=True)
    _REC['boxes'][tag] = {'ell0': ell0, 'Y0_head': Y0_head, 'Y0_tau': Y0_tau,
                          'Z1_head': Z1_head, 'Z1_tau': Z1_tau,
                          'Z1_tau_over_Z1': Z1_tau / Z1_tot,
                          'tau_break_factor': 1.0 + f}

_out = os.environ.get('CERT_OUT',
                      os.path.join(tempfile.gettempdir(), 'renorm_out'))
os.makedirs(_out, exist_ok=True)
with open(os.path.join(_out, 'tau_share.json'), 'w', encoding='utf-8') as _f:
    json.dump(_REC, _f, ensure_ascii=False, indent=1)
print('протокол: %s' % os.path.join(_out, 'tau_share.json'))
