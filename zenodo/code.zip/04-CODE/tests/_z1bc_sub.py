# -*- coding: utf-8 -*-
"""
_z1bc_sub.py — снять миллеровскую обёртку в Z1b/Z1c подразбиением бокса.

Интервальный Z1bc считает пакет оператора при ИНТЕРВАЛЬНОМ центре по всему
боксу сразу, и ширина раздувается как e^{O(w·N_W)}. Отсюда быстрый рост Z1c
по ℓ: на поставленных боксах g34→g35→g36 множитель около трёх на шаг 0.045.

Но supremum по боксу = максимум супремумов по его кускам. Значит бокс можно
разрезать на K частей, посчитать Z1b/Z1c на каждой (там центр уже узкий,
обёртка мала) и взять максимум. Это законно и не меняет утверждения.

Здесь измеряется, как Z1c падает с ростом K на самом тяжёлом из посчитанных
боксов.
"""
import os, sys, time
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)          # движок лежит уровнем выше
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)
BRANCH_DIR = os.environ.get('HYP_BRANCHES',
    os.path.join(os.path.dirname(PARENT), '03-CERTIFICATES', 'branches'))

import rig_lib as rl
import tube_lib as tl
import fp_lib as fl
from flint import arb, ctx

ctx.prec = 256
NP = tl.N_p


def z1bc_sub(c_a, m, ell0, w, A_mid, B_A, K):
    """max по K подынтервалам бокса — законная верхняя граница по всему боксу."""
    b_max, c_max = arb(0), arb(0)
    for s in range(K):
        xlo, xhi = -1.0 + 2.0 * s / K, -1.0 + 2.0 * (s + 1) / K
        Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
        elo = ell0 - w / 2 + w * arb(s) / K
        ehi = ell0 - w / 2 + w * arb(s + 1) / K
        pkg = tl.build_pkg_fast(Pint, elo.union(ehi))
        if pkg is None:
            raise RuntimeError('pkg failed on sub %d/%d' % (s, K))
        xn = tl.compute_x_norms_and_beta(pkg)
        _, _, Z1b, Z1c = tl.compute_Z1(
            pkg, A_mid, B_A, strict_consts=tl.build_strict_consts_from_pkg(pkg, xn))
        if Z1b.upper() > b_max:
            b_max = Z1b.upper()
        if Z1c.upper() > c_max:
            c_max = Z1c.upper()
    return b_max, c_max


TAG, ELL0, W, M = 'g35', 3.60, 0.05, 6
z = np.load(os.path.join(BRANCH_DIR, 'branch_%s.npz' % TAG))
c_a = z['c_a']
print('бокс %s: ell0=%.4f w=%.3f m=%d' % (TAG, ELL0, W, M), flush=True)

# Ã(0) и B_A — как в сертификате
tay_A = np.zeros((M + 1, NP, NP))
c_A = z['c_A']
for j in range(NP):
    for k in range(NP):
        tay_A[:, j, k] = fl.cheb_to_taylor(c_A[:M + 1, j, k], W)
colsums = np.zeros(NP)
for p in range(M + 1):
    colsums += np.sum(np.abs(tay_A[p]), axis=0) * (W / 2) ** p
B_A = arb(float(np.max(colsums))).upper()
A_mid = tay_A[0]
print('B_A = %.6f' % float(B_A), flush=True)

ell0_a, w_a = arb('%.17e' % ELL0), arb('%.17e' % W)
print()
print('%-4s %-12s %-12s %-8s' % ('K', 'Z1b', 'Z1c', 'сек'))
for K in (1, 2, 4, 8, 16):
    t0 = time.time()
    try:
        b, c = z1bc_sub(c_a, M, ell0_a, w_a, A_mid, B_A, K)
        print('%-4d %-12.4e %-12.4e %-8.1f' % (K, float(b), float(c), time.time() - t0),
              flush=True)
    except Exception as e:
        print('%-4d ОШИБКА %s' % (K, str(e)[:60]), flush=True)
