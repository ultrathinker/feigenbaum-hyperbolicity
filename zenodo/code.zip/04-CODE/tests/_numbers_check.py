# -*- coding: utf-8 -*-
"""
_numbers_check.py — сверка чисел статьи и тождеств внутри json-сертификатов.

Старый тест брал округлённую строку из json и искал её в тексте статьи — то
есть проверял не верность json, а совпадение статьи с json. Этого мало:
статья могла повторять устаревшее значение, и тест бы проходил. Так было
поймано два минимума (хвост Y0 и extra), которые разъехались с реальными
диапазонами.

Новый тест проверяет восемь вещей (A–H, разделы вывода):

 A. **Оба конца** каждого диапазона из таблиц §3.6 и §4.8 статьи — диапазоны
    ПАРСЯТСЯ ИЗ ТЕКСТА СТАТЬИ и сверяются против фактических min/max в
    сертификатах. Допуск на округление: верхняя граница в статье не меньше
    сертификата (статья округляет вверх), нижняя — не больше (статья
    округляет вниз). 5 % в каждую сторону — грубое округление до 2 значащих.

 B. **Вычисляемые тождества** между полями json — например, что
    `rho_star_b·(1−Ẑ) ≈ Y0 + B_A·d_chk`, `guard_lhs ≈ B_A·dchk`,
    `guard_rhs ≈ Y0/2`, `rho_star_X = 1.75·rho_star_b` —
    вычисляются, а не ищутся в статье.

 C. **Спот-проверка** ключевых скаляров статьи: и вхождение строки, и —
    с круга 8 — направление того же литерала против факта. Одна лишь
    проверка вхождения пришпиливает статью к УСТАРЕВШЕМУ литералу и
    проходит именно потому, что статья не поправлена.

 D. **§6 (перенос с центра P(ℓ) на решение G*(ℓ))** — раньше не покрывалось
    вовсе, и именно поэтому там разъехались числа (найдено в четвёртом круге
    рецензирования): `L ≤ 4.26·10⁴`, `ρ*_b ≤ 4.85·10⁻¹³` и
    `1.75·ρ*_b = ρ*_X ≤ 8.49·10⁻¹³` (а1), возмущение `L·1.75·10⁻⁷ < 7.5·10⁻³`,
    итог §6.6.2 `max_бокс (B_A/(1−Z1))/(1−(B_A/(1−Z1))·L·1.75·10⁻⁷) = 4.292 < 4.30`
    (считается ПО КАЖДОМУ боксу со своими B_A, Z1, L — не по глобальным
    максимумам разных величин, которые достигаются на разных боксах), и
    `κ_G` — сверяется с ЖИВЫМ выводом `tests/_kappaG_bound.py` (который сам
    в этом круге правок не редактируется) против одной централизованной
    константы-порога.

 E. **§5.2.1 и приложение A (Q★, ℓ=3)** — `‖Q★¹⁶‖₁ ≤ 0.2905947` против
    `pointwise/q_perturb_patch.json`, и явная проверка ТОЖДЕСТВА
    `ρ(Q★) ≤ ‖Q★¹⁶‖₁^(1/16)`: считается корень 16-й степени из напечатанной
    в статье нормы и сверяется, что заявленная статьёй `ρ(Q★)` от него не
    меньше. Это ровно тот баг, что уже был в пакете: статья печатала `0.9255`,
    а `0.290595^(1/16) = 0.925668` — то есть «верхняя граница» была МЕНЬШЕ
    выводимого из неё же числа, неравенство было ложным.

 E2. **§5.1.2/§5.3.3 — `1.75·ρ★` теорем 1 и 3** .
    Та же болезнь, что в E: `1.75·rho_star_new` (`fixL_result.json`, ℓ=3) и
    `1.75·rho_star.mid` (`kant_l25.json`, ℓ=5/2) печатались округлением к
    БЛИЖАЙШЕМУ, а не вверх — `1.99×10⁻⁴²` и `2.73×10⁻³³` при истинных
    `1.9924936…×10⁻⁴²` и `2.7300004…×10⁻³³`.

 F. **Направление округления во ВСЕХ документах пакета** (рекурсивно по
    подпапкам). Разделы A и D разбирают таблицы и §6 статьи; проза с
    ФОРМУЛИРОВКАМИ теорем не покрывалась ничем, и там пережили проверку три
    ложные границы: `Ẑ ≤ 0.1691` и `Ẑ ≤ 0.163` при факте 0.170473 и
    `sup‖(DT₀−z)⁻¹‖₁ ≤ 3.796` при факте 3.7960642604. Проверяются 14
    величин; голое `ρ* ≤ …` без индекса `_b`/`_X` валит само по себе.

 G. **Ссылки документов на файлы пакета.** `COVERAGE.md` ссылался на
    `11-PARAM-SWEEP.md` как на носитель утверждения о покрытии всего
    отрезка — файла в пакете нет вовсе. Битая ссылка читается читателем
    как «проверено в другом месте» и гасит вопрос, поэтому каждая ссылка
    обязана либо разрешаться в пакете, либо стоять в списке заведомо
    внешних с причиной.

 H. **Словарь парных обозначений** . Самый живучий класс дефекта
    кампании — величина/приём поправлены в одном документе и остались
    старыми в другом (`β̂`, `ρ*` под двумя именами, `L` в §6, `X₀→𝒜`,
    `ρ′` вместо `ρ*_b`). Раздел
    не универсален — не каждое вхождение старого символа ошибочно (в §2
    явно разрешено сокращение `G*(ℓ)∈X₀`), поэтому здесь два уровня:
    БЕЗУСЛОВНЫЙ провал для паттернов, у которых нет законного прочтения
    (шар `B_{X₀}` с ненулевым центром — `X₀` линейно, у него не может быть
    такого шара в принципе; символ ворот `ρ′` рядом с формулой `extra`,
    которая всегда считается через `ρ*_b`), и ИНФОРМАЦИОННЫЙ список для
    остальных известных пар — на провал теста не влияет, только печатает
    все вхождения для ручного/агентского разбора.

Числа §6/§5.2.1 (D, E) достаются из текста статьи ТОЧЕЧНЫМИ регэкспами по
уникальному контексту формулы, а не построчным разбором markdown-таблиц по
`|`: сводная таблица допущений (а1, а2, а4) содержит LaTeX-нормы `\\|...\\|`,
неэкранированные для markdown, — наивный `line.split('|')` на этих строках
даёт лишние «ячейки» и путает разбор (одна из двух граблей, на которых тест
уже спотыкался; см. также `parse_art_num` — вторая, на мантиссах вида
«8.10·10⁻¹⁴»).

Тест, который проходит на любом тексте, ничего не проверяет: парсер статьи
переписывался так, чтобы он падал на расхождениях типа «минимум 3.15·10⁻³³
вместо 2.9535·10⁻³³» (статья округлила минимум ВВЕРХ, против правила).

Запуск:  python tests/_numbers_check.py
"""
import os, sys, json, glob, re, math, subprocess
# _math был связан внутри блока I18 и использовался в блоке J1: если I18
# не отработал (таблица не найдена), J1 падал NameError вместо вердикта.
import math as _math
from decimal import (Decimal as _Dec, ROUND_CEILING as _ROUND_CEILING,
                     ROUND_FLOOR as _ROUND_FLOOR)

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))          # корень пакета
CERTS = os.environ.get('HYP_CERTS', os.path.join(PKG, '03-CERTIFICATES', 'existence'))
TUBE = os.environ.get('HYP_TUBE_OUT', os.path.join(PKG, '03-CERTIFICATES', 'tube'))
OFFS = os.environ.get('HYP_OFFSETS', os.path.join(TUBE, 'offsets.json'))
ART = os.environ.get('HYP_ARTICLE', os.path.join(PKG, '01-ARTICLE.md'))
POINTWISE = os.environ.get('HYP_POINTWISE', os.path.join(PKG, '03-CERTIFICATES', 'pointwise'))
# радиус шара единственности теоремы A (Theorem A), константа §6.4.3/§6.6.2 —
# те же 1.75e-7, что используются в tests/_kappaG_bound.py (RHO_UNIQ).
RHO_UNIQUENESS = 1.75e-7


def parse_arb(s):
    if isinstance(s, (int, float)):
        return float(s)
    t = str(s).strip()
    m = re.search(r'([+\-]?[0-9]+(?:\.[0-9]+)?(?:[eE][+\-]?[0-9]+)?)', t)
    return float(m.group(1)) if m else float(t)


def parse_art_num(s):
    """Числа из статьи вида '5.06·10⁻¹³' → 5.06e-13.

    Разбор идёт с ХВОСТА: степень — это завершающая группа надстрочных
    знаков, и только она переводится в обычные цифры. Прежняя версия
    заменяла в строке все вхождения '10' на 'e' и ломалась на мантиссах,
    кончающихся на «10» ('8.10·10⁻¹⁴' → '8.ee-14').
    """
    sup = {'⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4',
           '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9',
           '⁺': '+', '⁻': '-'}
    t = s.replace('·', '').replace('−', '-').replace('–', '-')
    t = t.replace(' ', '').replace(' ', '').strip()
    m = re.search(r'([' + ''.join(sup) + r']+)$', t)
    if m:
        exp = ''.join(sup[ch] for ch in m.group(1))
        base = t[:m.start()]
        if base.endswith('10'):
            base = base[:-2]
        if base in ('', '-', '+'):
            base += '1'
        return float(base) * (10.0 ** int(exp))
    if '10^' in t:
        base, exp = t.split('10^', 1)
        if base in ('', '-', '+'):
            base += '1'
        return float(base) * (10.0 ** int(exp))
    return float(t)

def rng(vals):
    vals = list(vals)
    return min(vals), max(vals)


bad = 0
# Счётчик ВЫПОЛНЕННЫХ проверок. Без него ворот был fail-open —
# если обнулить список проверяемых объектов (мутация «пустые кортежи»), скрипт
# печатал «ИТОГО: 0 провалов» и выходил с 0, потому что пустая проверка была
# неотличима от успешной. Порог CHECKS_MIN ниже стережёт именно это.
checks = 0
# Порог — ХРАПОВИК, а не круглое число «на всякий случай».  Он стоял на 300 при
# фактических 683: молчаливая потеря сотни проверок (сломанный шаблон, съеденная
# ветка, исчезнувший файл) не уронила бы ворот, и «0 провалов» по-прежнему
# ничего бы не значило.  Держать вплотную под фактическим: любое падение счёта
# — сигнал, что часть проверок не запустилась.  Подняв число проверок, поднять
# и порог.
CHECKS_MIN = 790


def report(label, ok, details=''):
    global bad, checks
    checks += 1
    if not ok:
        bad += 1
    print('%-58s  %s   %s' % (label, 'ok' if ok else '*** FAIL ***', details))


# === Загрузка сертификатов ===
ex = sorted(glob.glob(os.path.join(CERTS, 'box_*.json')))
ex_loaded = [json.load(open(f, encoding='utf-8')) for f in ex]
ex_passed = [j for j in ex_loaded if j.get('passed')]

tb = sorted(glob.glob(os.path.join(TUBE, 'box_*.json')))
tb_loaded = [json.load(open(f, encoding='utf-8')) for f in tb]
tb_passed = [j for j in tb_loaded if j.get('pass')]
offs = json.load(open(OFFS, encoding='utf-8'))

# Фактические диапазоны из json — это истина.
truth = {
    # 'label used to find row in article': (fact_min, fact_max)
    'Y0':                                 rng([float(j['Y0']) for j in ex_passed]),
    'Z1':                                 rng([float(j['Z1']) for j in ex_passed]),
    'Ẑ':                                  rng([float(j['best']['Zhat']) for j in ex_passed]),
    'хвост Y0':                           rng([float(j['Ftail_sup']) for j in ex_passed]),
    'Z1b':                                rng([float(j['Z1b']) for j in ex_passed]),
    'Z1c':                                rng([float(j['Z1c']) for j in ex_passed]),
    'τ_F':                                rng([float(j['tau_F']) for j in ex_passed]),
    'L':                                  rng([float(j['best']['L']) for j in ex_passed]),
    'ρ*_b':                               rng([parse_arb(j['best'].get('rho_star_b', j['best']['rho_star'])) for j in ex_passed]),
    'ρ*_X':                               rng([parse_arb(j['best'].get('rho_star_X', j['best']['rho_star'])) for j in ex_passed]),
    'охранный критерий B_A·d_chk / (Y0/2)': rng([float(j['B_A'])*float(j['dchk'])/(float(j['Y0'])/2) for j in ex_passed]),
    'U_min':                              rng([float(j['lemma1_U_min']) for j in ex_passed]),
    'd_chk':                              rng([parse_arb(j['dchk']) for j in ex_passed]),
    'min Re U':                           rng([float(j['lemma1_ReU_min_R']) for j in ex_passed]),
    'q':                                  rng([float(j['bases_q']) for j in ex_passed]),
    'q_s':                                rng([float(j['bases_q_s']) for j in ex_passed]),
    'R':                                  rng([float(t['R']) for t in tb_passed]),
    '‖Δ‖':                                rng([float(t['delta_norm']) for t in tb_passed]),
    'R·‖Δ‖':                              rng([float(t['prod']) for t in tb_passed]),
    'extra':                              rng([v['extra'] for v in offs.values()]),
    '‖C‖':                                rng([v['C_norm'] for v in offs.values()]),
    '‖[B;D]‖':                            rng([v['BD_norm'] for v in offs.values()]),
}


# === Парсим строки таблиц §3.6 и §4.8 из статьи ===
art_text = open(ART, encoding='utf-8').read()


def parse_table_rows(text, marker_starts):
    """Извлекает строки таблиц, начинающиеся с одной из подстрок в marker_starts.
    На одну строку — один матч: самый длинный маркер, начинающий строку с
    позиции 0; если такого нет, самый ранний матч."""
    candidates = []     # (marker, line, mn, mx)
    markers = list(set(marker_starts))
    for line in text.splitlines():
        if not line.startswith('|'):
            continue
        cells = [c.strip().strip('`') for c in line.strip('|').split('|')]
        if len(cells) < 3:
            continue
        first = cells[0]
        try:
            mn = parse_art_num(cells[1])
            mx = parse_art_num(cells[2])
        except ValueError:
            continue
        # Шаг 1: ищем маркеры, начинающие строку с позиции 0. Среди них —
        # самый длинный.
        starts = [mk for mk in markers
                  if first.startswith(mk)
                  and (len(first) == len(mk)
                       or not (first[len(mk)].isalnum() or first[len(mk)] == '_'))]
        if starts:
            best = max(starts, key=len)
            candidates.append((best, first, mn, mx))
            continue
        # Шаг 2: нет матчей с начала — берём самый ранний по позиции
        # (на случай, когда маркер встроен в формулу внутри ячейки).
        earliest = None
        for mk in markers:
            for m in re.finditer(re.escape(mk), first):
                s = m.start()
                e = m.end()
                left_ok = (s == 0) or not (first[s-1].isalnum() or first[s-1] == '_')
                right_ok = (e == len(first)) or not (first[e].isalnum() or first[e] == '_')
                if left_ok and right_ok:
                    if earliest is None or s < earliest[1]:
                        earliest = (mk, s, mn, mx)
                    break
        if earliest is not None:
            candidates.append((earliest[0], first, earliest[2], earliest[3]))
    # Каждый маркер — берём первое вхождение.
    out = {}
    for marker, first, mn, mx in candidates:
        if marker not in out:
            out[marker] = (mn, mx)
    return out


# Парсим строки §3.6.
art36 = parse_table_rows(art_text, [
    'Y0', 'Z1', 'Ẑ', 'хвост Y0', 'Z1b', 'Z1c', 'τ_F', 'L',
    'ρ*_b', 'ρ*_X', 'd_chk', 'min Re U',
    'охранный критерий', 'U_min', 'q', 'q_s',
])
art48 = parse_table_rows(art_text, [
    'R', '‖Δ‖', 'R·‖Δ‖', 'extra', '‖C‖', '‖[B;D]‖',
])

# Нормализуем ключи.
def key_norm(k):
    k = k.strip().rstrip(',')
    # 'Y0 ' и 'Y0' различимы только по тому, что идёт после числа
    return k.rstrip()


print('=== A. ОБА КОНЦА ДИАПАЗОНОВ ИЗ §3.6 И §4.8 ===')
print('Правило: lo_статья ≤ факт.min   и   факт.max ≤ hi_статья')
print('   (направление буквальное, без допуска — STRICT-DIR, см. ниже)')
print('-'*100)

# Префиксы в статье могут чуть-чуть отличаться от меток truth, маппим вручную.
keys36 = [
    ('Y0',         'Y0'),
    ('Z1',         'Z1'),
    ('Ẑ',          'Ẑ'),
    ('хвост Y0',   'хвост Y0'),
    ('Z1b',        'Z1b'),
    ('Z1c',        'Z1c'),
    ('τ_F',        'τ_F'),
    ('L',          'L'),
    ('ρ*_b',       'ρ*_b'),
    ('ρ*_X',       'ρ*_X'),
    ('d_chk',      'd_chk'),
    ('min Re U',   'min Re U'),
    ('охранный',   'охранный критерий B_A·d_chk / (Y0/2)'),
    ('U_min',      'U_min'),
    ('q',          'q'),
    ('q_s',        'q_s'),
]
keys48 = [
    ('R',          'R'),
    ('‖Δ‖',        '‖Δ‖'),
    ('R·‖Δ‖',      'R·‖Δ‖'),
    ('extra',      'extra'),
    ('‖C‖',        '‖C‖'),
    ('‖[B;D]‖',    '‖[B;D]‖'),
]

for art_prefix, truth_key in keys36 + keys48:
    f_min, fact_max = truth[truth_key]
    # Поиск ключа в art36 или art48, где ключ начинается с art_prefix.
    pool = art36 if any(k.startswith(art_prefix) for k in art36) else art48
    found = [k for k in pool if k.startswith(art_prefix)]
    if not found:
        report(art_prefix, False, 'СТРОКА НЕ НАЙДЕНА В СТАТЬЕ')
        continue
    art_key = found[0]
    a_lo, a_hi = pool[art_key]
    base_min = max(abs(f_min), 1e-30)
    base_max = max(abs(fact_max), 1e-30)
    # STRICT-DIR (18.08): было `f_min * 1.05` / `fact_max * 0.95`, то есть
    # тест разрешал напечатать мажоранту НИЖЕ факта на 5 %.  Ровно так в
    # статью и попали `q <= 0.991` при факте 0.99107 и ещё пять таких же.
    # Направление теперь буквальное: наружу можно сколько угодно, внутрь —
    # ни на ulp.
    ok_lo = a_lo <= f_min
    ok_hi = fact_max <= a_hi
    details = '[%.3e, %.3e] vs статья [%.3e, %.3e]' % (f_min, fact_max, a_lo, a_hi)
    report(art_key[:55], ok_lo and ok_hi, details)

    # Проверки выше — только НАПРАВЛЕНИЕ:
    # наружу можно сколько угодно.  Поэтому устаревший нижний конец τ_F
    # (`3.60·10⁻¹⁹` при факте `3.980460·10⁻¹⁹`, промах 10 %) проходил молча:
    # он безопасен, но не является минимумом.  А таблица озаглавлена
    # «диапазоны по всем 46 боксам», то есть её концы обязаны ДОСТИГАТЬСЯ,
    # иначе это не диапазон, а свободное утверждение.  Допуск 5 % — заведомо
    # шире округления до трёх значащих цифр (≤0.5 %), которым напечатаны все
    # строки таблицы, и заведомо у́же промахов вроде этого.
    if ok_lo and f_min > 0:
        report(art_key[:45] + ' — нижний конец достигается',
               a_lo >= f_min * 0.95,
               'статья %.4e, факт.min %.4e (промах %.1f %%)'
               % (a_lo, f_min, (f_min - a_lo) / f_min * 100))
    if ok_hi and fact_max > 0:
        report(art_key[:45] + ' — верхний конец достигается',
               a_hi <= fact_max * 1.05,
               'статья %.4e, факт.max %.4e (промах %.1f %%)'
               % (a_hi, fact_max, (a_hi - fact_max) / fact_max * 100))


# «полный тест worst» (R_tot·(‖Δ‖+extra+хвост), tube_accept.py) НИГДЕ не
# лежит полем в json — считается ЖИВЫМ прогоном tube_accept.py, у него в
# stdout только 4 знака после запятой, а сравнение направления нужно против
# ТОЧНОГО факта. Вычисляется здесь, ДО раздела F, чтобы обе проверки (F —
# по всем .md, C — спот по статье) пользовались одним и тем же живым фактом,
# а не гоняли tube_accept.py дважды.
try:
    # tube_accept.py по умолчанию (без env) ищет сертификаты в СВОЁМ
    # `tube_out` рядом с собой, а не в `PKG/03-CERTIFICATES/tube`, где их
    # ищет этот тест — окружение обязано передаваться явно, а не наследоваться
    # молча (при запуске `python tests/_numbers_check.py` без обвязки
    # verify_pkg.sh HYP_* не установлены вовсе, и подпроцесс тихо находит
    # 0 сертификатов).
    _ta_env = dict(os.environ)
    _ta_env['HYP_TUBE_OUT'] = TUBE
    _ta_env['HYP_OFFSETS'] = OFFS
    _ta_env.setdefault('HYP_BRANCHES', os.path.join(PKG, '03-CERTIFICATES', 'branches'))
    _ta_env['PYTHONIOENCODING'] = 'utf-8'
    ta_proc = subprocess.run(
        [sys.executable, os.path.join(HERE, os.pardir, 'tube_accept.py')],
        capture_output=True, text=True, encoding='utf-8', errors='replace',
        cwd=os.path.join(HERE, os.pardir), env=_ta_env, timeout=600)
    # Код возврата ОБЯЗАТЕЛЕН к проверке. Раньше отсюда брали только число из
    # stdout, а `returncode` не читали — при том что в двух других местах
    # этого же файла коды возврата подпроцессов читаются. Порча одного бокса
    # трубки (`delta_norm` = 0.279707, опубликованный максимум §4.8) даёт
    # `tube_accept.py` код 2 и «ПРИЁМКА: НЕ ПРОЙДЕНА», а этот ворот в тот же
    # момент печатал «0 провалов из 684»: испорченный сертификат проходил
    # главную числовую приёмку целиком.
    if ta_proc.returncode != 0:
        report('tube_accept.py вернул 0', False,
               'код %d; приёмка трубки НЕ ПРОЙДЕНА, и числа ниже опираются '
               'на её вывод: %s' % (ta_proc.returncode,
                                    '; '.join(l.strip() for l in
                                              (ta_proc.stdout or '').splitlines()
                                              if 'НЕ ПРОШЁЛ' in l
                                              or 'ПРИЁМКА' in l)[:300]))
    m_ta = re.search(r'R_tot·\(‖Δ‖\+extra\+хвост\)\s*=\s*([0-9.]+)\s*\(точно:\s*([0-9.]+)\)', ta_proc.stdout or '')
    _full_test_worst_fact = float(m_ta.group(2)) if m_ta else None
    if _full_test_worst_fact is None:
        report('живой прогон tube_accept.py дал разбираемый вывод', False,
               'строка "R_tot·(...)  = ..." не найдена в stdout')
    else:
        # Короткая форма раньше попадала в НЕиспользуемую группу: сверялось
        # только «точно», а направление округления печати не сверялось ничем.
        # Статья описывает эту печать словами, и однажды описание отстало от
        # кода на круг (печать «к ближайшему» против фактического ВВЕРХ).
        _short_txt = m_ta.group(1)
        _dec_short = _Dec(_short_txt)
        _dec_exact = _Dec(m_ta.group(2))
        _q = _Dec(1).scaleb(-(len(_short_txt.split('.')[1])
                              if '.' in _short_txt else 0))
        _up = _dec_exact.quantize(_q, rounding=_ROUND_CEILING)
        report('короткая форма полного теста печатается с округлением ВВЕРХ',
               _dec_short == _up,
               'напечатано %s, вверх от %s даёт %s'
               % (_short_txt, m_ta.group(2), _up))
        report('короткая форма — мажоранта точного значения',
               _dec_short >= _dec_exact,
               'напечатано %s ≥ точного %s' % (_short_txt, m_ta.group(2)))
except Exception as e:
    _full_test_worst_fact = None
    report('живой прогон tube_accept.py завершился', False, 'ошибка: %r' % e)
truth['_full_test_worst'] = (0.0, _full_test_worst_fact) if _full_test_worst_fact is not None else (0.0, 1e99)


print()
print('=== F. НАПРАВЛЕНИЕ ОКРУГЛЕНИЯ ВО ВСЕХ ДОКУМЕНТАХ ПАКЕТА ===')
print('-' * 100)
# Раздел A сверяет только 01-ARTICLE.md.  Опубликованные границы, однако,
# повторяются в README и в маршруте воспроизведения, и там они уже один раз
# разъехались со статьёй.  Здесь тот же вопрос задаётся КАЖДОМУ .md пакета:
# найденная в тексте граница обязана лежать снаружи факта.
#
# Устаревшее `0.9918` в `02-REPRODUCE.md` (дважды) —
# статья давно поправлена на `0.9919`, а REPRODUCE — нет; раздел F этого не
# ловил, потому что фразы вида «полный тест ... N» не было в списке правил.
import glob as _glob
import re as _re

# Факты берутся из уже собранного `truth` (min, max) — один источник истины
# на весь тест: раздел A сверяет по нему таблицы, раздел F — прозу.
# Граница §4.7 `sup_{|z|=1}‖(A − z)⁻¹‖₁ ≤ 3.279` — резольвента
# ЯКОРНОЙ матрицы A при ℓ=3 — не покрывалась ни одним разделом: правило `R`
# матчит только форму с `DT₀`, а другой формы у него нет.  Порча 3.279 -> 3.27
# проходила молча.  Факт берём из протокола якоря, а не из литерала статьи;
# по всем вхождениям `R_rig = <число>` берём МАКСИМУМ — для проверки «вверх»
# это консервативно.
_ANCHOR_MD = os.path.join(PKG, '03-CERTIFICATES', 'anchor-inertia',
                          'REPORT-ANCHOR.md')
try:
    _anch_txt = open(_ANCHOR_MD, encoding='utf-8').read()
    _anch_vals = [float(x) for x in
                  _re.findall(r'R_rig\s*=\s*([0-9]+\.[0-9]+)', _anch_txt)]
    _R_A_fact = max(_anch_vals) if _anch_vals else None
except OSError:
    _R_A_fact = None
if _R_A_fact is None:
    # `_rel` определяется ниже, в разделе F — здесь путь пишем прямо
    report('источник R_A: 03-CERTIFICATES/anchor-inertia/REPORT-ANCHOR.md', False,
           'не удалось прочитать R_rig — граница ≤3.279 осталась непроверенной')

_facts = {
    'rho_b': truth['ρ*_b'][1],
    'rho_X': truth['ρ*_X'][1],
    'U_min': truth['U_min'][0],
    'q': truth['q'][1],
    'q_s': truth['q_s'][1],
    # --- величины, которые печатаются в ФОРМУЛИРОВКАХ теорем ---
    'Zhat': truth['Ẑ'][1],
    'Y0': truth['Y0'][1],
    'Z1': truth['Z1'][1],
    'd_chk': truth['d_chk'][1],
    'L': truth['L'][1],
    'Delta': truth['‖Δ‖'][1],
    'R': truth['R'][1],
    'R_A': _R_A_fact,
    'RD': truth['R·‖Δ‖'][1],
    'extra': truth['extra'][1],
    # --- «полный тест worst» — устаревшее значение в 02-REPRODUCE.md ---
    'full_test': truth['_full_test_worst'][1] if truth['_full_test_worst'][1] < 1e99 else None,
}

# (имя, регексп с одной группой-числом, множитель, направление)
#   'up'   — напечатанное обязано быть НЕ МЕНЬШЕ факта (мажоранта)
#   'down' — напечатанное обязано быть НЕ БОЛЬШЕ факта (миноранта)
#
# Раньше здесь стояло пять величин, и раздел A разбирал только
# таблицы §3.6/§4.8.  Проза с формулировками теорем не покрывалась НИЧЕМ —
# и там пережили проверку три ложные границы: `Ẑ ≤ 0.1691` и `Ẑ ≤ 0.163`
# (факт 0.170473) и `sup‖(DT₀−z)⁻¹‖₁ ≤ 3.796` (факт 3.7960642604).
# Правило то же, что и всегда: величина, напечатанная как граница, обязана
# проверяться там, где она напечатана, а не там, где удобно парсить.
_LE = r'(?:≤|\\le\s*)'
_GE = r'(?:≥|\\ge\s*)'
_rules = [
    ('q',     r'`?q`?\s*' + _LE + r'\s*([0-9]*\.[0-9]+)', 1.0, 'up'),
    ('q_s',   r'`?q_s`?\s*' + _LE + r'\s*([0-9]*\.[0-9]+)', 1.0, 'up'),
    ('U_min', r'U_?\{?\\?min\}?`?\s*' + _GE + r'\s*([0-9]*\.[0-9]+)', 1.0, 'down'),
    ('rho_b', r'ρ\*_b(?:\(ℓ\))?\s*≤\s*([0-9]*\.?[0-9]+)·10⁻¹³', 1e-13, 'up'),
    ('rho_X', r'ρ\*_X(?:\(ℓ\))?\s*≤\s*([0-9]*\.?[0-9]+)·10⁻¹³', 1e-13, 'up'),
    ('rho_X', r'1\.75ρ\*_b\s*≤\s*([0-9]*\.?[0-9]+)·10⁻¹³', 1e-13, 'up'),
    ('Zhat',  r'Ẑ\s*' + _LE + r'\s*([0-9]*\.[0-9]+)', 1.0, 'up'),
    ('Y0',    r'`?Y0`?\s*' + _LE + r'\s*([0-9]*\.?[0-9]+)·10⁻¹³', 1e-13, 'up'),
    ('d_chk', r'd_chk`?\s*' + _LE + r'\s*([0-9]*\.?[0-9]+)·10⁻¹⁵', 1e-15, 'up'),
    ('Z1',    r'`?Z1(?![bc])`?\s*' + _LE + r'\s*([0-9]*\.[0-9]+)', 1.0, 'up'),
    ('L',     r'`?L`?\s*' + _LE + r'\s*([0-9]*\.?[0-9]+)(?:·10⁴|\\cdot10\^4)', 1e4, 'up'),
    ('Delta', r'‖Δ‖(?:₁)?\s*' + _LE + r'\s*([0-9]*\.[0-9]+)', 1.0, 'up'),
    # (?<!R\,) — иначе правило ловит ещё и `R\,\|\Delta\|\le0.9896` посылки а7,
    # где число относится к произведению, а не к самой норме
    ('Delta', r'(?<!R\\,)\\\|\\Delta\\\|\\le([0-9]*\.[0-9]+)', 1.0, 'up'),
    ('extra', r'`?extra`?\s*' + _LE + r'\s*([0-9]*\.?[0-9]+)·10⁻⁶', 1e-6, 'up'),
    # sup‖(DT₀−z)⁻¹‖₁ ≤ R — в юникоде (формулировки теорем B и C) и в
    # LaTeX-варианте сводной таблицы допущений (посылка а7)
    ('R',     r'\(DT₀−z\)⁻¹‖₁\s*≤\s*([0-9]*\.[0-9]+)', 1.0, 'up'),
    # Резольвента ЯКОРНОЙ матрицы (§4.7) — другая величина и другая
    # форма записи, чем `R` выше; своего правила у неё не было.
    ('R_A',   r'\(A\s*−\s*z\)⁻¹‖₁\s*≤\s*([0-9]*\.[0-9]+)', 1.0, 'up'),
    ('R',     r'\(DT_0-z\)\^\{-1\}\\\|_1\\le\s*R\\le([0-9]*\.[0-9]+)', 1.0, 'up'),
    ('RD',    r'R\\,\\\|\\Delta\\\|\\le([0-9]*\.[0-9]+)', 1.0, 'up'),
    # «полный тест worst»: устаревшее `0.9918` долго держалось в
    # 02-REPRODUCE.md. Ловит и юникод, и LaTeX-вариант посылки а7.
    ('full_test', r'полн\w*\s+тест\w*[^\n]{0,60}?(?:≤|\\le)\s*\*{0,2}([0-9]\.[0-9]+)', 1.0, 'up'),
    # Формулировка теоремы B печатает то же число
    # как «`0.9919 < 1`» — без `≤`, поэтому правило выше его не видело, и
    # порча 0.9919 -> 0.9819 проходила молча.  Величина одна и та же, форма
    # записи другая: граница, напечатанная как «X < 1», — тоже граница.
    ('full_test', r'полн\w*\s+тест\w*[^\n]{0,80}?\*{0,2}([0-9]\.[0-9]+)\*{0,2}\s*<\s*1', 1.0, 'up'),
]
# «ρ*» без индекса означает в одном документе b-радиус, в другом — X-радиус;
# это ровно та подмена имени, которую раздел и должен ловить, поэтому голое
# `ρ* ≤ …` считается ошибкой само по себе.
_ambiguous = _re.compile(r'(?<!1\.75)ρ\*(?!_[bX])(?:\(ℓ\))?\s*≤\s*[0-9]')

# СОСТОЯНИЕ.md — рабочая записка автора, в пакет не входит и в манифесте
# её нет; числа в ней цитируются как история, а не как утверждения.
# раньше стояло `PKG/*.md` — только верхний уровень.  COVERAGE.md,
# REPORT-ANCHOR.md и delta_scan.md лежат в подпапках и не сканировались
# вовсе, то есть «во ВСЕХ документах пакета» в заголовке раздела было
# неправдой.
_md = sorted(f for f in _glob.glob(os.path.join(PKG, '**', '*.md'), recursive=True)
             if os.path.basename(f) != 'СОСТОЯНИЕ.md')
# Раньше раздел читал только `PKG/01-ARTICLE.md` и не
# знал про HYP_ARTICLE.  Последствие: фальсификация на порченой копии
# статьи вообще не доходила до этого раздела — он сверял оригинал и
# молча проходил, а числа, которые стережёт только F (например границы
# в абстракте), выглядели непроверяемыми.  Теперь при заданном
# HYP_ARTICLE место штатной статьи в списке занимает указанная копия.
def _rel(path):
    """Путь относительно пакета.  HYP_ARTICLE может указывать на копию на
    ДРУГОМ диске (так и делают фальсификацию), а os.path.relpath на
    Windows просто бросает ValueError для разных томов.  Сторож, который
    падает исключением посередине, не досчитывает оставшиеся разделы и даёт
    ложное «провалов нет»."""
    try:
        return os.path.relpath(path, PKG).replace(os.sep, '/')
    except ValueError:
        return path.replace(os.sep, '/')


_art_pkg = os.path.join(PKG, '01-ARTICLE.md')
if os.path.abspath(ART) != os.path.abspath(_art_pkg):
    _md = [ART if os.path.abspath(f) == os.path.abspath(_art_pkg) else f
           for f in _md]
_seen = 0
# Пошаблонный счётчик.  Общего сторожа «_seen == 0» мало: он падает, только
# если не нашлось НИ ОДНОГО совпадения по всем правилам сразу, — умри
# пятнадцать правил из двадцати, раздел промолчит, и «0 провалов» будет
# означать «0 проверок».  Мерено: на корпусе пакета живы все 20 правил.
_hits = [0] * len(_rules)
for _path in _md:
    _txt = open(_path, encoding='utf-8').read()
    _name = os.path.basename(_path)
    for _i, (_key, _pat, _scale, _dir) in enumerate(_rules):
        for _m in _re.finditer(_pat, _txt):
            _hits[_i] += 1
            # `q̂` (`\hat q`) — другая величина, чем `q`; `1.75ρ*` — чем `ρ*`
            _pre = _txt[max(0, _m.start() - 8):_m.start()]
            if _key == 'q' and ('hat' in _pre or '̂' in _pre):
                continue
            if _key == 'rho_b' and '1.75' in _pre:
                continue
            _fact = _facts[_key]
            if _fact is None:
                continue  # живой факт недоступен (сбой subprocess) — раздел C уже сообщил об этом
            _val = float(_m.group(1)) * _scale
            _seen += 1
            if _dir == 'up':
                _ok = _val >= _fact
            else:
                _ok = _val <= _fact
            report('%s: %s %s %.6g' % (_name, _key,
                                       '≤' if _dir == 'up' else '≥', _val),
                   _ok, 'факт %.10g' % _fact)
    for _m in _ambiguous.finditer(_txt):
        _seen += 1
        report('%s: «ρ*» без индекса _b/_X у границы' % _name, False,
               'фрагмент %r' % _txt[_m.start():_m.start() + 30])
print('проверено опубликованных границ в %d документах: %d'
      % (len(_md), _seen))
if _seen == 0:
    report('раздел F нашёл хотя бы одну границу', False,
           'ни одного совпадения — регекспы разъехались с текстом')
_dead = [(_i, _rules[_i][0]) for _i in range(len(_rules)) if _hits[_i] == 0]
report('раздел F: живы все %d правил' % len(_rules), not _dead,
       ('мёртвые (0 совпадений во всём корпусе): %s — правило есть, а текста '
        'под него нет: проверка не может упасть'
        % ', '.join('#%d %s' % _d for _d in _dead)) if _dead else
       'по каждому правилу есть совпадения: %s'
       % ' '.join('%s:%d' % (_rules[_i][0], _hits[_i])
                  for _i in range(len(_rules))))

print()
print('=== F2. ЧИСЛА ЯКОРНОГО БОКСА И ОПИСАТЕЛЬНЫЕ ДИАПАЗОНЫ ===')
print('-' * 100)
# Раздел F сверяет ГЛОБАЛЬНЫЕ худшие величины и
# потому не может проверять числа отдельного бокса: у него нет для них факта.
# Числа якорного бокса t0215 (§4.8) и описательный диапазон B_A (посылка а3)
# из-за этого не сверялись ни с чем — и там оказались два нарушения
# направления сразу.  Здесь у каждой величины СВОЙ факт.

# --- t0215: якорный бокс §4.8 -----------------------------------------
_t0215 = None
try:
    _t0215 = json.load(open(os.path.join(TUBE, 'box_t0215.json'), encoding='utf-8'))
except Exception as _e:
    report('F2: box_t0215.json читается', False, str(_e))
if _t0215 is not None:
    # все три печатаются как верхние границы -> обязаны идти ВВЕРХ
    for _lbl, _pat, _fact in (
            ('R (t0215)', r'`t0215`:[^\n]*?`R`\s*=\s*([0-9]+\.[0-9]+)',
             _t0215['R']),
            ('‖Δ‖ (t0215)', r'`‖Δ‖`\s*=\s*([0-9]+\.[0-9]+)·10⁻¹',
             _t0215['delta_norm'] * 10),
            ('R·‖Δ‖ (t0215)', r'`R·‖Δ‖`\s*=\s*([0-9]+\.[0-9]+)',
             _t0215['prod'])):
        _m = re.search(_pat, art_text, re.S)
        if not _m:
            report('F2: %s найдено в статье' % _lbl, False, 'регексп не сработал')
            continue
        _v = float(_m.group(1))
        report('F2: %s опубликовано ВВЕРХ' % _lbl, _v >= _fact,
               'статья %.6f, факт %.9f' % (_v, _fact))

# --- диапазон B_A в посылке а3 §6.2 ------------------------------------
# Нижний конец диапазона — миноранта (ВНИЗ), верхний — мажоранта (ВВЕРХ).
_ba = [float(j['B_A']) for j in ex_passed if 'B_A' in j]
if _ba:
    _m = re.search(r'B_A`?\s*\(диапазон \$\[([0-9.]+),\\,([0-9.]+)\]\$\)', art_text)
    if not _m:
        report('F2: диапазон B_A найден в статье', False, 'регексп не сработал')
    else:
        _lo, _hi = float(_m.group(1)), float(_m.group(2))
        report('F2: нижний конец B_A опубликован ВНИЗ', _lo <= min(_ba),
               'статья %.6f, факт min %.6f' % (_lo, min(_ba)))
        report('F2: верхний конец B_A опубликован ВВЕРХ', _hi >= max(_ba),
               'статья %.6f, факт max %.6f' % (_hi, max(_ba)))

print()
print('=== G. ССЫЛКИ ДОКУМЕНТОВ НА ФАЙЛЫ ПАКЕТА ===')
print('-' * 100)
# `COVERAGE.md` ссылался на `11-PARAM-SWEEP.md` как на носитель
# утверждения о покрытии всего отрезка — а этого файла в пакете нет вовсе.
# Битая ссылка легко переписывается в отчёт как проверенную («rests on
# 11-PARAM-SWEEP.md, verified earlier»), даже не открыв файла — читается
# как «проверено в другом месте» и гасит вопрос.
# Здесь каждая ссылка вида `путь.расширение` обязана либо существовать в
# пакете, либо стоять в списке заведомо внешних с причиной.
_KNOWN_EXTERNAL = {
    # рабочее дерево сборки движка; оговорено в 05-DATA-INDEX.md §«Ссылки на
    # рабочее дерево в комментариях»
    'BRIEF-*.md': 'рабочее дерево сборки',
    'REPORT.md': 'рабочее дерево сборки',
    'BRIEF.md': 'задание якорного расчёта, в пакет не входит',
    # выходы скриптов, создаются при запуске; оговорено в REPORT-ANCHOR.md
    '_LOG.md': 'создаётся при запуске',
    'work/_LOG.md': 'создаётся при запуске',
    '_s3s4_result.json': 'создаётся при запуске',
    'work/_s3s4_result.json': 'создаётся при запуске',
    # сырой банк марша; оговорено в 05-DATA/COVERAGE.md §1
    'results.json': 'сырой банк марша, в пакет не входит',
    'xcheck_scale.json': 'выход xcheck_scale.py, в пакет не входит',
    'xcheck_scale.log': 'выход xcheck_scale.py, в пакет не входит',
    # сокращённая запись пары реальных файлов task_A_/task_B_
    'task_A/B_krawzyk_result.json': 'сокращение для task_A_ и task_B_',
    # Скрипт приёмки в пакет не входит; оговорено в REPORT-ANCHOR.md
    # (тот же список есть в tests/_refs_check.py::_ALLOWED_MISSING —
    # правило одно: запись сюда только вместе с оговоркой в тексте)
    'verify_pkg.sh': 'скрипт приёмки вне пакета, документ это оговаривает',
    # rerun_all.sh пишет прогресс во временный каталог ОС (HYP_RERUN);
    # 02-REPRODUCE.md это прямо оговаривает в таблице переменных.
    'rerun_progress.log': 'создаётся при запуске rerun_all.sh, в пакет не входит',
}
_EXT = ('.md', '.py', '.json', '.npz', '.sh', '.txt', '.out', '.log', '.csv')
_have = set()
for _r, _ds, _fs in os.walk(PKG):
    _ds[:] = [d for d in _ds if not d.startswith('.') and d != '__pycache__']
    for _f in _fs:
        _have.add(_f)
        _have.add(os.path.relpath(os.path.join(_r, _f), PKG).replace(os.sep, '/'))
_ref = _re.compile(r'`([^`\s]+?(?:' + '|'.join(_re.escape(e) for e in _EXT) + r'))`')
_dang, _nref = [], 0
for _path in _md:
    _txt = open(_path, encoding='utf-8').read()
    _name = os.path.basename(_path)
    for _m in _ref.finditer(_txt):
        _t = _m.group(1).lstrip('./')
        # шаблоны и плейсхолдеры проверять нечем
        if any(ch in _t for ch in '*<>?'):
            continue
        _nref += 1
        if _t in _have or os.path.basename(_t) in _have:
            continue
        if _t in _KNOWN_EXTERNAL:
            continue
        _dang.append((_name, _t))
for _name, _t in _dang:
    report('%s: ссылка на `%s`' % (_name, _t), False, 'файла в пакете нет')
report('битых ссылок на файлы пакета нет', not _dang,
       'проверено ссылок: %d в %d документах' % (_nref, len(_md)))

print()
print('=== B. ВЫЧИСЛЯЕМЫЕ ТОЖДЕСТВА ВНУТРИ JSON ===')
print('-'*100)

# 1) ρ* = Y0 / (1 − Ẑ)   (формула из §5.1)
# 2) guard_lhs = B_A · dchk
# 3) guard_rhs = Y0 / 2
# 4) Y0 + Ẑ·ρ' ≤ ρ'   (ворота Канторовича)
for j in ex_passed:
    tag = j.get('idx', '?')
    Y0 = float(j['Y0'])
    Z1 = float(j['Z1'])
    Zh = float(j['best']['Zhat'])
    rp = parse_arb(j['best']['rho_prime'])
    rs = parse_arb(j['best'].get('rho_star_b', j['best']['rho_star']))
    rsX = parse_arb(j['best'].get('rho_star_X')) if j['best'].get('rho_star_X') else None
    B_A = float(j['B_A'])
    dchk = float(j['dchk'])
    glhs = parse_arb(j.get('guard_lhs')) if j.get('guard_lhs') is not None else None
    grhs = parse_arb(j.get('guard_rhs')) if j.get('guard_rhs') is not None else None
    # Ẑ и L — арб-шары; в json лежит их ВЕРХНИЙ конец (тот, что шёл в ворота),
    # а числитель и знаменатель ворот записаны отдельными полями gate_num,
    # gate_den. Тождество проверяем по ним: воспроизводить его из округлённых
    # Y0, B_A, d_chk, Ẑ можно только с точностью до последнего знака печати.
    gnum = parse_arb(j['best'].get('gate_num')) if j['best'].get('gate_num') else None
    gden = parse_arb(j['best'].get('gate_den')) if j['best'].get('gate_den') else None
    if gnum is not None and gden is not None and gden > 0:
        rs_calc = gnum / gden
        ok = abs(rs - rs_calc) / max(rs, 1e-30) < 1e-5
        report('box %-10s  ρ*_b = gate_num/gate_den' % tag, ok,
               '%.4e vs %.4e (Δ %.2e%%)' % (rs, rs_calc, 100*abs(rs-rs_calc)/max(rs, 1e-30)))
        ok2 = abs(gnum - (Y0 + B_A * dchk)) / max(gnum, 1e-30) < 1e-5
        report('box %-10s  gate_num = Y0 + B_A·d_chk' % tag, ok2,
               '%.6e vs %.6e' % (gnum, Y0 + B_A * dchk))
        ok3 = abs(gden - (1 - Zh)) / max(gden, 1e-30) < 1e-5
        report('box %-10s  gate_den = 1 − Ẑ' % tag, ok3,
               '%.6e vs %.6e' % (gden, 1 - Zh))
    elif 1 - Zh > 0:
        rs_calc = (Y0 + B_A * dchk) / (1 - Zh)
        ok = abs(rs - rs_calc) / max(rs, 1e-30) < 1e-3
        report('box %-10s  ρ*_b = (Y0+B_A·d_chk)/(1−Ẑ)' % tag, ok,
               '%.4e vs %.4e (Δ %.2e%%)' % (rs, rs_calc, 100*abs(rs-rs_calc)/max(rs, 1e-30)))
    if rsX is not None:
        # Было двустороннее `|rsX − 1.75·rs| / rsX < 1e-5`: допуск
        # шире нужного и не различает сторон.  А стороны здесь разные:
        # `rho_star_X` = fmt_up(1.75 · ТОЧНОГО b), тогда как `rho_star_b`
        # уже округлён вверх, поэтому наивно можно было бы ждать
        # `rsX ≤ 1.75·rs` без исключений — но оба числа сами направленно
        # округлены до 7 значащих цифр (см. ниже), и это округление уже
        # способно сдвинуть каждое на свой ulp в любую сторону: живая
        # проверка по всем 46 боксам даёт 13, где `rsX` на 1 ulp ВЫШЕ
        # `1.75·rs` (напр. g00: превышение ≈7.5e-20 при rsX≈7.49e-13).
        # Направление НЕ гарантировано — окно обязано быть двусторонним.
        # Оба числа — семизначные НАПРАВЛЕННЫЕ округления величин, точно
        # различающихся в 1.75 раза: `rs = fmt_up(b)`, `rsX = fmt_up(1.75·b)`.
        # Поэтому разойтись они могут максимум на единицу последнего разряда
        # в любую сторону (≈1e-7 относительно), но не больше: окно 2.5e-7 —
        # в сорок раз у́же прежнего 1e-5 и ловит реальную рассинхронизацию.
        _ref = 1.75 * rs
        # Допуск считаем не «на глаз», а как единицу последнего печатного
        # разряда: оба числа записаны семью значащими, поэтому разойтись
        # они могут максимум на ulp в каждую сторону.
        import math as _mh
        _ulp7 = 10.0 ** (_mh.floor(_mh.log10(max(rsX, _ref, 1e-300))) - 6)
        ok = abs(rsX - _ref) <= 2.05 * _ulp7
        report('box %-10s  ρ*_X = fmt_up(1.75·ρ*_b), не выше двойного '
               'округления' % tag, ok,
               '%.7e против 1.75·ρ*_b = %.7e (отн. %+.2e)'
               % (rsX, _ref, (rsX - _ref) / _ref))
    if glhs is not None:
        glhs_calc = B_A * dchk
        ok = abs(glhs - glhs_calc) / max(glhs, 1e-30) < 1e-3
        report('box %-10s  guard_lhs = B_A·dchk' % tag, ok,
               '%.4e vs %.4e' % (glhs, glhs_calc))
    if grhs is not None:
        grhs_calc = Y0 / 2
        ok = abs(grhs - grhs_calc) / max(grhs, 1e-30) < 1e-3
        report('box %-10s  guard_rhs = Y0/2' % tag, ok,
               '%.4e vs %.4e' % (grhs, grhs_calc))
    if rp > 0:
        lhs = Y0 + B_A * dchk + Zh * rp
        ok = lhs <= rp * (1 + 1e-9)
        report('box %-10s  Y0 + B_A·d_chk + Ẑ·ρ′ ≤ ρ′' % tag, ok,
               '%.3e vs ρ′=%.2e' % (lhs, rp))
    if Zh >= 1:
        report('box %-10s  Ẑ < 1' % tag, False, '%.6f' % Zh)


print()
print('=== C. СПОТ-ПРОВЕРКА КЛЮЧЕВЫХ СКАЛЯРОВ СТАТЬИ ===')
print('-'*100)
# Спот-проверка ищет ВХОЖДЕНИЕ СТРОКИ — и в этом её ловушка: когда
# сертификат сдвигается, она продолжает требовать СТАРЫЙ литерал и «проходит»
# ровно потому, что статья не поправлена.  Так `Ẑ max («0.1691»)` пережил
# при факте 0.170473 и был опубликован в формулировке теоремы A.
# Поэтому теперь каждый литерал сверяется ещё и ПО НАПРАВЛЕНИЮ с фактом из
# `truth`: наличие строки — это про вёрстку, направление — про истинность.
spot = [
    ('8.49·10⁻¹³', 'ρ*_X max',          'ρ*_X', 'up'),
    ('4.85·10⁻¹³', 'ρ*_b max',          'ρ*_b', 'up'),
    ('4.31·10⁻¹³', 'Y0 max',            'Y0',   'up'),
    ('7.98·10⁻¹⁵', 'd_chk max',         'd_chk', 'up'),
    ('0.1501',     'Z1 max',            'Z1',   'up'),
    ('0.1705',     'Ẑ max',             'Ẑ',    'up'),
    ('3.7961',     'R max',             'R',    'up'),
    ('2.798·10⁻¹', '‖Δ‖ max',           '‖Δ‖',  'up'),
    ('0.9919',     'полный тест worst',  '_full_test_worst', 'up'),
]
# «полный тест worst» посчитан ДО раздела F (см. выше) — здесь только сверка.
_full_test_worst_fact = truth['_full_test_worst'][1] if truth['_full_test_worst'][1] < 1e99 else None

for needle, label, key, direction in spot:
    found = needle in art_text
    report('статья содержит ' + label + ' («' + needle + '»)', found)
    if key is None:
        continue
    if key == '_full_test_worst' and _full_test_worst_fact is None:
        continue
    val = parse_art_num(needle)
    fact = truth[key][1] if direction == 'up' else truth[key][0]
    ok = (val >= fact) if direction == 'up' else (val <= fact)
    report('   он же как граница: %s %s %.6g' % (label, '≥' if direction == 'up' else '≤', val),
           ok, 'факт %.10g' % fact)


print()
print('=== D. §6 (ПЕРЕНОС С ЦЕНТРА НА РЕШЕНИЕ) — числа статьи против сертификатов ===')
print('-'*100)
print('Раньше §6 и §5.2.1 не покрывались этим тестом вовсе — числа там могли')
print('разъехаться с сертификатами незамеченными (что и произошло). Числа ниже')
print('вылавливаются ТОЧЕЧНЫМИ регэкспами по уникальному контексту формулы, а')
print('не построчным разбором таблицы по «|»: строки а1/а2/а4 сводной таблицы')
print('допущений статьи содержат LaTeX-нормы \\|...\\| — НЕЭКРАНИРОВАННЫЙ для')
print('markdown символ «|» внутри LaTeX-конструкции, который ломает наивный')
print('split(\'|\') по ячейкам (грабля §3, п.1 задания). Точечный regex по')
print('содержимому формулы эту грабли не задевает.')
print()

m_rho_b = re.search(r'\\rho\^\{\\star\}\\le([0-9.]+)\\cdot10\^\{-13\}', art_text)
m_rho_X = re.search(r'1\.75\\rho\^\{\\star\}\\le([0-9.]+)\\cdot10\^\{-13\}', art_text)
m_pert = re.search(r'([0-9.]+)\\cdot10\^4\\cdot1\.75\\cdot10\^\{-7\}<([0-9.]+)\\cdot10\^\{-3\}', art_text)
m_662 = re.search(r'равен\s*\$([0-9.]+)<([0-9.]+)\$', art_text)
found_d = sum(x is not None for x in (m_rho_b, m_rho_X, m_pert, m_662))
print('формул §6 найдено в тексте статьи: %d из 4' % found_d)
print()

# --- ρ*_b и ρ*_X (а1): границы берутся ИЗ ТЕКСТА статьи, не зашиты ---
rsb_max = truth['ρ*_b'][1]
rsX_max = truth['ρ*_X'][1]
if m_rho_b is not None:
    rsb_art = float(m_rho_b.group(1)) * 1e-13
    ok = rsb_max <= rsb_art
    report('ρ*_b <= %.3e (а1, против max best.rho_star_b)' % rsb_art, ok,
           'факт max=%.4e vs статья=%.4e' % (rsb_max, rsb_art))
else:
    report('ρ*_b <= ... (а1)', False, 'формула не найдена в тексте статьи')

if m_rho_X is not None:
    rsX_art = float(m_rho_X.group(1)) * 1e-13
    ok = rsX_max <= rsX_art
    report('1.75·ρ*_b = ρ*_X <= %.3e (а1, против max best.rho_star_X)' % rsX_art, ok,
           'факт max=%.4e vs статья=%.4e' % (rsX_max, rsX_art))
else:
    report('1.75·ρ* <= ... (а1)', False, 'формула не найдена в тексте статьи')

# --- L (§6.6.2, тот же максимум, что и в §3.6, но своя проверка,
#     привязанная к ЭТОЙ фразе §6 — если её отредактируют отдельно от §3.6,
#     расхождение поймается здесь) ---
L_max = truth['L'][1]
if m_pert is not None:
    L_art = float(m_pert.group(1)) * 1e4
    ok = L_max <= L_art
    report('L <= %.3e (§6.6.2, против max box_g*.json::best.L)' % L_art, ok,
           'факт max=%.4e vs статья=%.4e' % (L_max, L_art))
else:
    report('L <= ... (§6.6.2)', False, 'формула не найдена в тексте статьи')

# --- возмущение L·1.75e-7 < 6.6e-3 (§6.6.2) ---
pert_val = L_max * RHO_UNIQUENESS
if m_pert is not None:
    pert_art = float(m_pert.group(2)) * 1e-3
    ok = pert_val < pert_art
    report('L·1.75·10⁻⁷ < %.3e (§6.6.2)' % pert_art, ok,
           'факт=%.4e vs порог статьи=%.4e' % (pert_val, pert_art))
else:
    report('L·1.75·10⁻⁷ < 6.6·10⁻³ (§6.6.2)', False, 'формула не найдена в тексте статьи')

# --- итог §6.6.2: max по боксам СО СВОИМИ B_A, Z1, L (не по глобальным
#     максимумам разных величин — они достигаются на разных боксах) ---
worst_662 = None
for j in ex_passed:
    B_A_j = float(j['B_A'])
    Z1_j = float(j['Z1'])
    L_j = float(j['best']['L'])
    bAZ = B_A_j / (1 - Z1_j)
    # Здесь стоял знаменатель БЕЗ множителя 1.75 перехода из нормы X в
    # столбцовую (§6.6.2 статьи: 1 − (B_A/(1−Z1)) · 1.75 · L · 1.75e−7 ).
    # Пока в статье стояло 4.292, расхождение укладывалось в допуск 1 % и
    # сторож молчал; после уточнения числа до 4.3414 он стал красным — и был
    # прав по существу, но по неверной формуле: неверна была она, а не число
    # статьи.  Урок: допуск 1 % прячет ошибку в самом сторожe.
    denom = 1 - bAZ * 1.75 * L_j * RHO_UNIQUENESS
    val = bAZ / denom if denom > 0 else float('inf')
    if worst_662 is None or val > worst_662[0]:
        worst_662 = (val, j.get('idx', '?'))
if m_662 is not None:
    art_662_val = float(m_662.group(1))
    art_662_thresh = float(m_662.group(2))
    # Допуск здесь был ДВУСТОРОННИМ: |факт − статья|/статья < 1 %. Статья
    # печатает ВЕРХНЮЮ границу, округлённую наружу, поэтому число ниже факта —
    # не «неточность в пределах допуска», а неверная граница; при двустороннем
    # допуске статья могла напечатать 4.3000 < 4.35 при факте 4.3414, и все
    # текстовые шаги оставались зелёными. Направление проверяется отдельно от
    # тесноты — тот же образец, что в I10 и в проверках art_val ниже.
    ok_dir = art_662_val >= worst_662[0]
    ok_val = ok_dir and (art_662_val - worst_662[0]) / art_662_val < 0.01
    report('§6.6.2: max ‖D_GF⁻¹‖ по боксам (своими B_A,Z1,L) = %.4f (статья: %s)'
           % (art_662_val, worst_662[1]), ok_val,
           'факт=%.4f (бокс %s) vs статья=%.4f' % (worst_662[0], worst_662[1], art_662_val))
    ok_thresh = worst_662[0] < art_662_thresh
    report('§6.6.2: max ‖D_GF⁻¹‖ < %.2f' % art_662_thresh, ok_thresh,
           'факт=%.4f' % worst_662[0])
else:
    report('§6.6.2: max ‖D_GF⁻¹‖ = 4.292 < 4.30', False,
           'формула не найдена в тексте статьи')

# --- κ_G: сверка с ЖИВЫМ выводом tests/_kappaG_bound.py.
#     Числа снимаются ИЗ СТАТЬИ (§2 и §6.4.3), а не хранятся здесь
#     литералом: тест, который сверяет собственный литерал с выводом
#     скрипта, не падает НИ ПРИ КАКОЙ порче статьи — это тот самый
#     «резиновый штамп», который в этом пакете считается дефектом. ---
_kg_art = re.search(
    r'Максимум по всем 46 боксам равен \$\\kappa_G\\le([0-9.]+)\$\s*\n'
    r'\(фактически \$([0-9.]+)\$, худший бокс `(\w+)`\)', art_text)
_kg_s2 = re.search(r'обоснован явной константой `κ_G ≤ ([0-9.]+)`', art_text)
_kg_shift = re.search(r'\\kappa_G\\cdot1\.75\\cdot10\^\{-7\}='
                      r'([0-9.]+)\\cdot10\^\{-([0-9]+)\}', art_text)
_kg_field = re.search(r'с полем в \$([0-9.]+)\\cdot10\^\{([0-9]+)\}\$ раз', art_text)
_kg_k1 = re.search(r'подразбиении\s+\$K=1\$ они дают \$([0-9.]+)\$ и '
                   r'\$[0-9.]+\$ на `(\w+)`', art_text)
_kg_k1_top = re.search(r'`gtop` \$([0-9.]+)\$ против', art_text)
_kg_k1_42 = re.search(r'`g42` \$([0-9.]+)\$ против', art_text)

report('κ_G: числа §6.4.3 читаются из статьи (порог, факт, худший бокс)',
       _kg_art is not None and _kg_s2 is not None,
       '§6.4.3=%s, §2=%s' % (bool(_kg_art), bool(_kg_s2)))

if _kg_art and _kg_s2:
    KAPPA_G_THRESH = float(_kg_art.group(1))
    kg_fact_art = float(_kg_art.group(2))
    kg_box_art = _kg_art.group(3)
    report('κ_G: §2 и §6.4.3 объявляют одну и ту же границу',
           abs(float(_kg_s2.group(1)) - KAPPA_G_THRESH) < 1e-12,
           '§2=%s, §6.4.3=%s' % (_kg_s2.group(1), _kg_art.group(1)))

    def _kg_run(args, tag):
        """Запуск скрипта; возвращает (худшая κ, худший бокс, {бокс: κ}, stdout)."""
        pr = subprocess.run(
            [sys.executable, os.path.join(HERE, '_kappaG_bound.py')] + args,
            capture_output=True, encoding='utf-8', errors='replace', timeout=900,
            env=dict(os.environ, PYTHONIOENCODING='utf-8'))
        # NB: text=True декодировал бы вывод локальной cp1252 (Windows) и падал
        # с UnicodeDecodeError на кириллице — encoding='utf-8' нужен явно,
        # PYTHONIOENCODING в env влияет только на кодировку ЗАПИСИ в дочернем
        # процессе, а не на декодирование в родительском subprocess.run.
        out = pr.stdout or ''
        mw = re.search(r'худшая\s+κ_G\s+по\s+\d+\s+боксам:\s*([0-9.eE+-]+)\s*'
                       r'\(бокс\s+(\w+)\)', out)
        # печать боксов направленная (десятичная), но старый e-формат
        # тоже принимаем, чтобы тест не зависел от косметики вывода
        per = dict((b, float(v)) for b, v in
                   re.findall(r'^(\w+)\s+([0-9.]+(?:e[+-][0-9]+)?)\s*$',
                              out, re.M))
        if not mw:
            report('κ_G (%s): скрипт отработал' % tag, False,
                   'нет строки "худшая κ_G" (rc=%s, stderr=%s)'
                   % (pr.returncode, (pr.stderr or '')[:200]))
            return None, None, per, out
        return float(mw.group(1)), mw.group(2), per, out

    try:
        kg_val, kg_box, _kg_per, kg_out = _kg_run([], 'K=8')
        if kg_val is not None:
            report('κ_G <= %s (граница §6.4.3)' % _kg_art.group(1),
                   kg_val <= KAPPA_G_THRESH, 'скрипт: %.6e' % kg_val)
            # «фактически» в статье — тоже верхняя оценка: обязана быть не
            # меньше живого значения, но и не завышена (это не порог).
            report('κ_G: «фактически %s» совпадает с выводом скрипта'
                   % _kg_art.group(2),
                   kg_fact_art >= kg_val and (kg_fact_art - kg_val) / kg_val < 1e-6,
                   'статья=%.6f, скрипт=%.6f' % (kg_fact_art, kg_val))
            report('κ_G: худший бокс `%s`' % kg_box_art, kg_box == kg_box_art,
                   'скрипт: %s' % kg_box)
            if _kg_shift:
                _sh_art = float(_kg_shift.group(1)) * 10 ** (-int(_kg_shift.group(2)))
                _m_sh = re.search(r'κ_G · 1\.75e-7 = ([0-9.eE+-]+)', kg_out)
                _sh = float(_m_sh.group(1)) if _m_sh else None
                report('κ_G·ρ = %s·10^-%s (§6.4.3, округление ВВЕРХ)'
                       % (_kg_shift.group(1), _kg_shift.group(2)),
                       _sh is not None and _sh <= _sh_art,
                       'статья=%.6e, скрипт=%s' % (_sh_art, _sh))
            else:
                report('κ_G·ρ найдено в §6.4.3', False, 'формула не найдена')
            if _kg_field:
                _fl_art = float(_kg_field.group(1)) * 10 ** int(_kg_field.group(2))
                _m_fl = re.search(r'поле запаса больше в ([0-9.]+) раз', kg_out)
                _fl = float(_m_fl.group(1)) if _m_fl else None
                report('поле запаса >= %s·10^%s раз (§6.4.3, округление ВНИЗ)'
                       % (_kg_field.group(1), _kg_field.group(2)),
                       _fl is not None and _fl >= _fl_art,
                       'статья=%.6e, скрипт=%s' % (_fl_art, _fl))
            else:
                report('поле запаса найдено в §6.4.3', False, 'число не найдено')

        # Сверка с §10.7 при равном подразбиении K = 1 — три числа,
        # опубликованные в §6.4.3 как свидетельство согласия двух реализаций.
        if _kg_k1 and _kg_k1_top and _kg_k1_42:
            k1_val, k1_box, k1_per, _kg_out1 = _kg_run(['1'], 'K=1')
            if k1_val is not None:
                report('κ_G при K=1: %s на `%s` (сверка с §10.7)'
                       % (_kg_k1.group(1), _kg_k1.group(2)),
                       k1_box == _kg_k1.group(2)
                       and abs(k1_val - float(_kg_k1.group(1))) < 5e-6,
                       'скрипт: %.6f на %s' % (k1_val, k1_box))
                for _b, _mm in (('gtop', _kg_k1_top), ('g42', _kg_k1_42)):
                    _v = k1_per.get(_b)
                    report('κ_G при K=1, бокс `%s` = %s' % (_b, _mm.group(1)),
                           _v is not None
                           and abs(_v - float(_mm.group(1))) < 5e-6,
                           'скрипт: %s' % _v)
        else:
            report('κ_G: числа сверки K=1 найдены в §6.4.3', False,
                   'K=1: %s, gtop: %s, g42: %s'
                   % (bool(_kg_k1), bool(_kg_k1_top), bool(_kg_k1_42)))
    except Exception as e:
        report('κ_G: запуск tests/_kappaG_bound.py', False, 'ошибка: %r' % e)


# --- посылка (C.1): сверка с ЖИВЫМ выводом tests/_nozeros_check.py.
#     в §6.11 стояло 0.3782 на `g04`, в §6.4.2 — 0.3648 на `g06`;
#     оба числа проходили мимо теста.  Теперь худший бокс и его значение
#     сверяются со ВСЕМИ упоминаниями в статье. ---
try:
    nz_proc = subprocess.run(
        [sys.executable, os.path.join(HERE, '_nozeros_check.py')],
        capture_output=True, encoding='utf-8', errors='replace', timeout=300,
        env=dict(os.environ, PYTHONIOENCODING='utf-8'))
    m_nz = re.search(r'худший бокс:\s*(\w+),\s*sup\(C\.1\)\s*=\s*\[?'
                     r'([0-9.]+)', nz_proc.stdout or '')
    if not m_nz:
        report('посылка (C.1): худший бокс и его значение', False,
               'не нашли строку "худший бокс" в выводе _nozeros_check.py '
               '(rc=%s, stderr=%s)' % (nz_proc.returncode, nz_proc.stderr[:200]))
    else:
        nz_box, nz_val = m_nz.group(1), float(m_nz.group(2))
        # все упоминания вида «... `gNN`: $0.XXXX$» и «$0.XXXX$ на `gNN`»
        pats = re.findall(r'`(g\d+|gtop)`\s*:\s*\$([0-9.]+)\$', art_text)
        pats += [(b, v) for v, b in
                 re.findall(r'\$([0-9.]+)\$\s*на\s*`(g\d+|gtop)`', art_text)]
        nz_bad = [(b, v) for b, v in pats
               if abs(float(v) - nz_val) > 1e-3 or b != nz_box]
        # оставляем только те упоминания, которые ПРЕТЕНДУЮТ быть этим числом:
        # рядом в тексте стоит порог 0.379 или имя скрипта _nozeros_check
        nz_bad = [(b, v) for b, v in nz_bad if 0.30 < float(v) < 0.45]
        # тест обязан уметь провалиться: если в статье вообще НЕТ упоминаний
        # этой величины, пустой список — не успех, а отсутствие проверки
        nz_seen = [(b, v) for b, v in pats if 0.30 < float(v) < 0.45]
        if not nz_seen:
            report('посылка (C.1): все упоминания', False,
                   'в статье не найдено ни одного упоминания значения (C.1) — '
                   'сверять нечего, а значит проверка не выполнена')
        else:
            report('посылка (C.1): %d упоминан. = %s на `%s`'
                   % (len(nz_seen), ('%.4f' % nz_val), nz_box), not nz_bad,
                   'скрипт: sup=%.10f на `%s`; расхождения в статье: %s'
                   % (nz_val, nz_box, nz_bad if nz_bad else 'нет'))
    # --- широкий домен.  §10.7 берёт sup|U| из ЭТОГО числа, а не из
    #     базового 0.379: база на целевых слоях не мажорирует (сумма растёт
    #     по c+r).  Сверяем разом три места: живой вывод скрипта, литерал
    #     статьи и константу в коде.
    #     Сам домен в шаблоне НЕ зашит: он менялся (3/2 -> 1.53, чтобы
    #     покрыть коридор), и зашитое значение молча рассыпало бы ворота —
    #     m_nzw стал бы None, и проверка превратилась бы в отчёт о том, что
    #     сверять нечего.
    m_nzw = re.search(r'худший бокс \(широкий домен c\+r=[0-9./]+\):\s*(\w+),'
                      r'\s*sup\s*=\s*\[?([0-9.]+)', nz_proc.stdout or '')
    # Замок обязан требовать и слагаемого `+ ΔU`. Без него статья
    # печатала мажоранту для ИНТЕРПОЛЯНТА `P`, а код (правильно) считал
    # `1.392 + dU` — то есть замок сторожил ровно ту часть, которая верна.
    m_art_supu = re.search(r'sup\|U\|\s*≤\s*1\s*\+\s*([0-9.]+)\s*\+\s*ΔU'
                           r'\s*=\s*([0-9.]+)\s*\+\s*ΔU', art_text)
    if m_nzw is None or m_art_supu is None:
        report('sup|U| широкого домена сверен со статьёй', False,
               'нашли в выводе скрипта: %s, в §10.7: %s'
               % (bool(m_nzw), bool(m_art_supu)))
    else:
        nzw_val = float(m_nzw.group(2))
        art_add = float(m_art_supu.group(1))
        art_sup = float(m_art_supu.group(2))
        report('sup|U−1| при c+r=3/2 = %.6f (`%s`), статья публикует %s'
               % (nzw_val, m_nzw.group(1), m_art_supu.group(1)),
               art_add >= nzw_val and (art_add - nzw_val) < 0.01
               and abs(art_sup - (1.0 + art_add)) < 1e-12,
               'мажоранта обязана быть округлена ВВЕРХ и не грубее 0.01; '
               'скрипт %.6f, статья 1+%s=%s' % (nzw_val, art_add, art_sup))
        _lk_path = os.path.join(os.path.dirname(HERE), 'layer',
                                'layer_kappa.py')
        _m_lk = re.search(r"supU = arb\('([0-9.]+)'\) \+ dU",
                          open(_lk_path, encoding='utf-8').read())
        # сравниваем ЛИТЕРАЛЫ как строки, а не их float-значения: обе
        # стороны — десятичные записи из исходников, и строгое равенство
        # строк здесь и точнее, и не тащит в ворота сравнение чисел с
        # эпсилоном (сравнение чисел с допуском — отдельный класс дефекта).
        report('константа sup|U| в layer_kappa.py совпадает со статьёй',
               _m_lk is not None
               and _m_lk.group(1) == m_art_supu.group(2),
               'код: %s, статья: %s'
               % (_m_lk.group(1) if _m_lk else None, m_art_supu.group(2)))
except Exception as e:
    report('посылка (C.1): худший бокс и его значение', False,
           'ошибка запуска tests/_nozeros_check.py: %r' % e)


print()
print('=== E. §5.2.1 И ПРИЛОЖЕНИЕ A — Q★ (ℓ=3) ===')
print('-'*100)

qpp = json.load(open(os.path.join(POINTWISE, 'q_perturb_patch.json'), encoding='utf-8'))
q16_cert = float(qpp['summary']['sum_q16'])

m_q16rho = re.search(r'\(([0-9.]+)\)\^\{1/16\}\s*.\s*([0-9.]+)\s*<\s*1', art_text)
found_e = 1 if m_q16rho is not None else 0
print('формула §5.2.1 (ρ(Q★) ≤ ‖Q★¹⁶‖₁^(1/16) ≤ ...) найдена в статье: %s' %
      ('да' if found_e else 'НЕТ'))
print()

if m_q16rho is not None:
    q16_art = float(m_q16rho.group(1))
    rho_art = float(m_q16rho.group(2))

    ok1 = q16_cert <= q16_art * 1.0001
    # Было %.6f — печать сама срезала седьмой знак и показывала
    # старое 0.290595 вместо опубликованного 0.2905947.
    report('‖Q★¹⁶‖₁ <= %.7g (§5.2.1, против q_perturb_patch.json::summary.sum_q16)'
           % q16_art, ok1, 'факт=%.9g vs статья=%.7g' % (q16_cert, q16_art))

    # Сама заявленная в статье цепочка неравенств: ρ(Q★) <= (число_статьи)^(1/16).
    # Это и есть найденный в брифе баг: 0.290595^(1/16)=0.925668, а раньше
    # статья печатала 0.9255 < 0.925668 — ложное неравенство. Проверяем это
    # тождество явно, а не полагаемся на то, что кто-то посчитал верно руками.
    root16_art = q16_art ** (1.0 / 16.0)
    ok2 = rho_art >= root16_art
    report('ρ(Q★) <= ‖Q★¹⁶‖₁^(1/16): заявлено %.5f, корень 16-й степени из %.6f = %.6f'
           % (rho_art, q16_art, root16_art), ok2,
           '%.6f %s %.6f' % (rho_art, '>=' if ok2 else '<', root16_art))

    # То же от «сырого» (неокруглённого) значения сертификата — чуть строже,
    # ловит ситуацию, когда сама статья округлила ‖Q★¹⁶‖₁ вниз (что тоже
    # было бы занижением мажоранты).
    root16_cert = q16_cert ** (1.0 / 16.0)
    ok3 = rho_art >= root16_cert
    report('ρ(Q★) <= ‖Q★¹⁶‖₁_сертификат^(1/16) (от неокруглённого значения)', ok3,
           '%.6f vs %.8f^(1/16)=%.8f' % (rho_art, q16_cert, root16_cert))
else:
    report('‖Q★¹⁶‖₁ <= 0.2905947 и тождество ρ(Q★) <= (...)^(1/16)', False,
           'формула §5.2.1 не найдена в тексте статьи')


print()
print('=== E2. §5.1.2/§5.3.3 — ρ★ ТОЧЕЧНЫХ ЯКОРЕЙ (ℓ=3, ℓ=5/2) ===')
print('-' * 100)
# Раздел F проверяет прозу §3/§4, раздел E —
# §5.2.1/Приложение A (Q★).  Точечные формулировки теорем 1 и 3
# (‖G★−Ḡ‖_X ≤ 1.75·ρ★ = …) не проверялись НИЧЕМ — и там нашлась ровно та
# же болезнь, что и везде: `1.75·ρ★` округлили к БЛИЖАЙШЕМУ вместо ВВЕРХ.
# Честный пересчёт: 1.75·rho_star_new (fixL_result.json, ℓ=3) =
# 1.9924936269…×10⁻⁴², а статья печатала 1.99×10⁻⁴² — МЕНЬШЕ истинного.
# Аналогично при ℓ=5/2 (kant_l25.json): 1.75·rho_star.mid = 2.7300004…×10⁻³³
# против напечатанных 2.73×10⁻³³.
def _arb_upper(s):
    """'[mid +/- rad]' -> float(mid)+float(rad), верхний конец шара arb.
    Некоторые точечные сертификаты хранят такие поля строками (python-flint
    здесь намеренно не подключаем — этот скрипт весь остальной путь ходит
    только по json/regex)."""
    if not isinstance(s, str):
        return float(s)
    s = s.strip()
    if not (s.startswith('[') and s.endswith(']')):
        raise SystemExit(s)
    mid_s, rad_s = s[1:-1].split('+/-')
    return float(mid_s.strip()) + float(rad_s.strip())

_fixL = json.load(open(os.path.join(POINTWISE, 'fixL_result.json'), encoding='utf-8'))
_rho_l3 = _arb_upper(_fixL['rho_star_new'])
_fact_l3 = 1.75 * _rho_l3
_m_l3 = re.search(r'1\.75·ρ★\s*≤\s*([0-9.]+)×10⁻⁴²', art_text)
if _m_l3 is not None:
    _art_l3 = float(_m_l3.group(1)) * 1e-42
    report('теорема 1 (ℓ=3): 1.75·ρ★ ≤ %s×10⁻⁴²' % _m_l3.group(1),
           _art_l3 >= _fact_l3,
           'факт=%.10e vs статья=%.10e' % (_fact_l3, _art_l3))
else:
    report('теорема 1 (ℓ=3): 1.75·ρ★ найдена в статье', False,
           'регексп не нашёл формулировку — возможно, изменилась')

_kant25 = json.load(open(os.path.join(POINTWISE, 'kant_l25.json'), encoding='utf-8'))
_rho_l25 = float(_kant25['rho_star']['value']['mid']) + float(_kant25['rho_star']['value']['rad'])
_fact_l25 = 1.75 * _rho_l25
_m_l25 = re.search(r'1\.75·ρ★\s*≤\s*([0-9.]+)×10⁻³³', art_text)
if _m_l25 is not None:
    _art_l25 = float(_m_l25.group(1)) * 1e-33
    report('теорема 3 (ℓ=5/2): 1.75·ρ★ ≤ %s×10⁻³³' % _m_l25.group(1),
           _art_l25 >= _fact_l25,
           'факт=%.10e vs статья=%.10e' % (_fact_l25, _art_l25))
else:
    report('теорема 3 (ℓ=5/2): 1.75·ρ★ найдена в статье', False,
           'регексп не нашёл формулировку — возможно, изменилась')

print()
print('=== H. СЛОВАРЬ ПАРНЫХ ОБОЗНАЧЕНИЙ ===')
print('-' * 100)
# Самый живучий класс дефекта кампании: величина/приём поправлены
# в одном документе и остались старыми в другом (β̂, `ρ*` под двумя
# именами, `L` в §6, `X₀→𝒜`, `ρ′` вместо `ρ*_b` — все четыре случая
# уже были). Не всё здесь можно автоматически считать провалом: не каждое
# вхождение старого символа ошибочно (в §2 явно разрешено сокращение
# `G*(ℓ)∈X₀`, и `ρ′` законно используется в §3 — формула Ẑ ворот
# Канторовича, `Ẑ=Z1+1.75²·B_A·L·ρ′`, — там это ДРУГАЯ, верная формула,
# внешне похожая на формулу `extra` из §4.5/tube_offset.py, где то же
# сочетание `1.75²·B_A·L·ρ` обязано быть с `ρ*_b`, а не `ρ′`). Проверено
# на живом тексте: наивный grep по «ρ′ рядом с 1.75²·B_A·L» ложно сработал
# бы на §3 — поэтому это НЕ провал теста, а только список для разбора.

_code_py = sorted(_glob.glob(os.path.join(PKG, '04-CODE', '**', '*.py'), recursive=True))
_scan_files = list(_md) + [f for f in _code_py if os.path.basename(f) != os.path.basename(__file__)]

# H1 — БЕЗУСЛОВНЫЙ провал: шар B_{X₀,...} с ЦЕНТРОМ P(...) или G(...)/G*(...).
# X₀ — линейное подпространство ({h:h(0)=0}), P(ℓ) и G*(ℓ) в него не входят
# (P(0)=G*(0)=1≠0) — у такого шара просто нет законного прочтения. Центр 0
# (`B_{X₀,...}(0, R)`) законен и не ловится. Ровно этот паттерн нашёлся в
# §6.5 (рецидив уже исправленного дефекта §6.6.3) —
# регрессионный тест на его возврат.
_ball_bad = _re.compile(r'B_\{X_?\{?0[^}]{0,25}\}\}?\(\s*[PG]')
_ball_hits = []
for _path in _scan_files:
    _txt = open(_path, encoding='utf-8').read()
    for _m in _ball_bad.finditer(_txt):
        _ln = _txt.count('\n', 0, _m.start()) + 1
        _ball_hits.append('%s:%d' % (_rel(_path), _ln))
for _h in _ball_hits:
    report('%s: шар B_{X₀,...} с ненулевым центром' % _h, False,
           'X₀ линейно — у P(ℓ)/G*(ℓ) нормировка G(0)=1≠0, такой шар не определён; '
           'нужен аффинный шар P(ℓ)+B_{X₀,...}(0,R) ⊂ 𝒜')
report('H1: шар B_{X₀,...} нигде не центрирован в P/G*', not _ball_hits,
       'проверено файлов: %d' % len(_scan_files))

# H2..H6 — информационно: известные пары обозначений, за которыми стоит
# следить при следующей правке. Печатает вхождения, на bad НЕ влияет —
# контекст (какое из двух чтений верно в конкретном месте) не formalизуем
# дёшево, решает человек по списку в рабочем дереве (в пакет не входит).
_vocab_pairs = [
    ('ρ′ (радиус ворот, ~1e-7) — не путать с ρ*_b (радиус существования, ~1e-13)',
     r'ρ′|ρ\''),
    ('X₀ (линейное подпространство) рядом с G*(ℓ)/G★(ℓ) — легитимно только как '
     'разрешённое в §2 сокращение для h=G*-P∈X₀, иначе должно быть 𝒜',
     r'G[\*★][^\n]{0,15}∈\s*X₀|G\^\{\\star\}[^\n]{0,20}\\in\s*X_0'),
    ('Z_hat_new (историческое поле) без _strict рядом',
     r'Z_hat_new(?!_strict)'),
    ('голое ρ* без индекса _b/_X (см. также раздел F)',
     r'(?<!1\.75)ρ\*(?!_[bX])(?:\(ℓ\))?\s*[=≤≥]'),
]
for _label, _pat in _vocab_pairs:
    _rx = _re.compile(_pat)
    _cnt = 0
    _locs = []
    for _path in _scan_files:
        _txt = open(_path, encoding='utf-8').read()
        for _m in _rx.finditer(_txt):
            _cnt += 1
            if len(_locs) < 5:
                _ln = _txt.count('\n', 0, _m.start()) + 1
                _locs.append('%s:%d' % (_rel(_path), _ln))
    print('  %-90s %3d вхожд.  %s' % (_label[:90], _cnt, ', '.join(_locs) + (' …' if _cnt > 5 else '')))

# ======================================================================
# I. §10 (теорема D, независимость от слоя).
#
# Все проверки читают ПЕРЕНЕСЁННЫЕ артефакты `03-CERTIFICATES/layer/`, а не
# пересчитывают сертификаты: полный прогон 644 пар занимает десятки минут и
# в стандартный маршрут проверки не входит (тот же принцип, по которому
# трубка стережётся через offsets.json, а не пересчётом 706 боксов).
#
# Направление публикации: МАРЖА — величина, которую утверждение хочет иметь
# побольше, поэтому опубликованное значение обязано быть НЕ ВЫШЕ факта;
# ВОЗМУЩЕНИЕ (ΔU/ΔW/κ_G) — наоборот, опубликованное обязано быть НЕ НИЖЕ
# факта. Иначе текст обещает больше, чем посчитано.
# ======================================================================
print()
print('=== I. §10: независимость от слоя (теорема D) ===')

LAYER = os.environ.get('HYP_LAYER', os.path.join(PKG, '03-CERTIFICATES', 'layer'))


def _lj(name):
    """Загрузить артефакт слоя; None если нет (тогда проверка сообщает пропуск)."""
    p = os.path.join(LAYER, name)
    if not os.path.isfile(p):
        return None
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def _art10():
    """Текст §10 статьи (от заголовка до Приложения A)."""
    t = open(ART, encoding='utf-8').read()
    i = t.find('## 10. ')
    j = t.find('## Приложение A')
    return t[i:j] if (i >= 0 and j > i) else ''


_A10 = _art10()
report('I0: §10 присутствует в статье', len(_A10) > 10000,
       '%d символов' % len(_A10))


def _a10_rows(header_frag):
    """Строки markdown-таблицы §10, чей заголовок содержит header_frag.

    Возвращает список списков-ячеек. Нужно, чтобы числа СНИМАЛИСЬ С ТЕКСТА,
    а не сверялись с зашитой в тест константой: иначе порча ячейки проходит
    незамеченной, если то же число стоит где-то ещё (тест, который не может
    провалиться, — ловушка 4 из §4.10).
    """
    out = []
    lines = _A10.split('\n')
    for i, ln in enumerate(lines):
        if header_frag in ln and ln.strip().startswith('|'):
            for ln2 in lines[i + 1:]:
                if not ln2.strip().startswith('|'):
                    break
                cells = [c.strip() for c in ln2.strip().strip('|').split('|')]
                if cells and set(''.join(cells)) <= set('-: '):
                    continue
                out.append(cells)
            break
    return out


def _cell_num(cell):
    """Первое число из ячейки таблицы (снимает **жирный**, скобки, backticks)."""
    t = cell.replace('**', '').replace('`', '')
    m = re.search(r'[0-9]+(?:[.,][0-9]+)?(?:·10[⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)?', t)
    return parse_art_num(m.group(0)) if m else None


def _a10_scalar(pattern):
    """Число из §10 по регэкспу с одной группой захвата; None если нет."""
    m = re.search(pattern, _A10)
    if not m:
        return None
    try:
        return parse_art_num(m.group(1))
    except Exception:
        return None


def _art_has(pat, label, expect=None):
    """Сколько раз число/паттерн встречается в §10."""
    n = len(re.findall(pat, _A10))
    if expect is None:
        return n
    report(label, n == expect, 'найдено %d, ожидалось %d' % (n, expect))
    return n


def _pub_margin(fact, art_val, label, tol_rel=0.02):
    """Маржа: опубликованное не выше факта и совпадает в печатаемых знаках."""
    ok = (art_val <= fact * (1 + 1e-12)) and (abs(art_val - fact) <= tol_rel * fact)
    report(label, ok, 'факт %.6g, статья %.6g%s'
           % (fact, art_val, '' if ok else '  <-- НАПРАВЛЕНИЕ ИЛИ ВЕЛИЧИНА'))


def _pub_upper(fact, art_val, label, tol_rel=0.02):
    """Возмущение: опубликованное не ниже факта и совпадает в знаках."""
    ok = (art_val >= fact * (1 - 1e-12)) and (abs(art_val - fact) <= tol_rel * fact)
    report(label, ok, 'факт %.6g, статья %.6g%s'
           % (fact, art_val, '' if ok else '  <-- НАПРАВЛЕНИЕ ИЛИ ВЕЛИЧИНА'))


# --- I1: 644 точечных сертификата -------------------------------------
_rc = _lj('full_recheck_644.json')
if _rc is None:
    report('I1: full_recheck_644.json на месте', False, 'файла нет в ' + LAYER)
else:
    # структура протокола: dict[слой][бокс] -> {pass, K, min_margin, failed_gate}
    _pairs = []
    if isinstance(_rc, dict):
        for _lay, _boxes in _rc.items():
            for _tag, _r in _boxes.items():
                _q = dict(_r)
                _q['layer'], _q['box'] = _lay, _tag
                _pairs.append(_q)
    else:
        _pairs = list(_rc)
    _n = len(_pairs)
    _npass = sum(1 for x in _pairs if x.get('pass'))
    report('I1a: пар ровно 644 (14 слоёв x 46 боксов)', _n == 644, 'найдено %d' % _n)
    report('I1b: прошли все 644', _npass == _n and _n > 0,
           'прошло %d из %d' % (_npass, _n))
    _mm = [x['min_margin'] for x in _pairs
           if x.get('pass') and x.get('min_margin') is not None]
    if _mm:
        _worst = min(_mm)
        _wp = [x for x in _pairs if x.get('min_margin') == _worst]
        _k1 = [x for x in _pairs if (x.get('K') or 1) > 1]
        # статья цитирует это число в ЧЕТЫРЁХ местах (10.6 таблица, 10.6
        # текст, 10.9, 10.11) — сверяем ВСЕ, а не одно.
        #
        # Раньше выборка шла по ПРАВИЛЬНОМУ литералу
        # (`findall('1.0965·10⁻³|1.09·10⁻³')`) с порогом `>= 3`.  Порча ОДНОГО
        # из четырёх вхождений просто выпадала из выборки (3 >= 3 — ok), то
        # есть проверка сама отбирала себе только целые цитаты.  Теперь
        # выборка идёт по КОНТЕКСТУ (строка §10 с `g00` или `644` и числом
        # вида `X·10⁻³`), а количество закреплено точно: испорченное
        # значение либо попадает в выборку и падает на _pub_margin (направление
        # или допуск 2 %), либо теряет форму и роняет счётчик 4 -> 3.
        # --- Круг 43. Ожидание «ровно 4» снято НЕ подгонкой, а заменой
        # прокси-величины. Проверено прогоном на живой статье: разрыв одной
        # длинной строки §10.8 по границе предложения меняет счёт с 6 на 4,
        # не меняя ни одного слова и ни одного числа. То есть равенство
        # меряло позицию переноса строки, а не текст. Комментарий выше
        # говорит, от чего защита нужна: текст «теряет форму и роняет
        # счётчик 4 -> 3», то есть от УДАЛЕНИЯ и ПОРЧИ цитирования; запрет
        # на добавление целью не был и ничего не стерёг (добавленное
        # упоминание всё равно проходит через I1d ниже).
        #
        # Стережём четыре ИМЕНОВАННЫЕ площадки: каждая на месте, единственна
        # и несёт число в канонической форме. Так ловится и то, что счётчик
        # пропускал: исчезновение цитаты в §10.11, скомпенсированное
        # упоминанием в другом месте (сумма та же, площадки — нет).
        _lines_10 = _A10.split(chr(10))
        _ANCH = [
            # win=1 — строка markdown-таблицы, она по построению не переносится;
            # win=3 — проза, число может уехать на следующую строку.
            # Якорь таблицы 10.6 привязан к НАЧАЛУ строки: просто
            # «I2_margin_s in _l» находит и строку 50 приложения A.
            ('10.6 таблица', lambda _l: _l.startswith('| `I2_margin_s`'), 1),
            ('10.6 текст', lambda _l: 'Глобальный минимум' in _l and '644' in _l, 3),
            ('10.9 п.5', lambda _l: '644/644 прошли' in _l, 3),
            ('10.11 строка', lambda _l: _l.startswith('|') and '644/644' in _l, 1),
        ]
        for _nm, _pred, _win in _ANCH:
            _hit = [_i for _i, _l in enumerate(_lines_10) if _pred(_l)]
            report('I1c[%s]: площадка цитирования единственна' % _nm,
                   len(_hit) == 1, 'совпадений якоря: %d' % len(_hit))
            if len(_hit) != 1:
                continue
            _c = re.findall(r'[0-9]+\.[0-9]+·10⁻³',
                            chr(10).join(_lines_10[_hit[0]:_hit[0] + _win]))
            report('I1c[%s]: число процитировано в канонической форме' % _nm,
                   len(_c) >= 1, 'найдено: %s' % _c)
            if _c:
                _pub_margin(_worst, parse_art_num(_c[0]),
                            'I1c[%s]: значение цитаты "%s"' % (_nm, _c[0]))

        _cite_lines = [_l for _l in _lines_10
                       if ('g00' in _l or '644' in _l)
                       and re.search(r'[0-9]+\.[0-9]+·10⁻³', _l)]
        _cites = [_m for _l in _cite_lines
                  for _m in re.findall(r'[0-9]+\.[0-9]+·10⁻³', _l)]
        report('I1c: цитирований худшей маржи не меньше четырёх',
               len(_cites) >= 4, 'найдено %d вхождений: %s'
               % (len(_cites), _cites))
        for _i, _c in enumerate(_cites):
            _pub_margin(_worst, parse_art_num(_c),
                        'I1d[%d]: худшая маржа 644, вхождение "%s"'
                        % (_i, _c))
        _tag = _wp[0].get('box') if _wp else '?'
        _lay = _wp[0].get('layer') if _wp else '?'
        report('I1e: худший бокс — g00 на слое (0.7,0.75)',
               _tag == 'g00' and '0.7' in str(_lay) and '0.75' in str(_lay),
               'факт: %s / %s' % (_lay, _tag))
        # K-эскалация реально сработала (не мёртвый код): по 10.6 это ровно
        # 9 боксов слоя (0.55,0.90), остальные 635 проходят при K=1.
        report('I1f: K-эскалация сработала (9 боксов слоя (0.55,0.90))',
               len(_k1) == 9, 'боксов с K>1: %d (%s)'
               % (len(_k1), sorted(set(x['layer'] for x in _k1))))

# --- I2: худшее по каждому гейту --------------------------------------
_wg = _lj('worst_by_gate.json')
if _wg is None:
    report('I2: worst_by_gate.json на месте', False, 'файла нет в ' + LAYER)
else:
    # Значения берём ИЗ ТАБЛИЦЫ §10.6, а не из зашитых литералов.
    _rows = _a10_rows(u'| калитка | худшее значение')
    _tbl = {}
    for _r in _rows:
        if len(_r) < 3:
            continue
        _m = re.match(r'`([A-Za-z0-9_]+)`', _r[0])
        if _m:
            _tbl[_m.group(1)] = (_cell_num(_r[1]), _r[2])
    report('I2a: таблица гейтов §10.6 разобрана (7 строк)', len(_tbl) == 7,
           'разобрано строк: %d %s' % (len(_tbl), sorted(_tbl)))
    for _g in ('D_margin_a', 'D_margin_c', 'I1_margin_s',
               'I1_margin_W', 'I2_margin_s', 'I2_margin_W'):
        _rec = _wg.get(_g)
        if _rec is None:
            report('I2: гейт %s есть в протоколе' % _g, False, '')
            continue
        _fact = _rec['value'] if isinstance(_rec, dict) else _rec
        if _g not in _tbl or _tbl[_g][0] is None:
            report('I2: гейт %s есть в таблице §10.6' % _g, False, '')
            continue
        _pub_margin(_fact, _tbl[_g][0], 'I2: %s (из таблицы §10.6)' % _g)
        # и место (слой/бокс) тоже сверяем с протоколом
        _where = _tbl[_g][1].replace(' ', '')
        _lw = str(_rec.get('layer', '')).replace(' ', '').strip('()')
        _bw = str(_rec.get('box', ''))
        _lp = [p for p in _lw.split(',') if p]
        _ok_where = _bw in _where and all(
            (p if not p.endswith('0') else p) in _where or
            ('%.2f' % float(p)) in _where for p in _lp)
        report('I2: %s — место совпадает' % _g, _ok_where,
               'таблица "%s", протокол %s/%s' % (_tbl[_g][1], _rec.get('layer'), _bw))

    # q — диагностика, НЕ гейт: он законно > 1, и текст обязан это говорить
    _q = _wg.get('D_q')
    _qv = _q['value'] if isinstance(_q, dict) else _q
    if _qv is not None:
        report('I2q: q > 1 на широких ячейках (снятая калитка D4)', _qv > 1.0,
               'max q = %.4f' % _qv)

# --- I3: континуальная ячейка 𝔔 ---------------------------------------
_bi = _lj('cells3_bisect.json')
if _bi is None:
    report('I3: cells3_bisect.json на месте', False, 'файла нет в ' + LAYER)
else:
    _by_h = {}
    for _c in _bi:
        _h = _c.get('half_width')
        if _h is None:
            _cl = _c['cell']
            _h = round((_cl[1] - _cl[0]) / 2.0, 6)
        _by_h[round(_h, 6)] = _c
    # Маржи снимаем ИЗ ТАБЛИЦЫ «полуширина, БЕЗ калитки D4», не из литералов.
    _crows = _a10_rows(u'| полуширина, БЕЗ калитки D4')
    _ctbl = {}
    for _r in _crows:
        if len(_r) < 3:
            continue
        _hh = _cell_num(_r[0])
        if _hh is None:
            continue
        _ctbl[round(_hh, 6)] = (_r[1], _cell_num(_r[2]))
    report('I3a: таблица полуширин §10.6 разобрана (5 строк)', len(_ctbl) == 5,
           'разобрано: %s' % sorted(_ctbl))
    for _h, _exp_pass in ((0.035, True), (0.04, True), (0.045, False)):
        _c = _by_h.get(_h)
        if _c is None:
            report('I3: ячейка +-%g есть в протоколе' % _h, False, '')
            continue
        report('I3: ячейка +-%g, прошла=%s' % (_h, _exp_pass),
               bool(_c['cell_pass']) == _exp_pass,
               'n_pass=%d/46' % _c['n_pass'])
        _row = _ctbl.get(round(_h, 6))
        if _row is None:
            report('I3: строка +-%g есть в таблице §10.6' % _h, False, '')
            continue
        # число прошедших боксов из текста
        _npass_txt = _cell_num(_row[0])
        report('I3: +-%g, прошедших боксов совпадает' % _h,
               _npass_txt == _c['n_pass'],
               'таблица %s, протокол %d' % (_row[0], _c['n_pass']))
        if _exp_pass:
            if _row[1] is None:
                report('I3: маржа +-%g есть в таблице' % _h, False, '')
            else:
                _pub_margin(_c['worst_margin'], _row[1],
                            'I3: маржа +-%g (из таблицы §10.6)' % _h)

    # 𝔔 в тексте — именно ±4e-2
    report('I3: 𝔔 = (0.56, 0.64) × (0.76, 0.84) в тексте',
           '(0.56, 0.64) × (0.76, 0.84)' in _A10 or
           '(0.56,0.64)' in _A10.replace(' ', ''), '')

# --- I4: коридор ------------------------------------------------------
_co = _lj('corridor.json')
if _co is None:
    report('I4: corridor.json на месте', False, 'файла нет в ' + LAYER)
else:
    report('I4a: коридор из 7 ячеек, все прошли',
           len(_co) == 7 and all(c['cell_pass'] for c in _co),
           'ячеек %d, прошло %d' % (len(_co), sum(1 for c in _co if c['cell_pass'])))
    _ms = [c['worst_margin'] for c in _co if c.get('worst_margin') is not None]
    if _ms:
        report('I4b: маржа коридора нигде не пересекает ноль', min(_ms) > 0,
               'минимум %.4g' % min(_ms))
        # утверждение 10.13: маржа монотонно сужается к дальнему концу
        _mono = all(_ms[i + 1] <= _ms[i] * (1 + 1e-9) for i in range(len(_ms) - 1))
        report('I4c: маржа монотонно сужается по коридору', _mono,
               ' -> '.join('%.2e' % m for m in _ms))
        _cm_art = _a10_scalar(
            r'худшая маржа `([0-9.]+·10[⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)`\*\*')
        if _cm_art is None:
            report('I4d: худшая маржа коридора найдена в тексте', False, '')
        else:
            _pub_margin(min(_ms), _cm_art, 'I4d: худшая маржа коридора (из текста)')

# --- I5: перенос P -> G* (κ_G, ΔU, ΔW) --------------------------------
_kp = _lj('kappa_full.json')
if _kp is None:
    report('I5: kappa_full.json на месте', False, 'файла нет в ' + LAYER)
else:
    _base = [x for x in _kp if x['layer'] == '(0.60,0.80)']
    report('I5a: базовый слой посчитан (нужен для сверки с §6.4.3)',
           len(_base) > 0, 'записей по базе: %d' % len(_base))
    # Все три числа снимаются ИЗ ТЕКСТА §10.7 по контексту, не из литералов.
    _kb_art = _a10_scalar(r'\*\*`κ_G ≤ ([0-9.]+)`\*\*')
    if _base and _kb_art is not None:
        _pub_upper(max(x['kappa_G'] for x in _base), _kb_art,
                   'I5b: κ_G базового слоя (из текста §10.7)')
    else:
        report('I5b: κ_G базового слоя найден в тексте', _kb_art is not None, '')
    _kmax_art = _a10_scalar(r'`κ_G = ([0-9.]+)`, `ΔW =')
    _dw_art = _a10_scalar(r'`κ_G = [0-9.]+`, `ΔW = ([0-9.]+·10[⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)`')
    _km = max(x['kappa_G'] for x in _kp)
    _dw = max(x['dW'] for x in _kp)
    if _kmax_art is None or _dw_art is None:
        report('I5d: κ_G максимум и ΔW максимум найдены в тексте §10.7', False,
               'κ_G=%s, ΔW=%s' % (_kmax_art, _dw_art))
    else:
        _pub_upper(_km, _kmax_art, 'I5d: κ_G максимум (из текста §10.7)')
        _pub_upper(_dw, _dw_art, 'I5e: ΔW максимум (из текста §10.7)')
    _dwq_art = _a10_scalar(
        r'равно `([0-9.]+·10[⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)` — это худший угол')
    _cq = [x for x in _kp if x['layer'] == 'Q corner (0.64,0.84)']
    if _cq and _dwq_art is not None:
        _pub_upper(max(x['dW'] for x in _cq), _dwq_art,
                   'I5f: ΔW в худшем углу 𝔔 (из текста §10.7)')
    else:
        report('I5f: ΔW худшего угла найден в тексте', _dwq_art is not None, '')
    _g34_art = _a10_scalar(
        r'`ΔW\(\(0\.60,0\.90\), g34\) = ([0-9.]+·10[⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)`')
    _g34 = [x for x in _kp if x['layer'] == '(0.60,0.90)' and x['box'] == 'g34']
    if _g34 and _g34_art is not None:
        _pub_upper(_g34[0]['dW'], _g34_art, 'I5h: ΔW((0.60,0.90), g34) (из текста)')
    else:
        report('I5h: ΔW(g34) найден в тексте', _g34_art is not None, '')

    # ΔW > ΔU на каждой паре — утверждение 10.7
    _bad_du = [x for x in _kp if not (x['dW'] > x['dU'])]
    report('I5g: ΔW > ΔU на всех парах (множитель ℓ|U|^{ℓ−1} > 1)',
           not _bad_du, 'нарушений: %d' % len(_bad_du))

# --- I6: смена слоя доходит до DT (10.8) ------------------------------
_dt = _lj('dt_layer_probe.json')
if _dt is None:
    report('I6: dt_layer_probe.json на месте', False, 'файла нет в ' + LAYER)
else:
    _ls = _dt['layers'] if isinstance(_dt, dict) else _dt
    report('I6a: n_out = 1 на каждом слое',
           all(x['n_out'] == 1 for x in _ls),
           'слоёв %d' % len(_ls))
    # В тексте 10.8 это МАКСИМУМ ОТКЛОНЕНИЯ ОТ БАЗОВОГО значения, а не
    # полный размах max-min (тот вдвое больше: отклонения идут в обе стороны).
    _bs = [x for x in _ls if abs(x['c'] - 0.6) < 1e-12 and abs(x['r'] - 0.8) < 1e-12]
    if not _bs:
        report('I6b: базовый слой есть в dt_layer_probe', False, '')
    else:
        _dev = max(abs(x['delta'] - _bs[0]['delta']) for x in _ls)
        # Число снимается ИЗ ТЕКСТА §10.8, а не из литерала здесь: сверка
        # литерала с фактом не падает ни при какой порче статьи.
        _dev_art = _a10_scalar(r'точно: `([0-9.]+·10⁻¹⁵)`')
        if _dev_art is None:
            report('I6b: отклонение δ названо в §10.8', False, 'не нашли в тексте')
        else:
            _pub_upper(_dev, _dev_art,
                       'I6b: макс. отклонение δ от базового слоя (из текста §10.8)')
    _rd = max(x.get('rel_diff_vs_base', 0.0) for x in _ls)
    report('I6c: матрицы DT реально расходятся (не тавтология)', _rd > 0.5,
           'max отн. расхождение %.3f (в тексте 118 %%)' % _rd)
    _rd_art = _a10_scalar(r'максимум различия матриц \*\*([0-9.]+) %\*\*')
    if _rd_art is None:
        report('I6d: различие матриц названо в §10.8', False, 'не нашли в тексте')
    else:
        _pub_upper(_rd * 100, float(_rd_art),
                   'I6d: расхождение матриц, % (из текста §10.8)', tol_rel=0.02)
    _rad = max(x.get('arb_rad_max', 0.0) for x in _ls)
    report('I6e: расхождение не численный шум (радиусы шаров ничтожны)',
           _rad < 1e-60, 'max радиус %.2e' % _rad)

# --- I7: незанятые кодпойнты Unicode во всех .md ----------------------
# Свой класс дефекта: 𝔔 (фрактурная Q) — это U+1D514, а U+1D51D в том же
# блоке НЕ НАЗНАЧЕН и отрисовался бы квадратиком у каждого читателя.
try:
    import unicodedata as _ud
    _unassigned = []
    for _path in _md:
        _txt = open(_path, encoding='utf-8').read()
        for _i, _ch in enumerate(_txt):
            if ord(_ch) < 0x2000:
                continue
            try:
                _ud.name(_ch)
            except ValueError:
                _ln = _txt.count('\n', 0, _i) + 1
                _unassigned.append('%s:%d U+%04X'
                                   % (_rel(_path),
                                      _ln, ord(_ch)))
    report('I7: незанятых кодпойнтов Unicode в .md нет', not _unassigned,
           '; '.join(sorted(set(_unassigned))[:5]) or 'проверено файлов: %d' % len(_md))
except Exception as _e:
    report('I7: проверка кодпойнтов выполнилась', False, str(_e))

# --- I8: смешанные латиница/кириллица внутри слова --------------------
_mixed = []
for _path in _md:
    _txt = open(_path, encoding='utf-8').read()
    for _m in re.finditer(r'[A-Za-zА-Яа-яЁё]{3,}', _txt):
        _w = _m.group(0)
        _has_c = any('\u0400' <= _ch <= '\u04FF' for _ch in _w)
        _has_l = any(('a' <= _ch <= 'z') or ('A' <= _ch <= 'Z') for _ch in _w)
        if _has_c and _has_l:
            _ln = _txt.count('\n', 0, _m.start()) + 1
            _mixed.append('%s:%d %s' % (_rel(_path),
                                        _ln, _w))
report('I8: смешанных лат/кир слов в .md нет', not _mixed,
       '; '.join(sorted(set(_mixed))[:5]) or 'проверено файлов: %d' % len(_md))

# --- I9: рабочая хроника не просочилась в пакет -----------------------
# Осторожно: «Шаг 1..5» в §6.7 — законные шаги ДОКАЗАТЕЛЬСТВА, не хроника.
# Хроника опознаётся по составному номеру шага рабочего плана («Шаг 3.6»),
# по дате рядом, по именам моделей-ревьюеров и по именам рабочих файлов.
_chron = re.compile('|'.join([
    r'слепо(?:го|е|му) ревью', r'claude-glm', r'nemotron',
    r'Шаг[а-я]* \d+\.\d',
    r'Шаг[а-я]* \d+,\s*1[89]\.08',
    r'1[89]\.08\.2026',
    r'ЖУРНАЛ\.md', r'_fable', r'cells_fable',
    r'lemma_u_direct', r'kappa_check\.py', r'diag_all_margins',
    # Н-88: [codex-r4, 24.08] - скобочная цитата агент+дата правки,
    # оставленная самим оркестратором. Общий паттерн вместо ещё одного
    # точечного имени.
    r'\[[a-zA-Zа-яА-Я0-9_-]+,\s*\d\d?\.\d\d\]',
]))
_chron_hits = []
for _path in _md:
    _txt = open(_path, encoding='utf-8').read()
    for _m in _chron.finditer(_txt):
        _ln = _txt.count('\n', 0, _m.start()) + 1
        _chron_hits.append('%s:%d %s'
                           % (_rel(_path),
                              _ln, _m.group(0)))
report('I9: рабочей хроники (даты/имена ревьюеров/шаги плана) в .md нет',
       not _chron_hits, '; '.join(sorted(set(_chron_hits))[:5]) or 'чисто')

# Состав пакета — по манифесту: всё, чего в нём нет, пакетом не является.
_MAN_REL = []
_man_p = os.path.join(PKG, 'MANIFEST.sha256')
if os.path.isfile(_man_p):
    for _l in open(_man_p, encoding='utf-8'):
        if _l.strip() and not _l.startswith('#'):
            _MAN_REL.append(_l[66:].strip().replace(chr(92), '/'))

# --- I9b: то же самое в КОДЕ пакета -----------------------------------
# I9 сторожил только .md, и 152 строки хроники в 04-CODE прожили все круги
# незамеченными: номера находок («Н-59»), круги и раунды ревью («КРУГ 8»),
# слово «рецензент», имена моделей-агентов и имена наших рабочих документов
# (`ОТЧЁТ.md`, `ФИНАЛЬНОЕ-РЕВЬЮ-ПЛАН.md`, `ЖУРНАЛ-ПРАВОК.md`), которых в
# пакете нет вовсе. Для читателя это висячие ссылки: разрешить их нечем.
#
# ЧТО ЗДЕСЬ НЕ ЗАПРЕЩЕНО. Объяснение «почему эта строка именно такая» —
# нужное содержание, а не хроника; запрещена только АДРЕСАЦИЯ к тому, чего
# рецензент не увидит. Поэтому образцы — метки, а не слова вообще.
_chron_py = re.compile('|'.join([
    r'(?<![A-Za-zА-Яа-я])[НУСЭФПР]-\d+',
    r'(?i:рецензент)', r'РЕЦЕНЗИЯ', r'НАХОДК',
    r'(?:КРУГ|Круг|круг|волна|Волна|раунд|Раунд)\s*\d',
    # Круги нумеровались и БУКВАМИ («КРУГ J», «КРУГ N»); шаблон с цифрой их
    # пропускал, и такие метки прожили семь мест прямо в 04-CODE.
    r'(?<![А-Яа-я])(?:КРУГ|Круг)\s+[A-ZА-Я](?![a-zа-я])',
    # тот же класс, но словами: как шла проверка и как называется программа
    r'(?i:слеп\w*\s+рецензи)', r'«Ноль ошибок»',
    r'(?i:minimax|codex|sonnet|kilo)', r'\bGLM\b', r'glm-',
    r'ФИНАЛЬНОЕ-РЕВЬЮ-ПЛАН', r'НАХОДКИ\.md', r'ВОРКЛОГ',
    r'ЖУРНАЛ-ПРАВОК', r'ОТЧЁТ\.md', r'ПЕРЕДАЧА\.md', r'Программа-Ноль',
]))
_chron_py_hits = []
# Обход был ограничен `04-CODE`, а утверждение ниже говорит «в .py» — про весь
# пакет. Хроника переехала ровно за эту границу: 22 метки жили в `_manifest.py`
# и в `03-CERTIFICATES/anchor-inertia/*.py`, и сторож их не видел.
for _root, _dirs, _files in os.walk(PKG):
    _dirs[:] = [_d for _d in _dirs if _d != '__pycache__']
    for _f in sorted(_files):
        if not _f.endswith('.py'):
            continue
        _p = os.path.join(_root, _f)
        # сам этот линт держит образцы в своём тексте — его не сканируем,
        # иначе он краснеет на себе (ровно та ловушка, что была у сторожа кода)
        if os.path.basename(_p) == '_numbers_check.py':
            continue
        _txt = open(_p, encoding='utf-8', errors='replace').read()
        for _m in _chron_py.finditer(_txt):
            _ln = _txt.count('\n', 0, _m.start()) + 1
            _chron_py_hits.append('%s:%d %s' % (_rel(_p), _ln, _m.group(0)))
report('I9b: рабочей хроники (номера находок, круги, имена агентов) в .py нет',
       not _chron_py_hits,
       '; '.join(sorted(set(_chron_py_hits))[:6])
       or 'проверено .py всего пакета, упоминаний 0')

# --- I9c: абсолютных путей в пакете нет -------------------------------
# 42 таких пути прожили все круги в полях провенанса сертификатов
# (`kant_consolidated.json` и соседи): `D:/<чужая папка>/waveN/...`.
# Не ловил никто: `_refs_check.py` сверяет имена, раздел G и I9 смотрят
# только .md, I9b — только .py. Путь при этом и висячий (папки у читателя
# нет), и лишний (раскрывает раскладку чужого диска).
# Регулярка узкая нарочно: LaTeX даёт похожие куски, поэтому
# обратнослэшевая форма требует ВТОРОГО разделителя.
_abs_rx = re.compile(
    r'(?<![A-Za-z0-9])[A-Za-z]:/[^\s' + chr(34) + chr(39) + r'<>]{3,}'
    r'|(?<![A-Za-z0-9])[A-Za-z]:\[A-Za-zА-Яа-я0-9_.\-]{2,}[\/]')
_abs_hits = []
for _rel_p in _MAN_REL:
    if _rel_p.rsplit('.', 1)[-1].lower() not in ('md', 'py', 'json', 'txt', 'sh'):
        continue
    _fp = os.path.join(PKG, _rel_p)
    if not os.path.isfile(_fp):
        continue
    _txt = open(_fp, encoding='utf-8', errors='replace').read()
    for _m in _abs_rx.finditer(_txt):
        _v = _m.group(0)
        if _v.lower().startswith(('http', 'ftp')):
            continue
        _ln = _txt.count(chr(10), 0, _m.start()) + 1
        _abs_hits.append('%s:%d %s' % (_rel_p, _ln, _v[:60]))
report('I9c: абсолютных путей в файлах пакета нет', not _abs_hits,
       '; '.join(sorted(set(_abs_hits))[:6])
       or 'проверено файлов манифеста: %d' % len(_MAN_REL))

# --- I10: отношения «маржа / возмущение» ------------------------------
# Смысл: §10.6/10.7 утверждают, что маржа сертификата превосходит возмущение
# переноса P(ℓ)→G*(ℓ) во столько-то раз. Отношение считается ИЗ АРТЕФАКТОВ и
# сверяется с напечатанным. Проверка ловит ровно тот класс, который по
# отдельности незаметен: округление маржи ВВЕРХ или возмущения ВНИЗ
# завышает запас, при этом каждое число по отдельности «почти верное».
if _bi is not None and _kp is not None:
    _cq2 = [x for x in _kp if x['layer'] == 'Q corner (0.64,0.84)']
    if _cq2:
        _dw_q = max(x['dW'] for x in _cq2)
        for _h, _txt_ratio in ((0.04, '71.9'), (0.035, '375')):
            _c = None
            for _cc in _bi:
                _hh = _cc.get('half_width')
                if _hh is None:
                    _cl = _cc['cell']
                    _hh = (_cl[1] - _cl[0]) / 2.0
                if abs(_hh - _h) < 1e-9:
                    _c = _cc
            if _c is None or _c.get('worst_margin') is None:
                report('I10: ячейка +-%g для отношения найдена' % _h, False, '')
                continue
            _fact_ratio = _c['worst_margin'] / _dw_q
            _art_ratio = float(_txt_ratio)
            # напечатанное отношение не должно быть ВЫШЕ фактического
            _ok = (_art_ratio <= _fact_ratio * 1.005) and \
                  (abs(_art_ratio - _fact_ratio) <= 0.02 * _fact_ratio)
            report('I10: отношение маржа/ΔW на +-%g' % _h, _ok,
                   'факт %.1f, статья %s' % (_fact_ratio, _txt_ratio))
            report('I10: отношение "%s" напечатано в §10' % _txt_ratio,
                   _txt_ratio in _A10, '')

# --- чем замкнут якорь теоремы B ---------------------------------
#     §4.7 замыкает цепочку через ПРАВУЮ часть равенства переноса: инерция
#     считается для матрицы, собранной по ТОМУ ЖЕ интерполянту, что и вся
#     трубка.  Если якорный скрипт когда-нибудь начнёт строить матрицу из
#     другого объекта (например из численного центра точечного
#     сертификата), замыкание молча потребует неопубликованного
#     отождествления — ровно эта дыра и была здесь.
_anch = os.path.join(PKG, '03-CERTIFICATES', 'anchor-inertia',
                     '_anchor_check.py')
try:
    _anch_txt = open(_anch, encoding='utf-8').read()
except Exception as _e:
    _anch_txt = ''
    report('_anchor_check.py читается', False, repr(_e))
if _anch_txt:
    _ok55 = ('hr.load_box(3.0' in _anch_txt
             and 'hr.rl.P_at(' in _anch_txt
             and 'hr.dt_from_pkg(' in _anch_txt)
    report('якорная матрица строится из интерполянта P(3), а не из '
           'иного объекта', _ok55,
           'ожидались load_box(3.0 ...) -> P_at -> dt_from_pkg')
    report('якорь замыкается через правую часть (нет ссылки на §5.2 '
           'как на звено)',
           'левая часть при ℓ=3\nизвестна из §5.2' not in art_text,
           'в §4.7 не должно остаться замыкания через точечный сертификат')

# --- узел «от проекции 80x80 к полному оператору» (§4.5-4.6) ----
#     §4.6 систематически читался как недоказанный шаг:
#     деление `‖C‖ ≤ Z1b/B_A` из блочной алгебры не следует (контрпример
#     Ã=diag(100,0.01)).  Оно законно ровно потому, что множители B_A и
#     (1+B_A) внесены в САМО определение Z1b/Z1c.  Запираем три вещи:
#     определение в коде, тождество на артефактах и то, что максимум
#     нормы M' берётся на головной ветви.
_r2f = os.path.join(os.path.dirname(HERE), 'rig2fix3.py')
try:
    _r2f_txt = open(_r2f, encoding='utf-8').read()
except Exception as _e:
    _r2f_txt = ''
    report('rig2fix3.py читается', False, repr(_e))
if _r2f_txt:
    report('множители на месте и в σ-пути (диагностика)',
           'Z1b = (B_A * max_tail_prime)' in _r2f_txt
           and 'Z1c = ((1 + B_A) * (beta_Np1' in _r2f_txt,
           'rig2fix3.sigma_tails_full — ВТОРОЙ, диагностический путь')
# в сертификат идут значения из tube_lib.compute_Z1
#     (rig2fix3._z1bc_subdivided -> tl.compute_Z1), а не из σ-пути.
#     Сторожить надо тот путь, которым считают, иначе проверка холостая:
#     ровно здесь и была ошибка первой версии правки.
_tlb_p = os.path.join(os.path.dirname(HERE), 'tube_lib.py')
try:
    _tlb = open(_tlb_p, encoding='utf-8').read()
except Exception as _e:
    _tlb = ''
    report('tube_lib.py читается', False, repr(_e))
if _tlb:
    report('Z1b в ИСПОЛЬЗУЕМОМ пути = B_A · (масса блока C)',
           'Z1b = A_norm1_arb * max_tail_prime' in _tlb,
           'tube_lib.compute_Z1 — путь, значения которого идут в сертификат')
    report('Z1c в ИСПОЛЬЗУЕМОМ пути = (1 + B_A) · (масса блока [B;D])',
           'Z1c = (arb(1) + A_norm1_arb) * (beta_Np1' in _tlb,
           'без множителя внутри деление Z1c/(1+B_A) в §4.6 незаконно')
    report('β₀* строится от M_e − I, то есть от DT, а не от M′',
           'diff_e0 = [M_e[j][0] - (arb(1) if j == 0 else arb(0))' in _tlb,
           'именно здесь единица сокращается; иначе хвост нёс бы 1')
    # Прежняя проверка искала размер M_prime,
    #     а контракт — про Ã. Сторожим именно A_tilde: он N_p×N_p, то есть
    #     головной, а вне головы продолжение тождественное.
    report('Ã строится только на голове (Ã_full = Ã_head ⊕ I_tail)',
           'A_tilde = np.zeros((N_p, N_p))' in _tlb
           and 'A_tilde[:, col] = x_col' in _tlb,
           'на этом держится вывод (ii) и (iii) из §4.6')
_offs_p = OFFS          # именно OFFS: иначе HYP_OFFSETS не действует на эту проверку
try:
    _offs = json.load(open(_offs_p, encoding='utf-8'))
except Exception as _e:
    _offs = None
if not _offs:
    report('offsets.json на месте', False, 'нет ' + _offs_p)
else:
    _bad_id, _bad_dom, _n54 = [], [], 0
    for _bx, _rec in sorted(_offs.items()):
        try:
            _ba = float(_rec['B_A'])
            _z1b, _z1c = float(_rec['Z1b']), float(_rec['Z1c'])
            _cn, _bd = float(_rec['C_norm']), float(_rec['BD_norm'])
            _mf = float(_rec['Mprime_full'])
        except Exception:
            _bad_id.append('%s: нет полей' % _bx)
            continue
        _n54 += 1
        for _got, _want, _nm in ((_cn, _z1b / _ba, 'C_norm=Z1b/B_A'),
                                 (_bd, _z1c / (1.0 + _ba),
                                  'BD_norm=Z1c/(1+B_A)')):
            if abs(_got - _want) > 1e-5 * max(abs(_want), 1e-300):
                _bad_id.append('%s %s: %.9g vs %.9g' % (_bx, _nm, _got, _want))
        if not (_mf >= 1.0 + _bd):
            _bad_dom.append('%s: Mprime_full=%.9g < 1+BD=%.9g'
                            % (_bx, _mf, 1.0 + _bd))
    report('тождество извлечения блоков на всех %d боксах' % _n54,
           not _bad_id and _n54 > 0, '; '.join(_bad_id[:4]) or 'сходится')
    report('максимум ‖M′‖ берётся на головной ветви (§4.5)',
           not _bad_dom and _n54 > 0, '; '.join(_bad_dom[:4]) or 'везде')
    # Прежняя проверка Mprime_full >= 1+BD_norm
    #     слаба — она верна и тогда, когда max взят не на той ветви.
    #     Проверяем РАВЕНСТВО реализации и отдельно доминирование головы.
    _bad_impl, _bad_head = [], []
    for _bx, _rec in sorted(_offs.items()):
        try:
            _mh = float(_rec['Mprime_norm'])
            _mf = float(_rec['Mprime_full'])
            _cn = float(_rec['C_norm'])
            _bd = float(_rec['BD_norm'])
        except Exception:
            continue
        _head, _tail = _mh + _cn, 1.0 + _bd
        if abs(_mf - max(_head, _tail)) > 1e-9 * max(abs(_mf), 1.0):
            _bad_impl.append('%s: %.12g vs max(%.12g, %.12g)'
                             % (_bx, _mf, _head, _tail))
        if not (_head >= _tail):
            _bad_head.append('%s: голова %.12g < хвост %.12g'
                             % (_bx, _head, _tail))
    report('Mprime_full = max(голова+‖C‖, 1+‖[B;D]‖) — равенство '
           'реализации', not _bad_impl, '; '.join(_bad_impl[:3]) or 'сходится')
    report('головная ветвь доминирует на всех боксах (утверждение §4.5)',
           not _bad_head, '; '.join(_bad_head[:3]) or 'везде')
    # Обе проверки выше сравнивают offsets.json САМ С СОБОЙ: и `C_norm`, и
    # `Z1b`, и `B_A` берутся из одной записи одного файла.  Поэтому
    # рассинхронизация offsets.json с сертификатами боксов ими не ловится:
    # `L`, `Z1`, `ρ*_b` можно испортить в offsets.json, и ни одни ворота не
    # заметят, хотя `extra` монотонно растёт по ним и заниженное `extra`
    # делает полный тест Руше ЛЕГЧЕ.  Здесь: (1) девять полей-копий
    # сверяются с box_g##.json на точное равенство; (2) `C_norm`, `BD_norm`,
    # `Mprime_full` и `extra` пересчитываются по формулам tube_offset.py из
    # полей СЕРТИФИКАТА, и записанное обязано быть не меньше пересчитанного
    # (все четыре — мажоранты).  Дорогая величина `Mprime_norm` (столбцовая
    # норма головы) сюда не пересчитывается: она берётся из offsets.json как
    # есть, и это остаётся признанной дырой.
    _off_copy, _off_calc, _off_n = [], [], 0
    try:
        sys.path.insert(0, os.path.join(PKG, '04-CODE'))
        import hyp_rouche as _ohr
        from flint import arb as _oa, ctx as _octx
        _oprec = _octx.prec
        _octx.prec = 256
        _EXD = CERTS
        for _bx, _rec in sorted(_offs.items()):
            _bf = os.path.join(_EXD, 'box_%s.json' % _bx)
            if not os.path.exists(_bf):
                _off_copy.append('%s: нет box_%s.json' % (_bx, _bx))
                continue
            _j = json.load(open(_bf, encoding='utf-8'))
            _off_n += 1
            for _k in ('ell0', 'w', 'Z1', 'B_A', 'Z1b', 'Z1c'):
                if float(_rec[_k]) != float(_j[_k]):
                    _off_copy.append('%s.%s: %r vs %r'
                                     % (_bx, _k, _rec[_k], _j[_k]))
            for _k in ('L', 'rho_prime', 'rho_star_b'):
                if float(_rec[_k]) != float(_j['best'][_k]):
                    _off_copy.append('%s.best.%s: %r vs %r'
                                     % (_bx, _k, _rec[_k], _j['best'][_k]))
            _oZ1, _oBA = _oa(_j['Z1']), _oa(_j['B_A'])
            _oBAlo = _oa(_j['B_A_lo'])
            _oL, _ors = _oa(_j['best']['L']), _oa(_j['best']['rho_star_b'])
            _oc = _ohr.up_float(_oa(_j['Z1b']) / _oBAlo)
            _ob = _ohr.up_float(_oa(_j['Z1c']) / (1 + _oBAlo))
            _omf = max(_ohr.up_float(_oa(_rec['Mprime_norm']) + _oa(_oc)),
                       _ohr.up_float(_oa(1) + _oa(_ob)))
            _oex = _ohr.up_float((_oa(_omf) / (1 - _oZ1)) * _oa('3.0625')
                                 * _oBA * _oL * _ors)
            for _nm, _mine, _got in (('C_norm', _oc, _rec['C_norm']),
                                     ('BD_norm', _ob, _rec['BD_norm']),
                                     ('Mprime_full', _omf, _rec['Mprime_full']),
                                     ('extra', _oex, _rec['extra'])):
                if not (float(_got) >= _mine):
                    _off_calc.append('%s.%s: записано %.12g < пересчёт %.12g'
                                     % (_bx, _nm, float(_got), _mine))
        _octx.prec = _oprec
    except Exception as _e:
        _off_copy.append('исключение: %s' % _e)
    report('offsets.json: девять полей-копий совпадают с box_g##.json '
           'точно (%d боксов)' % _off_n,
           not _off_copy and _off_n > 0, '; '.join(_off_copy[:4]) or 'все совпали')
    report('offsets.json: extra/‖C‖/‖[B;D]‖/‖M′‖_full не занижены против '
           'пересчёта из сертификата',
           not _off_calc and _off_n > 0,
           '; '.join(_off_calc[:4]) or 'записанное >= пересчитанного везде')
# текстовый замок идентичности. §4.6 систематически читался
#     как ложный шаг именно из-за подписи блочной матрицы буквой M′.
#     Возврат такой подписи — в статью или в докстринги — обязан краснеть.
# линт расширен. Первая версия запрещала только ПОДПИСЬ блочной
#     матрицы буквой M′, поэтому «возмущение M′ − S» и «хвостовой столбец
#     M′» прошли зелёными; расширенная версия ловит и их.
_zapret = ['M′ = [[A,B],[C,D]]', 'M′ = [[A, B],[C, D]]',
           'M′ = [ A  B ]', "M' = [[A,B],[C,D]]",
           'M′ − S', "M' - S", 'M′ - S',
           'хвостового столбца `M′`', 'хвостовой столбец M′',
           'хвостовые столбцы M′',
           'Σ_j |M′_jk| <= ‖[B;D]‖₁', 'максимум с нормой хвостовых '
           'столбцов `‖[B;D]‖₁`']
_hits_z = [z for z in _zapret if z in art_text]
for _f in ('tube_accept.py', 'tube_offset.py'):
    try:
        _tt = open(os.path.join(os.path.dirname(HERE), _f),
                   encoding='utf-8').read()
    except Exception:
        continue
    _hits_z += ['%s: %s' % (_f, z) for z in _zapret if z in _tt]
report('блочная матрица нигде не подписана M′ (только DT)',
       not _hits_z, '; '.join(_hits_z[:3]) or 'чисто')

# --- I12: сверка двух реализаций марж I1/I2 ---------------------------
_cc = _lj('crosscheck.json')
if _cc is None:
    report('I12: crosscheck.json на месте', False, 'файла нет в ' + LAYER)
else:
    # Число берётся ИЗ ТЕКСТА §10.9: расхождение — мажоранта, публикуется вверх.
    _cc_art = _a10_scalar(r'расхождением `≤([0-9.]+)·10⁻³`')
    if _cc_art is None:
        report('I12a: расхождение сверки названо в §10.9', False,
               'не нашли число в тексте')
    else:
        _cc_w = _cc.get('worst_rel', 1.0)
        report('I12a: две реализации марж I1/I2 согласованы (≤%s·10⁻³ по §10.9)'
               % _cc_art,
               bool(_cc.get('ok')) and _cc_w <= float(_cc_art) * 1e-3,
               'пар %s, худшее отн. расхождение %.3g'
               % (_cc.get('pairs'), _cc_w))
        # Одного «текст ≥ факта» мало: порог брался ИЗ ТЕКСТА,
        # и синхронный сдвиг обоих (4.16 → 4.17 при том же артефакте) тест
        # проходил — что и было продемонстрировано.  Требуем,
        # чтобы напечатанное было ТЕСНЫМ округлением вверх до трёх значащих:
        # тогда свободы «поставить любое большее число» не остаётся.
        _ulp = 1e-5          # единица последнего знака у 4.16·10⁻³
        report('I12a-tight: порог §10.9 — тесное округление ВВЕРХ от '
               'crosscheck.json::worst_rel',
               float(_cc_art) * 1e-3 < _cc_w + _ulp,
               'текст %s·10⁻³, факт %.6g·10⁻³, запас %.3g·10⁻³'
               % (_cc_art, _cc_w * 1e3, float(_cc_art) - _cc_w * 1e3))
        # Маржи _s полином не трогают, и обе стороны считают их ОДНИМ И ТЕМ
        # ЖЕ выражением над одним и тем же A: в arb оператор степени при
        # неточном показателе — это и есть exp(y·log x), а показатель здесь
        # интервал.  Значит ноль тут ТОЖДЕСТВО, а не измерение (круг 70), и
        # проверять надо именно тождество: иначе ноль читается как согласие
        # двух дорог, которых нет.
        _pow_same, _pow_bad = True, []
        try:
            import numpy as _np
            from flint import arb as _pa, ctx as _pctx
            _pprec_save = _pctx.prec
            _pctx.prec = 256
            sys.path.insert(0, os.path.join(PKG, '04-CODE'))
            import rig_lib as _prl
            _BRD = os.environ.get(
                'HYP_BRANCHES', os.path.join(PKG, '03-CERTIFICATES', 'branches'))
            for _tag in sorted(set(r['box'] for r in _cc.get('rows', []))):
                _z = _np.load(os.path.join(_BRD, 'branch_%s.npz' % _tag))
                _e0, _w = float(_z['ell0'][0]), float(_z['w'][0])
                _P = _prl.P_at_interval(
                    _z['c_a'], int(_z['m'][0]),
                    _pa('%.17e' % -1.0).union(_pa('%.17e' % 1.0)))
                _g1 = _pa(0)
                for _k in range(len(_P)):
                    _g1 = _g1 + _P[_k]
                _ell = _pa('%.17e' % (_e0 - _w / 2.0)).union(
                    _pa('%.17e' % (_e0 + _w / 2.0)))
                _bs = -_pa(1) / _g1
                _A1, _A2 = _bs ** (-_ell), (_bs.log() * (-_ell)).exp()
                if not (_A1.mid() == _A2.mid() and _A1.rad() == _A2.rad()):
                    _pow_same = False
                    _pow_bad.append(_tag)
            _pctx.prec = _pprec_save
        except Exception as _e:
            _pow_same = False
            _pow_bad.append('исключение: %s' % _e)
        report('I12c: ноль по маржам _s — ТОЖДЕСТВО, а не измерение '
               '(A обеими дорогами совпадает бит в бит)',
               _pow_same and _cc.get('worst_rel_s', 1.0) == 0.0,
               'worst_rel_s = %s; расхождения A: %s'
               % (_cc.get('worst_rel_s'), _pow_bad or 'нет'))
    # §10.9 обязан честно оговаривать, что это НЕ проверка арифметики
    _honest = ('не** проверка самой' in _A10) or ('не проверка самой' in _A10)
    report('I12b: §10.9 оговаривает границы этой сверки', _honest,
           'ищем оговорку про одну библиотеку/схему заключения дуги')

# --- I13: верхняя таблица §10.6 (исторические режимы) -----------------
# Строки этой таблицы получены в режимах LAYER_PKG_LEMMA / LAYER_GATE_D4 и
# до появления cells3_hist.json прослеживались только до текста. Сверяем
# позиционно: и артефакт, и таблица идут в одном порядке (старая lemma_U,
# затем мономиальная по возрастанию полуширины), количество строк сверяется.
_hist = _lj('cells3_hist.json')
if _hist is None:
    report('I13: cells3_hist.json на месте', False, 'файла нет в ' + LAYER)
else:
    # Строки берём ТОЛЬКО из таблицы под этим заголовком: в §10.6 есть
    # и другая таблица с ячейками, и по маске '| `±' они смешивались.
    _hlines = _A10.split(chr(10))
    _hi = next((i for i, l in enumerate(_hlines)
                if l.startswith('| ячейка (полуширина вокруг')), None)
    _hrows = []
    if _hi is not None:
        for l in _hlines[_hi + 2:]:
            if not l.startswith('|'):
                break
            _hrows.append(l)
    report('I13a: строк таблицы §10.6 столько же, сколько в протоколе',
           len(_hrows) == len(_hist),
           'в тексте %d, в протоколе %d' % (len(_hrows), len(_hist)))
    if len(_hrows) == len(_hist):
        for _i, (_line, _fact) in enumerate(zip(_hrows, _hist)):
            _c = [x.strip() for x in _line.strip('|').split('|')]
            if len(_c) < 5:
                report('I13[%d]: строка таблицы разобрана' % _i, False, _line[:60])
                continue
            _np = re.search(r'(\d+)\s*/\s*46', _c[1])
            _mm = re.search(r'([0-9][0-9.]*(?:·10⁻[⁰¹²³⁴⁵⁶⁷⁸⁹]+)?)', _c[2])
            _bx = re.search(r'\((\w+)\)', _c[2])
            _qq = re.search(r'([0-9][0-9.]*)', _c[3])
            _tag = 'h=%g%s' % (_fact['half_width'],
                               ', старая lemma_U' if _fact['pkg_lemma'] else '')
            if not (_np and _mm and _bx and _qq):
                report('I13[%s]: строка разобрана' % _tag, False, _line[:70])
                continue
            report('I13[%s]: прошло боксов' % _tag,
                   int(_np.group(1)) == _fact['n_pass'],
                   'текст %s, факт %d' % (_np.group(1), _fact['n_pass']))
            report('I13[%s]: худший бокс' % _tag,
                   _bx.group(1) == _fact['worst_box'],
                   'текст %s, факт %s' % (_bx.group(1), _fact['worst_box']))
            try:
                _mv = parse_art_num(_mm.group(1))
            except Exception:
                _mv = None
            report('I13[%s]: маржа опубликована ВНИЗ' % _tag,
                   _mv is not None and _mv <= _fact['worst_margin'],
                   'текст %s, факт %.6e' % (_mm.group(1), _fact['worst_margin']))
            report('I13[%s]: q_max опубликован ВВЕРХ' % _tag,
                   float(_qq.group(1)) >= _fact['q_max'],
                   'текст %s, факт %.6f' % (_qq.group(1), _fact['q_max']))
        # ровно одна строка обязана провалиться — иначе таблица не показывает
        # границу, ради которой она и приведена
        _nfail = sum(1 for r in _hist if r['n_pass'] < 46)
        report('I13b: таблица доходит до провала (граница найдена)',
               _nfail >= 1, 'провалившихся ячеек: %d' % _nfail)

# --- I11: строки таблицы полуширин ------------------------------------
_hw = _lj('cells3_hw.json')
if _hw is None:
    report('I11: cells3_hw.json на месте', False, 'файла нет в ' + LAYER)
else:
    _rows2 = {}
    for _c in _hw:
        _h = _c.get('half_width')
        if _h is None:
            _cl = _c['cell']
            _h = (_cl[1] - _cl[0]) / 2.0
        _rows2[round(_h, 6)] = _c
    for _h in (0.02, 0.03):
        _c = _rows2.get(round(_h, 6))
        if _c is None:
            report('I11: строка +-%g есть в протоколе' % _h, False, '')
            continue
        report('I11: +-%g прошла 46/46' % _h, _c['n_pass'] == 46, '')
        _row = _ctbl.get(round(_h, 6)) if '_ctbl' in dir() else None
        if _row is None or _row[1] is None:
            report('I11: маржа +-%g есть в таблице §10.6' % _h, False, '')
        else:
            _pub_margin(_c['worst_margin'], _row[1],
                        'I11: маржа +-%g (из таблицы §10.6)' % _h)
    # первая провалившаяся при поиске границы
    _fail = [(_h, _c) for _h, _c in _rows2.items() if not _c['cell_pass']]
    report('I11: поиск границы дошёл до провала', bool(_fail),
           'первая провалившаяся полуширина: %s'
           % (('%g' % min(h for h, _ in _fail)) if _fail else 'нет'))

# --- I14: колонка q_max таблицы §10.6 (БЕЗ калитки D4) ----------------
# Это мажоранта, значит публикуется ВВЕРХ.  До круга 5 колонку не проверял
# никто: I11 брал только маржу и только на двух полуширинах, а q_max в
# двух строках из пяти был округлён ВНИЗ (1.296 при 1.2963602 и 1.222 при
# 1.2222306).
_q_facts = {}
for _fn in ('cells3_hw.json', 'cells3_bisect.json'):
    _js = _lj(_fn)
    if not _js:
        continue
    for _c in _js:
        _h = _c.get('half_width')
        if _h is None:
            _cl = _c['cell']
            _h = (_cl[1] - _cl[0]) / 2.0
        _qs = [_b['worst']['D_q'] for _b in _c['boxes'].values()
               if isinstance(_b, dict) and 'worst' in _b
               and 'D_q' in _b['worst']]
        if _qs:
            _q_facts[round(_h, 6)] = max(_qs)

_qlines = _A10.split(chr(10))
_qi = next((i for i, l in enumerate(_qlines)
            if l.startswith('| полуширина, БЕЗ калитки D4')), None)
report('I14: таблица §10.6 «без калитки D4» найдена', _qi is not None, '')
if _qi is not None:
    _qrows = []
    for l in _qlines[_qi + 2:]:
        if not l.startswith('|'):
            break
        _qrows.append([x.strip() for x in l.strip('|').split('|')])
    report('I14a: строк в таблице', len(_qrows) == 5,
           'разобрано %d' % len(_qrows))
    _seen_q = 0
    for _r in _qrows:
        if len(_r) < 4:
            continue
        _h = _cell_num(_r[0])
        _qm = re.search(r'([0-9][0-9.]*)', _r[3])
        if _h is None or not _qm:
            report('I14: строка разобрана', False, ' | '.join(_r)[:70])
            continue
        _fact = _q_facts.get(round(_h, 6))
        if _fact is None:
            report('I14: для +-%g есть протокол' % _h, False,
                   'ни в cells3_hw, ни в cells3_bisect')
            continue
        _seen_q += 1
        report('I14: q_max +-%g опубликован ВВЕРХ' % _h,
               float(_qm.group(1)) >= _fact,
               'текст %s, факт %.7f' % (_qm.group(1), _fact))
    report('I14b: колонка q_max проверена целиком', _seen_q == 5,
           'сверено строк: %d из 5' % _seen_q)

# --- I15: таблица §10.7 (κ_G, ΔU, ΔW по выборочным боксам) -------------
# Все три величины — возмущения/мажоранты, публикуются ВВЕРХ.  До круга 5
# таблицу не сторожил никто, и три из четырёх строк были округлены внутрь.
_kf = _lj('kappa_full.json')
if not _kf:
    report('I15: kappa_full.json на месте', False, 'файла нет в ' + LAYER)
else:
    _base = dict((_r['box'], _r) for _r in _kf
                 if _r.get('layer') == '(0.60,0.80)')
    report('I15: базовый слой есть в kappa_full', bool(_base),
           'боксов: %d' % len(_base))
    _klines = _A10.split(chr(10))
    _ki = next((i for i, l in enumerate(_klines)
                if l.startswith('| бокс | ℓ | `κ_G`')), None)
    report('I15a: таблица §10.7 найдена', _ki is not None, '')
    if _ki is not None and _base:
        _n_k = 0
        for l in _klines[_ki + 2:]:
            if not l.startswith('|'):
                break
            _c = [x.strip() for x in l.strip('|').split('|')]
            if len(_c) < 5 or _c[0] not in _base:
                report('I15: строка разобрана', False, l[:70])
                continue
            _f = _base[_c[0]]
            _n_k += 1
            for _col, _key, _nm in ((2, 'kappa_G', 'κ_G'),
                                    (3, 'dU', 'ΔU'), (4, 'dW', 'ΔW')):
                try:
                    _pub = parse_art_num(_c[_col])
                except Exception:
                    report('I15[%s]: %s разобрано' % (_c[0], _nm), False,
                           _c[_col][:30])
                    continue
                report('I15[%s]: %s опубликовано ВВЕРХ' % (_c[0], _nm),
                       _pub >= _f[_key],
                       'текст %s, факт %.9g' % (_c[_col], _f[_key]))
        report('I15b: все строки таблицы §10.7 сверены', _n_k == 4,
               'сверено строк: %d' % _n_k)

# --- I16: два диапазона вне §10, которые не сторожил никто -------------
# у диапазона концы направляются в РАЗНЫЕ стороны — нижний вниз,
# верхний вверх, — и оба были округлены внутрь: `‖M′_head‖ [6.35, 18.65]`
# при факте [6.346523, 18.652444] и нижний конец λ₂ 0.1600 при 0.1599709924.
_ART_ALL = open(ART, encoding='utf-8').read()

try:
    _off = json.load(open(OFFS, encoding='utf-8'))
except Exception as _e:
    _off = None
    report('I16: offsets.json читается', False, str(_e)[:60])
if _off:
    _mn = min(r['Mprime_norm'] for r in _off.values())
    _mx = max(r['Mprime_norm'] for r in _off.values())
    _m = re.search(r'‖M′_head‖ ∈ \[([0-9.]+), ([0-9.]+)\]', _ART_ALL)
    report('I16: диапазон ‖M′_head‖ найден в §4.5', _m is not None, '')
    if _m:
        report('I16: ‖M′_head‖ нижний конец ВНИЗ', float(_m.group(1)) <= _mn,
               'текст %s, факт %.6f' % (_m.group(1), _mn))
        report('I16: ‖M′_head‖ верхний конец ВВЕРХ', float(_m.group(2)) >= _mx,
               'текст %s, факт %.6f' % (_m.group(2), _mx))

_lam, _del = [], []
for _p in glob.glob(os.path.join(TUBE, 'box_t*.json')):
    try:
        _j = json.load(open(_p, encoding='utf-8'))
    except Exception:
        continue
    if 'lam2_mid' in _j:
        _lam.append(_j['lam2_mid'])
    if 'delta_mid' in _j:
        _del.append(_j['delta_mid'])
report('I16: боксы трубки прочитаны', len(_lam) > 700,
       'боксов с lam2_mid: %d' % len(_lam))
if _lam and _del:
    _m2 = re.search(r'`δ\(ℓ\)` пробегает \[([0-9.]+), ([0-9.]+)\], '
                    r'`λ₂\(ℓ\)` — \[([0-9.]+), ([0-9.]+)\]', _ART_ALL)
    report('I16: диапазоны δ и λ₂ найдены в §4.8', _m2 is not None, '')
    if _m2:
        for _lo, _hi, _vals, _nm in ((_m2.group(1), _m2.group(2), _del, 'δ'),
                                     (_m2.group(3), _m2.group(4), _lam, 'λ₂')):
            report('I16: %s нижний конец ВНИЗ' % _nm,
                   float(_lo) <= min(_vals),
                   'текст %s, факт %.10f' % (_lo, min(_vals)))
            report('I16: %s верхний конец ВВЕРХ' % _nm,
                   float(_hi) >= max(_vals),
                   'текст %s, факт %.10f' % (_hi, max(_vals)))

# --- I17: посылка а9 против holo_radius.json ---------------------------
_POINT = os.environ.get('HYP_POINTWISE',
                        os.path.join(PKG, '03-CERTIFICATES', 'pointwise'))
_hr_p = os.path.join(_POINT, 'holo_radius.json')
if not os.path.exists(_hr_p):
    report('I17: holo_radius.json на месте', False, 'нет ' + _hr_p)
else:
    _hr = json.load(open(_hr_p, encoding='utf-8'))
    report('I17: протокол по всем 46 боксам', _hr['n_boxes'] == 46,
           'боксов в протоколе: %d' % _hr['n_boxes'])
    _m = re.search(r'\\hat q\\le([0-9.]+)<1', _ART_ALL)
    report('I17: `q̂ ≤ …` найдено в посылке а9', _m is not None, '')
    if _m:
        report('I17: q̂ опубликовано ВВЕРХ',
               float(_m.group(1)) >= _hr['q_hat_max'],
               'текст %s, факт %.10f (бокс %s)'
               % (_m.group(1), _hr['q_hat_max'], _hr['q_hat_max_box']))
    # Границ |G(1)| в статье четыре (0.393 — m1, 0.3963 — _nozeros_check,
    # 0.3987 — _kappaG_bound, 0.396279 — посылка а9).  Нужна ИМЕННО а9,
    # поэтому якорь по слову «отделённость», а не первое совпадение.
    _m = re.search(r'отделённость \$\\lvert G\(1\)\\rvert\\ge([0-9.]+)\$', _ART_ALL)
    report('I17: `|G(1)| ≥ …` найдено в посылке а9', _m is not None, '')
    if _m:
        report('I17: |G(1)| опубликовано ВНИЗ',
               float(_m.group(1)) <= _hr['g1_min'],
               'текст %s, факт %.12f (бокс %s)'
               % (_m.group(1), _hr['g1_min'], _hr['g1_min_box']))
    report('I17: R_G в протоколе тот же, что публикуется',
           abs(_hr['R_G'] - 1.75e-07) < 1e-20,
           'в протоколе %.6e' % _hr['R_G'])
    report('I17: R_G строго больше худшего ρ*_X',
           _hr['R_G'] > _hr['rho_X_max_field'],
           'R_G=%.4e, max ρ*_X=%.7e (бокс %s)'
           % (_hr['R_G'], _hr['rho_X_max_field'], _hr['rho_X_max_box']))
    _m = re.search(r'худший `ρ\*_X` — с `[0-9.·⁻¹⁰²³⁴⁵⁶⁷⁸⁹]+` на '
                   r'`([0-9.]+)·10⁻¹³`', _ART_ALL)
    if _m:
        report('I17: худший ρ*_X опубликован ВВЕРХ',
               float(_m.group(1)) * 1e-13 >= _hr['rho_X_max_field'],
               'текст %s·10⁻¹³, факт %.7e'
               % (_m.group(1), _hr['rho_X_max_field']))
    # Всё выше сверяет текст со СВОДНЫМИ полями, а сводка ниоткуда не
    # пересчитывается: испортив `boxes.g43.q_hat` и не тронув `q_hat_max`,
    # мимо всех ворот можно провести любой бокс.  Пересчитываем сводку из
    # 46 записей того же файла.
    _hb = _hr.get('boxes') or {}
    _sum_bad = []
    for _fld, _key, _agg in (('q_hat_max', 'q_hat', max),
                             ('g1_min', 'g1_lo', min),
                             ('kap_U_max', 'kap_U', max)):
        _vals = [float(_v[_key]) for _v in _hb.values() if _key in _v]
        if not _vals:
            _sum_bad.append('%s: нет записей по боксам' % _fld)
        elif float(_hr[_fld]) != _agg(_vals):
            _sum_bad.append('%s: сводка %.17g, по боксам %.17g'
                            % (_fld, float(_hr[_fld]), _agg(_vals)))
    if len(_hb) != _hr.get('n_boxes'):
        _sum_bad.append('n_boxes=%r, записей %d' % (_hr.get('n_boxes'), len(_hb)))
    report('I17-свод: сводка holo_radius.json пересчитывается из 46 записей '
           'того же файла', not _sum_bad, '; '.join(_sum_bad[:3]) or 'сходится')
    # κ_U публикуется дважды (§3.6 «≤ 0.39» и §6.5 п.5 «≤ 0.363184») со
    # ссылкой на поле `kap_U_max`, и до сих пор не сверялся НИЧЕМ: grep по
    # сторожам пакета давал ноль вхождений.  При этом на κ_U < 1 держится
    # однозначность главной ветви `Log U`, то есть законность всего перехода
    # к степеням.
    _kap = _hr.get('kap_U_max')
    report('I17-κ_U: kap_U_max < 1 (однозначность главной ветви Log U)',
           _kap is not None and float(_kap) < 1.0,
           'kap_U_max = %r' % _kap)
    _kap_txt = re.findall(r'`κ_U ≤ ([0-9.]+)`', _ART_ALL)
    report('I17-κ_U: обе публикации κ_U найдены в тексте',
           len(_kap_txt) >= 2, 'нашли: %s' % _kap_txt)
    if _kap is not None and _kap_txt:
        _kbad = [t for t in _kap_txt if not (float(t) >= float(_kap))]
        report('I17-κ_U: каждое опубликованное κ_U — мажоранта kap_U_max',
               not _kbad, 'факт %.12f; не мажорируют: %s'
               % (float(_kap), _kbad or 'нет'))

# --- I18: таблица §3.7 против tau_share.json ---------------------------
_ts_p = os.path.join(_POINT, 'tau_share.json')
if not os.path.exists(_ts_p):
    report('I18: tau_share.json на месте', False, 'нет ' + _ts_p)
else:
    _ts = json.load(open(_ts_p, encoding='utf-8'))['boxes']
    _tl = _ART_ALL.split(chr(10))
    _ti = next((i for i, l in enumerate(_tl)
                if l.startswith('| бокс | ℓ₀ | Z1_τ / Z1')), None)
    report('I18: таблица §3.7 найдена', _ti is not None, '')
    if _ti is not None:
        _n18 = 0
        for l in _tl[_ti + 2:]:
            if not l.startswith('|'):
                break
            _c = [x.strip() for x in l.strip('|').split('|')]
            if len(_c) < 4 or _c[0] not in _ts:
                report('I18: строка разобрана', False, l[:70])
                continue
            _f = _ts[_c[0]]
            _n18 += 1
            try:
                _sh = parse_art_num(_c[2])
            except Exception:
                _sh = None
            report('I18[%s]: доля Z1_τ/Z1 опубликована ВВЕРХ' % _c[0],
                   _sh is not None and _sh >= _f['Z1_tau_over_Z1'],
                   'текст %s, факт %.6e' % (_c[2], _f['Z1_tau_over_Z1']))
            _bm = re.search(r'([0-9.]+)·10([⁰¹²³⁴⁵⁶⁷⁸⁹]+)', _c[3])
            if not _bm:
                report('I18[%s]: множитель разобран' % _c[0], False, _c[3][:40])
                continue
            _sup = '⁰¹²³⁴⁵⁶⁷⁸⁹'
            _pw = int(''.join(str(_sup.index(ch)) for ch in _bm.group(2)))
            _pub = float(_bm.group(1)) * (10.0 ** _pw)
            # множитель запаса — публикуется ВНИЗ
            report('I18[%s]: множитель отказа ворот опубликован ВНИЗ' % _c[0],
                   _pub <= _f['tau_break_factor'],
                   'текст %s, факт %.4e' % (_c[3][:24], _f['tau_break_factor']))
        report('I18a: все три бокса таблицы сверены', _n18 == 3,
               'сверено: %d' % _n18)
        _lo = min(v['tau_break_factor'] for v in _ts.values())
        _hi = max(v['tau_break_factor'] for v in _ts.values())
        import math as _math
        report('I18b: «пять-девять порядков» соответствует протоколу',
               ('пять-девять порядков' in _ART_ALL
                and 5 <= _math.log10(_lo) and _math.log10(_hi) <= 10),
               'по протоколу от 10^%.1f до 10^%.1f'
               % (_math.log10(_lo), _math.log10(_hi)))

# --- I19: цена счёта пересчитывается из своих же посылок --------------
# «~1200 ядро-часов марша» не выводилось из приведённого рядом
# основания (8 ч × 8 машин = 64 ядро-часа на 14.3 %) и завышало цену
# прежнего подхода в 2.7 раза, а вместе с ней и выигрыш нового.  Теперь
# обе цифры — стоимость и кратность — пересчитываются из текста.
_m = re.search(r'за 8 часов на восьми машинах — то есть за (\d+) ядро-часа? — он\s*'
               r'прошёл ([0-9.]+) % отрезка, откуда полная стоимость линейно\s*'
               r'экстраполируется в\s*\*\*≈(\d+) ядро-час(?:ов|а)\*\*', _ART_ALL)
report('I19: основание оценки марша найдено в §1', _m is not None, '')
if _m:
    _ch, _frac, _pub = float(_m.group(1)), float(_m.group(2)) / 100, float(_m.group(3))
    report('I19: 8 ч × 8 машин = 64 ядро-часа', abs(_ch - 64) < 1e-9,
           'в тексте %g' % _ch)
    _full = _ch / _frac
    report('I19: полная стоимость марша опубликована ВНИЗ',
           _pub <= _full, 'текст %g, пересчёт %.1f' % (_pub, _full))
    report('I19: и не занижена больше чем на процент',
           _pub >= _full * 0.99, 'текст %g, пересчёт %.1f' % (_pub, _full))
    _m2 = re.search(r'\*\*Цена: ([0-9.]+) ядро-минуты\*\*.*?против ≈(\d+) ядро-часов\s*'
                    r'марша.*?примерно \*\*(\d+)×\*\*', _ART_ALL, re.S)
    report('I19: кратность найдена в §3.6', _m2 is not None, '')
    if _m2:
        _cost, _march, _ratio = (float(_m2.group(1)), float(_m2.group(2)),
                                 float(_m2.group(3)))
        report('I19: цена марша в §1 и §3.6 совпадает', _march == _pub,
               '§1 %g, §3.6 %g' % (_pub, _march))
        _true = _march * 60.0 / _cost
        report('I19: кратность опубликована ВНИЗ', _ratio <= _true,
               'текст %g×, пересчёт %.1f×' % (_ratio, _true))
        report('I19: и не занижена больше чем на два процента',
               _ratio >= _true * 0.98,
               'текст %g×, пересчёт %.1f×' % (_ratio, _true))

print()
print('=' * 100)
print('=== J. то, что публиковалось без носителя или без направления ===')
print('-' * 100)

# --- J1: q_perturb_patch.json — тождества, вложение, направление печати ---
# H#3.  Вся арифметика файла интервальная (`all_arithmetic_via_arb`, шары в
# `caps`), но блок `summary` — печать, и печаталась она через `%e`, то есть
# округлением К БЛИЖАЙШЕМУ.  Для мажорант это неверная сторона:
# `sum_q16` и `bound` уходили ВНИЗ.  Наружу дефект не вышел (статья
# публикует свои числа вверх), но сравнение шло именно с этими полями.
# Проверяем три разных вещи, а не одну:
#   (а) заявленные тождества между шарами действительно выполняются в arb;
#   (б) `floats.*` лежат внутри соответствующих шаров;
#   (в) каждое поле `summary` мажорирует верхний конец своего шара и
#       отстоит от него не более чем на единицу последнего знака.
from flint import arb as _arb, ctx as _ctx
_ctx.prec = 512
try:
    _qp = json.load(open(os.path.join(POINTWISE, 'q_perturb_patch.json'),
                         encoding='utf-8'))
except Exception as _e:
    _qp = None
    report('J1: q_perturb_patch.json читается', False, str(_e))

if _qp is not None:
    _caps, _fl, _sm = _qp['caps'], _qp['floats'], _qp['summary']
    report('J1: файл объявляет арифметику через arb',
           _qp.get('all_arithmetic_via_arb') is True,
           'all_arithmetic_via_arb = %r' % _qp.get('all_arithmetic_via_arb'))

    def _b(k):
        return _arb(_caps[k])

    for _nm, _lhs, _rhs in (
            ('sum_q16 = Q16_HAT + bound', 'sum_q16',
             _b('Q16_HAT') + _b('bound')),
            ('inner_max = ‖Q̂‖₁ + E', 'inner_max',
             _arb(_qp['inputs']['qhat_1norm']) + _b('E')),
            ('E = term_a + term_b', 'E', _b('term_a') + _b('term_b'))):
        _d = float((_b(_lhs) - _rhs).abs_upper())
        report('J1: тождество %s' % _nm, _d < 1e-100,
               'расхождение шаров %.3g' % _d)

    for _k in ('sum_q16', 'bound', 'E', 'Q16_HAT', 'inner_max'):
        if _k not in _fl:
            continue
        # Шар тоньше двойной точности (rad ~ 1e-150), поэтому «float внутри
        # шара» невыполнимо в принципе: правильный вопрос — совпадает ли
        # float с ближайшим к середине шара double.
        _mid = float(_b(_k))
        report('J1: floats.%s — это ближайший double к шару caps.%s' % (_k, _k),
               _fl[_k] == _mid,
               'float %r, ближайший к шару %r' % (_fl[_k], _mid))

    for _k in ('sum_q16', 'bound', 'E'):
        _hi = float(_b(_k).upper())
        _pub = float(_sm[_k])
        _ulp = 10.0 ** (_math.floor(_math.log10(abs(_hi))) - 6)
        report('J1: summary.%s мажорирует шар (печать ВВЕРХ)' % _k,
               _pub >= _hi, 'summary %r, верх шара %.17g' % (_sm[_k], _hi))
        report('J1: summary.%s не завышено больше единицы последнего знака' % _k,
               _pub <= _hi + 1.001 * _ulp,
               'summary %r, верх шара %.17g, ulp %.3g' % (_sm[_k], _hi, _ulp))

try:
    _cc
except NameError:
    _cc = None

# --- J2: §10.9 п.5 — на сколько alt тоньше сертификатора ------------------
# H#2.  Эти два числа вписаны вручную, и ни один сторож их не касался.
# Пересчитываем ВСЁ утверждение: сколько пар консервативны, какая пара
# выбивается, и обе величины расхождения — с требованием тесного
# округления ВВЕРХ (число публикуется как «тоньше НА столько-то»).
if _cc is not None and _cc.get('rows'):
    _byp = {}
    for _r in _cc['rows']:
        if not _r['key'].endswith('_W'):
            continue
        _byp.setdefault((tuple(_r['layer']), _r['box']), []).append(_r)
    _thin = {k: v for k, v in _byp.items()
             if any(r['alt'] > r['cert'] for r in v)}
    report('J2: пар со сверкой _W', len(_byp) == 6, 'найдено %d' % len(_byp))
    report('J2: ровно одна пара, где alt ТОНЬШЕ сертификатора',
           len(_thin) == 1, 'таких пар %d: %s' % (len(_thin), sorted(_thin)))
    _m = re.search(r'на (пяти|четырёх|трёх|шести) *\n? *парах из (шести|пяти)'
                   r' `alt` консервативнее', _A10)
    _WORD = {'трёх': 3, 'четырёх': 4, 'пяти': 5, 'шести': 6}
    report('J2: счёт консервативных пар назван в §10.9', _m is not None, '')
    if _m:
        report('J2: счёт консервативных пар совпадает с протоколом',
               _WORD[_m.group(1)] == len(_byp) - len(_thin)
               and _WORD[_m.group(2)] == len(_byp),
               'текст %s из %s, протокол %d из %d'
               % (_m.group(1), _m.group(2), len(_byp) - len(_thin), len(_byp)))
    _m2 = re.search(r'на паре\s*\n?\s*`\(([0-9.]+),([0-9.]+)\)/(g\d\d)` — наоборот '
                    r'тоньше его на `([0-9.]+)·10⁻⁶` и `([0-9.]+)·10⁻⁶`', _A10)
    report('J2: пара-исключение и две величины названы в §10.9',
           _m2 is not None, '')
    if _m2 and len(_thin) == 1:
        _key = list(_thin)[0]
        _lay, _box = _key
        report('J2: названа именно та пара, что выбивается в протоколе',
               abs(_lay[0] - float(_m2.group(1))) < 1e-12
               and abs(_lay[1] - float(_m2.group(2))) < 1e-12
               and _box == _m2.group(3),
               'текст (%s,%s)/%s, протокол (%g,%g)/%s'
               % (_m2.group(1), _m2.group(2), _m2.group(3),
                  _lay[0], _lay[1], _box))
        _diffs = sorted((r['alt'] - r['cert']) for r in _thin[_key]
                        if r['alt'] > r['cert'])
        _pubs = sorted([float(_m2.group(4)) * 1e-6,
                        float(_m2.group(5)) * 1e-6])
        report('J2: величин расхождения столько же, сколько в тексте',
               len(_diffs) == len(_pubs),
               'протокол %d, текст %d' % (len(_diffs), len(_pubs)))
        if len(_diffs) == len(_pubs):
            for _d, _p in zip(_diffs, _pubs):
                _ulp = 1e-8       # единица последнего знака у 3.05·10⁻⁶
                report('J2: «тоньше на %.3g·10⁻⁶» — округление ВВЕРХ и тесное'
                       % (_p * 1e6), _p >= _d and _p <= _d + 1.001 * _ulp,
                       'текст %.6g, факт %.10g' % (_p, _d))

# --- J3: §10.9 обязан называть пробел охвата (D-маржи) --------------------
# I-37.  Сверка вторым счётом покрывает только I1/I2; ворота самовложения
# слоя (D_margin_a/D_margin_c) независимой реализации не имеют.  Текст это
# не заявлял ложно, но и не говорил вслух — теперь говорит, и это условие.
if _cc is not None and _cc.get('rows'):
    _keys = sorted(set(r['key'] for r in _cc['rows']))
    report('J3: crosscheck.json действительно только про I1/I2',
           all(k.startswith('I1_') or k.startswith('I2_') for k in _keys),
           'ключи: %s' % ', '.join(_keys))
    report('J3: §10.9 вслух называет непокрытые D-маржи',
           'D_margin_a' in _A10 and 'не сверяются вовсе' in _A10,
           'ищем упоминание D_margin_a и оговорку о непокрытии')


# --- J4: §10 обязан печатать ИСТИННУЮ нижнюю границу D_ReU_R -------------
# Ранее в статье стояло `D_ReU_R >= 0.53`, а минимум по слоевым прогонам —
# 0.515287 (cells3_hist, бокс g03): опубликованная миноранта была ВЫШЕ факта,
# то есть попросту неверна.  У числа не было носителя (в инвентаре
# `source = НЕ-НАЙДЕН`), поэтому слой 3 его не сверял и дефект дожил до
# финального ревью.  Теперь носитель есть: пересчитываем минимум по всем
# слоевым сертификатам и требуем, чтобы напечатанное было не больше факта.
_dre = []
for _nm in ('cells3_bisect.json', 'cells3_hist.json', 'cells3_hw.json',
            'cells3_offcenter.json', 'corridor.json'):
    _j = _lj(_nm)
    if _j is None:
        continue

    def _collect(o):
        if isinstance(o, dict):
            for _k, _v in o.items():
                if _k == 'D_ReU_R':
                    try:
                        _dre.append(float(_v))
                    except (TypeError, ValueError):
                        pass
                else:
                    _collect(_v)
        elif isinstance(o, list):
            for _v in o:
                _collect(_v)
    _collect(_j)

_m4 = re.search(r'`D_ReU_R\s*(?:>=|\u2265)\s*([0-9.]+)`', _ART_ALL)
report('J4: §10 печатает границу D_ReU_R', _m4 is not None and len(_dre) > 0,
       'значений в слоевых сертификатах: %d' % len(_dre))
if _m4 is not None and _dre:
    _pub4 = float(_m4.group(1))
    _fact4 = min(_dre)
    _ulp4 = 10.0 ** -(len(_m4.group(1).split('.')[1]) if '.' in _m4.group(1) else 0)
    report('J4: опубликованная миноранта D_ReU_R не выше факта',
           _pub4 <= _fact4, 'текст %.6g, факт min %.6g по %d значениям'
           % (_pub4, _fact4, len(_dre)))
    report('J4: миноранта D_ReU_R тесная (в пределах единицы последнего знака)',
           _pub4 > _fact4 - 1.001 * _ulp4,
           'текст %.6g, факт %.6g, ulp %.6g' % (_pub4, _fact4, _ulp4))

print()
def _arbnum(x):
    """Число из поля сертификата: arb печатает `[значение +/- радиус]`."""
    s = str(x).strip()
    if s.startswith('['):
        s = s[1:].split('+/-')[0].strip()
    return float(s)

# --- J5: обозначения §1.1 не разъезжаются с остальным текстом -------------
# Читатель нашёл в §1.1 три расхождения букв: показатель
# назывался `m` (а `m` в сертификатах — число подразбиений бокса, `box_g*.json::m`),
# `ᾱ` стояла без определения (определена `α_G`, а `ᾱ` в таблице численных значений
# означает сид 1.92769…), и тот же показатель в ссылке на Lanford назывался `d`.
# Ни один слой на согласованность букв не смотрел, поэтому разнобой дожил до
# финального ревью.  Теперь смотрит.
_n5 = []
if re.search(r'W\s*=\s*U(?:\u1d50|\^m|\^\{m\})', _ART_ALL):
    _n5.append('показатель в W = U^… обозначен m (m занято: подразбиения бокса)')
# ᾱ бывает и цельным символом U+1FB1, и парой «α + макрон» — ловим обе записи
_bar = [i + 1 for i, _l in enumerate(_ART_ALL.split(chr(10)))
        if ('\u1fb1' in _l or '\u03b1\u0304' in _l)
        and 'seed' not in _l and 'сид' not in _l]
if _bar:
    _n5.append('символ ᾱ вне таблицы численных значений, строки %s'
               % ', '.join(str(x) for x in _bar[:8]))
if re.search(r'Lanford[^.\n]{0,40}при\s+d\s*=\s*2', _ART_ALL):
    _n5.append('показатель в ссылке на Lanford обозначен d, а не ℓ')
# Замена `ᾱ` -> `α_G` в §1.1 стоит на том, что это ОДНА
# величина.  Совпадение было установлено вручную на 152 знака и в замок не вшито —
# то есть держалось на записи в журнале.  Теперь проверяется прогоном: табличный сид
# `ᾱ` обязан совпасть с `kant_l3.json::abar`, а сам `abar` — быть обратным к `m1`
# (это и есть определение `α_G = −1/Ḡ(1)`).
try:
    _kl3 = json.load(open(os.path.join(POINTWISE, 'kant_l3.json'), encoding='utf-8'))
    _abar = _arbnum(_kl3['abar'])
    _m1 = _arbnum(_kl3['m1'])
    if abs(_abar * _m1 - 1.0) > 1e-12:
        _n5.append('abar * m1 = %.17g, а обязано быть 1 (ᾱ и α_G — не одна величина)'
                   % float(_abar * _m1))
    _таб = re.search(r'ᾱ \(seed\)[^|]*\|\s*([0-9.]+)', _ART_ALL)
    if _таб and not ('%.13f' % _abar).startswith(_таб.group(1)[:15].rstrip('0')[:13]):
        _n5.append('табличный ᾱ = %s расходится с kant_l3.json::abar = %.14f'
                   % (_таб.group(1), _abar))
except Exception as _e:                                   # noqa: BLE001
    _n5.append('проверка ᾱ = α_G не выполнена: %s' % _e)

report('J5: обозначения статьи согласованы (показатель ℓ, α_G, ᾱ = α_G сверена с сертификатом)',
       not _n5, '; '.join(_n5) if _n5 else 'разнобоя не найдено')

# --- J6: обещание «разбор ниже в этом разделе» обязано быть адресом ------
# §1.1 обещала «подробный разбор — ниже в этом разделе», а разбор
# лежал в §6.3-6.4, за полторы тысячи строк.  Такой адрес не ловит ни один слой:
# это не ссылка на файл (её проверяет `_refs_check`) и не число (его проверяет
# слой 3).  Читатель идёт по обещанию, не находит ничего и остаётся с
# необоснованным утверждением — там, где текст сам пометил его «наблюдением».
# Только ВПЕРЁД: «введён выше в этом разделе» в формулировке теоремы C —
# законная отсылка к 𝒜 := 1 + X₀, введённому выше в той же §2 «Основные
# результаты», проверено вручную.
# Первая версия требовала
# дословного «ниже в этом разделе», проверяла ПОСТРОЧНО и без IGNORECASE, поэтому
# мимо шли: вставленное «же», запятая и тире вместо пробела, заглавные буквы,
# «в этой главе», «в текущем разделе», обратный порядок «в этом разделе ниже»,
# «дальше» и та же фраза, разорванная переносом строки.  Сторож выглядел живым, а
# класс не покрывал.  Проверено: все двенадцать обходов ловятся,
# законное «выше в этом разделе» молчит, на текущей статье срабатываний 0.
_ВПЕРЁД = r'(?:ниже|далее|дальше)'
_МЕСТО = (r'(?:эт(?:ом|ой)|том|текущ(?:ем|ей))\s+(?:же\s+)?'
          r'(?:раздел[еа]|глав[еы]|параграф[еа]|подраздел[еа])')
_RX6 = re.compile(r'(?:%s\s*[,—–-]?\s*(?:в\s+)?%s|в\s+%s\s*[,—–-]?\s*%s)'
                  % (_ВПЕРЁД, _МЕСТО, _МЕСТО, _ВПЕРЁД), re.IGNORECASE)
_n6 = _RX6.findall(re.sub(r'\s+', ' ', _ART_ALL))
report('J6: обещания «разбор ниже/далее в этом разделе» заменены адресами разделов',
       not _n6,
       ('строки: %s' % ', '.join(str(x) for x in _n6[:8])) if _n6 else 'таких обещаний нет')

# --- J7 (3.1, S2-замки, Л2): Z1a — компонента разложения Z1=Z1a+Z1b+Z1c — не
# входила в truth-словарь выше (там только Z1, Z1b, Z1c из ex_passed). Атака на
# приёмку (`финал/агенты/3.2/mx2`, ложь Л2) подменила Z1a в Z1c_l3_strict.json
# на 9.5e-15 вместо 4.4785695964985562e-15 синхронно со статьёй (оба места,
# где стоит литерал Z1a: строка таблицы «Z₁ = Z₁a+Z₁b+Z₁c» в §5.1.1 и пункт 4
# перечня в §5.1.2) — видимая сумма за 15-м знаком не сдвинулась, слой 3
# молчал. Проверяем ОТДЕЛЬНО: литерал Z1a в статье обязан совпасть с
# Z1c_l3_strict.json::Z1a.
try:
    _z1c_strict = json.load(open(os.path.join(POINTWISE, 'Z1c_l3_strict.json'), encoding='utf-8'))
    _z1a_fact = _arbnum(_z1c_strict['Z1a'])
    _z1a_pos = [m.end() for m in re.finditer(r'Z[₁1]a\b', _ART_ALL)]
    _z1a_lits = []
    for _p in _z1a_pos:
        _m = re.search(r'(\d\.\d+e-\d+)', _ART_ALL[_p:_p + 200])
        if _m:
            _z1a_lits.append(_m.group(1))
    if not _z1a_lits:
        report('J7: Z1a (компонента Z1=Z1a+Z1b+Z1c) сверена с Z1c_l3_strict.json',
               False, 'литерал Z1a не найден рядом ни с одним упоминанием «Z1a» в статье')
    else:
        _z1a_bad = [lit for lit in _z1a_lits
                   if abs(float(lit) - _z1a_fact) > 0.01 * abs(_z1a_fact)]  # не ворота: обычные float, не arb-середина
        report('J7: Z1a (компонента Z1=Z1a+Z1b+Z1c) сверена с Z1c_l3_strict.json',
               not _z1a_bad,
               ('факт %.6g, литералы статьи %s' % (_z1a_fact, sorted(set(_z1a_lits))))
               if not _z1a_bad else
               ('расхождение >1%%: факт %.6g, статья %s' % (_z1a_fact, _z1a_bad)))
except Exception as _e:                                    # noqa: BLE001
    report('J7: Z1a (компонента Z1=Z1a+Z1b+Z1c) сверена с Z1c_l3_strict.json',
           False, 'проверка не выполнена: %r' % (_e,))

# ====================================================================
# K. Депонированное, но никем не читаемое.
#
# Три класса, найденные обратным ходом «от поля сертификата к статье»:
# сводка glue.json (файл цитируется статьёй как источник вердикта, а при
# приёмке не читается вовсе), флаги и маржи box_g*.json (сертификат несёт
# «проверено», сама проверка выполнена генератором и после этого флаг не
# читает никто) и поле dS файла kappa_full.json (три числа §10.7/§10.9
# стоят на нём, а из четырёх колонок ворота брали три).  Общее у всех
# трёх — профиль fail-open: испортить можно молча.
# ====================================================================
try:
    _gl_p = os.path.join(PKG, '03-CERTIFICATES', 'existence', 'glue.json')
    _gl = json.load(open(_gl_p, encoding='utf-8'))
    _gl_recs = _gl['boxes']
    report('K1: сводка glue.json на месте и полна',
           len(_gl_recs) == _gl['n_boxes'] == 46,
           'записей %d, n_boxes %s' % (len(_gl_recs), _gl.get('n_boxes')))
    _gl_bad, _gl_n = [], 0
    for _r in _gl_recs:
        _bp = os.path.join(CERTS, 'box_%s.json' % _r['tag'])
        if not os.path.exists(_bp):
            _gl_bad.append('%s: нет сертификата' % _r['tag'])
            continue
        _b = json.load(open(_bp, encoding='utf-8'))
        _gl_n += 1
        for _k, _got, _want in (('ell0', _r['ell0'], _b['ell0']),
                                ('w', _r['w'], _b['w']),
                                ('lo', _r['lo'], _b['ell_lo']),
                                ('hi', _r['hi'], _b['ell_hi']),
                                ('Y0', _r['Y0'], _b['Y0']),
                                ('Z1', _r['Z1'], _b['Z1']),
                                ('passed', _r['passed'], _b['passed']),
                                ('tail_used', _r['tail_used'], _b['tail_used']),
                                ('Zhat', _r['Zhat'], _b['best']['Zhat']),
                                ('rho_prime', _r['rho_prime'],
                                 _b['best']['rho_prime'])):
            if _got != _want:
                _gl_bad.append('%s.%s: %r vs %r' % (_r['tag'], _k, _got, _want))
    report('K1: десять полей каждой записи glue.json совпадают с '
           'box_g##.json точно (%d боксов)' % _gl_n,
           not _gl_bad and _gl_n == 46, '; '.join(_gl_bad[:4]) or 'сходится')
    # вердикты сводки пересчитываются из её же записей и из сертификатов
    _gl_pass = all(bool(_r['passed']) for _r in _gl_recs)
    _iv = sorted((float(_r['lo']), float(_r['hi'])) for _r in _gl_recs)
    _u_lo, _u_hi = _iv[0][0], _iv[0][1]
    _gl_gaps = []
    for _lo, _hi in _iv[1:]:
        if _lo > _u_hi:
            _gl_gaps.append([_u_hi, _lo])
        _u_hi = max(_u_hi, _hi)
    report('K1: all_gate сводки = «прошли все боксы»',
           bool(_gl['all_gate']) == _gl_pass and _gl_pass,
           'all_gate=%s, по записям %s' % (_gl['all_gate'], _gl_pass))
    report('K1: union сводки пересчитывается из её записей',
           [_u_lo, _u_hi] == list(_gl['union']),
           'записано %s, пересчитано %s' % (_gl['union'], [_u_lo, _u_hi]))
    report('K1: gaps сводки пересчитываются из её записей',
           [list(map(float, _g)) for _g in _gl['gaps']] == _gl_gaps
           and not _gl_gaps,
           'записано %s, пересчитано %s' % (_gl['gaps'], _gl_gaps))
    report('K1: булевы вердикты сводки положительны',
           all(bool(_gl[_k]) for _k in ('guard', 'seams_ok', 'covers',
                                        'complete')),
           'guard=%s seams_ok=%s covers=%s complete=%s'
           % (_gl['guard'], _gl['seams_ok'], _gl['covers'], _gl['complete']))
except Exception as _e:                                        # noqa: BLE001
    report('K1: сводка glue.json сверена с сертификатами', False,
           'проверка не выполнена: %r' % (_e,))

try:
    _fl_bad, _fl_n, _cont_seen = [], 0, 0
    for _bp in sorted(glob.glob(os.path.join(CERTS, 'box_*.json'))):
        _b = json.load(open(_bp, encoding='utf-8'))
        _tag = os.path.basename(_bp)[4:-5]
        _fl_n += 1
        for _k in ('bases_ok', 'guard_ok', 'guard_in_gate', 'lemma1_OK',
                   'lemma1_nonzero_ok', 'passed'):
            if _k in _b and not bool(_b[_k]):
                _fl_bad.append('%s.%s = %r' % (_tag, _k, _b[_k]))
        for _k in ('lemma1_margin_a', 'lemma1_margin_c',
                   'lemma1_ReU_min_r_val', 'lemma1_ReU_min_R'):
            if _k in _b and _b[_k] is not None and not (float(_b[_k]) > 0):
                _fl_bad.append('%s.%s = %s' % (_tag, _k, _b[_k]))
        _c = _b.get('containment')
        if isinstance(_c, dict):
            _cont_seen += 1
            if not bool(_c.get('contains')):
                _fl_bad.append('%s.containment.contains = %r'
                               % (_tag, _c.get('contains')))
            if not (float(_c['dX']) <= float(_c['rho_X'])):
                _fl_bad.append('%s: dX=%s > rho_X=%s'
                               % (_tag, _c['dX'], _c['rho_X']))
    report('K2: флаги и маржи всех %d сертификатов положительны '
           '(флаг перестал быть свидетельством о себе)' % _fl_n,
           not _fl_bad and _fl_n == 46, '; '.join(_fl_bad[:4]) or 'везде')
    report('K2: вложение ‖P(3)−Ḡ‖_X ≤ 1.75·ρ′ депонировано и проверено',
           _cont_seen == 1, 'записей containment с данными: %d' % _cont_seen)
except Exception as _e:                                        # noqa: BLE001
    report('K2: флаги и маржи сертификатов проверены', False,
           'проверка не выполнена: %r' % (_e,))

try:
    _kf = json.load(open(os.path.join(PKG, '03-CERTIFICATES', 'layer',
                                      'kappa_full.json'), encoding='utf-8'))
    _ds_all = [(_r['dS'], _r) for _r in _kf if 'dS' in _r]
    _ds_pt = [(v, r) for v, r in _ds_all
              if 'corridor' not in str(r.get('layer', ''))]
    _ds_max = max(_ds_all, key=lambda t: t[0])
    _ds_pmax = max(_ds_pt, key=lambda t: t[0])
    report('K3: dS есть у всех записей kappa_full.json',
           len(_ds_all) == len(_kf) == 1058,
           'записей %d, с dS %d' % (len(_kf), len(_ds_all)))
    for _lbl, _fact, _lit in (
            ('максимум Δs по всем слоям', _ds_max[0], '2.399·10⁻⁷'),
            ('максимум Δs по точечным слоям', _ds_pmax[0], '2.364·10⁻⁷')):
        _pub = float(_lit.replace('·10⁻⁷', 'e-07').replace('⁻', '-'))
        report('K3: «%s» в тексте — мажоранта факта' % _lbl,
               (_lit in _ART_ALL) and _pub >= _fact and _pub <= _fact * 1.001,
               'текст %s, факт %.10e (%s)'
               % (_lit, _fact, _ds_max[1].get('box') if _lbl.endswith('слоям')
                  else ''))
    _ratio, _rbad = {}, []
    for _v, _r in _ds_all:
        if _v and _r.get('kappa_G'):
            _ratio.setdefault(_r['box'], []).append((_r['kappa_G'] - 1.0) / _v)
    _rworst, _rwbox = 0.0, None
    for _bx, _vals in _ratio.items():
        _sp = (max(_vals) - min(_vals)) / max(_vals)
        if _sp > _rworst:
            _rworst, _rwbox = _sp, _bx
    report('K3: (κ_G−1)/Δs постоянна вдоль слоёв одного бокса (§10.9)',
           _rworst < 1e-9,
           'худший относительный разброс %.3e на %s' % (_rworst, _rwbox))
except Exception as _e:                                        # noqa: BLE001
    report('K3: поле dS сверено со статьёй', False,
           'проверка не выполнена: %r' % (_e,))

# --- K4: элементарные условия (E1)/(E2) на каждом слое и каждой ячейке -----
# Они не гейтились сертификатором `one_box` и были объявлены «проверенными
# вручную».  Проверка элементарна (|c′| < r′ и |1 − c′| < r′), а
# депонированные слои и ячейки лежат в самих сертификатах — значит её место
# в воротах, а не в примечании.  Для ячейки берётся худший угол: |c′| < r′
# в (c_hi, r_lo), |1 − c′| < r′ в (c_lo, r_lo).
try:
    _e_bad, _e_n = [], 0
    _e_worst = None

    def _e_check(where, c_lo, c_hi, r_lo):
        global _e_n, _e_worst
        _e_n += 1
        m1 = r_lo - abs(c_hi)
        m2 = r_lo - abs(1.0 - c_lo)
        if not (m1 > 0):
            _e_bad.append('%s: (E1) |c\'|=%.6g не < r\'=%.6g' % (where, abs(c_hi), r_lo))
        if not (m2 > 0):
            _e_bad.append('%s: (E2) |1-c\'|=%.6g не < r\'=%.6g'
                          % (where, abs(1.0 - c_lo), r_lo))
        m = min(m1, m2)
        if _e_worst is None or m < _e_worst[0]:
            _e_worst = (m, where)

    _lay_seen = set()
    for _r in json.load(open(os.path.join(PKG, '03-CERTIFICATES', 'layer',
                                          'kappa_full.json'), encoding='utf-8')):
        _lb = str(_r.get('layer', ''))
        if _lb in _lay_seen:
            continue
        _lay_seen.add(_lb)
        _m = re.search(r'\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*\)', _lb)
        if not _m or 'corridor' in _lb:
            continue
        _c, _rr = float(_m.group(1)), float(_m.group(2))
        _e_check('слой ' + _lb, _c, _c, _rr)

    for _fn in ('corridor.json', 'cells3_bisect.json', 'cells3_hist.json',
                'cells3_hw.json', 'cells3_offcenter.json'):
        _fp = os.path.join(PKG, '03-CERTIFICATES', 'layer', _fn)
        if not os.path.exists(_fp):
            continue
        _d = json.load(open(_fp, encoding='utf-8'))
        for _cell in (_d if isinstance(_d, list) else [_d]):
            _cc = _cell.get('cell')
            if not _cc or len(_cc) != 4:
                continue
            _e_check('%s %s' % (_fn, _cc), _cc[0], _cc[1], _cc[2])

    report('K4: (E1)/(E2) выполнены на каждом депонированном слое и ячейке '
           '(%d штук)' % _e_n,
           not _e_bad and _e_n >= 20,
           ('; '.join(_e_bad[:3]) if _e_bad else
            'худший запас %.4g на %s' % _e_worst))
except Exception as _e:                                        # noqa: BLE001
    report('K4: (E1)/(E2) под воротами', False,
           'проверка не выполнена: %r' % (_e,))

# --- K5: числа круга 71, которых не было ни под какими воротами --------------
# Три величины публиковались с округлением, но никакой скрипт их не пересчитывал:
# граница "с одной степенью" по 46 боксам, доля липшицева члена в Zhat и доля
# охранного критерия.  Все три собираются из полей сертификатов, значит их место
# здесь.  Направление округления проверяется отдельно от самого значения:
# мажоранта обязана быть >= факта, миноранта <= факта.
try:
    _q12 = _Dec('1e-12')

    def _ulp_up(s):
        _d = _Dec(s)
        return _d + _Dec(1).scaleb(_d.as_tuple().exponent)

    _one_pow, _one_pow_ulp, _share = [], [], []
    for _j in ex_loaded:
        _b = _j['best']
        _one_pow.append(_Dec(_j['Z1']) + _Dec('1.75') * _Dec(_j['B_A'])
                        * _Dec(_b['L']) * _Dec(_b['rho_prime']))
        _one_pow_ulp.append(_ulp_up(_j['Z1']) + _Dec('1.75') * _ulp_up(_j['B_A'])
                            * _ulp_up(_b['L']) * _Dec(_b['rho_prime']))
        _share.append((_j.get('idx'), _b,
                       _Dec('3.0625') * _Dec(_j['B_A']) * _Dec(_b['L'])
                       * _Dec(_b['rho_prime']) / _Dec(_b['Zhat']) * 100,
                       os.path.basename('')))
    _tags = [os.path.basename(_f)[4:-5] for _f in ex]
    _sh = sorted(zip([_s[2] for _s in _share], _tags))

    _m = re.search(r'максимум по 46 боксам равен `([0-9.]+)` на `(\w+)`'
                  r'\s*\(`([0-9.]+)`', art_text)
    if not _m:
        report('K5: граница "с одной степенью" найдена в статье', False, 'шаблон не совпал')
    else:
        _pr, _pr_box, _pr_ulp = _Dec(_m.group(1)), _m.group(2), _Dec(_m.group(3))
        _fact = max(_one_pow)
        _fact_box = _tags[_one_pow.index(_fact)]
        _fact_ulp = max(_one_pow_ulp)
        report('K5: max(Z1+1.75*B_A*L*rho\') — печать мажорирует факт',
               _pr >= _fact, 'печать %s, факт %s' % (_pr, _fact))
        report('K5: та же печать — округление ВВЕРХ до 12 знаков',
               _pr == _fact.quantize(_q12, rounding=_ROUND_CEILING),
               'вверх12 = %s' % _fact.quantize(_q12, rounding=_ROUND_CEILING))
        report('K5: бокс максимума назван верно', _pr_box == _fact_box,
               'статья %s, факт %s' % (_pr_box, _fact_box))
        report('K5: прочтение "печать плюс ulp" мажорирует факт',
               _pr_ulp >= _fact_ulp, 'печать %s, факт %s' % (_pr_ulp, _fact_ulp))
        report('K5: то же прочтение — округление ВВЕРХ до 12 знаков',
               _pr_ulp == _fact_ulp.quantize(_q12, rounding=_ROUND_CEILING),
               'вверх12 = %s' % _fact_ulp.quantize(_q12, rounding=_ROUND_CEILING))
        report('K5: обе границы <= 0.162', max(_pr, _pr_ulp) <= _Dec('0.162'),
               'больше из двух %s' % max(_pr, _pr_ulp))

    _m = re.search(r'даёт ([0-9.]+) % от `Ẑ` на `(\w+)` и от ([0-9.]+) % \(`(\w+)`\)'
                  r' до ([0-9.]+) % \(`(\w+)`\) по 46 боксам, медиана ([0-9.]+) %', art_text)
    if not _m:
        report('K5: доля липшицева члена найдена в статье', False, 'шаблон не совпал')
    else:
        _p_g01, _b_g01, _p_min, _b_min, _p_max, _b_max, _p_med = (
            _Dec(_m.group(1)), _m.group(2), _Dec(_m.group(3)), _m.group(4),
            _Dec(_m.group(5)), _m.group(6), _Dec(_m.group(7)))
        _f_min, _t_min = _sh[0]
        _f_max, _t_max = _sh[-1]
        _f_med = (_sh[len(_sh)//2 - 1][0] + _sh[len(_sh)//2][0]) / 2
        _f_g01 = dict((b, v) for v, b in _sh)['g01']
        report('K5: нижняя граница доли — миноранта факта', _p_min <= _f_min,
               'печать %s, факт %s на %s' % (_p_min, _f_min, _t_min))
        report('K5: нижняя граница — округление ВНИЗ до 2 знаков',
               _p_min == _f_min.quantize(_Dec('1e-2'), rounding=_ROUND_FLOOR),
               'вниз2 = %s' % _f_min.quantize(_Dec('1e-2'), rounding=_ROUND_FLOOR))
        report('K5: бокс минимума назван верно', _b_min == _t_min,
               'статья %s, факт %s' % (_b_min, _t_min))
        report('K5: верхняя граница доли — мажоранта факта', _p_max >= _f_max,
               'печать %s, факт %s на %s' % (_p_max, _f_max, _t_max))
        report('K5: бокс максимума назван верно', _b_max == _t_max,
               'статья %s, факт %s' % (_b_max, _t_max))
        report('K5: медиана считана по ВСЕМ 46 боксам (среднее 23-го и 24-го)',
               abs(_p_med - _f_med) <= _Dec('0.005'),
               'печать %s, факт %s' % (_p_med, _f_med))
        report('K5: доля на g01 совпадает с фактом',
               abs(_p_g01 - _f_g01) <= _Dec('0.005') and _b_g01 == 'g01',
               'печать %s, факт %s' % (_p_g01, _f_g01))

    _m = re.search(r'\(([0-9.]+) против\s*\n?\s*([0-9.]+) при пороге ([0-9.]+)\)', art_text)
    _g01 = [_j for _j, _tg in zip(ex_loaded, _tags) if _tg == 'g01']
    if not _m or not _g01:
        report('K5: доля охранного критерия найдена в статье', False, 'шаблон не совпал')
    else:
        _j = _g01[0]
        _f_guard = _Dec(_j['guard_lhs']) / _Dec(_j['Y0'])
        _p_rerun, _p_dep, _p_thr = _Dec(_m.group(1)), _Dec(_m.group(2)), _Dec(_m.group(3))
        report('K5: доля охранного критерия B_A*dchk/Y0 депонированного прогона',
               abs(_p_dep - _f_guard) <= _Dec('0.00005'),
               'печать %s, факт %s' % (_p_dep, _f_guard))
        report('K5: это доля от Y0, а не от Y0/2 (порог 0.5 назван верно)',
               _p_thr == _Dec('0.5')
               and abs(_p_dep - _Dec(_j['guard_lhs']) / _Dec(_j['guard_rhs'])) > _Dec('0.005'),
               'от Y0/2 было бы %s'
               % (_Dec(_j['guard_lhs']) / _Dec(_j['guard_rhs'])))
        report('K5: перепрогон хуже депонированного (направление сохранено)',
               _p_rerun > _p_dep, 'перепрогон %s, депонировано %s' % (_p_rerun, _p_dep))
        report('K5: обе доли ниже порога охранного критерия',
               max(_p_rerun, _p_dep) < _p_thr, 'больше из двух %s' % max(_p_rerun, _p_dep))
except Exception as _e:                                        # noqa: BLE001
    report('K5: числа круга 71 под воротами', False,
           'проверка не выполнена: %r' % (_e,))

# --- K6: слоевые максимумы Приложения A (строки 52-55) ----------------
# Их источник назван без поля, поэтому `_appendix_check` сверял published
# со ВСЕМИ 7360 числами `kappa_full.json`: подмена kappa_G базового слоя на
# kappa_G соседнего слоя проходила молча (проверено фальсификацией).
# Здесь величина ПЕРЕСЧИТЫВАЕТСЯ: максимум по нужному множеству записей,
# и отдельно проверяется, что названы верная метка и верный бокс.
try:
    _kf = json.load(open(os.path.join(PKG, '03-CERTIFICATES', 'layer',
                                      'kappa_full.json'), encoding='utf-8'))
    _labels = sorted(set(str(_r['layer']) for _r in _kf))
    report('K6: меток layer 23, записей 1058',
           len(_labels) == 23 and len(_kf) == 1058,
           'меток %d, записей %d' % (len(_labels), len(_kf)))

    def _ceil_at(fact, lit):
        """Потолок факта на той точности, с какой напечатан литерал."""
        _mant = str(lit).split('e')[0].split('E')[0].lstrip('-+').replace('.', '')
        _dig = len(_mant.lstrip('0')) or 1
        _q = _Dec(1).scaleb(fact.adjusted() - _dig + 1)
        return fact.quantize(_q, rounding=_ROUND_CEILING)

    def _mx(recs, key):
        _b = max(recs, key=lambda r: float(r[key]))
        return _Dec(str(_b[key])), str(_b['layer']), str(_b['box'])

    _base = [_r for _r in _kf if str(_r['layer']) == '(0.60,0.80)']
    report('K6: базовый слой (0.60,0.80) — 46 боксов', len(_base) == 46,
           'записей %d' % len(_base))

    _f52, _, _b52 = _mx(_base, 'kappa_G')
    _m = re.search(r'\|\s*52\s*\|[^|]*\|\s*([0-9.]+)\s*\(бокс\s*`(\w+)`\)'
                   r'[^|]*?публикуется\s*≤\s*([0-9.]+)', art_text)
    if not _m:
        report('K6: строка 52 найдена в статье', False, 'шаблон не совпал')
    else:
        _p, _pbox, _pmaj = _Dec(_m.group(1)), _m.group(2), _Dec(_m.group(3))
        report('K6: kappa_G базового слоя — печать мажорирует пересчёт',
               _p >= _f52, 'печать %s, пересчёт %s' % (_p, _f52))
        report('K6: kappa_G базового слоя — печать ЕСТЬ потолок пересчёта',
               _p == _ceil_at(_f52, _m.group(1)),
               'печать %s, потолок %s' % (_p, _ceil_at(_f52, _m.group(1))))
        report('K6: kappa_G базового слоя — бокс назван верно', _pbox == _b52,
               'статья %s, пересчёт %s' % (_pbox, _b52))
        report('K6: объявленная граница 4.42 мажорирует пересчёт',
               _pmaj >= _f52, 'граница %s, пересчёт %s' % (_pmaj, _f52))

    _f53, _l53, _b53 = _mx(_kf, 'kappa_G')
    _m = re.search(r'\|\s*53\s*\|[^|]*\|\s*([0-9.]+)\s*\(метка\s*`([^`]+)`,'
                   r'\s*бокс\s*`(\w+)`', art_text)
    if not _m:
        report('K6: строка 53 найдена в статье', False, 'шаблон не совпал')
    else:
        report('K6: kappa_G максимум по 23 меткам — печать мажорирует',
               _Dec(_m.group(1)) >= _f53,
               'печать %s, пересчёт %s' % (_m.group(1), _f53))
        report('K6: максимум по 23 меткам — печать ЕСТЬ потолок',
               _Dec(_m.group(1)) == _ceil_at(_f53, _m.group(1)),
               'печать %s, потолок %s' % (_m.group(1), _ceil_at(_f53, _m.group(1))))
        report('K6: максимум kappa_G — метка и бокс названы верно',
               _m.group(2) == _l53 and _m.group(3) == _b53,
               'статья %s/%s, пересчёт %s/%s'
               % (_m.group(2), _m.group(3), _l53, _b53))

    _f54, _, _ = _mx(_kf, 'dW')
    _m = re.search(r'\|\s*54\s*\|[^|]*\|\s*([0-9.]+)×10⁻⁶', art_text)
    if not _m:
        report('K6: строка 54 найдена в статье', False, 'шаблон не совпал')
    else:
        report('K6: dW максимум по 23 меткам — печать мажорирует',
               _Dec(_m.group(1)) * _Dec('1e-6') >= _f54,
               'печать %se-6, пересчёт %s' % (_m.group(1), _f54))
        report('K6: dW максимум по 23 меткам — печать ЕСТЬ потолок',
               _Dec(_m.group(1)) * _Dec('1e-6') == _ceil_at(_f54, _m.group(1)),
               'печать %se-6, потолок %s'
               % (_m.group(1), _ceil_at(_f54, _m.group(1))))

    _cor = [_r for _r in _kf
            if 'Q corner (0.64,0.84)' in str(_r['layer']) and _r['box'] == 'g43']
    _m = re.search(r'\|\s*55\s*\|[^|]*\|\s*([0-9.]+)×10⁻⁶', art_text)
    if not _m or not _cor:
        report('K6: строка 55 найдена в статье и в пакете', False,
               'шаблон или запись не найдены')
    else:
        _f55 = _Dec(str(_cor[0]['dW']))
        report('K6: dW в худшем углу Q — печать мажорирует пересчёт',
               _Dec(_m.group(1)) * _Dec('1e-6') >= _f55,
               'печать %se-6, пересчёт %s' % (_m.group(1), _f55))
        report('K6: dW в худшем углу Q — печать ЕСТЬ потолок',
               _Dec(_m.group(1)) * _Dec('1e-6') == _ceil_at(_f55, _m.group(1)),
               'печать %se-6, потолок %s'
               % (_m.group(1), _ceil_at(_f55, _m.group(1))))
except Exception as _e:                                        # noqa: BLE001
    report('K6: слоевые максимумы под воротами', False,
           'проверка не выполнена: %r' % (_e,))

# --- K7: поля сертификата, которые не читал НИ ОДИН ворот ---------------
# Круг 73, угол «ворота против ворот»: порча поля ×100 на боксе, где оно
# максимально, и опрос всех пяти ворот.  Три поля не заметил никто:
# `w2_sup` (хвостовой член Y0), `best.rho_star` (двойник `rho_star_b`) и
# `D` (степень тейлоровского пакета).  `glue.py` их не читает вовсе,
# `_numbers_check` знал только про диапазоны опубликованных величин.
#
# Закрывается не новым числом в статье, а ТОЖДЕСТВАМИ, которые движок
# обязан соблюдать на каждом боксе.  Все три проверены на депонированных
# данных: выполняются точно на всех 46.
try:
    _k7_bad = []
    _k7_worst = None
    for _f, _j in zip(ex, ex_loaded):
        _tag = os.path.basename(_f)[4:-5]
        _b = _j.get('best') or {}
        # (1) rho_star и rho_star_b — одна величина под двумя именами
        if str(_b.get('rho_star')) != str(_b.get('rho_star_b')):
            _k7_bad.append('%s: rho_star=%s != rho_star_b=%s'
                           % (_tag, _b.get('rho_star'), _b.get('rho_star_b')))
        # (2) rho_star_X = 1.75 * rho_star_b (перевод b-нормы в X-норму)
        _rx, _rb = _b.get('rho_star_X'), _b.get('rho_star_b')
        if _rx is not None and _rb is not None:
            _lhs, _rhs = _Dec(str(_rx)), _Dec('1.75') * _Dec(str(_rb))
            if _rhs == 0 or abs(_lhs - _rhs) > abs(_rhs) * _Dec('1e-6'):
                _k7_bad.append('%s: rho_star_X=%s != 1.75*rho_star_b=%s'
                               % (_tag, _rx, _rhs))
        # (3) Y0 мажорирует сумму собственных слагаемых
        #     (rig2fix3: Y0 = head + B_A*tau_F + w2_sup + Ftail_sup)
        try:
            _y0 = _Dec(str(_j['Y0']))
            _sum = (_Dec(str(_j['w2_sup'])) + _Dec(str(_j['Ftail_sup']))
                    + _Dec(str(_j['B_A'])) * _Dec(str(_j['tau_F'])))
            if _sum > _y0:
                _k7_bad.append('%s: w2_sup+Ftail_sup+B_A*tau_F=%s > Y0=%s'
                               % (_tag, _sum, _y0))
            _r = _sum / _y0 if _y0 else _Dec(0)
            if _k7_worst is None or _r > _k7_worst[0]:
                _k7_worst = (_r, _tag)
        except (KeyError, TypeError):
            _k7_bad.append('%s: нет полей w2_sup/Ftail_sup/tau_F для сверки с Y0' % _tag)
    report('K7: rho_star и rho_star_b совпадают во всех боксах',
           not [x for x in _k7_bad if 'rho_star=' in x],
           'боксов %d' % len(ex_loaded))
    report('K7: rho_star_X = 1.75*rho_star_b во всех боксах',
           not [x for x in _k7_bad if 'rho_star_X=' in x], '')
    report('K7: Y0 мажорирует сумму своих слагаемых',
           not [x for x in _k7_bad if 'w2_sup+' in x or 'нет полей' in x],
           ('худшая доля суммы %s на %s'
            % (_k7_worst[0].quantize(_Dec('1e-6')), _k7_worst[1]))
           if _k7_worst else '')
    # (4) хвостовые поля: неотрицательны и не превосходят Y0.  Слабая
    #     граница, но ЕДИНСТВЕННАЯ верная: `w2_sup` составляет ~10^-20 от
    #     `Y0`, поэтому проверка по доле бессмысленна — порча ×100 остаётся
    #     невидимой не из-за дыры в воротах, а потому что величина ни на что
    #     не влияет.  Так и записано в круге 73.
    _t_bad = []
    for _f, _j in zip(ex, ex_loaded):
        _tag = os.path.basename(_f)[4:-5]
        for _fld in ('w2_sup', 'Ftail_sup'):
            _v = _j.get(_fld)
            if _v is None:
                _t_bad.append('%s: нет поля %s' % (_tag, _fld)); continue
            _d = _Dec(str(_v))
            if _d < 0 or _d > _Dec(str(_j['Y0'])):
                _t_bad.append('%s: %s=%s вне [0, Y0]' % (_tag, _fld, _v))
    report('K7: w2_sup и Ftail_sup присутствуют и лежат в [0, Y0]',
           not _t_bad, '; '.join(_t_bad[:2]) if _t_bad else 'полей 92 в 46 боксах')

    _Dset = sorted(set(str(_j.get('D')) for _j in ex_loaded))
    report('K7: степень D одна и та же на всех 46 боксах',
           len(_Dset) == 1 and _Dset[0] == '8', 'значения: %s' % ', '.join(_Dset))
    if _k7_bad:
        for _x in _k7_bad[:4]:
            print('    K7 подробности: %s' % _x)
except Exception as _e:                                        # noqa: BLE001
    report('K7: поля вне ворот', False, 'проверка не выполнена: %r' % (_e,))

# --- K8: две таблицы подразбиения (§3.2 и §3.4) под воротами ------------
# Круг 73, угол «сходимость против сошлось на этом прогоне».  Статья печатает
# десять чисел, полученных ЗАМЕРОМ (как падает оценка при дроблении бокса), и
# называет скрипты-репродюсеры.  Но ни один ворот их не читал: сверять было
# не с чем, скрипт назван без депонированного результата — та же схема «сверка
# против стога сена», что ловилась в приложении A.
#
# Пересняты обоими скриптами 04.09.2026 и положены в
# 03-CERTIFICATES/measurements/subdivision_tables.json.  Здесь проверяется
# каждое из десяти чисел по правилу направления: без пометки обрыва печать
# обязана быть ПОТОЛКОМ факта на своей точности, с пометкой (…) — ПОЛОМ, то
# есть префиксом факта.  Замер §3.4 при K=1 и K=2 этой проверки не проходил:
# 2.584 при факте 2.584044 и 1.224 при 1.224187 лежали ВНУТРИ факта без
# пометки.  Исправлено пометкой обрыва, а не округлением вверх: вверх — значило
# бы усилить собственный довод статьи о непригодности интервального пути.
try:
    _k8_p = os.path.join(PKG, '03-CERTIFICATES', 'measurements',
                         'subdivision_tables.json')
    with open(_k8_p, encoding='utf-8') as _fh:
        _k8 = json.load(_fh)
    with open(ART, encoding='utf-8') as _fh:
        _k8_art = _fh.read()

    _K8SUP = {'⁰': '0', '¹': '1', '²': '2', '³': '3',
              '⁴': '4', '⁵': '5', '⁶': '6', '⁷': '7',
              '⁸': '8', '⁹': '9', '⁺': '+', '⁻': '-'}

    def _k8_split(cell):
        """'2.584…·10⁻¹' -> ('2.584', -1, True); '5.252' -> ('5.252', 0, False)"""
        s = re.sub(r'\(.*?\)', '', str(cell)).strip()
        trunc = ('…' in s) or ('\\ldots' in s)
        s = s.replace('…', '').replace('\\ldots', '').strip()
        mm = re.match(r'^([0-9]+\.[0-9]+)(?:·10([⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+))?$', s)
        if not mm:
            return None
        _e = 0
        if mm.group(2):
            _e = int(''.join(_K8SUP[c] for c in mm.group(2)))
        return mm.group(1), _e, trunc

    def _k8_at(fact, lit, up):
        _mant = str(lit).lstrip('-+').replace('.', '')
        _dig = len(_mant.lstrip('0')) or 1
        _q = _Dec(1).scaleb(fact.adjusted() - _dig + 1)
        return fact.quantize(_q, rounding=_ROUND_CEILING if up else _ROUND_FLOOR)

    def _k8_one(label, cell, fact_str):
        _p = _k8_split(cell)
        if _p is None:
            report(label, False, 'клетка не разобрана: %r' % (cell,))
            return
        _lit, _exp, _tr = _p
        _fact = _Dec(fact_str)
        _pr = _Dec(_lit).scaleb(_exp)
        _want = _k8_at(_fact, _lit, not _tr)
        report(label, _pr == _want,
               '%s %s, факт %s, %s %s'
               % (_lit, '(обрыв)' if _tr else '(мажоранта)', fact_str,
                  'пол' if _tr else 'потолок', _want))

    # §3.2 — строка Z1c таблицы «K | 1 | 2 | 4 | 8»
    _m32 = re.search(r'^\|\s*Z1c\s*\|([^\n]*)\|\s*$', _k8_art, re.M)
    if _m32 is None:
        report('K8: таблица §3.2 (Z1c против K) найдена в статье', False,
               'строка «| Z1c | ... |» не найдена')
    else:
        report('K8: таблица §3.2 (Z1c против K) найдена в статье', True, '')
        _cells = [c for c in _m32.group(1).split('|')]
        _rows32 = _k8['z1bc_sub_g35']['rows']
        for _i, _c in enumerate(_cells[:4]):
            _k8_one('K8: §3.2 Z1c при K=%d' % _rows32[_i]['K'], _c,
                    _rows32[_i]['Z1c'])

    # §3.4 — три строки «| K | ширина | голова Y0 | Z1a |»
    _rows34 = _k8['pure_interval_g01']['rows']
    _seen34 = 0
    for _r in _rows34:
        _pat = (r'^\|\s*%d\s*\|\s*%s\s*\|([^|]+)\|([^|]+)\|\s*$'
                % (_r['K'], re.escape(str(_r['width']))))
        _mm = re.search(_pat, _k8_art, re.M)
        if _mm is None:
            report('K8: §3.4 строка K=%d найдена' % _r['K'], False, 'не найдена')
            continue
        _seen34 += 1
        _k8_one('K8: §3.4 голова Y0 при K=%d' % _r['K'], _mm.group(1), _r['Y0_head'])
        _k8_one('K8: §3.4 Z1a при K=%d' % _r['K'], _mm.group(2), _r['Z1a'])
    report(u'K8: все три строки таблицы §3.4 на месте', _seen34 == 3,
           u'найдено %d из 3' % _seen34)
except Exception as _e:                                        # noqa: BLE001
    report('K8: таблицы подразбиения под воротами', False,
           'проверка не выполнена: %r' % (_e,))

# --- K9: 13 строк Приложения A, которые сверялись только со «стогом» ----
# Круг 74.  `_appendix_check.check_haystack` считает строки, у которых в
# столбце «источник» назван ФАЙЛ без поля: сверять нечего, и подмена значения
# внутри файла остаётся зелёной.  Таких строк 17; четыре из них (52–55) закрыл
# блок K6 в круге 72, остальные тринадцать — 42–51, 56, 57, 58 — не проверял
# по значению никто.
#
# Здесь каждая из тринадцати пересчитывается из своего слоевого артефакта, и
# печать проверяется ПО СТОРОНЕ: «худшая маржа» — миноранта, печать обязана
# быть ПОЛОМ факта на своей точности; максимум (`q`, отклонение δ, расхождение
# матриц) — мажоранта, печать обязана быть ПОТОЛКОМ.  Заодно сверяются имена
# бокса и слоя, на которых достигается крайнее значение: число без своего
# адреса — половина утверждения.
try:
    _k9_dir = os.path.join(PKG, '03-CERTIFICATES', 'layer')

    def _k9_json(name):
        with open(os.path.join(_k9_dir, name), encoding='utf-8') as _fh:
            return json.load(_fh)

    def _k9_row(num):
        _m = re.search(r'^\|\s*%d\s*\|(.*)$' % num, _ART_ALL, re.M)
        return _m.group(1) if _m else None

    def _k9_at(fact, lit, up):
        """Округление факта на точности литерала: ВВЕРХ для мажоранты, ВНИЗ для миноранты."""
        _mant = str(lit).lstrip('-+').replace('.', '')
        _dig = len(_mant.lstrip('0')) or 1
        _q = _Dec(1).scaleb(fact.adjusted() - _dig + 1)
        return fact.quantize(_q, rounding=_ROUND_CEILING if up else _ROUND_FLOOR)

    def _k9_num(label, num, lit, exp, fact, up):
        _row = _k9_row(num)
        if _row is None:
            report(label, False, 'строка %d не найдена в статье' % num)
            return
        if lit not in _row:
            report(label, False, 'литерал %s не найден в строке %d' % (lit, num))
            return
        _f = _Dec(repr(float(fact)))
        _pr = _Dec(lit).scaleb(exp)
        _want = _k9_at(_f, lit, up)
        report(label, _pr == _want,
               '%s, факт %.12g, %s %s' % (lit, float(fact),
                                          'потолок' if up else 'пол', _want))

    def _k9_has(label, num, *needles):
        _row = _k9_row(num)
        _miss = [x for x in needles if _row is None or x not in _row]
        report(label, not _miss, ('нет в строке %d: %s' % (num, ', '.join(_miss)))
               if _miss else ', '.join(needles))

    # --- строки 42-45: бисекция ячейки Q ---------------------------------
    _cb = _k9_json('cells3_bisect.json')
    _by_hw = {}
    for _e in _cb:
        _by_hw[round(float(_e['half_width']), 6)] = _e

    def _k9_worst(entry):
        _mm = {}
        for _tag, _v in entry['boxes'].items():
            if _v.get('min_margin') is not None:
                _mm[_tag] = _v['min_margin']
        _wb = min(_mm, key=_mm.get)
        return _mm[_wb], _wb

    report('K9: cells3_bisect — три полуширины 0.035/0.04/0.045',
           sorted(_by_hw) == [0.035, 0.04, 0.045], 'найдено: %s' % sorted(_by_hw))
    _e40 = _by_hw.get(0.04)
    if _e40 is not None:
        _cell = [float(x) for x in _e40['cell']]
        _want = [0.56, 0.64, 0.76, 0.84]
        report('K9: строка 42 — границы ячейки Q совпадают с артефактом',
               all(abs(_a - _b) < 1e-9 for _a, _b in zip(_cell, _want)),
               'артефакт %s' % ([round(x, 6) for x in _cell],))
        _k9_has('K9: строка 42 — напечатаны те же границы', 42,
                '0.56', '0.64', '0.76', '0.84')
        _w40, _b40 = _k9_worst(_e40)
        _k9_num('K9: строка 43 — худшая маржа на Q (миноранта, ВНИЗ)',
                43, '6.32', -4, _w40, False)
        _k9_has('K9: строка 43 — назван бокс, где достигается', 43, _b40)
    _e35 = _by_hw.get(0.035)
    if _e35 is not None:
        _w35, _b35 = _k9_worst(_e35)
        _k9_num('K9: строка 44 — худшая маржа на подячейке (ВНИЗ)',
                44, '3.30', -3, _w35, False)
        _k9_has('K9: строка 44 — назван бокс, где достигается', 44, _b35)
    _e45 = _by_hw.get(0.045)
    if _e45 is not None:
        _g45 = sorted(set(_v.get('failed_gate') for _v in _e45['boxes'].values()
                          if _v.get('failed_gate')))
        report('K9: строка 45 — первая непроходящая полуширина: 44 из 46 и гейт lemma_U',
               int(_e45.get('n_pass', -1)) == 44 and not _e45.get('cell_pass')
               and _g45 == ['lemma_U'],
               'n_pass=%s cell_pass=%s гейты=%s'
               % (_e45.get('n_pass'), _e45.get('cell_pass'), _g45))
        _k9_has('K9: строка 45 — напечатаны полуширина, счёт и имя гейта',
                45, '4.5', '44/46', 'lemma_U')

    # --- строка 46: полный переучёт 644 пар ------------------------------
    _fr = _k9_json('full_recheck_644.json')
    _n644 = 0
    _b644 = None
    for _lay, _boxes in _fr.items():
        for _tag, _v in _boxes.items():
            _n644 += 1
            _m = _v.get('min_margin')
            if _m is not None and (_b644 is None or _m < _b644[0]):
                _b644 = (_m, _lay, _tag)
    report('K9: строка 46 — пар в артефакте ровно 644', _n644 == 644,
           'пар %d (%d слоёв)' % (_n644, len(_fr)))
    _k9_num('K9: строка 46 — худшая маржа по 644 парам (ВНИЗ)',
            46, '1.0965', -3, _b644[0], False)
    _k9_has('K9: строка 46 — названы слой и бокс', 46,
            _b644[1].replace(' ', ''), _b644[2])

    # --- строки 47-51: худшее по каждому гейту ---------------------------
    _wg = _k9_json('worst_by_gate.json')

    def _k9_lay(key):
        return str(_wg[key]['layer']).replace(' ', '')

    _k9_num('K9: строка 47 — D_margin_a худшее (ВНИЗ)', 47, '2.44', -2,
            _wg['D_margin_a']['value'], False)
    _k9_has('K9: строка 47 — назван бокс', 47, _wg['D_margin_a']['box'])
    _k9_num('K9: строка 48 — D_margin_c худшее (ВНИЗ)', 48, '5.28', -2,
            _wg['D_margin_c']['value'], False)
    _k9_has('K9: строка 48 — назван бокс', 48, _wg['D_margin_c']['box'])
    _k9_num('K9: строка 49 — I1_margin_s худшее (ВНИЗ)', 49, '0.126', 0,
            _wg['I1_margin_s']['value'], False)
    _k9_num('K9: строка 49 — I1_margin_W худшее (ВНИЗ)', 49, '1.95', -3,
            _wg['I1_margin_W']['value'], False)
    _k9_num('K9: строка 50 — I2_margin_s худшее (ВНИЗ)', 50, '1.09', -3,
            _wg['I2_margin_s']['value'], False)
    _k9_num('K9: строка 50 — I2_margin_W худшее (ВНИЗ)', 50, '6.80', -3,
            _wg['I2_margin_W']['value'], False)
    _k9_num('K9: строка 51 — q максимум (МАЖОРАНТА, ВВЕРХ)', 51, '1.2352', 0,
            _wg['D_q']['value'], True)
    _k9_has('K9: строка 51 — названы слой и бокс', 51,
            _k9_lay('D_q'), _wg['D_q']['box'])
    report('K9: строка 46 и строка 50 — это одно и то же худшее число',
           abs(float(_wg['I2_margin_s']['value']) - float(_b644[0])) < 1e-15,
           'worst_by_gate %.12g против пересчёта 644 %.12g'
           % (float(_wg['I2_margin_s']['value']), float(_b644[0])))

    # --- строка 56: коридор ----------------------------------------------
    _co = _k9_json('corridor.json')
    _bc = None
    for _e in _co:
        for _tag, _v in _e['boxes'].items():
            _m = _v.get('min_margin')
            if _m is not None and (_bc is None or _m < _bc[0]):
                _bc = (_m, _tag)
    report('K9: строка 56 — ячеек коридора ровно 7', len(_co) == 7,
           'ячеек %d' % len(_co))
    _k9_num('K9: строка 56 — худшая маржа коридора (ВНИЗ)', 56, '1.14', -3,
            _bc[0], False)

    # --- строки 57-58: проба слоёв DT ------------------------------------
    _dt = _k9_json('dt_layer_probe.json')['layers']
    _base = None
    for _x in _dt:
        if abs(_x['c'] - 0.6) < 1e-12 and abs(_x['r'] - 0.8) < 1e-12:
            _base = _x
    report('K9: строка 57 — слоёв 15, опорный (0.6,0.8) найден',
           len(_dt) == 15 and _base is not None, 'слоёв %d' % len(_dt))
    _dev = max(abs(_x['delta'] - _base['delta']) for _x in _dt if _x is not _base)
    _spread = max(_x['delta'] for _x in _dt) - min(_x['delta'] for _x in _dt)
    _k9_num('K9: строка 57 — max|δ−δ_base| по 14 слоям (МАЖОРАНТА, ВВЕРХ)',
            57, '8.882', -15, _dev, True)
    _k9_num('K9: строка 57 — полный разброс δ (МАЖОРАНТА, ВВЕРХ)',
            57, '1.51', -14, _spread, True)
    _rd = max((_x.get('rel_diff_vs_base'), _x['c'], _x['r']) for _x in _dt
              if _x.get('rel_diff_vs_base') is not None)
    _k9_num('K9: строка 58 — максимум расхождения DT в процентах (ВВЕРХ)',
            58, '118', 0, _rd[0] * 100, True)
    _k9_has('K9: строка 58 — назван слой, где достигается', 58, '0.70,0.75')
except Exception as _e:                                        # noqa: BLE001
    report('K9: 13 строк Приложения A под воротами', False,
           'проверка не выполнена: %r' % (_e,))

# --- K10: граница ‖φ★‖_∞ в теореме 2 -----------------------------------
# Проход перед публикацией.  Теорема 2 печатала «‖φ★‖_∞ ≤ 1», а
# собственный сертификат `q_perturb_patch.json` даёт `caps.phi_star =
# 1.00000000578194...` — СТРОГО больше единицы.  Нормировка ‖φ̂‖_∞ = 1
# наложена на ПРИБЛИЖЕНИЕ, а точный φ★ отстоит от него на `diff_phi`;
# сам сертификат всюду пользуется БОЛЬШИМ значением (`term_a`), то есть
# вывод не пострадал — но напечатанная мажоранта была округлена ВНУТРЬ факта.
# Здесь проверяется и печать (по СТОРОНЕ), и тождества самого сертификата,
# включая то, что `term_a` собран именно с `phi_star`, а не с единицей.
try:
    with open(os.path.join(PKG, '03-CERTIFICATES', 'pointwise',
                           'q_perturb_patch.json'), encoding='utf-8') as _fh:
        _k10 = json.load(_fh)['caps']

    def _k10_dec(name):
        """ВЕРХНИЙ конец шара `[mid +/- rad]` как Decimal."""
        _s = str(_k10[name]).strip()
        if _s.startswith('['):
            _m = re.match(r'\[([^\s\]]+)(?:\s*\+/-\s*([^\]]+))?\]', _s)
            _mid = _Dec(_m.group(1))
            return _mid + (_Dec(_m.group(2)) if _m.group(2) else _Dec(0))
        return _Dec(_s)

    def _k10_at(fact, lit):
        """Потолок факта на точности литерала (мажоранта округляется ВВЕРХ)."""
        _dig = len(str(lit).lstrip('-+').replace('.', '').lstrip('0')) or 1
        return fact.quantize(_Dec(1).scaleb(fact.adjusted() - _dig + 1),
                             rounding=_ROUND_CEILING)

    _phi = _k10_dec('phi_star')
    _hat = _k10_dec('phi_norm_inf_hat')
    _dif = _k10_dec('diff_phi')
    _v = _k10_dec('v_star')
    _dov = _k10_dec('delta_over_ip')
    _ta = _k10_dec('term_a')
    _tb = _k10_dec('term_b')
    _E = _k10_dec('E')

    report('K10: ‖φ★‖_∞ строго больше 1 — «≤ 1» было бы ложью',
           _phi > _Dec(1), 'факт %s' % _phi)
    report('K10: в статье нет старой печати «‖φ★‖_∞ ≤ 1)»',
           '‖φ★‖_∞ ≤ 1)' not in _ART_ALL, 'старая форма вернулась')
    _lit_phi = '1.000000006'
    report('K10: статья печатает ‖φ★‖_∞ ≤ %s' % _lit_phi,
           '‖φ★‖_∞ ≤ %s' % _lit_phi in _ART_ALL, 'литерал не найден')
    report('K10: напечатанная граница φ★ — ПОТОЛОК факта (МАЖОРАНТА, ВВЕРХ)',
           _Dec(_lit_phi) == _k10_at(_phi, _lit_phi),
           'потолок %s' % _k10_at(_phi, _lit_phi))
    _lit_d = '5.782'
    report('K10: напечатанное отстояние %s×10⁻⁹ — ПОТОЛОК diff_phi' % _lit_d,
           ('%s×10⁻⁹' % _lit_d) in _ART_ALL
           and _Dec(_lit_d).scaleb(-9) == _k10_at(_dif, _lit_d),
           'факт %s, потолок %s' % (_dif, _k10_at(_dif, _lit_d)))
    report('K10: phi_star = phi_norm_inf_hat + diff_phi (тождество сертификата)',
           abs(_phi - (_hat + _dif)) < _Dec('1e-140'), 'расхождение %s' % (_phi - (_hat + _dif)))
    _rec = _dov * _v * _phi
    _rec1 = _dov * _v * _Dec(1)
    report('K10: term_a собран с phi_star, а не с единицей',
           abs(_ta - _rec) < abs(_ta - _rec1), 'факт %s' % _ta)
    report('K10: E = term_a + term_b',
           abs(_E - (_ta + _tb)) < _Dec('1e-20'), 'расхождение %s' % (_E - _ta - _tb))
except Exception as _e:                                        # noqa: BLE001
    report('K10: граница ‖φ★‖_∞ под воротами', False,
           'проверка не выполнена: %r' % (_e,))

print('='*100)
print('ИТОГО: %d провалов из %d ВЫПОЛНЕННЫХ проверок' % (bad, checks))
if checks < CHECKS_MIN:
    print('*** ПРОВАЛ ВЫРОЖДЕНИЯ: выполнено %d проверок, минимум %d — часть '
          'проверок не запустилась, «0 провалов» ничего не значит ***'
          % (checks, CHECKS_MIN))
    sys.exit(3)
sys.exit(0 if bad == 0 else 2)