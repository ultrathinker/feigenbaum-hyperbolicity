# -*- coding: utf-8 -*-
"""
sig_lib.py — sigma-Taylor (l-dependence) bivariate series engine, arb.

Representation: a sigma-object is  (slices, tau)
  slices[i] : list of arb — t-series (u-coords) coefficient of sigma^i, i <= D
  tau       : arb — bound of  sum_{i>D} ||slice_i||_X * smax^i   (tail mass)
Invariant: sup_{|sigma|<=smax} ||obj||_X <= sum_{i<=D} ||slices[i]||_X smax^i + tau.

Every operation keeps the invariant:
  mul: slices = exact sigma-convolution of kept slices (cap D); the mass
       dropped by capping is computed EXACTLY from the kept slice norms;
       input taus propagate as  tauA*MB + MA*tauB + tauA*tauB.
  add / scalar ops: obvious.

Base objects (t-series, u-coords, at sigma=0):
  conv(a,b,N)        truncated t-product
  tinv(b0, N)        t-series inverse of b0 (b0[0] != 0)
  tlog_seed(u, N)    Log(u) with L[0] = log(u[0]) and the L'-recursion
  powers of a t-series via repeated convolution.
"""
from flint import arb, ctx


def xnorm(h, r):
    s = arb(0)
    rk = arb(1)
    for k in range(len(h)):
        s = s + abs(h[k]) * rk
        rk = rk * r
    return s


def conv(a, b, N):
    out = [arb(0)] * (N + 1)
    for i in range(min(len(a), N + 1)):
        ai = a[i]
        if ai == 0:
            continue
        jmax = min(len(b), N + 1 - i)
        for j in range(jmax):
            if b[j] != 0:
                out[i + j] = out[i + j] + ai * b[j]
    return out


def tinv(b, N):
    """inverse of t-series b (b[0] != 0), truncated to N."""
    if b[0] == 0:
        raise ZeroDivisionError('tinv: b[0]=0')
    out = [arb(0)] * (N + 1)
    out[0] = 1 / b[0]
    for n in range(1, N + 1):
        s = arb(0)
        for k in range(n):
            if b[n - k] != 0 and out[k] != 0:
                s = s + b[n - k] * out[k]
        out[n] = -s / b[0]
    return out


def tlog(u, N):
    """Log of t-series u (u[0] > 0.5 real positive so the principal branch is
    the continued one). L[0] = log(u[0]); L_n from  U' = L' U."""
    out = [arb(0)] * (N + 1)
    out[0] = u[0].log()
    for n in range(N):
        # coefficient n of U' is (n+1) u_{n+1}
        up = arb(n + 1) * u[n + 1]
        # U' = L' U :  (n+1)L_{n+1} u0 + sum_{j=1..n} j L_j u_{n+1-j}
        s = arb(0)
        for j in range(1, n + 1):
            if out[j] != 0 and u[n + 1 - j] != 0:
                s = s + arb(j) * out[j] * u[n + 1 - j]
        out[n + 1] = (up - s) / (arb(n + 1) * u[0])
    return out


class Sig:
    """sigma-object: slices + tau, with cap D and smax fixed at construction."""
    __slots__ = ('slices', 'tau', 'D', 'smax')

    def __init__(self, slices, tau, smax):
        self.slices = slices
        self.tau = tau
        self.D = len(slices) - 1
        self.smax = smax

    def total_mass(self, r):
        """M = sum_{i<=D} ||slice_i||_X smax^i + tau."""
        s = arb(0)
        for i in range(len(self.slices)):
            s = s + xnorm(self.slices[i], r) * (self.smax ** i)
        return (s + self.tau).upper()

    def supnorm(self, r):
        """sup_{|sigma|<=smax} ||obj(sigma)||_X (upper)."""
        return self.total_mass(r)

    def add(self, other):
        n = max(len(self.slices), len(other.slices))
        sl = []
        for i in range(n):
            a = self.slices[i] if i < len(self.slices) else None
            b = other.slices[i] if i < len(other.slices) else None
            if a is None:
                sl.append(b)
            elif b is None:
                sl.append(a)
            else:
                m = max(len(a), len(b))
                sl.append([(a[k] if k < len(a) else arb(0)) +
                           (b[k] if k < len(b) else arb(0)) for k in range(m)])
        return Sig(sl, self.tau + other.tau, self.smax)

    def scale(self, c):
        """multiply by a scalar arb c (sigma-independent)."""
        return Sig([[c * x for x in sl] for sl in self.slices],
                   abs(c) * self.tau, self.smax)

    def mul(self, other, D, N, r):
        """bivariate product with sigma-cap D and t-cap N."""
        la, lb = len(self.slices), len(other.slices)
        sl = [None] * (D + 1)
        dropped = arb(0)
        # full sigma-convolution mass for i <= la+lb-1; keep i <= D
        for i in range(la + lb - 1):
            acc = None
            for j in range(max(0, i - lb + 1), min(i, la - 1) + 1):
                a = self.slices[j]
                b = other.slices[i - j]
                pr = conv(a, b, N)
                if acc is None:
                    acc = pr
                else:
                    m = max(len(acc), len(pr))
                    acc = [(acc[k] if k < len(acc) else arb(0)) +
                           (pr[k] if k < len(pr) else arb(0)) for k in range(m)]
            if acc is None:
                continue
            if i <= D:
                sl[i] = acc
            else:
                dropped = dropped + xnorm(acc, r) * (self.smax ** i)
        # slice arrays may have different lengths: pad
        for i in range(D + 1):
            if sl[i] is None:
                sl[i] = [arb(0)]
        MA = self.total_mass(r)
        MB = other.total_mass(r)
        tau = self.tau * MB + MA * other.tau + self.tau * other.tau + dropped
        return Sig(sl, tau.upper(), self.smax)

    def mul_scalar_sig(self, s, D, r):
        """multiply by a SCALAR sigma-series s (list of arb, s[i]=coeff sigma^i,
        with its own tau_s). Same bookkeeping."""
        la, ls = len(self.slices), len(s)
        sl = [None] * (D + 1)
        dropped = arb(0)
        for i in range(la + ls - 1):
            terms = []
            for j in range(max(0, i - ls + 1), min(i, la - 1) + 1):
                terms.append((s[i - j], self.slices[j]))
            if not terms:
                continue
            if i <= D:
                # sigma^i slice: sum of scalar*slice (t-series scaled) — but the
                # t-lengths may exceed N; keep as is (scalar mult keeps length)
                sl[i] = _scaled_sum(terms)
            else:
                nm = arb(0)
                for c, arr in terms:
                    nm = nm + abs(c) * xnorm(arr, r)
                dropped = dropped + nm * (self.smax ** i)
        for i in range(D + 1):
            if sl[i] is None:
                sl[i] = [arb(0)]
        MA = self.total_mass(r)
        Ms = arb(0)
        for i in range(len(s)):
            Ms = Ms + abs(s[i]) * (self.smax ** i)
        # tau of the scalar series passed separately via s_tau argument? we
        # encode: s has no tau here (polynomial). Caller adds tau via add().
        tau = MA * arb(0) + dropped
        return Sig(sl, tau.upper(), self.smax)

    def smul_sig_with_tau(self, s, s_tau, D, r):
        res = self.mul_scalar_sig(s, D, r)
        MA = self.total_mass(r)
        res.tau = (res.tau + MA * s_tau).upper()
        return res

    def shift_mul_sigma(self, D, r):
        """multiply by sigma (coefficient shift); dropped top slice mass."""
        sl = [arb(0)] + list(self.slices)
        dropped = arb(0)
        if len(sl) > D + 1:
            dropped = xnorm(sl[D + 1], r) * (self.smax ** (D + 1))
            sl = sl[:D + 1]
        return Sig(sl, (self.tau + dropped).upper(), self.smax)


def _scaled_sum(terms):
    """sum of scalar*slice with common t-length."""
    m = max(len(arr) for _, arr in terms)
    out = [arb(0)] * m
    for c, arr in terms:
        for k in range(len(arr)):
            out[k] = out[k] + c * arr[k]
    return out


def sig_from_poly(coeffs_slices, smax):
    """exact polynomial sigma-object (tau = 0)."""
    return Sig([list(s) for s in coeffs_slices], arb(0), smax)


def horner_compose(Gc_slices, Q, D, N, r):
    """compose the sigma-varying t-series Gc (Sig) with the Sig Q:
       result = Gc[deg] + result*Q (Horner over t-coefficients of each slice).
    Gc_slices: Sig whose slices share a common t-length."""
    deg = len(Gc_slices.slices[0]) - 1
    res_slices = [[(s[deg] if deg < len(s) else arb(0))]
                  for s in Gc_slices.slices]
    res = Sig(res_slices, arb(0), Gc_slices.smax)
    for k in range(deg - 1, -1, -1):
        res = res.mul(Q, D, N, r)
        col = Sig([[s[k] if k < len(s) else arb(0)] for s in Gc_slices.slices],
                  arb(0), Gc_slices.smax)
        res = res.add(col)
    return res


# ---------------- scalar sigma-series (list of arb + tau) ---------------- #

def scalar_recip(g, D, smax):
    """1/g for scalar sigma-series g with g[0] ~ O(1), via the geometric
    recursion; tau from the geometric tail (valid when |g/g0 - 1| < 1)."""
    g = list(g) + [arb(0)] * (D + 1 - len(g)) if len(g) < D + 1 else list(g)
    g0 = g[0]
    out = [arb(0)] * (D + 1)
    out[0] = 1 / g0
    for n in range(1, D + 1):
        s = arb(0)
        for k in range(1, n + 1):
            if g[k] != 0 and out[n - k] != 0:
                s = s + g[k] * out[n - k]
        out[n] = -s / g0
    # tail: |sum_{i>D} c_i sigma^i| <= |c-D-weighted| ... use geometric bound:
    # 1/g(sigma) = (1/g0) * 1/(1+h(sigma)), h = g/g0-1:
    h_abs = arb(0)
    for i in range(1, len(g)):
        h_abs = h_abs + abs(g[i] / g0) * (smax ** i)
    if not (h_abs < 1):
        raise RuntimeError('scalar_recip: |h| >= 1 (%s)' % h_abs)
    # truncated geometric series of 1/(1+h) at D: bound the tail by
    # |c_{D+1}|... c_n = (-1)^n h^n convolution-free bound: |c_n| <= h_abs^n
    tau = abs(out[0]) * (h_abs ** (D + 1)) / (1 - h_abs)
    return out, tau.upper(), h_abs


def scalar_log_from_recip(g, D, smax):
    """Log(g) = Log(g0) + Log(1+h); h-abs must be < 1. Returns (series, tau)."""
    g = list(g) + [arb(0)] * (D + 1 - len(g)) if len(g) < D + 1 else list(g)
    g0 = g[0]
    h = [arb(1)] + [g[i] / g0 for i in range(1, len(g))]
    # h[0] = 1 - 1 = ... careful: h = g/g0 - 1 -> h[0] = 0
    h = [arb(0)] + [g[i] / g0 for i in range(1, len(g))]
    h_abs = arb(0)
    for i in range(1, len(h)):
        h_abs = h_abs + abs(h[i]) * (smax ** i)
    if not (h_abs < 1):
        raise RuntimeError('scalar_log: |h| >= 1')
    # Log(1+h) = sum (-1)^{n+1} h^n / n : power series in sigma
    # compute h^n as scalar sigma-series powers to D
    out = [g0.log()] + [arb(0)] * D
    hp = [arb(1)] + [arb(0)] * D    # h^0
    for n in range(1, D + 1):
        # h^n = hp * h truncated at D
        new = [arb(0)] * (D + 1)
        for i in range(D + 1):
            if hp[i] == 0:
                continue
            for j in range(0, D + 1 - i):
                if h[j] != 0:
                    new[i + j] = new[i + j] + hp[i] * h[j]
        hp = new
        for i in range(D + 1):
            out[i] = out[i] + ((arb(-1) ** (n + 1)) / n) * hp[i]
    # tail: |sum_{n>D} h^n/n| <= h_abs^{D+1}/((D+1)(1-h_abs))
    tau = (h_abs ** (D + 1)) / (arb(D + 1) * (1 - h_abs))
    return out, tau.upper()


def scalar_exp(M, D, smax):
    """exp(M) for scalar sigma-series M with M[0] arbitrary:
    E[0] = exp(M[0]); E_n = (1/n) sum_{j=1..n} j M_j E_{n-j}.
    tau <= e^{Ms} * (Ms - |M0|)^{D+1}/(D+1)! style bound."""
    E = [arb(0)] * (D + 1)
    E[0] = M[0].exp()
    for n in range(1, D + 1):
        s = arb(0)
        for j in range(1, n + 1):
            if M[j] != 0 and E[n - j] != 0:
                s = s + arb(j) * M[j] * E[n - j]
        E[n] = s / n
    Ms = arb(0)
    for i in range(len(M)):
        Ms = Ms + abs(M[i]) * (smax ** i)
    M0 = abs(M[0])
    rest = (Ms - M0).upper()
    if rest < 0:
        rest = arb(0)
    tau = Ms.exp() * rest ** (D + 1) / _fact(D + 1)
    return E, tau.upper()


def _fact(n):
    f = arb(1)
    for i in range(2, n + 1):
        f = f * i
    return f


def t_exp_seed(M_sig, X0_slice, D, N, r):
    """bivariate exp: X = exp(M) with the t-seed X(0) = X0_slice given.
    Recursion: dX/dsigma = X * dM/dsigma  (slice-wise):
      (i+1) X_{i+1} = sum_{j=0..i} (j+1) M_{j+1} * X_{i-j}   (t-convolutions)
    Tail: tau_X <= M_X * (tau_M + tail-of-capping) + ... plus exp-type
    Poisson tail via the scalar majorant of (M - M0)."""
    smax = M_sig.smax
    X = [list(X0_slice)]
    for i in range(D):
        acc = [arb(0)] * (N + 1)
        for j in range(0, i + 1):
            Mj1 = M_sig.slices[j + 1] if j + 1 < len(M_sig.slices) else None
            Xi_j = X[i - j]
            if Mj1 is None:
                continue
            fac = arb(j + 1)   # scalar (j+1) * M_{j+1}
            pr = conv([fac * (Mj1[k] if k < len(Mj1) else arb(0))
                       for k in range(N + 1)], Xi_j, N)
            acc = [(acc[k] if k < len(acc) else arb(0)) +
                   (pr[k] if k < len(pr) else arb(0)) for k in range(max(len(acc), len(pr)))]
            acc = acc[:N + 1]
        X.append([x / arb(i + 1) for x in acc])
    # tail bound: X satisfies dX/ds = X dM/ds; with majorants
    # Mhat(s) = sum ||M_i|| s^i + tau_M, Xhat <= exp-ish...
    # simple valid bound: Xhat <= X0hat * exp(Mhat - M0hat) and the sigma-Taylor
    # of exp at order D misses  <= value * (Mhat-M0hat)^{D+1}/(D+1)! e^{...}
    MX = M_sig.total_mass(r)
    M0 = xnorm(M_sig.slices[0], r).upper()
    X0 = xnorm(X0_slice, r).upper()
    rest = (MX - M0)
    if rest < 0:
        rest = arb(0)
    # propagation of tau_M: dX/ds = X M'(s): tau contributes X*tau_M*(1+...)
    tau = X0 * rest.exp() * rest ** (D + 1) / _fact(D + 1) + \
        (X0 * rest.exp() + arb(1)) * M_sig.tau
    return Sig(X, tau.upper(), smax)
