# -*- coding: utf-8 -*-
"""
_dt_fd_cross.py — вторая, архитектурно независимая сборка матрицы DT
(шаг приёмки `dt_fd_cross`).

ЗАЧЕМ.
Единственная сборка DT в пакете — hyp_rouche.dt_from_pkg(build_pkg_fast(...))
опирается на РУЧНУЮ аналитическую производную DF_at_ell (tube_lib.py:487-504,
708-716). Докстринг tube_lib.py:5-9 сам говорит, что ошибка именно такого
типа однажды дала 29% отклонения (v5 "hardcoded l=2.5 derivative pieces").
Здесь строится ВТОРОЙ путь: столбцы DT получаются конечным дифференцированием
ЗНАЧЕНИЯ оператора (tube_lib.compute_F_poly), без единого обращения к
DF_at_ell/M_full, и сравниваются с первым путём.

НИЧЕГО В ПАКЕТ НЕ ПИШЕТ: отчёт и лог идут в $CERT_OUT (или во временную
папку), пакет только читается. Путь к отчёту переопределяется DT_FD_REPORT.
Стоимость шага — около 100 с на одном ядре.
Код возврата: 0 — два пути сошлись; 1 — расхождение выше порога.

БАЗИС (установлен эмпирически, см. §"Как соответствуют столбцы" ниже и
ОТЧЁТ-DT-FD.md): official M_full[j][k] = d/dε F_poly(P0 + eps*e_k)[j],
где e_k — НЕ единичный вектор координаты a64_arb[k], а направление
   e_k(tau) = tau^k / r^k,   tau = t - c,
выраженное через ИСХОДНЫЕ (raw, "центр 0") координаты a64_arb как
   v_k[i] = C(k,i) * (-c)^(k-i) / r^k   для i = 0..k  (иначе 0),
потому что build_pkg_fast/compute_F_poly внутри делают
   G_c(tau) = G_raw(c + tau)  =>  G_raw(w) = G_c(w - c),
и поэтому "чистое приращение tau^k/r^k в G_c" эквивалентно приращению
(w-c)^k/r^k в G_raw, разложенному по биному в raw-координатах. Это ЧИСТАЯ
линейная алгебра (биномиальный сдвиг центра разложения), не связанная с
DF_at_ell — проверена отдельно на согласии с M_full до ~1e-40 (см. пробники).
Проверка гипотезы "наивный единичный вектор" (без сдвига) дала расхождение
порядка самих элементов матрицы (не совпадает вообще) — эта гипотеза
отброшена, что и запротоколировано в отчёте.

Выход compute_F_poly читается НАПРЯМУЮ (без обратного преобразования) —
это тоже проверено эмпирически: FD, посчитанный так, сходится к M_full[j][k]
с ошибкой O(eps^2), убывающей до ~1e-40 при eps=1e-20 (arb, prec=256), то
есть выходной индекс j уже в той же условности, что и строки M_full.

Запуск:  python dt_fd_cross.py [ell0] [eps] [ncols]
  ell0  — точка сравнения (по умолчанию 3.0, как в приёмке)
  eps   — половина шага центральной разности, arb (по умолчанию 1e-12)
  ncols — если задано, сравнить только первые ncols столбцов DT (для
          быстрой проверки); по умолчанию все NP=80.
"""
import os
import os as _os  # алиас для env в воркере (os остаётся)
import multiprocessing as _mp
import sys
import time
import json
import tempfile
from math import comb

# ------------------------------------------------------------------ #
# Ограничение потоков BLAS/OMP (директива "не больше 4 ядер").      #
# Наша работа — последовательный python-цикл с flint/arb, но numpy  #
# используется в конце (np.linalg.eigvals), защищаемся заранее.     #
# ------------------------------------------------------------------ #
for _v in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
           'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ.setdefault(_v, '4')

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_CODE = os.path.dirname(HERE)                    # 04-CODE
PKG_ROOT = os.path.dirname(PKG_CODE)                # корень пакета
PKG_CERT = os.path.join(PKG_ROOT, '03-CERTIFICATES')
_WORK = os.environ.get('CERT_OUT') or tempfile.gettempdir()
REPORT = os.environ.get('DT_FD_REPORT', os.path.join(_WORK, 'dt_fd_cross_report.md'))

# Пакет читаем как модули; переменные окружения — как в приёмке hyp_rouche.
os.environ.setdefault('HYP_BRANCHES', os.path.join(PKG_CERT, 'branches'))
os.environ.setdefault('HYP_LOG', os.path.join(_WORK, "_hyp_rouche_fd_cross.log"))
sys.path.insert(0, PKG_CODE)

import rig_lib as rl          # noqa: E402  (пакет, только читаем)
import tube_lib as tl         # noqa: E402
import hyp_rouche as hr       # noqa: E402
from flint import arb, ctx    # noqa: E402

ctx.prec = 256

NP = tl.N_p                    # 80
C_A, R_A = tl.c_arb, tl.r_arb  # arb(3)/5, arb(4)/5


def log_append(text):
    """Инкрементальная запись в отчёт (как лог, не всё разом в конце)."""
    with open(REPORT, 'a', encoding='utf-8') as f:
        f.write(text)
        if not text.endswith('\n'):
            f.write('\n')
    print(text)


def shift_dir_arb(k):
    """v_k[i] = C(k,i) * (-c)^(k-i) / r^k, i = 0..k  (arb, точная биномиальная
    матрица сдвига центра разложения раскрытия (w-c)^k/r^k -> raw-базис).
    Это чистая линейная алгебра, независимая от DF_at_ell."""
    v = [arb(0)] * (k + 1)
    rk = R_A ** k if k else arb(1)
    for i in range(k + 1):
        v[i] = arb(comb(k, i)) * ((-C_A) ** (k - i)) / rk
    return v


def _dt_fd_worker(args):
    """один столбец FD → dict с float-массивом Fp-Fm/(2*eps).
    Воркер получает c_a (numpy float64), m, e0b, wb, ell_str, eps_f, k.
    P0, R_A, C_A, NP восстанавливаются в воркере из тех же источников.
    """
    import os as _os2
    import sys as _sys
    _os2.environ['OMP_NUM_THREADS'] = '1'
    _os2.environ['MKL_NUM_THREADS'] = '1'
    _os2.environ['OPENBLAS_NUM_THREADS'] = '1'
    PKG_CODE = _os2.path.dirname(_os2.path.dirname(_os2.path.abspath(__file__)))
    _sys.path.insert(0, PKG_CODE)
    import rig_lib as rl       # noqa
    import tube_lib as tl      # noqa
    from flint import arb, ctx
    ctx.prec = 256
    NP = tl.N_p
    C_A, R_A = tl.c_arb, tl.r_arb
    (c_a, m, e0b, wb, ell_str, eps_f, k) = args
    from math import comb as _comb
    ell = float(ell_str)
    x0 = 2.0 * (ell - e0b) / wb
    P0 = rl.P_at(c_a, m, arb('%.17e' % x0))
    ell_pt = arb('%.17e' % ell)
    epsA = arb(eps_f)
    rk = R_A ** k if k else arb(1)
    v = [arb(0)] * (k + 1)
    for i in range(k + 1):
        v[i] = arb(_comb(k, i)) * ((-C_A) ** (k - i)) / rk
    Pp = list(P0)
    Pm = list(P0)
    for i, vi in enumerate(v):
        Pp[i] = Pp[i] + epsA * vi
        Pm[i] = Pm[i] - epsA * vi
    Fp = tl.compute_F_poly(Pp, ell_pt)
    Fm = tl.compute_F_poly(Pm, ell_pt)
    # Перепроверка: разность в arb, как в оригинале; передаётся
    # ТОЧНО парой (мантисса, экспонента) середины — float давал 1.776e-15 вместо 0.
    col = []
    for j in range(NP + 1):
        d = ((Fp[j] - Fm[j]) / (2 * epsA)).mid().man_exp()
        col.append((int(d[0]), int(d[1])))
    return {'k': k, 'col': col}


def build_dt_from_Mfull_like(Mfull_get):
    """Точная копия арифметики hyp_rouche.dt_from_pkg, но читающая матрицу
    через функцию доступа Mfull_get(row, col) — чтобы прогнать ОДИНАКОВОЕ
    пост-преобразование (r^{j+1}-масштаб, (-c/r)^{k+1}-поправка col0) и на
    официальной M_full, и на нашей FD-матрице. Сама эта арифметика скопирована
    буквально (hyp_rouche.py:92-104) — она не содержит DF_at_ell."""
    rp = [R_A ** (j + 1) for j in range(NP)]
    mp = [(-C_A / R_A) ** (k + 1) for k in range(NP)]
    DT = [[None] * NP for _ in range(NP)]
    for j in range(NP):
        col0 = Mfull_get(j + 1, 0)
        for k in range(NP):
            v = rp[j] * (Mfull_get(j + 1, k + 1) - mp[k] * col0)
            DT[j][k] = (arb(1) - v) if j == k else -v
    return DT


def main():
    ell0 = float(sys.argv[1]) if len(sys.argv) > 1 else 3.0
    eps_f = float(sys.argv[2]) if len(sys.argv) > 2 else 1e-12
    ncols = int(sys.argv[3]) if len(sys.argv) > 3 else NP

    # свежий отчёт
    open(REPORT, 'w', encoding='utf-8').close()
    log_append('# Отчёт: перекрёстная проверка DT (FD vs аналитика), ell0=%.4f\n' % ell0)
    log_append('Пакет: `%s` (только чтение). Скрипт: '
                '`04-CODE/tests/_dt_fd_cross.py`.' % PKG_ROOT + chr(10))
    log_append('eps (половина шага центральной разности, arb) = %.3e; '
                'столбцов сравнивается: %d из %d.\n' % (eps_f, ncols, NP))

    t_start = time.time()

    # -------------------------------------------------- путь 1 (штатный)
    c_a, m, e0b, wb, fname = hr.load_box(ell0, 0.0)
    x0 = 2.0 * (ell0 - e0b) / wb
    P0 = rl.P_at(c_a, m, arb('%.17e' % x0))
    ell_pt = arb('%.17e' % ell0)

    t0 = time.time()
    pkg0 = tl.build_pkg_fast(P0, ell_pt)
    Mf_official = pkg0['M_full']
    DT_official = hr.dt_from_pkg(pkg0)
    log_append('## Путь 1 (штатный, hyp_rouche.dt_from_pkg)\n')
    log_append('ветка: `%s` (l0=%.4f, w=%.3f, m=%d); DT построен за %.1f с.\n'
                % (fname, e0b, wb, m, time.time() - t0))

    # -------------------------------------------------- контроль epsilon
    # Быстрая проверка сходимости на одной паре (j=2, k=5), не входящей в
    # основной проход — просто документирует выбор eps в отчёте.
    log_append('## Контроль выбора eps (одна ячейка j=2,k=5, вне основного прохода)\n')
    log_append('| eps | FD (mid) | отклонение от M_full[2][5] |')
    log_append('|---|---|---|')
    j_probe, k_probe = 2, 5
    v_probe = shift_dir_arb(k_probe)
    target_probe = Mf_official[j_probe][k_probe]
    for eps_try in (1e-5, 1e-8, 1e-12, 1e-15, 1e-20):
        epsA = arb(eps_try)
        Pp = list(P0)
        Pm = list(P0)
        for i, vi in enumerate(v_probe):
            Pp[i] = Pp[i] + epsA * vi
            Pm[i] = Pm[i] - epsA * vi
        Fp = tl.compute_F_poly(Pp, ell_pt)
        Fm = tl.compute_F_poly(Pm, ell_pt)
        fd = (Fp[j_probe] - Fm[j_probe]) / (2 * epsA)
        err = float(fd - target_probe)
        log_append('| %.0e | %.15g | %.3e |' % (eps_try, float(fd), err))
    log_append('')
    log_append('Вывод: ошибка убывает как eps^2 до ~1e-42 при eps=1e-20 (arb, '
                'prec=256) — это подтверждает, что базисное соответствие '
                '(биномиальный сдвиг центра, см. шапку файла) ТОЧНОЕ, а не '
                'приблизительное совпадение. Наивная гипотеза "e_k = единичный '
                'вектор координаты a64_arb[k] без сдвига" была проверена и '
                'ОТБРОШЕНА — при ней FD расходится с M_full на величины '
                'порядка самих элементов матрицы (не поймать ошибку класса '
                '"29 процентов", а перепутать базис вообще). Для основного прохода взято '
                'eps=%.0e — глубоко внутри плато квадратичной сходимости, '
                'без риска отмены (arb хранит точный интервал, ширина шара '
                'на этом eps остаётся ~1e-55, то есть отмена значащих цифр '
                'не грозит даже при таком малом шаге).\n' % eps_f)

    # -------------------------------------------------- путь 2 (FD)
    log_append('## Путь 2 (FD через compute_F_poly, без обращения к DF_at_ell/M_full)\n')
    t0 = time.time()
    eps = arb(eps_f)
    FD_Mfull = [[None] * (NP + 1) for _ in range(NP + 1)]
    ncols_eff = min(ncols, NP)
    log_append('Строим %d столбцов (k=0..%d) FD-аналога M_full, каждый — 2 '
                'вызова compute_F_poly (центральная разность).\n' % (ncols_eff + 1, ncols_eff))
    _DT_ARGS = [(c_a, m, e0b, wb, ell0, eps_f, k)
                 for k in range(0, ncols_eff + 1)]
    _DT_W = max(1, int(_os.environ.get('HYP_WORKERS', '1')))
    if _DT_W > 1 and ncols_eff + 1 > 1:
        with _mp.get_context('spawn').Pool(_DT_W) as _pool:
            _DT_RES = _pool.map(_dt_fd_worker, _DT_ARGS)
    else:
        _DT_RES = [_dt_fd_worker(a) for a in _DT_ARGS]
    _DT_RES.sort(key=lambda r: r['k'])  # детерминированный порядок
    for _r in _DT_RES:
        k = _r['k']
        for j in range(NP + 1):
            _mn, _ex = _r['col'][j]
            FD_Mfull[j][k] = arb(_mn) * (arb(2) ** _ex)
        if k % 10 == 0 or k == ncols_eff:
            log_append('  столбец k=%d/%d готов (%.1f с суммарно)'
                        % (k, ncols_eff, time.time() - t0))
    log_append('FD-матрица (%d столбцов) построена за %.1f с.\n'
                % (ncols_eff + 1, time.time() - t0))

    if ncols_eff < NP:
        log_append('**ВНИМАНИЕ**: сравнивается только подматрица — первые '
                    '%d из %d столбцов (по запросу командной строки), '
                    'остальные столбцы DT не проверены этим прогоном.\n'
                    % (ncols_eff, NP))

    # -------------------------------------------------- сборка DT_FD
    def get_fd(row, col):
        if col > ncols_eff:
            raise RuntimeError('запрошен непостроенный столбец FD: %d' % col)
        return FD_Mfull[row][col]

    def get_official(row, col):
        return Mf_official[row][col]

    # Если считаем не все столбцы — DT строим только по доступной части
    # (DT[j][k] для k <= ncols_eff-1, k+1 <= ncols_eff).
    NP_eff = ncols_eff
    rp = [R_A ** (j + 1) for j in range(NP_eff)]
    mp = [(-C_A / R_A) ** (k + 1) for k in range(NP_eff)]

    DT_FD = [[None] * NP_eff for _ in range(NP_eff)]
    DT_official_sub = [[None] * NP_eff for _ in range(NP_eff)]
    for j in range(NP_eff):
        col0_fd = get_fd(j + 1, 0)
        col0_off = get_official(j + 1, 0)
        for k in range(NP_eff):
            v_fd = rp[j] * (get_fd(j + 1, k + 1) - mp[k] * col0_fd)
            v_off = rp[j] * (get_official(j + 1, k + 1) - mp[k] * col0_off)
            DT_FD[j][k] = (arb(1) - v_fd) if j == k else -v_fd
            DT_official_sub[j][k] = (arb(1) - v_off) if j == k else -v_off

    # -------------------------------------------------- сравнение поэлементно
    log_append('## Сравнение 1: поэлементно (DT_FD vs DT_official)\n')
    max_abs_diff = 0.0
    max_abs_A = 0.0
    worst = (None, None, 0.0)
    diffs = np.zeros((NP_eff, NP_eff))
    A_mid = np.zeros((NP_eff, NP_eff))
    for j in range(NP_eff):
        for k in range(NP_eff):
            a = float(DT_official_sub[j][k])
            b = float(DT_FD[j][k])
            d = abs(a - b)
            diffs[j, k] = d
            A_mid[j, k] = abs(a)
            if abs(a) > max_abs_A:
                max_abs_A = abs(a)
            if d > max_abs_diff:
                max_abs_diff = d
                worst = (j, k, d)
    rel = max_abs_diff / max_abs_A if max_abs_A > 0 else float('nan')
    log_append('max|A| (DT_official, %dx%d) = %.6e' % (NP_eff, NP_eff, max_abs_A))
    log_append('max|DT_FD - DT_official| = %.6e' % max_abs_diff)
    log_append('относительное расхождение max|delta A| / max|A| = %.6e' % rel)
    log_append('худший элемент: строка j=%d, столбец k=%d (|Delta|=%.6e)'
                % (worst[0], worst[1], worst[2]))
    # топ-5 худших элементов
    flat_idx = np.argsort(diffs, axis=None)[::-1][:5]
    log_append('топ-5 худших элементов (строка, столбец, |Delta|):')
    for idx in flat_idx:
        jj, kk = divmod(int(idx), NP_eff)
        log_append('  (j=%d, k=%d): |Delta|=%.6e  (A=%.6e, FD=%.6e)'
                    % (jj, kk, diffs[jj, kk],
                       float(DT_official_sub[jj][kk]), float(DT_FD[jj][kk])))
    log_append('')

    # -------------------------------------------------- сравнение по спектру
    log_append('## Сравнение 2: спектр (numpy.linalg.eigvals, float64 mid)\n')
    mid_off = np.array([[float(DT_official_sub[j][k]) for k in range(NP_eff)]
                         for j in range(NP_eff)])
    mid_fd = np.array([[float(DT_FD[j][k]) for k in range(NP_eff)]
                        for j in range(NP_eff)])
    ev_off = np.linalg.eigvals(mid_off)
    ev_fd = np.linalg.eigvals(mid_fd)
    ev_off = ev_off[np.argsort(-np.abs(ev_off))]
    ev_fd = ev_fd[np.argsort(-np.abs(ev_fd))]
    n_out_off = int((np.abs(ev_off) > 1).sum())
    n_out_fd = int((np.abs(ev_fd) > 1).sum())
    delta_off = ev_off[0].real
    delta_fd = ev_fd[0].real
    lam2_off = abs(ev_off[1]) if len(ev_off) > 1 else float('nan')
    lam2_fd = abs(ev_fd[1]) if len(ev_fd) > 1 else float('nan')
    log_append('DT_official: delta = %.12f, |lambda2| = %.12f, вне круга: %d'
                % (delta_off, lam2_off, n_out_off))
    log_append('DT_FD      : delta = %.12f, |lambda2| = %.12f, вне круга: %d'
                % (delta_fd, lam2_fd, n_out_fd))
    log_append('|delta_FD - delta_official| = %.3e (относительно: %.3e)'
                % (abs(delta_fd - delta_off), abs(delta_fd - delta_off) / abs(delta_off)))
    log_append('n_out совпадает: %s' % (n_out_off == n_out_fd))
    log_append('')

    # -------------------------------------------------- инвариант 4.1
    log_append('## Сравнение 3: дешёвый инвариант delta vs архивный eigen_l3_fixed.json\n')
    # Сравнение 3 печатало расхождение и НЕ входило в вердикт: подстановка
    # архивного delta, отличающегося на 20 %, оставляла шаг зелёным. Теперь
    # оно гейтится наравне с 1 и 2, а отсутствие архива при ell0 = 3 — красное
    # (пропуск законен только вне ell0 = 3, где архивной величины не существует).
    ARCH_THRESH = 1e-6
    arch_ok = True
    arch_rel = None
    eigen_path = os.path.join(PKG_CERT, 'pointwise', 'eigen_l3_fixed.json')
    if abs(ell0 - 3.0) < 1e-9 and not os.path.isfile(eigen_path):
        arch_ok = False
    if os.path.isfile(eigen_path) and abs(ell0 - 3.0) < 1e-9:
        with open(eigen_path, 'r', encoding='utf-8') as f:
            ej = json.load(f)
        delta_archive = ej['delta_bar']
        log_append('архивный delta_bar (eigen_l3_fixed.json, wave5, oid=%s) = %.12f'
                    % (ej.get('oid', '?'), delta_archive))
        arch_rel = abs(delta_off - delta_archive) / abs(delta_archive)
        arch_ok = arch_rel < ARCH_THRESH
        log_append('DT_official delta (эта сборка) = %.12f  (rel. diff = %.3e, '
                    'порог %.0e, %s)'
                    % (delta_off, arch_rel, ARCH_THRESH,
                       'ok' if arch_ok else 'ВЫШЕ ПОРОГА'))
        if NP_eff == NP:
            log_append('DT_FD delta (эта сборка)       = %.12f  (rel. diff = %.3e)'
                        % (delta_fd, abs(delta_fd - delta_archive) / abs(delta_archive)))
        else:
            log_append('DT_FD delta пропущен: сравнивалась подматрица %dx%d, '
                        'а не полная 80x80 — спектр неполной подматрицы не '
                        'сопоставим с архивным delta напрямую.' % (NP_eff, NP_eff))
    else:
        log_append('eigen_l3_fixed.json не найден или ell0 != 3.0 — инвариант '
                    'пропущен (найден только для ell0=3.0).')
    log_append('')

    # -------------------------------------------------- вердикт
    THRESH = 1e-6
    ok = ((rel < THRESH) and (n_out_off == n_out_fd)
          and (abs(delta_fd - delta_off) <= 1e-9 * abs(delta_off))
          and arch_ok)
    log_append('## Вердикт\n')
    if ok:
        log_append('**OK**: относительное поэлементное расхождение %.3e ниже '
                    'порога %.0e; спектральные инварианты (delta, n_out) '
                    'совпадают между путём 1 и путём 2.' % (rel, THRESH))
    else:
        log_append('**FAIL**: относительное поэлементное расхождение %.3e '
                    'ВЫШЕ порога %.0e. Худший элемент: строка j=%d, '
                    'столбец k=%d, |Delta|=%.3e. Требуется разбор.'
                    % (rel, THRESH, worst[0], worst[1], worst[2]))
    log_append('\nОбщее время выполнения скрипта: %.1f с.\n' % (time.time() - t_start))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
