# -*- coding: utf-8 -*-
"""_appendix_check.py — сплошная сверка Приложения A с артефактами.

ЗАЧЕМ ОН ЕСТЬ.  Приложение A связывает ~60 опубликованных
констант с полями json.  До круга 4 его не сторожил никто: `_numbers_check`
разбирает прозаические формы вида «Y0 ≤ ...·10⁻¹³» и до строк таблицы не
доходит, а `_refs_check` проверял, что поле СУЩЕСТВУЕТ, но не что в нём
лежит.  В эту щель провалилась строка 24: β_81 = 3.45728670541315·10⁻⁸ была
сослана на `kant_l3.json::beta_Np1`, где лежит 3.4572835066·10⁻⁸ — другая
величина, расходящаяся с седьмой значащей.  Ссылка существовала, число было
верным, а связь между ними — ложной.

ПРИНЦИП, который здесь важнее кода: **молчаливых пропусков быть не может**.
Строка таблицы либо проверена, либо внесена в `_ALLOW` с причиной; всё
остальное — провал.  Именно молчаливый пропуск делает сторожа опасным:
зелёный цвет читается как «проверено», а проверено не было.

Что проверяется в каждой строке:
  1. источник разрешается в реально существующий файл пакета;
  2. КАЖДОЕ число, напечатанное в ячейке значения, находится среди чисел
     артефакта — с точностью до единицы последнего напечатанного разряда;
  3. если числа в названном источнике нет, оно ищется по всем сертификатам
     пакета, и найденное там докладывается отдельно: «лежит не там» — это
     ровно дефект строки 24, и отличать его от «нет нигде» полезно.

Сравнение идёт в `decimal`, а не в float: у таблицы есть строки с 16–17
значащими цифрами, где двоичная погрешность сама по себе больше
последнего печатного разряда, и сторож на float пришлось бы ослаблять
до бессмысленного допуска.

Плюс раздел «производные факты»: величины, которых нет в json готовым
числом, а которые считаются по пакету (число боксов, суммарное время
прогона).  Это тот сорт чисел, который расходится с реальностью тише всего.

Переменные окружения: `HYP_ARTICLE` — статья (для фальсификации на копии),
`HYP_PKG` — корень пакета.  Код возврата 0 / 2.
"""
import glob
import io
import json
import os
import re
import sys
from decimal import Decimal, InvalidOperation, Overflow, getcontext

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
getcontext().prec = 60

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('HYP_PKG', os.path.dirname(os.path.dirname(HERE)))
ART = os.environ.get('HYP_ARTICLE', os.path.join(PKG, '01-ARTICLE.md'))

FAILS = []


def fail(where, msg):
    FAILS.append((where, msg))


# --------------------------------------------------------------- числа --
_SUP = {'⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4', '⁵': '5',
        '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9', '⁻': '-', '⁺': '+'}
_SUPCH = ''.join(_SUP)
_NUM = re.compile(r'[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?')


def _desuper(s):
    """`1.5 · 10⁻⁸`, `2 × 10³`, `10⁻⁷` -> `1.5e-8`, `2e3`, `1e-7`.

    Многоточие между мантиссой и показателем (`1.1385…×10⁻⁴²`) — помета
    «это усечение, а не граница» (см. `check_direction`).  Здесь её надо
    снять, иначе `_NUM` обрывает число на мантиссе и показатель
    превращается в отдельное «число» `-42`.
    """
    s = re.sub(r'(?<=[0-9])(?:\u2026|\\ldots)(?=\s*[·×x*]\s*10)', '', s)
    s = re.sub(r'\s*[·×x*]\s*10\s*([' + _SUPCH + r']+)',
               lambda m: 'e' + ''.join(_SUP[c] for c in m.group(1)), s)
    s = re.sub(r'(?<![\de.])10\s*([' + _SUPCH + r']+)',
               lambda m: '1e' + ''.join(_SUP[c] for c in m.group(1)), s)
    return s


# «см. строку 22», «§3.6», «(бокс g42)» — это ссылки, а не величины
_REFS = re.compile(r'(см\.\s*строк[уи]\s*\d+|§\s*[\d.]+|строка\s*\d+)')


def _sigdigits(lit):
    mant = lit.split('e')[0].split('E')[0].lstrip('-+')
    if '.' in mant:
        ip, fp = mant.split('.', 1)
        if ip.strip('0') == '':
            return len(fp.lstrip('0')) or 1
        return len(ip) + len(fp)
    return len(mant.lstrip('0')) or 1


def _dec(lit):
    try:
        return Decimal(lit)
    except InvalidOperation:
        return None


def numbers_in(text, strip_refs=True):
    """Числа строки: список (Decimal, знач_цифр, литерал)."""
    s = _desuper(_REFS.sub(' ', text) if strip_refs else text)
    out = []
    for m in _NUM.finditer(s):
        lit = m.group(0)
        if s[max(0, m.start() - 1):m.start()] in ('_', '['):
            continue                       # индекс, а не величина
        d = _dec(lit)
        if d is not None:
            out.append((d, _sigdigits(lit), lit))
    return out


def _ulp(value, digits):
    """Единица последнего напечатанного разряда."""
    if value == 0:
        return Decimal(10) ** (-digits)
    exp = value.copy_abs().adjusted()      # порядок: floor(log10|v|)
    return Decimal(10) ** (exp - digits + 1)


# Допуск — СТРОГО меньше одной единицы последнего напечатанного разряда.
# Больше нельзя: у двузначного `1.4` две единицы разряда — это ±0.2, и
# подмена на 1.5 проходила бы (проверено фальсификацией).  Меньше не
# нужно: усечение «…» и округление мажоранты вверх укладываются в разряд
# целиком, а дефект круга 4 расходился на 7-й значащей из 15 — на десять
# миллионов разрядов.
_TOL = 1


def close(pub, digits, fact, lit=None):
    """Согласуются ли опубликованное и фактическое.

    Для целого литерала (`80`, `706`, `118`) допуска нет вовсе: это
    счётчик или параметр, он не округляется, и «±2 последних разряда»
    означало бы, что 81 сойдёт за 80.  Для дробного — две единицы
    последнего напечатанного разряда (усечение «…» съедает почти одну,
    округление мажоранты вверх — ещё столько же).
    """
    if lit is not None and re.match(r'^[-+]?\d+$', lit):
        return pub == fact
    try:
        return abs(pub - fact) < _TOL * _ulp(pub, digits)
    except (Overflow, InvalidOperation):
        # `elsewhere()` прогоняет `fact` по ВСЕМ числам ВСЕХ сертификатов
        # пакета — среди них попадаются мусорные "числа" (regex `_NUM` иногда
        # хватает кусок хеша/ID как экспоненту, экспонента может выйти за
        # decimal.Emax=999999). Такой `fact` заведомо не близок к `pub`;
        # раньше это ронило весь сторож `decimal.Overflow`, а не отчитывалось
        # честным "не совпало".
        return False


# ----------------------------------------------------------- артефакты --
_ARBHEAD = re.compile(r'^\[?\s*([-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)')


def _leaf_numbers(obj, acc):
    """Все числа поддерева json как Decimal (arb-строка даёт и середину,
    и радиус: оба встречаются в таблице)."""
    if isinstance(obj, bool):
        return
    if isinstance(obj, int):
        acc.append(Decimal(obj))
    elif isinstance(obj, float):
        acc.append(Decimal(repr(obj)))
    elif isinstance(obj, str):
        head = _ARBHEAD.match(obj.strip())
        if head:
            d = _dec(head.group(1))
            if d is not None:
                acc.append(d)
        for mm in _NUM.finditer(obj):
            d = _dec(mm.group(0))
            if d is not None:
                acc.append(d)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            # ключ — тоже данные: слой записан ключом "(0.7,0.75)"
            for mm in _NUM.finditer(str(k)):
                d = _dec(mm.group(0))
                if d is not None:
                    acc.append(d)
            _leaf_numbers(v, acc)
    elif isinstance(obj, list):
        for v in obj:
            _leaf_numbers(v, acc)


_JCACHE = {}


def load_json(rel):
    if rel not in _JCACHE:
        try:
            _JCACHE[rel] = json.load(io.open(os.path.join(PKG, rel),
                                             encoding='utf-8'))
        except Exception as exc:                       # noqa: BLE001
            _JCACHE[rel] = exc
    return _JCACHE[rel]


def resolve_field(obj, path):
    """`best.L`, `a::b`, `x["1"]` -> список найденных поддеревьев."""
    cur = obj
    for part in re.split(r'[.:]+', path.strip().strip('`')):
        part = part.strip()
        if not part:
            continue
        m = re.match(r'^([\w-]+)\[\"?([\w-]+)\"?\]$', part)
        if m:
            if not isinstance(cur, dict) or m.group(1) not in cur:
                return []
            cur = cur[m.group(1)]
            part = m.group(2)
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return []
    return [cur]


_ALLCERTS = None


def elsewhere(pub, digits):
    """Где ещё в сертификатах лежит это число (для диагноза «не там»)."""
    global _ALLCERTS
    if _ALLCERTS is None:
        _ALLCERTS = []
        pat = os.path.join(PKG, '03-CERTIFICATES', '**', '*.json')
        for p in glob.glob(pat, recursive=True):
            try:
                j = json.load(io.open(p, encoding='utf-8'))
            except Exception:                          # noqa: BLE001
                continue
            acc = []
            _leaf_numbers(j, acc)
            _ALLCERTS.append((os.path.relpath(p, PKG).replace('\\', '/'), acc))
    hits = [rel for rel, acc in _ALLCERTS
            if any(close(pub, digits, f) for f in acc)]
    return hits[:3]


# --------------------------------------------------- список исключений --
# Строка попадает сюда, только если её нельзя проверить машинно, и рядом
# написано ПОЧЕМУ.  Пустая причина недопустима: список читается людьми и
# должен расти медленно — иначе он превращается в способ гасить сторожа.
# Здесь стояли строки 23 и 45 — и это было прикрытие шире
# причины: у обеих исключение оправдывало ОДИН литерал, а гасило строку
# целиком, вместе с реально опубликованными числами.  Пусто — и пусть
# остаётся пустым: строке место в `_ALLOW_NUM`, а не здесь.
_ALLOW = {}

# Исключение на ОТДЕЛЬНЫЙ литерал строки: остальные её числа продолжают
# сверяться.  Так список исключений не съедает строку целиком ради одного
# производного числа в подписи — а именно так сторожа и слепнут.
# Числа перед словом «бокс», которые не являются счётчиком сертификатов.
# Как и всюду здесь: с причиной, иначе исключение — это дыра.
_BOX_COUNT_OK = {
    5: '«4–5 боксах верхнего края» — оценка в тексте §10.9',
    7: '«всех 7 боксов» (g37..g43, lemma_bases_K=2, §6.2)',
    8: '«вернуло 8 боксов (g30–g37)» — подмножество',
    9: '«9 боксов слоя» — где потребовалось подразбиение K=2',
    43: '«на 43 боксах коэффициент отказа > 3.5» — подмножество 46, §3.5; '
        'побоксовые τ в пакете не депонированы, пересчитать нельзя',
    512: '512 боксов-дуг в gate 3 — дуги, не ℓ-боксы',
    696: 'исходный план трубки до перенарезки, назван историческим',
}

# Имена боксов и пар слоёв в ячейке значения: атрибуция, которую сверяем
# отдельно от чисел.
_BOXTAG = re.compile(r'\b(g\d{2}|gtop|ganchor|t\d{4})\b')
_LAYERPAIR = re.compile(r'\((0\.\d+)\s*,\s*(0\.\d+)\)')

# Исключения для атрибуции — с причиной, как и всюду здесь.
_ALLOW_ATTR = {}


def _num_in_text(s, raw):
    """Число слоя может лежать как 0.7, 0.70 или 0.7000000000000001."""
    if s in raw:
        return True
    try:
        v = float(s)
    except ValueError:
        return False
    for cand in ('%g' % v, '%.1f' % v, '%.2f' % v, repr(v)):
        if cand in raw:
            return True
    return False


# Какие исключения РЕАЛЬНО сработали за прогон.  Исключение, которое больше
# ничего не гасит, — это ложь о том, что в таблице стоит: строка 53 сменила
# число 1.50 на 1.522, исключение осталось со старым литералом, сторож молча
# покраснел и остался незапущенным.  Неиспользованное исключение теперь провал.
_ALLOW_NUM_USED = set()

_ALLOW_NUM = {
    ('35', '0.9256685'): 'корень 16-й степени из строки 34; '
                        'пересчитывается в разделе производных фактов',
    ('58', '118'): 'проценты от rel_diff_vs_base; пересчитываются '
                   'в разделе производных фактов',
    # Строка 53 сменила слой: максимум κ_G ушёл на дальний угол коридора
    # `corridor cell (0.612,0.910)`, и c+r стало 1.522 вместо 1.50.  Само
    # исключение осталось со старым литералом и молча краснело — сторож
    # падал, а его никто не запускал.  Отсюда правило ниже: НЕИСПОЛЬЗОВАННОЕ
    # исключение — тоже провал.
    ('53', '1.522'): 'c+r слоя: в json лежат слагаемые (0.612 и 0.910 '
                     'в метке layer «corridor cell»), а не сумма',
    ('57', '8.882e-15'): 'производная величина; сверяется пересчётом '
                         'в разделе производных фактов',
    # Здесь стояли ещё четыре исключения — ('57','1.51e-14') и все три из
    # строки 45. Новая проверка «неиспользованное исключение — провал»
    # показала, что ни одно из них ничего не гасит: эти числа сверяются сами,
    # прямо против артефактов. Исключение, которое ничего не гасит, — не
    # безобидная подстраховка, а заготовленная дыра: если артефакт изменится,
    # оно молча прикроет расхождение. Удалены.
    ('23', '1.1385676782e-42'): 'гипотетическое «со строгим Ẑ было бы»: '
                            'в артефактах не лежит по построению, '
                            'реальное значение строки сверяется',
}


# -------------------------------------------------------------- разбор --
_ROW = re.compile(r'^\|\s*([^|]{1,24}?)\s*\|(.+?)\|(.+?)\|(.+?)\|\s*$')


def parse_rows(text):
    rows, inapp = [], False
    for i, line in enumerate(text.split('\n'), 1):
        if line.startswith('## Приложение A'):
            inapp = True
            continue
        if inapp and line.startswith('## '):
            break
        if not inapp:
            continue
        m = _ROW.match(line)
        if not m or not re.match(r'^\d', m.group(1).strip()):
            continue
        rows.append({'n': m.group(1).strip(), 'line': i,
                     'name': m.group(2).strip(), 'value': m.group(3).strip(),
                     'src': m.group(4).strip()})
    return rows


_PATH = re.compile(r'((?:[\w-]+/)*[\w.-]+\.json)')


def _resolve_path(p):
    for cand in (p, '03-CERTIFICATES/' + p):
        if os.path.exists(os.path.join(PKG, cand)):
            return cand
    return None


def _fields_from(chunk):
    """`::a, b` и `::{a,b}` -> ['a', 'b']."""
    out = []
    for f in re.split(r'[,\s]+', chunk.strip().strip('{}')):
        f = f.strip().strip('{},')
        if re.match(r'^[\w.\[\]"-]+$', f) and not f.endswith('.json'):
            out.append(f)
    return out


def bindings_of(cell):
    """Ячейка источника -> [(путь, [поля]), ...].

    Поля привязываются к СВОЕМУ файлу: ячейка бывает вида
    `a.json::x + b.json::y`, и искать `x` в `b.json` — заведомо промах,
    который до круга 4 маскировался расширением поиска на весь файл.
    """
    s = cell.replace('`', '')
    hits = list(_PATH.finditer(s))
    out = []
    for i, m in enumerate(hits):
        rel = _resolve_path(m.group(1))
        if rel is None:
            continue
        tail = s[m.end():hits[i + 1].start() if i + 1 < len(hits) else len(s)]
        fm = re.match(r'\s*::\s*([^|+]+)', tail)
        out.append((rel, _fields_from(fm.group(1)) if fm else []))
    return out


def sources_of(cell):
    return [rel for rel, _ in bindings_of(cell)]


def published_values(cell):
    """Числа ячейки значения.  Дробь вида `3/5` — одно число, а не два."""
    plain = cell.replace('`', '').replace('*', '').strip()
    m = re.match(r'^(\d+)\s*/\s*(\d+)$', plain)
    if m:
        val = Decimal(m.group(1)) / Decimal(m.group(2))
        return [(val, 6, plain)]
    return numbers_in(plain)


# -------------------------------------------------------------- проход --
def check_table(text):
    rows = parse_rows(text)
    if len(rows) < 50:
        fail('Приложение A', 'разобрано всего %d строк — формат таблицы '
                             'изменился, сторож ослеп' % len(rows))
        return 0, 0
    seen = set()
    checked = allowed = 0
    for r in rows:
        if r['n'] in seen:
            fail('Приложение A', 'номер строки %s встречается дважды'
                                 % r['n'])
        seen.add(r['n'])
        tag = 'Прил.A стр.%s (:%d)' % (r['n'], r['line'])
        if r['n'] in _ALLOW:
            allowed += 1
            continue
        binds = bindings_of(r['src'])
        srcs = [rel for rel, _ in binds]
        if not srcs:
            fail(tag, 'источник не разрешается ни в один json пакета: %r'
                      % r['src'][:70])
            continue
        # Имена боксов (`g00`, `t0464`) — атрибуция, её сверяет
        # отдельная проверка ниже; из ячейки их надо убрать, иначе
        # числовой разбор видит в `g00` число «00» и ищет его в json.
        pubs = published_values(_BOXTAG.sub(' ', r['value']))
        if not pubs:
            fail(tag, 'в ячейке значения нет ни одного числа: %r'
                      % r['value'][:60])
            continue
        facts = []
        for s, flds in binds:
            j = load_json(s)
            if isinstance(j, Exception):
                fail(tag, 'не читается %s: %s' % (s, j))
                continue
            got, unresolved = [], []
            for f in flds:
                subs = resolve_field(j, f)
                if not subs:
                    unresolved.append(f)
                for sub in subs:
                    if sub is not None:
                        _leaf_numbers(sub, got)
            if flds and not got:
                # Поле названо, но не найдено.  Расширяться на весь файл
                # тут нельзя: тогда опечатка в имени поля прячется за
                # случайным совпадением где-то ещё в том же json — ровно
                # дефект круга 4, только с другой стороны.
                fail(tag, 'в %s не найдено ни одно из названных полей: %s'
                          % (s, ', '.join(unresolved)))
                continue
            if not got:
                _leaf_numbers(j, got)
            facts += got
        if not facts:
            fail(tag, 'из источника не извлеклось ни одного числа')
            continue
        # Атрибуция.  Имя бокса и слой в ячейке значения — такая же
        # часть утверждения, как число: по ним читатель идёт проверять.
        # Подмена, не меняющая цифр (`g43` -> `gtop`), проходила молча.
        _raw = ''
        for s, _ in binds:
            _p = os.path.join(PKG, s)
            if os.path.exists(_p):
                _raw += io.open(_p, encoding='utf-8',
                                errors='replace').read()
        # Если источник называет бокс отдельным полем (`*_box`), сверяем со
        # ЗНАЧЕНИЕМ этого поля: простое присутствие подстроки не годится там,
        # где json перечисляет все боксы подряд — тогда подходит любой.
        _named = set()
        for s, flds in binds:
            j = load_json(s)
            if isinstance(j, Exception):
                continue
            for f in flds:
                # Имя бокса может стоять не в значении поля, а в
                # САМОМ ПУТИ (`boxes.g00.tau_break_factor`).  Тогда искать
                # его подстрокой бесполезно: в протоколе лежат все боксы,
                # и подмена g00 -> g43 проходила молча.
                for _part in f.split('.'):
                    if _BOXTAG.fullmatch(_part):
                        _named.add(_part)
                for sub in resolve_field(j, f):
                    if isinstance(sub, str) and _BOXTAG.fullmatch(sub.strip()):
                        _named.add(sub.strip())
        for _tok in set(_BOXTAG.findall(r['value'])):
            if (r['n'], _tok) in _ALLOW_ATTR:
                continue
            if _named:
                if _tok not in _named:
                    fail(tag, 'атрибуция %r: источник (%s) называет боксом %s'
                              % (_tok, ', '.join(srcs), ', '.join(sorted(_named))))
            elif _tok not in _raw:
                fail(tag, 'атрибуция %r: в названном источнике (%s) такого '
                          'бокса нет' % (_tok, ', '.join(srcs)))
        for _c, _rr in set(_LAYERPAIR.findall(r['value'])):
            if (r['n'], _c + ',' + _rr) in _ALLOW_ATTR:
                continue
            if not (_num_in_text(_c, _raw) and _num_in_text(_rr, _raw)):
                fail(tag, 'атрибуция слоя (%s,%s): в названном источнике '
                          '(%s) такой пары нет' % (_c, _rr, ', '.join(srcs)))

        bad = []
        for d, dg, lit in pubs:
            if any(close(d, dg, f, lit) for f in facts):
                continue
            if (r['n'], lit) in _ALLOW_NUM:
                _ALLOW_NUM_USED.add((r['n'], lit))
                continue
            bad.append((d, dg, lit))
        if bad:
            for d, dg, lit in bad:
                where = elsewhere(d, dg)
                if where:
                    fail(tag, 'напечатано %s — в названном источнике (%s) '
                              'этого числа нет, оно лежит в %s'
                              % (lit, ', '.join(srcs), ', '.join(where)))
                else:
                    fail(tag, 'напечатано %s — такого числа нет ни в '
                              'названном источнике (%s), ни в остальных '
                              'сертификатах' % (lit, ', '.join(srcs)))
        else:
            checked += 1
    return checked, allowed


# --------------------------------------------------- производные факты --
def check_derived(text):
    """Числа, которых нет в json готовыми: счётчики и суммы."""
    done = [0]
    ex = sorted(glob.glob(os.path.join(PKG, '03-CERTIFICATES', 'existence',
                                       'box_g*.json')))
    total_s = Decimal(0)
    for p in ex:
        j = json.load(io.open(p, encoding='utf-8'))
        total_s += Decimal(repr(float(j.get('time_s') or 0.0)))

    def one(what, patt, fact, digits=None):
        hits = re.findall(patt, text)
        if not hits:
            fail('производные', '%s: в статье нет ни одного вхождения %r — '
                                'проверка стала холостой' % (what, patt))
            return
        for h in hits:
            lit = h if isinstance(h, str) else h[0]
            nums = numbers_in(lit)
            if not nums:
                continue
            value, dig, vlit = nums[0]
            if not close(value, digits or dig, fact,
                         vlit if digits is None else None):
                fail('производные', '%s: в статье %s, посчитано по пакету %s'
                                    % (what, lit, fact))
                return
        done[0] += 1

    # Строка 45 Приложения A: «первая непроходящая полуширина ±4.5·10⁻²,
    # 44/46, гейт lemma_U».  Ни одно из трёх чисел не лежит в json готовым,
    # поэтому пересчитываем из ячеек: берём наименьшую полуширину, на
    # которой прошли не все боксы.
    _bis = os.path.join(PKG, '03-CERTIFICATES', 'layer', 'cells3_bisect.json')
    if not os.path.exists(_bis):
        fail('производные', 'нет cells3_bisect.json — строка 45 Приложения A '
                            'осталась бы непроверенной')
    else:
        _cells = json.load(io.open(_bis, encoding='utf-8'))
        _fails = []
        for _c in _cells:
            _hw = (_c['cell'][1] - _c['cell'][0]) / 2
            _tot = len(_c['boxes'])
            _ok = sum(1 for _b in _c['boxes'].values() if _b.get('pass'))
            if _ok < _tot:
                _fails.append((_hw, _ok, _tot))
        if not _fails:
            fail('производные', 'в cells3_bisect.json нет ни одной ячейки с '
                                'провалом — строке 45 неоткуда взяться')
        else:
            _hw, _ok, _tot = min(_fails)
            _r45 = [r for r in parse_rows(text) if r['n'] == '45']
            if not _r45:
                fail('производные', 'строка 45 Приложения A не найдена')
            else:
                _v = _r45[0]['value']
                _want = ('4.5', '%d/%d' % (_ok, _tot))
                for _w in _want:
                    if _w not in _v:
                        fail('производные',
                             'строка 45: в статье %r, по cells3_bisect '
                             'полуширина ±%.4g, прошло %d/%d'
                             % (_v, _hw, _ok, _tot))
                        break
                else:
                    if abs(_hw - 0.045) > 1e-12:
                        fail('производные',
                             'строка 45: полуширина по пакету ±%.6g, '
                             'а в статье ±4.5·10⁻²' % _hw)
                    else:
                        done[0] += 1

    # Счётчик боксов проверяется не по одному месту, а инвариантом:
    # КАЖДОЕ число перед словом «бокс» в статье обязано быть либо реальным
    # числом сертификатов, либо явно объяснённым исключением.  Так «706 ->
    # 707» ловится, где бы его ни написали, а не только в опорной фразе.
    tube_n = len(glob.glob(os.path.join(PKG, '03-CERTIFICATES', 'tube',
                                        'box_*.json')))
    legit = {len(ex): 'сертификаты существования',
             tube_n: 'сертификаты трубки'}
    for num, why in _BOX_COUNT_OK.items():
        legit[num] = why
    # Счётчики боксов трубки по десятым отрезка (§7.4) — не в белый список, а
    # ВЫЧИСЛЯЕМЫЕ: белый список говорит «этому числу верь», не проверяя его, и
    # ровно так «107 боксов» пережило смену критерия. Считаем по ЦЕНТРУ бокса,
    # как и сказано в тексте; если статья разойдётся с сертификатами, число не
    # попадёт в `legit` и сторож упадёт.
    from fractions import Fraction as _Fr
    _cent = []
    for _p in glob.glob(os.path.join(PKG, '03-CERTIFICATES', 'tube',
                                     'box_t*.json')):
        _j = json.load(open(_p, encoding='utf-8'))
        _cent.append(_Fr('%.17e' % _j['ell0']))
    for _lo, _hi, _what in ((_Fr(19, 5), _Fr(4), 'последняя'),
                            (_Fr(2), _Fr(11, 5), 'первая')):
        _n = sum(1 for _e in _cent if _lo <= _e <= _hi)
        legit[_n] = ('%s десятая отрезка, боксов трубки ПО ЦЕНТРУ — '
                     'пересчитано по %d сертификатам' % (_what, len(_cent)))
    # `(?<![\d.])` — иначе «0.03 бокса» (ШИРИНА бокса `gtop`) читается как
    # «3 бокса»: регулярка выхватывает `03` из дробной части.
    seen_counts = set(int(m) for m in re.findall(r'(?<![\d.])(\d+)\s+бокс\w*',
                                                 text))
    for n in sorted(seen_counts):
        if n not in legit:
            fail('производные', 'в статье написано «%d боксов», а в пакете '
                                'их %d (существование) и %d (трубка); если '
                                'число законно, его место в _BOX_COUNT_OK '
                                'с причиной' % (n, len(ex), tube_n))
    if seen_counts:
        done[0] += 1
    one('суммарное время существования, ядро-минуты',
        r'([\d.]+)\s+ядро-минут', total_s / 60, digits=3)

    # Отклонение δ по слоям (теорема D): в json лежат сами δ, а не их
    # разности, поэтому оба числа строки 57 считаются здесь.
    probe = os.path.join(PKG, '03-CERTIFICATES', 'layer',
                         'dt_layer_probe.json')
    # Три блока ниже стояли как «есть файл — проверяем, нет — молчим»: пропажа
    # файла пакета убирала проверку и оставляла шаг зелёным. Оба файла входят
    # в манифест, значит их отсутствие — порча пакета, и она обязана быть
    # красной здесь же, а не только в отдельном шаге целостности.
    for _need in (probe, os.path.join(PKG, '03-CERTIFICATES', 'pointwise',
                                      'q_perturb_patch.json')):
        if not os.path.exists(_need):
            raise SystemExit('нет файла пакета %s: без него проверки строк 57-58 '
                             'приложения молча не выполняются'
                             % os.path.relpath(_need, PKG))
    if os.path.exists(probe):
        layers = json.load(io.open(probe, encoding='utf-8'))['layers']
        base = [l for l in layers
                if abs(l['c'] - 0.6) < 1e-12 and abs(l['r'] - 0.8) < 1e-12]
        others = [l for l in layers if l not in base]
        if base and others:
            # Разности считаются во float — ровно так, как их посчитал
            # производивший скрипт.  В Decimal по 17-значным reprs
            # вычитание близких чисел даёт 8.9e-15 вместо 8.8818e-15:
            # это не расхождение с пакетом, а другая арифметика.
            bf = base[0]['delta']
            devs = [Decimal(repr(abs(l['delta'] - bf))) for l in others]
            dd = [l['delta'] for l in layers]
            alld = [Decimal(repr(max(dd) - min(dd)))]
            one('число точечных слоёв', r'(\d+)\s+сло[её]в:',
                Decimal(len(others)))
            one('максимум отклонения δ от базового слоя',
                r'максимум отклонения `δ` от базового слоя по \d+ слоям'
                r'[^|]*\|\s*([\d.]+×10⁻¹⁵)', max(devs))
            one('полный разброс δ по слоям',
                r'полный разброс — ([\d.]+×10⁻¹⁴)', alld[0])
    # Строка 35: ρ(Q★) ≤ (‖Q★¹⁶‖₁)^{1/16}.  Отдельным числом не лежит,
    # поэтому берём корень из того, что лежит.
    qp = os.path.join(PKG, '03-CERTIFICATES', 'pointwise',
                      'q_perturb_patch.json')
    if os.path.exists(qp):
        s16 = json.load(io.open(qp, encoding='utf-8'))['summary']['sum_q16']
        rho = Decimal(repr(float(s16) ** (1.0 / 16.0)))
        one('rho(Q*) как корень 16-й степени',
            'ρ\\(Q★\\) upper[^|]*\\|\\s*([0-9.]+)…', rho)

    # Строка 58: расхождение матриц DT в процентах.
    if os.path.exists(probe):
        rel = [l.get('rel_diff_vs_base', 0.0) for l in layers]
        one('расхождение матриц DT, проценты',
            'максимум расхождения матриц `DT` \\| ([0-9]+) %',
            Decimal(repr(max(rel) * 100)), digits=3)

    return done[0]


# --------------------------------------------------------------- main --
# ------------------------------------------- направление округления --
# Конвенция статьи: мажоранта печатается ВВЕРХ, миноранта ВНИЗ, «обратное
# направление — дефект».  До круга 72 сторож этого не проверял вовсе:
# `close()` — симметричный допуск в один разряд, и мажоранту можно было
# занизить внутрь на целую единицу последнего знака, оставив ворота
# зелёными (проверено фальсификацией на четырёх строках подряд).
#
# Многоточие в напечатанном числе — не украшение, а ЗАЯВЛЕНИЕ: «это
# усечение точного значения, а не граница».  Такие числа от правила
# стороны освобождены, остальные — обязаны стоять снаружи факта.
_DIR = {
    '14': 'up', '15–18': 'up', '19': 'up', '25': 'up', '27': 'up',
    '28': 'up', '30': 'up', '33': 'up', '38': 'up', '39': 'up',
    '51': 'up', '62': 'up', '63': 'up',
    '43': 'dn', '44': 'dn', '46': 'dn', '47': 'dn', '48': 'dn',
    '49': 'dn', '50': 'dn', '56': 'dn', '64': 'dn',
}
# Сколько величин реально прошло проверку стороны в прошлый раз.  Падение
# счёта означает, что строка переименовалась или число перестало
# разбираться, — и проверка молча стала холостой.
DIR_MIN = 27


def check_direction(text):
    """Стоит ли каждое НЕусечённое число объявленной стороной от факта."""
    done = 0
    for r in parse_rows(text):
        want = _DIR.get(r['n'])
        if want is None:
            continue
        tag = 'направление стр.%s (:%d)' % (r['n'], r['line'])
        cell = _LAYERPAIR.sub(' ', _BOXTAG.sub(' ', r['value']))
        binds = bindings_of(r['src'])
        facts = []
        for s, flds in binds:
            j = load_json(s)
            if isinstance(j, Exception):
                continue
            got = []
            for f in flds:
                for sub in resolve_field(j, f):
                    if sub is not None:
                        _leaf_numbers(sub, got)
            if not got:
                _leaf_numbers(j, got)
            facts += got
        pubs = published_values(cell)
        seen = 0
        for d, dg, lit in pubs:
            # Усечение помечено многоточием — стороне не подчиняется.
            # Сравнивать надо МАНТИССУ: в `lit` показатель уже свёрнут в `e-33`,
            # а в тексте многоточие стоит между мантиссой и «×10⁻³³».
            _mant = lit.split('e')[0].split('E')[0]
            if (_mant + '\u2026') in cell or (_mant + '\\ldots') in cell:
                continue
            m = [f for f in facts if close(d, dg, f, lit)]
            if not m:
                continue
            seen += 1
            f = m[0]
            ok = (d >= f) if want == 'up' else (d <= f)
            if not ok:
                fail(tag, 'напечатано %s, факт %s — граница округлена '
                          'ВНУТРЬ (ждём %s)'
                          % (lit, str(f)[:26],
                             'вверх' if want == 'up' else 'вниз'))
            else:
                done += 1
        if seen == 0:
            fail(tag, 'ни одно число строки не сверилось с фактом — '
                      'проверка направления стала холостой')
    if done < DIR_MIN:
        fail('направление округления',
             'сторон проверено %d, минимум %d — часть строк перестала '
             'разбираться' % (done, DIR_MIN))
    return done


# ------------------------------------------------- сверка со стогом --
# Если источник строки назван БЕЗ поля (`layer/kappa_full.json` вместо
# `...json::kappa_G`), сверка вырождается: `_leaf_numbers` вываливает ВСЕ
# числа файла, и опубликованному хватает совпасть с любым из них.  На
# `kappa_full.json` это 7360 чисел; подмена `κ_G` базового слоя на `κ_G`
# СОСЕДНЕГО слоя проходила молча (проверено фальсификацией).
#
# Убрать вырождение целиком нельзя, не переписав столбец происхождения у
# семнадцати строк.  Но его можно СДЕЛАТЬ ВИДИМЫМ и запретить расти:
# каждая новая строка без поля обязана быть осознанным решением, а не
# случайностью.
HAY_MAX = 17


def check_haystack(text):
    """Сколько строк сверяется не с полем, а с любым числом файла."""
    hay = []
    for r in parse_rows(text):
        if r['n'] in _ALLOW:
            continue
        binds = bindings_of(r['src'])
        if binds and not any(flds for _, flds in binds):
            n = 0
            for s, _ in binds:
                j = load_json(s)
                if isinstance(j, Exception):
                    continue
                acc = []
                _leaf_numbers(j, acc)
                n += len(acc)
            hay.append((r['n'], n))
    if len(hay) > HAY_MAX:
        fail('сверка со стогом',
             'строк без названного поля стало %d, было не более %d: %s'
             % (len(hay), HAY_MAX,
                ', '.join(n for n, _ in hay[HAY_MAX:])))
    return hay


def main():
    if not os.path.exists(ART):
        print('НЕТ СТАТЬИ: %s' % ART)
        return 2
    text = io.open(ART, encoding='utf-8').read()
    checked, allowed = check_table(text)
    derived = check_derived(text)
    directed = check_direction(text)
    print('Приложение A: строк сверено с артефактами %d, '
          'в списке исключений %d' % (checked, allowed))
    print('производных фактов сверено: %d' % derived)
    print('сторон округления проверено: %d' % directed)
    _hay = check_haystack(text)
    print('сверяется со стогом (источник без поля): строк %d, чисел в стогах %d'
          % (len(_hay), sum(n for _, n in _hay)))
    stale = sorted(set(_ALLOW_NUM) - _ALLOW_NUM_USED)
    if stale:
        for key in stale:
            fail('исключение %s' % (key,),
                 'больше ничего не гасит: литерал из таблицы исчез или '
                 'изменился, а исключение осталось — проверь строку')
    else:
        print('исключений на литерал: %d, все сработали'
              % len(_ALLOW_NUM))
    if FAILS:
        print('\n*** ПРОВАЛЫ (%d) ***' % len(FAILS))
        for where, msg in FAILS:
            print('  %-22s %s' % (where, msg))
        return 2
    print('расхождений нет.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
