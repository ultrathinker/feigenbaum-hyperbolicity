# -*- coding: utf-8 -*-
"""
_classic_constants.py — внешняя сверка: δ и α на концах отрезка против
классических значений Фейгенбаума.

Зачем. У всех внутренних проверок пакета есть общая точка отказа: и
сертификаты существования, и трубка, и оба точечных якоря опираются на один
и тот же вывод производной `DF`. Систематическая ошибка в нём была бы
унаследована всеми проверками сразу: сертификаты добросовестно подтверждали
бы неверную величину, и ни одна внутренняя проверка этого не поймала бы.

Против этого есть ровно одно дешёвое лекарство — сверить наши числа с
числами, посчитанными другими людьми другими методами. Оба конца отрезка
для этого годятся:

  * `ℓ = 2` — классический квадратичный случай, δ и α известны с сотнями
    знаков (OEIS A006890 / A006891; Briggs, *Math. Comp.* 57 (1991);
    Broadhurst 1999);
  * `ℓ = 4` — критическая точка четвёртой степени, δ и α взяты из
    Burbanks-Osbaldestin-Thurlby (2021), десять знаков (независимо
    согласуется с ~60 знаками Briggs (1991)).

Как считается наше значение. `α = −1/G(1)` берётся прямо из коэффициентов
параметрического центра `P(ℓ)`: они хранятся в мономиальном базисе, поэтому
`G(1)` — просто их сумма. `δ` — степенным методом в arb по матрице `DT`:
`|λ₂|/δ ≈ 0.034`, так что нескольких десятков итераций хватает с запасом.
Ни float-собственные значения, ни разведочный скан `05-DATA/delta_scan.py`
здесь не участвуют — это независимый от них путь.

Чего тест НЕ проверяет: он работает с центром `P(ℓ)`, а не с решением
`G*(ℓ)`. Расстояние между ними ограничено `ρ*_X` порядка `10⁻¹²`, и оно же
задаёт предел достижимого совпадения — глубже сходиться не с чем.

Запуск:  python tests/_classic_constants.py
"""
import math
import os
import sys

import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                      # 04-CODE
PKG = os.path.dirname(PARENT)
sys.path.insert(0, PARENT)
BRANCH_DIR = os.environ.get('HYP_BRANCHES',
                            os.path.join(PKG, '03-CERTIFICATES', 'branches'))

import rig_lib as rl
import tube_lib as tl
import hyp_rouche as hr
from flint import arb, ctx, arb_mat

ctx.prec = 256

# Внешние значения.  ℓ=2: OEIS A006890 (δ) и A006891 (α) — здесь 48 знаков
# из доступных 100+.  ℓ=4: Burbanks-Osbaldestin-Thurlby (2021) — 10 знаков
# (почему не Briggs — см. примечание к самим значениям ниже).
EXT = {
    2.0: {'delta': ('4.669201609102990671853203820466201617258185577476',
                    'OEIS A006890 / Briggs 1991'),
          'alpha': ('2.502907875095892822283902873218215786381271376727',
                    'OEIS A006891 / Briggs 1991')},
    # Было «Briggs 1991» — атрибуция подписи была неверной, не факт
    # расчёта: Бриггс независимо считал и ℓ=4 (Briggs 1991; см. также его же
    # диссертацию 1997 г., §2.1, Table 2.3, ~60 верных знаков), но с меньшей
    # точностью, чем ниже.  Значения при ℓ=4 ниже — из
    # Burbanks-Osbaldestin-Thurlby (2021), >320 знаков, см. 06-REFERENCES.md.
    # Здесь стояли ОДИННАДЦАТЬ знаков — при том что комментарий выше сам
    # говорит «>320 знаков». Одиннадцать — это черновая промежуточная граница
    # из §IV E статьи BOT (`δ ∈ [7.28468621706, 7.28468621709]`), а не её
    # результат: Table II на с. 8 печатает 331 верный знак α и 325 знаков δ.
    # Из-за усечения внешний контроль при ℓ = 4 был ослаблен на три порядка
    # ровно на том конце отрезка, который труднее.
    4.0: {'delta': ('7.28468621707334336430893056799555306947804661979979',
                    'Burbanks-Osbaldestin-Thurlby 2021, Table II'),
          'alpha': ('1.69030297140524485334378015032416134822827805970956',
                    'Burbanks-Osbaldestin-Thurlby 2021, Table II')},
}

BOX = {2.0: 'branch_g00.npz', 4.0: 'branch_gtop.npz'}

# Ровно те числа, которые заявлены в §3.9 статьи.  Выше поднимать нельзя:
# предел задаётся расстоянием центр P(ℓ) → решение G*(ℓ).
NEED = {2.0: {'delta': 15, 'alpha': 14},
        # 11 -> 14: порог был не пределом точности, а длиной УСЕЧЁННОГО
        # эталона. Против настоящего (BOT Table II) совпадение равно 14 знакам
        # у обеих величин — столько и требуем.
        4.0: {'delta': 14, 'alpha': 14}}


def center_at(tag, ell):
    z = np.load(os.path.join(BRANCH_DIR, tag))
    c_a, m = z['c_a'], int(z['m'][0])
    e0, w = float(z['ell0'][0]), float(z['w'][0])
    if not (e0 - w / 2 - 1e-12 <= ell <= e0 + w / 2 + 1e-12):
        raise RuntimeError('ветка %s не накрывает ell=%.3f' % (tag, ell))
    x = 2.0 * (ell - e0) / w
    return rl.P_at(c_a, m, arb('%.17e' % x)), (e0 - w / 2, e0 + w / 2)


def delta_power(P, ell, iters=60, tol='1e-45'):
    """Ведущее собственное значение DT степенным методом в arb."""
    pkg = tl.build_pkg_fast(P, arb('%.17e' % ell))
    if pkg is None:
        raise RuntimeError('пакет не построился при ell=%.3f' % ell)
    DT = hr.dt_from_pkg(pkg)
    n = hr.NP
    A = arb_mat(n, n, [DT[j][k] for j in range(n) for k in range(n)])
    v = arb_mat(n, 1, [arb(1) for _ in range(n)])
    prev = None
    lam = arb(0)
    for it in range(iters):
        w = A * v
        jm, best = 0, arb(0)
        for j in range(n):
            a = abs(v[j, 0])
            if a > best:
                best, jm = a, j
        lam = w[jm, 0] / v[jm, 0]
        mx = arb(0)
        for j in range(n):
            a = abs(w[j, 0])
            if a > mx:
                mx = a
        v = arb_mat(n, 1, [w[j, 0] / mx for j in range(n)])
        if prev is not None and abs(lam - prev) < arb(tol):
            return lam, it + 1
        prev = lam
    return lam, iters


def agree_digits(a, b):
    """Сколько первых значащих десятичных знаков совпало."""
    d = abs(a - b)
    if not (d > 0):
        return 99
    return int(math.floor(-math.log10(float(d) / float(abs(a)))))


def main():
    bad = 0
    print('внешняя сверка: наше значение против опубликованного')
    print('-' * 92)
    for ell in (2.0, 4.0):
        P, box = center_at(BOX[ell], ell)
        G1 = arb(0)
        for a in P:
            G1 = G1 + a
        alpha = -arb(1) / G1
        delta, iters = delta_power(P, ell)
        print('')
        print('ell = %.1f   бокс существования [%.4f, %.4f], степенной метод: %d итераций'
              % (ell, box[0], box[1], iters))
        for name, key, ours in (('delta', 'delta', delta), ('alpha', 'alpha', alpha)):
            ext_s, src = EXT[ell][key]
            ext = arb(ext_s)
            nd = agree_digits(ours, ext)
            # Порог обязан фальсифицировать ИМЕННО то, что напечатано в
            # статье (§3.9).  Прежнее `min(..., 12)` пропускало бы 12 знаков
            # как PASS, тогда как заявлено 15/14 при ℓ=2 и все 11 при ℓ=4.
            need = NEED[ell][key]
            ok = nd >= need
            if not ok:
                bad += 1
            print('  %-5s наше    %s' % (name, ours.str(20)))
            print('        внешнее %s   (%s)' % (ext.str(20), src))
            print('        совпало знаков: %d, нужно >= %d   %s'
                  % (nd, need, 'ok' if ok else '*** FAIL ***'))
    print('')
    print('-' * 92)
    if bad:
        print('*** ПРОВАЛОВ: %d ***' % bad)
    else:
        print('СВЕРКА ПРОЙДЕНА: движок воспроизводит опубликованные константы на')
        print('обоих концах отрезка. Систематическая ошибка в выводе DF, общая')
        print('для всех внутренних проверок, этим исключается.')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
