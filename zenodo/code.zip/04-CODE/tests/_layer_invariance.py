# -*- coding: utf-8 -*-
"""
_layer_invariance.py — зависит ли спектр `DT` от выбора слоя `(c, r)`.

Зачем. Теоремы A/B/C сформулированы про оператор, суженный на конкретное
пространство: аналитические функции в круге `D(c, r)` с `c = 3/5`,
`r = 4/5`. Отсюда законный вопрос: `δ(ℓ)` — универсальная величина при
показателе `ℓ` или собственное значение нашего оператора на нашем слое?
Строгий ответ даёт теорема D (§10 статьи, код `04-CODE/layer/`): спектр
совпадает на всём сертифицированном семействе слоёв `𝔉`. Этот тест —
независимая численная иллюстрация того же факта, более широкая по сетке
`(c, r, N_p)`, но не строгая.

Что важно понимать про устройство проверки. Параметрический центр `P(ℓ)`
хранится в МОНОМИАЛЬНОМ базисе `t^k` (`rig_lib.P_at`: «0-center coeffs»,
`out[0] = 1` — это нормировка `G(0) = 1`). Поэтому при смене слоя саму
функцию менять не надо и НЕЛЬЗЯ: подставляются те же коэффициенты, а
меняются только `c`, `r` и производные от них величины внутри движка.
Сдвиг коэффициентов «в новый центр» дал бы другую функцию `P(t + Δ)`,
которая неподвижной точкой не является, и спектр поехал бы — но это была бы
подмена задачи, а не свойство оператора.

Структурная причина ожидаемой инвариантности: усечение идёт на многочлены
степени `≤ N_p`, а это подпространство от `(c, r)` не зависит —
многочлены степени `≤ N_p` по `(t−c)` и по `(t−c′)` образуют одно и то же
множество. Смена слоя действует на нём как замена базиса: диагональная по
`r` (в точности, см. вес `r^k`) и треугольная по `c` (бином Ньютона).
Тест показывает, что и численно спектр от слоя не зависит.

Чего тест НЕ доказывает: это float-собственные значения усечённой матрицы,
а не сертификат. Строгое утверждение о независимости спектра от слоя в
работе ЕСТЬ — теорема D, §10, — но оно доказано для сертифицированного
семейства слоёв `𝔉`, а не для произвольного `(c, r)`; этот тест его не
заменяет и на слои вне `𝔉` его не распространяет.

Запуск:  python tests/_layer_invariance.py
"""
import os
import os as _os  # алиас для env в воркере (os остаётся)
import multiprocessing as _mp
import sys

import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)                      # 04-CODE
PKG = os.path.dirname(PARENT)
sys.path.insert(0, PARENT)
BRANCH_DIR = os.environ.get('HYP_BRANCHES',
                            os.path.join(PKG, '03-CERTIFICATES', 'branches'))

import rig_lib as rl
import tube_lib as tl
import hyp_rouche as hr
from flint import arb, ctx

ctx.prec = 256

C0, R0, NP0 = 0.6, 0.8, 80

# слои: (c, r, N_p).  Разброс по c — 25 % от номинала, по r — 25 %.
# Здесь было 13 строк, и из 14 слоёв семейства 𝔉 три не
# покрывались вовсе: (0.55,0.70), (0.65,0.85) и (0.70,0.75) — а последний
# в §10.13 назван самым тонким (худшая маржа по 644 парам).  Проверять
# инвариантность мимо самого тяжёлого слоя — ровно то, чего тест не
# должен делать.  Теперь список накрывает 𝔉 целиком (14 внешних слоёв),
# плюс базовый и две вариации N_p.
LAYERS = [
    (0.55, 0.80, 80), (0.575, 0.80, 80), (0.625, 0.80, 80),
    (0.65, 0.80, 80), (0.70, 0.80, 80),
    (0.60, 0.70, 80), (0.60, 0.75, 80), (0.60, 0.85, 80), (0.60, 0.90, 80),
    (0.65, 0.75, 80), (0.55, 0.90, 80),
    (0.55, 0.70, 80), (0.65, 0.85, 80), (0.70, 0.75, 80),
    (0.60, 0.80, 60), (0.65, 0.80, 100),
]

CASES = [('branch_ganchor.npz', 3.0), ('branch_g10.npz', 2.5),
         ('branch_g00.npz', 2.0), ('branch_gtop.npz', 4.0)]

TOL = 1e-11          # порог: спектры обязаны совпасть на уровне float-шума

# Тест обязан заявлять РАЗМЕР своей выборки.
# До этой проверки удаление трёх слоёв из LAYERS (в том числе самого
# тонкого по марже) НЕ делало тест красным: он просто проверял меньше
# слоёв и молча проходил (проверено порчей Сб-D-7 в обойме).
# Число слоёв зафиксировано и сверяется с документацией (05-DATA-INDEX.md,
# 00-README.md, 02-REPRODUCE.md говорят «16 слоёв»).
LAYERS_EXPECTED = 16
CASES_EXPECTED = 4


def spectrum(P, ell, c, r, npn):
    tl.c_arb = arb('%.17e' % c)
    tl.r_arb = arb('%.17e' % r)
    tl.N_p = npn
    hr.C_A = tl.c_arb
    hr.R_A = tl.r_arb
    hr.NP = npn
    hr.MPR = -tl.c_arb / tl.r_arb
    pkg = tl.build_pkg_fast(P, arb('%.17e' % ell))
    if pkg is None:
        return None
    DT = hr.dt_from_pkg(pkg)
    mid = np.array([[float(DT[j][k]) for k in range(npn)] for j in range(npn)])
    ev = np.linalg.eigvals(mid)
    return ev[np.argsort(-np.abs(ev))]


def restore():
    tl.c_arb = arb(3) / arb(5)
    tl.r_arb = arb(4) / arb(5)
    tl.N_p = NP0
    hr.C_A = tl.c_arb
    hr.R_A = tl.r_arb
    hr.NP = NP0
    hr.MPR = -tl.c_arb / tl.r_arb


def _layer_worker(args):
    """один (c, r, npn) → dict с float/int/bool. spectrum() мутирует
    глобалы tl.* и hr.* — внутри воркера это безопасно (spawn).
    Воркер получает base (numpy array complex) и n_out0 (int) сериализованными.
    """
    import os as _os2
    import sys as _sys
    _os2.environ['OMP_NUM_THREADS'] = '1'
    _os2.environ['MKL_NUM_THREADS'] = '1'
    _os2.environ['OPENBLAS_NUM_THREADS'] = '1'
    PARENT = _os2.path.dirname(_os2.path.dirname(_os2.path.abspath(__file__)))
    _sys.path.insert(0, PARENT)
    import rig_lib as rl       # noqa
    import tube_lib as tl      # noqa
    import hyp_rouche as hr    # noqa
    from flint import arb, ctx
    ctx.prec = 256
    (c, r, npn, c_a, m, e0, w, ell, base_re, base_im, n_out0) = args
    import numpy as _np2
    P = rl.P_at(c_a, m, arb('%.17e' % (2.0 * (ell - e0) / w)))
    base = _np2.array(base_re, dtype=complex) + 1j * _np2.array(base_im, dtype=complex)
    ev = spectrum(P, ell, c, r, npn)
    if ev is None:
        return {'c': c, 'r': r, 'npn': npn, 'failed': True,
                'ok': True, 'delta': 0.0, 'n_out': 0, 'dmax': 0.0}
    k = min(20, len(ev), len(base))
    dmax = max(abs(ev[i] - base[i]) for i in range(k))
    n_out = int((abs(ev) > 1).sum())
    ok = (dmax < TOL) and (n_out == n_out0)
    return {'c': c, 'r': r, 'npn': npn, 'failed': False, 'ok': ok,
            'delta': float(ev[0].real), 'n_out': n_out, 'dmax': float(dmax)}


def main():
    bad = 0
    for tag, ell in CASES:
        z = np.load(os.path.join(BRANCH_DIR, tag))
        c_a, m = z['c_a'], int(z['m'][0])
        e0, w = float(z['ell0'][0]), float(z['w'][0])
        P = rl.P_at(c_a, m, arb('%.17e' % (2.0 * (ell - e0) / w)))
        base = spectrum(P, ell, C0, R0, NP0)
        n_out0 = int((np.abs(base) > 1).sum())
        print('')
        print('=== %s, ell = %.2f ===' % (tag, ell))
        print('база c=%.2f r=%.2f N_p=%d: delta=%.16f |lam2|=%.16f вне круга %d'
              % (C0, R0, NP0, base[0].real, abs(base[1]), n_out0))
        _LAY_BASE_RE = base.real.astype(float).tolist()
        _LAY_BASE_IM = base.imag.astype(float).tolist()
        _LAY_ARGS = [(c, r, npn, c_a, m, e0, w, ell,
                      _LAY_BASE_RE, _LAY_BASE_IM, n_out0) for c, r, npn in LAYERS]
        _LAY_W = max(1, int(_os.environ.get('HYP_WORKERS', '1')))
        if _LAY_W > 1 and len(LAYERS) > 1:
            with _mp.get_context('spawn').Pool(_LAY_W) as _pool:
                _LAY_RES = _pool.map(_layer_worker, _LAY_ARGS)
        else:
            _LAY_RES = [_layer_worker(a) for a in _LAY_ARGS]
        for _r in _LAY_RES:
            c, r, npn = _r['c'], _r['r'], _r['npn']
            if _r['failed']:
                print('  c=%.3f r=%.2f N_p=%3d: пакет не построился '
                      '(нарушено sup|U-1|<1) — слой вне области применимости'
                      % (c, r, npn))
                continue
            delta, n_out, dmax, ok = (_r['delta'], _r['n_out'],
                                      _r['dmax'], _r['ok'])
            if not ok:
                bad += 1
            print('  c=%.3f r=%.2f N_p=%3d: delta=%.16f вне круга %d  '
                  'max|d lambda| (20 верхних) = %.3e   %s'
                  % (c, r, npn, delta, n_out, dmax,
                     'ok' if ok else '*** FAIL ***'))
    restore()
    if len(LAYERS) != LAYERS_EXPECTED or len(CASES) != CASES_EXPECTED:
        print('*** FAIL: выборка теста изменена: слоёв %d (ожидалось %d), '
              'случаев %d (ожидалось %d) — сокращённый тест не есть зелёный тест'
              % (len(LAYERS), LAYERS_EXPECTED, len(CASES), CASES_EXPECTED))
        bad += 1
    print('')
    print('-' * 92)
    if bad:
        print('*** ПРОВАЛОВ: %d ***' % bad)
        print('спектр зависит от слоя — это опровергло бы трактовку delta как')
        print('величины, не зависящей от выбора пространства; разбираться надо')
        print('немедленно.')
    else:
        print('спектр от слоя не зависит: на всех проверенных (c, r, N_p)')
        print('двадцать старших собственных значений совпадают с базовым слоем')
        print('на уровне float-шума, и счёт «снаружи ровно одно» тот же.')
        print('Это численное свидетельство, а не сертификат; строгое')
        print('утверждение — теорема D, §10, для семейства слоёв 𝔉.')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
