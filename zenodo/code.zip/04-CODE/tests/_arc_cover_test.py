# -*- coding: utf-8 -*-
"""
_arc_cover_test.py — падающий тест для дыры 2 (покрытие дуг).

Воспроизводит старый (бажный) arc_to_acb_box в виде локальной функции и
проверяет, что:
  - старая версия НЕ содержит точку c + R·exp(i·0) в коробке дуги m=0;
  - новая (после правки) — содержит.

Заодно проверяет, что и для дуг вокруг π/2, π, 3π/2 точка-экстремум попадает.
"""
import os, sys, sys
from flint import arb, acb

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
sys.path.insert(0, PARENT)
import lemma_domains as ld

PI = arb.pi()


def old_arc_to_acb_box(c_center, R, theta_lo, theta_hi):
    """Копия старой бажной реализации (cos/sin только в концах дуги)."""
    cos_lo = (theta_lo).cos()
    cos_hi = (theta_hi).cos()
    sin_lo = (theta_lo).sin()
    sin_hi = (theta_hi).sin()
    cos_lo_l, cos_lo_u = cos_lo.lower(), cos_lo.upper()
    cos_hi_l, cos_hi_u = cos_hi.lower(), cos_hi.upper()
    re_lo = min(cos_lo_l, cos_hi_l)
    re_hi = max(cos_lo_u, cos_hi_u)
    sin_lo_l, sin_lo_u = sin_lo.lower(), sin_lo.upper()
    sin_hi_l, sin_hi_u = sin_hi.lower(), sin_hi.upper()
    im_lo = min(sin_lo_l, sin_hi_l)
    im_hi = max(sin_lo_u, sin_hi_u)
    c_real = c_center.real if isinstance(c_center, acb) else c_center
    z_re = (c_real + R * re_lo).union(c_real + R * re_hi)
    z_im = (R * im_lo).union(R * im_hi)
    return acb(z_re, z_im)


def new_arc_to_acb_box(c_center, R, theta_lo, theta_hi):
    """Копия новой реализации (cos/sin на интервале θ)."""
    theta_int = theta_lo.union(theta_hi)
    cos_int = theta_int.cos()
    sin_int = theta_int.sin()
    re_lo = cos_int.lower()
    re_hi = cos_int.upper()
    im_lo = sin_int.lower()
    im_hi = sin_int.upper()
    c_real = c_center.real if isinstance(c_center, acb) else c_center
    z_re = (c_real + R * re_lo).union(c_real + R * re_hi)
    z_im = (R * im_lo).union(R * im_hi)
    return acb(z_re, z_im)


def point_on_circle(c, R, theta):
    """Точка на окружности |t-c|=R (acb)."""
    c_real = c.real if isinstance(c, acb) else c
    re_pt = R * theta.cos()
    im_pt = R * theta.sin()
    return acb(re_pt + c_real, im_pt)


def main():
    # Оба ассерта ниже стоят внутри `if m_ == 0`, и до сих пор никто
    # не проверял, что эта ветка вообще была достигнута: при пустом переборе
    # тест проходил вхолостую — ровно «проверка, которая не может упасть».
    checked = [0]
    # Без этой строки первый же print с кириллицей падает
    # на консоли Windows в cp1252 (UnicodeEncodeError) — тест краснеет по
    # причине, не имеющей отношения к математике. Остальные тесты пакета
    # (_numbers_check, _refs_check, _appendix_check) так и делают.
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    print('=== тест покрытия дуговых коробок ===')
    c = acb(arb('0.6'))
    R = arb('1.20')
    # Разные дуги, при которых cos/sin имеют внутренние экстремумы
    # (когда 0, π/2, π, 3π/2 лежат ВНУТРИ дуги [θ_lo, θ_hi])
    M_values = [64, 128]
    n_arcs = M_values  # тест для двух значений M

    for M in M_values:
        TAU = 2 * PI
        arc_w = TAU / M
        print('\n--- M=%d, arc_w=%s ---' % (M, arc_w))
        # четыре критичных дуги
        for m_, theta_center_times_pi_over_pi in [(0, 0), (M // 4, 0.5),
                                                   (M // 2, 1), (3 * M // 4, 1.5)]:
            th_m = arb(m_) * arc_w
            th_lo = th_m - arc_w / 2
            th_hi = th_m + arc_w / 2
            # критичная точка: экстремум cos или sin внутри дуги
            if m_ == 0:
                theta_extr = arb(0)
            elif m_ == M // 4:
                theta_extr = PI / 2
            elif m_ == M // 2:
                theta_extr = PI
            else:
                theta_extr = 3 * PI / 2
            pt = point_on_circle(c, R, theta_extr)

            old_box = old_arc_to_acb_box(c, R, th_lo, th_hi)
            new_box = new_arc_to_acb_box(c, R, th_lo, th_hi)

            old_in = old_box.contains(pt)
            new_in = new_box.contains(pt)
            print('  m=%d (центр=%.3fπ): точка θ=%.3fπ попадает в старую коробку: %s, в новую: %s'
                  % (m_, theta_center_times_pi_over_pi, theta_extr / PI,
                     'ДА' if old_in else 'НЕТ',
                     'ДА' if new_in else 'НЕТ'))
            if m_ == 0:
                # Главная проверка: дуга 0 НЕ накрывала c+R, новая — накрывает
                checked[0] += 1
                if old_in:
                    print('*** FAIL: СТАРАЯ ДОЛЖНА БЫЛА ПРОВАЛИТЬСЯ')
                    return 1
                if not new_in:
                    print('*** FAIL: НОВАЯ ОБЯЗАНА ПОКРЫВАТЬ')
                    return 1

    if checked[0] == 0:
        print('*** FAIL: ветка m=0 не была достигнута ни разу — тест прошёл '
              'вхолостую, ничего не проверив')
        return 1
    print('проверок в ветке m=0: %d' % checked[0])
    return 0


if __name__ == '__main__':
    sys.exit(main())