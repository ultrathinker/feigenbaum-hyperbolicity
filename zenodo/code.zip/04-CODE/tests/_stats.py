# -*- coding: utf-8 -*-
import json, glob, collections, sys, os
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(os.path.dirname(HERE))
TUBE = os.environ.get('HYP_TUBE_OUT',
                      os.path.join(PKG, '03-CERTIFICATES', 'tube'))
rs = [json.load(open(f, encoding='utf-8'))
      for f in glob.glob(os.path.join(TUBE, 'box_*.json'))]
if not rs:
    sys.exit('нет боксов трубки в %s (задайте HYP_TUBE_OUT)' % TUBE)
w = collections.Counter(round(r['w'], 5) for r in rs)
print('боксов: %d' % len(rs))
print('ширины боксов:')
for k in sorted(w):
    print('   w=%.5f : %d' % (k, w[k]))
print('узлов на окружности:', dict(collections.Counter(r['N'] for r in rs)))
print('подразбиение K:', dict(collections.Counter(r['K'] for r in rs)))
t = sum(r['wall_s'] for r in rs)
print('счёт: %.2f ядро-часов, среднее %.1f с/бокс' % (t / 3600, t / len(rs)))
pr = sorted(r['prod'] for r in rs)
print('R*||D||: медиана %.4f, 90%% %.4f, макс %.4f'
      % (pr[len(pr) // 2], pr[int(len(pr) * 0.9)], pr[-1]))
o = json.load(open(os.environ.get('HYP_OFFSETS',
                 os.path.join(TUBE, 'offsets.json')), encoding='utf-8'))
def rng(k, f='%.3e'):
    v = [x[k] for x in o.values()]
    return (f + ' … ' + f) % (min(v), max(v))
print('extra:      ' + rng('extra'))
print('||C||:      ' + rng('C_norm'))
print('||[B;D]||:  ' + rng('BD_norm'))
print('||M_prime||:' + rng('Mprime_norm', '%.2f'))
