# -*- coding: utf-8 -*-
"""_tail_bruteforce.py — независимая проверка оценки хвоста столбца.

Оценка `tail_cols` (tube_lib.build_pkg_fast) складывается из прямой суммы до
`N_MAX = 320`, цены усечения `W`, `U^{l-1}` на `N_W` и A-оценки остатка за
`N_MAX`.  Проверять её той же формулой бессмысленно, поэтому здесь она
проверяется ПРЯМЫМ СЧЁТОМ ДРУГОЙ ПРИРОДЫ: столбец `res` строится заново до
степени `N_HI >> N_MAX`, и измеренная масса хвоста сравнивается с границей.

Два обязательных требования к такому тесту, оба выполнены:

1. **Он умеет провалиться.**  Проверяется переменной окружения
   `CLAIM_SCALE`: при `CLAIM_SCALE=0.001` граница искусственно ужимается в
   тысячу раз, и тест обязан напечатать ПРОВАЛ.
2. **Он меряет то, что нужно.**  Граница считается по ИНТЕРВАЛУ `[lo, hi]`,
   а замер — в ТОЧКЕ внутри него, и берётся НИЖНИЙ конец измеренного.
   На интервале коэффициенты `res` — широкие шары (зависимостное раздутие
   по `l`), нижний конец уходит в минус и не опровергает ничего; сравнение
   же верхнего конца с верхней границей расходится на ширину шаров и даёт
   мнимое нарушение.  Правильное утверждение: граница по боксу обязана
   мажорировать замер в любой точке этого бокса.

Запуск:  python tests/_tail_bruteforce.py [N_HI]        (по умолчанию 600)
"""
import os
import sys

import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)
BRD = os.environ.get('HYP_BRANCHES',
                     os.path.join(os.path.dirname(PARENT),
                                  '03-CERTIFICATES', 'branches'))

import rig_lib as rl
import tube_lib as tl
from flint import arb, arb_poly, ctx

ctx.prec = 256
NP, NG, NW = tl.N_p, tl.N_G, tl.N_W
C, R = tl.c_arb, tl.r_arb
N_MAX = 320
N_HI = int(sys.argv[1]) if len(sys.argv) > 1 else 600
# для проверки самого теста на фальсификацию: искусственно ужать границу
CLAIM_SCALE = float(os.environ.get('CLAIM_SCALE', '1'))


def trunc(p, n):
    return arb_poly(list(p)[:n + 1])


def compose_trunc(pp, qq, n):
    """Горнер: pp(qq) с усечением на каждом шаге."""
    cs = list(pp)
    res = arb_poly([cs[-1]])
    for i in range(len(cs) - 2, -1, -1):
        res = trunc(res * qq, n)
        res = res + arb_poly([cs[i]])
    return res


def check(tag, lo, hi, ks, at=None):
    """Граница считается по ИНТЕРВАЛУ [lo,hi], а замер — в ТОЧКЕ at внутри него.

    Так и должно быть: на интервале коэффициенты res — широкие шары
    (зависимостное раздутие по ell), и нижний конец измерения уходит в минус,
    то есть ничего не опровергает. Точечный замер даёт узкие шары, и
    требование «граница по боксу мажорирует любую точку бокса» становится
    настоящим фальсифицируемым утверждением.
    """
    br = np.load(os.path.join(BRD, 'branch_%s.npz' % tag))
    c_a, m = br['c_a'], int(br['m'].ravel()[0])
    e0b, wb = float(br['ell0'].ravel()[0]), float(br['w'].ravel()[0])
    xlo, xhi = 2.0 * (lo - e0b) / wb, 2.0 * (hi - e0b) / wb
    Pint = rl.P_at_interval(c_a, m, arb('%.17e' % xlo).union(arb('%.17e' % xhi)))
    ell_iv = arb('%.17e' % lo).union(arb('%.17e' % hi))
    pkg_box = tl.build_pkg_fast(Pint, ell_iv)      # отсюда берём ГРАНИЦУ
    at = hi if at is None else at
    xat = 2.0 * (at - e0b) / wb
    Ppt = rl.P_at(c_a, m, arb('%.17e' % xat))
    ell = arb('%.17e' % at)
    pkg = tl.build_pkg_fast(Ppt, ell)              # отсюда — ЗАМЕР

    G_c = pkg['G_c']
    Gp = pkg['G_c_prime']
    abar = pkg['abar']
    G1sq = pkg['G_at_1_sq']
    s_mc = pkg['s_c_minus_c']
    Wm = trunc(pkg['W_c_shifted'], NW)
    Ulm = trunc(pkg['U_pow_lm1'], NW)
    tail_cols = pkg_box['tail_cols']
    abar_inv_ellp1 = abar ** (-(ell + arb(1)))

    # длинные композиции до N_HI (в движке — до N_MAX = 320)
    GpW = compose_trunc(Gp, Wm, N_HI)
    GcW = compose_trunc(G_c, Wm, N_HI)
    Gps = compose_trunc(Gp, s_mc, N_HI)
    Wp = [arb_poly([arb(1)])]
    sp = [arb_poly([arb(1)])]
    for _ in range(1, NP + 1):
        Wp.append(trunc(Wp[-1] * Wm, N_HI))
        sp.append(trunc(sp[-1] * s_mc, N_HI))

    print('%s  граница по [%.5f, %.5f], замер в точке l = %.5f, N_HI = %d'
          % (tag, lo, hi, at, N_HI))
    print('%-4s %-14s %-14s %-14s %-10s' %
          ('k', 'хвост >N_p (низ)', 'из них >N_MAX', 'tail_cols', 'вердикт'))
    worst_ratio = 0.0
    for k in ks:
        inv_rk = arb(1) / (R ** k) if k else arb(1)
        e_k = arb_poly([arb(0)] * k + [inv_rk]) if k else arb_poly([arb(1)])
        v_at_1 = e_k(arb(1) - C)
        Da = v_at_1 / G1sq
        coef = -ell * abar_inv_ellp1 * Da
        Ds = arb_poly([C * coef, coef])
        vos = trunc(sp[k] * inv_rk, N_HI)
        inner = trunc(vos + trunc(Gps * Ds, N_HI), N_HI)
        DW = trunc(ell * trunc(Ulm * inner, N_HI), N_HI)
        voW = trunc(Wp[k] * inv_rk, N_HI)
        res = trunc(e_k + Da * GcW + abar * (voW + trunc(GpW * DW, N_HI)), N_HI)

        # НИЖНЯЯ граница измеренного хвоста: |true_j| >= abs(ball_j).lower(),
        # поэтому сумма нижних концов не превосходит истинного хвоста.
        # Сравнивать верхний конец с верхней границей нельзя — разойдутся
        # на ширину шаров, и тест покажет мнимое нарушение.
        t_lo = arb(0)
        t_hi = arb(0)
        t_beyond = arb(0)
        deg = min(res.degree(), N_HI)
        for j in range(NP + 1, deg + 1):
            b = abs(res[j]) * (R ** j)
            t_lo = t_lo + b.lower()
            t_hi = t_hi + b.upper()
            if j > N_MAX:
                t_beyond = t_beyond + b.upper()
        claimed = (tail_cols[k] * arb(CLAIM_SCALE)).upper()
        ok = t_lo <= claimed
        ratio = float(t_lo / claimed) if float(claimed) else float('inf')
        worst_ratio = max(worst_ratio, ratio)
        print('%-4d %-14.6e %-14.6e %-14.6e %s (%.6f от границы)'
              % (k, float(t_lo), float(t_beyond.upper()),
                 float(claimed), 'ok' if ok else '*** ПРОВАЛ ***', ratio))
    print('  худшее отношение измеренного к заявленному: %.4f' % worst_ratio)
    print()
    return worst_ratio


if __name__ == '__main__':
    w = []
    w.append(check('gtop', 3.99625, 4.0075, [0, 1, 40, 79, 80]))
    w.append(check('g01', 2.045, 2.0575, [0, 40, 80]))
    # --- защита от fail-open: счётчик выполненных проверок ---
    # Без этой проверки ворот был fail-open: если тело check() обнулить
    # (return 0.0), то max(w) = 0 <= 1, печаталось «ИТОГ: измеренный хвост
    # нигде не превысил границу; худшее отношение 0.0000» и exit 0. Обнулённое
    # измерение было неотличимо от успешного, потому что скрипт не печатал ни
    # числа выполненных замеров, ни признака невырожденности.
    # Настоящее отношение измеренного хвоста к заявленному строго положительно
    # на каждом боксе (эталон: 0.0398), поэтому нулю здесь взяться неоткуда.
    print('  проверок выполнено: %d, из них с положительным отношением: %d'
          % (len(w), sum(1 for x in w if x > 0.0)))
    if len(w) < 2 or any(not (x > 0.0) for x in w):
        print('ИТОГ: ПРОВАЛ ВЫРОЖДЕНИЯ — измерение не состоялось (отношение '
              'равно нулю либо замеров меньше двух), ворот не имеет силы')
        sys.exit(2)
    if max(w) <= 1.0:
        print('ИТОГ: измеренный хвост нигде не превысил границу; худшее '
              'отношение %.4f' % max(w))
    else:
        print('ИТОГ: ЕСТЬ ПРОВАЛ, худшее отношение %.4f' % max(w))
    sys.exit(0 if max(w) <= 1.0 else 1)
