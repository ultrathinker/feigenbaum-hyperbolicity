# -*- coding: utf-8 -*-
"""Нижняя оценка радиуса области голоморфности R_G (посылка теоремы C).

ЗАЧЕМ.  §6.5 доказывает: существуют R_G, R_ℓ > 0, при которых F голоморфна
на Γ = B_X(P(ℓ₀), R_G) × D(ℓ₀, R_ℓ).  Аналитическая ТНФ (§6.6) применяется
не в центре P(ℓ₀), а в истинном решении G*(ℓ₀) — только там F = 0.  Значит
нужно ЗНАТЬ, что G*(ℓ₀) лежит в Γ, то есть нужна нижняя оценка R_G, с
которой можно сравнить ‖G*(ℓ₀) − P(ℓ₀)‖_X ≤ ρ*_X.  Ссылка на то, что ТНФ
«сама строит ветвь внутри Γ», этот шаг не заменяет: она его предполагает.

ЧТО ЗДЕСЬ ПРОВЕРЯЕТСЯ.  Что все посылки голоморфности §6.5 держатся не в
центре, а РАВНОМЕРНО НА ШАРЕ B_X(P(ℓ), ρ_X) при ρ_X = 1.75·10⁻⁷ — том
самом шаре единственности теоремы A, на котором в §6.6 уже считается L.
Тогда R_G ≥ 1.75·10⁻⁷, и сравнение с ρ*_X ≤ 8.49·10⁻¹³ становится
законным (запас ~2·10⁵).

    п.1  |G(1)| ≥ |P(1)| − ρ_X > 0            α_G = −1/G(1) голоморфна
    п.2  |arg α_G| ≤ arcsin(ρ_X/|P(1)|) < π/2  Re α_G > 0, Log без скачка
    п.3  |Δs| < margin_a                       s_G(D(c,r)) ⊆ D(c,r)
    п.5-6 q̂ = (‖W_P−c‖_X + ΔW)/r < 1          ряд композиции сходится,
                                               и W_G(D) ⊆ D(c, q̂r) ⋐ D(c,r)

п.1, п.2 и q̂ берутся из той же цепочки `tube_lib._compute_L`, которая
уже стоит в воротах сертификата (она возвращает None, если любая из них
не проходит); п.3 — та же оценка сдвига образа, что в `_kappaG_bound.py`.

R_ℓ остаётся экзистенциальным, и это законно: ℓ₀ — ЦЕНТР комплексного
диска по ℓ, никакая точка от него не отстоит, сравнивать не с чем.
Квантификации требовал только радиус по G, потому что G*(ℓ₀) от центра
P(ℓ₀) отстоит.

ЧЕГО ЭТОТ ТЕСТ НЕ ДЕЛАЕТ.  Он не является независимой проверкой самой
липшицевой цепочки: q̂ и ΔU он берёт из той же `tube_lib._compute_L`,
которая стоит в воротах сертификата.  Тест отвечает на вопрос «выполнены
ли посылки §6.5 равномерно на шаре», а не «верна ли формула, которой они
посчитаны».

ФАЛЬСИФИКАЦИЯ.  Переменная окружения `HOLO_RHO` задаёт ρ′ вручную;
на достаточно большом шаре посылки обязаны сломаться:
    HOLO_RHO=0.05 python tests/_holo_radius.py 2

Запуск:  python tests/_holo_radius.py [K]        (по умолчанию K = 2)
"""
import os
import os as _os  # алиас для env в воркере (os остаётся)
import multiprocessing as _mp
import sys
import glob
import json
import tempfile

import numpy as np
_np = np  # воркер ссылается на np через _np (без reimport)

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, PARENT)

import rig_lib as rl
import tube_lib as tl
from rig2fix3 import fmt_up as _sci_up
from flint import arb, ctx

ctx.prec = 256


def fmt_dir(x, d, up):
    """Десятичная запись `x` с `d` знаками после точки, ГАРАНТИРОВАННО не
    ниже (up=True) / не выше (up=False) истинного значения — в отличие от
    '%.Nf', которое округляет к БЛИЖАЙШЕМУ.
    `_holo_radius.py` печатал МИНИМАЛЬНОЕ |G(1)| через '%.6f', и на боксе
    g00 при K=2 это дало 0.396280 при истинном 0.396279689…  —
    напечатанная НИЖНЯЯ граница оказалась ВЫШЕ факта."""
    v = float(x)
    fs = '%.' + str(d) + 'f'
    s = fs % v
    for _ in range(4):
        if (float(s) >= v) if up else (float(s) <= v):
            return s
        step = 10.0 ** (-d)
        s = fs % (v + step if up else v - step)
    raise RuntimeError('десятичное округление не сошлось: %s vs %r' % (s, v))


NP, R, C = tl.N_p, tl.r_arb, tl.c_arb

_HOLO_POOL_MAX = 1   # переписывается ниже при импорте


def _holo_box_worker(args):
    """один файл → dict с float/str результатами (arb не пиклится).
    Возвращает всегда dict; check 'skip' / 'err' / 'ok' / поля.
    """
    import io as _io
    import json as _json
    import os as _os2
    import sys as _sys
    _os2.environ['OMP_NUM_THREADS'] = '1'
    _os2.environ['MKL_NUM_THREADS'] = '1'
    _os2.environ['OPENBLAS_NUM_THREADS'] = '1'
    HERE = _os2.path.dirname(_os2.path.abspath(__file__))
    PARENT = _os2.path.dirname(HERE)
    _sys.path.insert(0, HERE)
    _sys.path.insert(0, PARENT)
    import rig_lib as rl
    import tube_lib as tl
    from flint import arb, ctx
    ctx.prec = 256
    NP, R, C = tl.N_p, tl.r_arb, tl.c_arb
    f, BR, RHO_PRIME_str, K = args
    RHO_PRIME = arb(RHO_PRIME_str)
    RHO_X = arb('1.75') * RHO_PRIME
    j = _json.load(_io.open(f, encoding='utf-8'))
    tag = j.get('idx') or _os2.path.basename(f)[4:-5]
    out = {'tag': tag, 'rho_X': 0.0, 'rho_X_field': 0.0,
           'q_hat': 0.0, 'g1_lo': 0.0, 'arg_hi': 0.0, 'd_s': 0.0,
           'kap_U': 0.0,
           'ok': True, 'err': None, 'skip': False}
    if not j.get('passed'):
        out['skip'] = True
        return out
    rs = 1.75 * float(j['best'].get('rho_star_b', j['best']['rho_star']))
    out['rho_X'] = rs
    out['rho_X_field'] = float(j['best'].get('rho_star_X', rs))
    margin_a = arb(j['lemma1_margin_a'])
    z = _np.load(_os2.path.join(BR, 'branch_%s.npz' % tag))
    c_a, m = z['c_a'], int(z['m'].ravel()[0])
    e0b, wb = float(z['ell0'].ravel()[0]), float(z['w'].ravel()[0])
    lo = float(j['ell0']) - float(j['w']) / 2
    hi = float(j['ell0']) + float(j['w']) / 2
    res, err = one_box(tag, c_a, m, e0b, wb, lo, hi, margin_a)
    if res is None:
        out['err'] = err
        out['ok'] = False
        return out
    q_hat, g1_lo, arg_hi_, d_s, kap_u = res
    pi_half = arb.pi() / 2
    # `kap_u < 1` внесено в сам `ok`: раньше строка сводки печатала
    # «худший kap_U = … (< 1)», но «(< 1)» было подписью, а не сравнением —
    # в гейт κ_U не входил вовсе, хотя именно на нём держится однозначность
    # главной ветви `Log U`.  Пересчёт условие проверял (`tube_lib` вернул бы
    # None), но здесь оно теперь и утверждается.
    ok = ((q_hat < 1) and (g1_lo > 0) and (arg_hi_ < pi_half)
          and (d_s < margin_a) and (kap_u < 1))
    out['q_hat'] = float(q_hat)
    out['g1_lo'] = float(g1_lo)
    out['arg_hi'] = float(arg_hi_)
    out['d_s'] = float(d_s)
    out['kap_U'] = float(kap_u)
    out['ok'] = ok
    return out

BR = os.environ.get('HYP_BRANCHES',
                    os.path.join(os.path.dirname(PARENT),
                                 '03-CERTIFICATES', 'branches'))
CERTS = os.environ.get('HYP_CERTS',
                       os.path.join(os.path.dirname(PARENT),
                                    '03-CERTIFICATES', 'existence'))

# ρ′ такое, что ρ_X = 1.75·ρ′ = 1.75·10⁻⁷ — радиус шара единственности.
RHO_PRIME_STR = os.environ.get('HOLO_RHO', '1e-7')
RHO_PRIME = arb(RHO_PRIME_STR)
RHO_X = arb('1.75') * RHO_PRIME
K = int(sys.argv[1]) if len(sys.argv) > 1 else 2

bad = 0
rows = []


def fail(tag, what):
    global bad
    bad += 1
    print('  %-8s *** ПРОВАЛ *** %s' % (tag, what))


def one_box(tag, c_a, m, e0b, wb, lo, hi, margin_a):
    """Возвращает (q_hat, g1_lo, arg_hi, d_s, kap_U) — худшее по K подынтервалам.

    kap_U = ||U_G-1||_X — посылка X-значной голоморфности W_G=U_G^l (§6.5 п.5):
    (C.1) даёт только СКАЛЯРНУЮ sup-оценку |U_G(t)-1|<1 в точке; для ряда в
    банаховой алгебре нужна норма ||.||_X, а не sup — отдельная, более сильная
    посылка. tube_lib._compute_L уже считает и гейтит именно её
    (`if not (kap_U < arb(1)): return None`), но раньше значение не публиковалось
    ни в один сертификат.
    """
    q_worst, g1_worst, arg_worst, ds_worst = arb(0), None, arb(0), arb(0)
    kap_worst = 0.0
    ell_hi = arb('%.17e' % hi)
    for s in range(K):
        a = lo + (hi - lo) * s / K
        b = lo + (hi - lo) * (s + 1) / K
        xlo, xhi = 2.0 * (a - e0b) / wb, 2.0 * (b - e0b) / wb
        x_iv = arb('%.17e' % xlo).union(arb('%.17e' % xhi))
        Pint = rl.P_at_interval(c_a, m, x_iv)
        ell_iv = arb('%.17e' % a).union(arb('%.17e' % b))
        pkg = tl.build_pkg_fast(Pint, ell_iv)
        if pkg is None:
            return None, 'пакет не построился на [%.5f, %.5f]' % (a, b)
        xn = tl.compute_x_norms_and_beta(pkg)
        # вся цепочка посылок 1, 2, 5-6 на шаре радиуса RHO_X
        g = tl._compute_L(pkg, xn, RHO_PRIME)
        if g is None:
            return None, ('посылки §6.5 не держатся на шаре ρ_X=%s '
                          'при ℓ∈[%.5f, %.5f]' % (RHO_X.upper(), a, b))
        q_hat = g['gate_pkg']['q_hat'] if 'gate_pkg' in g else g['q_hat']
        if q_hat.upper() > q_worst:
            q_worst = q_hat.upper()
        # kap_U уже посчитан и прогейчен внутри _compute_L — публикуем.
        kap_u = g['gate_pkg']['kap_U'] if 'gate_pkg' in g else g['kap_U']
        if kap_u > kap_worst:
            kap_worst = kap_u

        # п.1 и п.2 — явные числа для статьи
        g1 = abs(pkg['G_at_1'])
        g1_lo = (g1 - RHO_X).lower()
        if not (g1_lo > 0):
            return None, '|G(1)| не отделён от нуля на шаре'
        if g1_worst is None or g1_lo < g1_worst:
            g1_worst = g1_lo
        # |arg α_G| ≤ arcsin(ρ_X/|P(1)|):  |h(1)| ≤ ‖h‖_X, так как |1−c| < r
        sin_hi = (RHO_X / g1.lower()).upper()
        if not (sin_hi < 1):
            return None, 'оценка arg α_G не определена'
        arg_hi = arb(sin_hi).asin().upper()
        if arg_hi > arg_worst:
            arg_worst = arg_hi

        # п.3 — сдвиг образа s_G против сертифицированного margin_a
        d_alpha = (RHO_X / (g1.lower() * arb(g1_lo))).upper()
        d_s = ((C + R) * ell_hi * d_alpha).upper()
        if not (d_s < margin_a):
            return None, ('образ s_G может выйти из D(c,r): Δs=%s ≥ '
                          'margin_a=%s' % (d_s, margin_a))
        if d_s > ds_worst:
            ds_worst = d_s
    return (q_worst, g1_worst, arg_worst, ds_worst, kap_worst), None


def main():
    global bad
    pi_half = arb.pi() / 2
    print('шар: ρ_X = 1.75·ρ′ = %s   (ρ′ = %s),  подынтервалов K = %d'
          % (RHO_X.upper(), RHO_PRIME, K))
    print()
    print('%-8s %-12s %-12s %-12s %-12s %-12s' %
          ('бокс', 'q̂ (<1)', '|G(1)| (>0)', '|arg α| (<π/2)', 'Δs < margin_a', 'kap_U (<1)'))
    rho_X_max, rho_tag = 0.0, None
    rho_X_field = 0.0
    _HOLO_FILES = sorted(glob.glob(os.path.join(CERTS, 'box_*.json')))
    _HOLO_ARGS = [(f, BR, RHO_PRIME_STR, K) for f in _HOLO_FILES]
    _HOLO_W = max(1, int(os.environ.get('HYP_WORKERS', '1')))
    if _HOLO_W > 1 and len(_HOLO_FILES) > 1:
        with _mp.get_context('spawn').Pool(_HOLO_W) as _pool:
            _HOLO_RES = _pool.map(_holo_box_worker, _HOLO_ARGS)
    else:
        _HOLO_RES = [_holo_box_worker(a) for a in _HOLO_ARGS]
    for _r in _HOLO_RES:
        tag = _r['tag']
        if _r['skip']:
            continue
        rs = _r['rho_X']
        if rs > rho_X_max:
            rho_X_max, rho_tag = rs, tag
        # Поле rho_star_X — это fmt_up(1.75*rho_star_b_точного), то
        # есть ЛЕГИТИМНО меньше, чем 1.75*(округлённое вверх rho_star_b).
        # Публикуется в статье именно оно, поэтому и стеречь надо его.
        _rx = _r['rho_X_field']
        if _rx > rho_X_field:
            rho_X_field = _rx
        if not _r['ok']:
            fail(tag, _r['err'] if _r['err'] is not None
                        else 'сводная проверка не прошла')
            continue
        q_hat, g1_lo, arg_hi, d_s, kap_u = (_r['q_hat'], _r['g1_lo'],
                                     _r['arg_hi'], _r['d_s'], _r['kap_U'])
        rows.append((tag, q_hat, g1_lo, arg_hi, d_s, kap_u))
        print('%-8s %-12.6f %-12.6f %-12.3e %-12.3e %-12.6f' %
              (tag, q_hat, g1_lo, arg_hi, d_s, kap_u))

    print()
    if not rows:
        print('НИ ОДНОГО БОКСА НЕ ПРОШЛО')
        return 1
    print('боксов проверено: %d, провалов: %d' % (len(rows), bad))
    print('худшее q̂            = %s   (< 1)' % fmt_dir(max(r[1] for r in rows), 6, True))
    print('минимальное |G(1)|   = %s   (> 0)' % fmt_dir(min(r[2] for r in rows), 6, False))
    print('худший |arg α_G|     = %s  (< π/2 = %.4f)'
          % (_sci_up(max(r[3] for r in rows), 3), float(pi_half)))
    print('худший kap_U          = %s   (< 1)' % fmt_dir(max(r[5] for r in rows), 6, True))
    print()
    # Сводка уходит в протокол: до сих пор опубликованные
    # `q̂ ≤ 0.955131` и `|G(1)| ≥ 0.396279` держались только на stdout, и
    # сверить их было не с чем — гейт проверяет `q̂ < 1`, а не саму цифру.
    _out = os.environ.get('CERT_OUT',
                          os.path.join(tempfile.gettempdir(), 'renorm_out'))
    os.makedirs(_out, exist_ok=True)
    _summary = {
        'task': 'holo_radius',
        'n_boxes': len(rows),
        'q_hat_max': max(r[1] for r in rows),
        'q_hat_max_box': max(rows, key=lambda r: r[1])[0],
        'g1_min': min(r[2] for r in rows),
        'g1_min_box': min(rows, key=lambda r: r[2])[0],
        'arg_alpha_max': max(r[3] for r in rows),
        'kap_U_max': max(r[5] for r in rows),
        'kap_U_max_box': max(rows, key=lambda r: r[5])[0],
        'R_G': float(RHO_X.lower()),
        'rho_X_max': rho_X_max,          # 1.75 * rho_star_b, грубее
        'rho_X_max_field': rho_X_field,  # поле best.rho_star_X, точнее
        'rho_X_max_box': rho_tag,
        'boxes': dict((r[0], {'q_hat': r[1], 'g1_lo': r[2],
                              'arg_hi': r[3], 'd_s': r[4], 'kap_U': r[5]})
                     for r in rows),
    }
    with open(os.path.join(_out, 'holo_radius.json'), 'w',
              encoding='utf-8') as _f:
        json.dump(_summary, _f, ensure_ascii=False, indent=1)
    print('протокол: %s' % os.path.join(_out, 'holo_radius.json'))

    R_G = float(RHO_X.lower())
    print('ВЫВОД: R_G ≥ %.4e на всех боксах,' % R_G)
    print('       max ρ*_X = %.4e (бокс %s),' % (rho_X_max, rho_tag))
    print('       запас = %.3e раз.' % (R_G / rho_X_max))
    if not (rho_X_max < R_G):
        print('*** ПРОВАЛ: G*(ℓ) не гарантированно внутри области голоморфности ***')
        bad += 1
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
