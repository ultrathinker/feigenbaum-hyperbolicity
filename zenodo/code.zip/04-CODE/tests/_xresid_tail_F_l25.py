# -*- coding: utf-8 -*-
"""_xresid_tail_F_l25.py — строгая верхняя граница tail_F / F_norm_strict при ℓ = 5/2.

ЗАЧЕМ.  §5.3.1 цитирует `F_norm_strict` (через xresid_l25.json) как `Y₀` теорем
3–4 — «строгую» оценку `‖F̄‖_X ≈ 1.559225696451281×10⁻³³`.  Независимый строгий
пересчёт (независимый, python-flint arb/acb prec=1536) нашёл, что
это число совпадает (с точностью до округления) с `kant_l25.json::Y0=1.56e-33` —
УСТАРЕВШЕЙ константой другой величины и чужого сида.  `tube_lib.py` v6 (строки
16-17, 1114-1117) прямо признаёт исторический баг именно этого рода: «v5
hardcoded 1.56e-33 — the wave3 ℓ=2.5 constant … for a foreign seed» — и вводит
честную `compute_F_tail_bound` взамен.  Честный пересчёт ПО ТЕКУЩЕМУ сиду даёт
число В 1.6–2.0 РАЗА БОЛЬШЕ заявленного (опасное направление: `tail_F` —
верхняя оценка остатка ряда, входящая в Кантóровичев гейт теорем 3-4).  До
этого файла у `tail_F`/`F_norm_strict` не было ворот, красящих на такую
подмену — соседние 6 полей того же файла (`u_0`, `M_W`, `tail_hW`,
`poly_Wc_norm`, `Wc_norm`, `poly_F_norm`) уже подтверждены S3-tierB-xresid.

ЧТО СЧИТАЕТСЯ.  `F̄ = Ḡ + ᾱ·H`, `H = Ḡ(W̄)`, `W̄ = Ū^ℓ`, `Ū(t) = G(K·t)`,
`K = ᾱ^{-ℓ}` (обозначения §1, `G` — замороженный сид, `hiprec_seeds.json`,
точка `ell=='2.5'`, 65 коэффициентов Маклорена `a64`).  Хвост усечения ряда
`F̄` на степени `N_ALG`:
    tail_F = |ᾱ| · M_H · (r/R)^(N_ALG+1) / (1 - r/R),   M_H = sup_{|t-c|=R} |H|.
Мажорируем `M_H` неравенством треугольника для полинома `G` по кругу радиуса
`M_W` (т.к. `|W̄(t)| <= M_W` на всей окружности `|t-c|=R`):
    M_H <= Σ_k |a_k| · M_W^k,
где `M_W = sup_{|t-c|=R} |Ū(t)|^ℓ` считается СТРОГОЙ коши-оценкой по `M_ARCS`
дугам box-арифметикой `acb` — тем же приёмом, что и `_reu_min_l25.py`:
окружность режется на дуги, каждая накрывается box'ом, `Ū` оценивается сверху
схемой Горнера по `acb`, берётся максимум `|Ū|^ℓ` по дугам (направленно вверх).
Эта же тесная `M_W` — независимо подтверждённое поле того же файла (S3-tierB).

ДОПОЛНИТЕЛЬНАЯ (не гейтящая) сверка направления другим маршрутом: дословное
воспроизведение ДОКУМЕНТИРОВАННОЙ в пакете формулы `tube_lib.py::compute_F_tail_bound`
(строки 1114-1162, диск-мажорант `s_R → M_U_R → M_W_R → M_H` через СДВИНУТЫЙ
`Ḡ_c`, только чтение формулы, код не импортируется) — печатается для
информации: если оба структурно разных маршрута дают число БОЛЬШЕ заявленного
в сертификате, находка подтверждена независимо от выбора конкретной мажоранты.
Официальным (гейтящим, записываемым в сертификат) является маршрут через
тесную арк-`M_W` — он математически ТУГЕЕ (даёт меньшее, но всё ещё строго
доказанное число), как и `M_W` там же.

ПОЧЕМУ ЭТО НЕ «ЗЕЛЁНОЕ ПО ПОСТРОЕНИЮ».  Ворота не читают опубликованное
`tail_F` как вход: они пересчитывают `M_W`/`M_H`/`tail_F` заново и падают, если
сертификат обещает ЧИСЛО МЕНЬШЕ пересчитанного — для верхней оценки это
опасное направление (заниженная граница, точно как исходная находка).

Запуск:
    python -X utf8 _xresid_tail_F_l25.py             сверить с сертификатом (ворота)
    python -X utf8 _xresid_tail_F_l25.py --обновить   пересчитать и записать в xresid_l25.json

Коды возврата: 0 — сертификат не занижает; 2 — расхождение (сертификат ниже).
"""
import io
import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import flint

ЗДЕСЬ = os.path.dirname(os.path.abspath(__file__))
ПАКЕТ = os.environ.get('HYP_PKG') or os.path.normpath(os.path.join(ЗДЕСЬ, '..', '..'))
СИД = os.path.join(ПАКЕТ, '04-CODE', 'hiprec_seeds.json')
XRESID = os.path.join(ПАКЕТ, '03-CERTIFICATES', 'pointwise', 'xresid_l25.json')

PREC = 1536            # >> ~460 десятичных знаков — запас x3+ над точностью сида/сертификата
M_ARCS = 2048           # дуг для строгой коши-оценки M_W (совпадает с тесным маршрутом S3-tierB-xresid)
МИН_ЦИФР = 30           # сколько знаков U(3/5) обязано совпасть с u_0 (сверка происхождения)
ЗНАКОВ = 160            # значащих цифр в записи в сертификат (запас над prec=1536)
ОБНОВИТЬ = '--обновить' in sys.argv


def poly_shift_c(a64, c):
    """G(c+w) — Хорнер-композиция полинома a64 (низшая степень первая) с (c+w).

    Точная конечная сумма (сдвиг многочлена степени 64 линейной заменой),
    без усечения бесконечного ряда — степень результата тоже 64.
    """
    n = len(a64) - 1
    res = [flint.arb(0)] * (n + 1)
    res[0] = a64[-1]
    for coef in reversed(a64[:-1]):
        new = [flint.arb(0)] * (n + 1)
        # умножение res на (c+w): new = res*c сдвинутое + res*w
        for i in range(len(res)):
            new[i] = new[i] + res[i] * c
            if i + 1 <= n:
                new[i + 1] = new[i + 1] + res[i]
        new[0] = new[0] + coef
        res = new
    return res


def main():
    flint.ctx.prec = PREC
    arb, acb = flint.arb, flint.acb

    сид = json.load(io.open(СИД, encoding='utf-8'))
    точка = [p for p in сид['points'] if str(p['ell']) in ('2.5', '2.50')]
    if len(точка) != 1:
        print('ОШИБКА: ожидалась ровно 1 точка с ell==2.5, найдено %d' % len(точка))
        return 2
    точка = точка[0]
    xres = json.load(io.open(XRESID, encoding='utf-8'))

    alpha = arb(точка['alpha'])
    a64 = [arb(s) for s in точка['a64']]
    if len(a64) != 65:
        print('ОШИБКА: ожидалось 65 коэффициентов a64, получено %d' % len(a64))
        return 2
    a64_acb = [acb(x) for x in a64]

    ell = arb(5) / arb(2)
    c = arb(3) / arb(5)
    r_val = arb(4) / arb(5)               # r_arb в tube_lib.py (радиус X-нормы)
    R = arb(xres['R'])
    N_ALG = int(xres['N_ALG'])

    K = alpha ** (-ell)
    K_acb = acb(K)

    def G(z):
        r = acb(0)
        for k in reversed(a64_acb):
            r = r * z + k
        return r

    # --- происхождение: U(3/5) против u_0 сертификата -----------------------
    U35 = G(K_acb * acb(c))
    u0_cert = arb(xres['u_0'])
    наше, их = U35.real.str(160, radius=False), u0_cert.str(160, radius=False)
    общих = 0
    for x, y in zip(наше, их):
        if x != y:
            break
        общих += 1
    print('происхождение: U(3/5) совпадает с xresid_l25.json::u_0 на %d знаков' % общих)
    if общих < МИН_ЦИФР:
        print('ОШИБКА: совпало меньше %d знаков — считается НЕ та функция' % МИН_ЦИФР)
        return 2

    # --- M_W = sup_{|t-c|=R} |U(t)|^ell -- строгая коши-оценка по M_ARCS дугам -
    два_пи = 2 * arb.pi()
    M_W_upper = arb(0)
    for i in range(M_ARCS):
        th_lo = arb(i) * два_пи / arb(M_ARCS)
        th_hi = arb(i + 1) * два_пи / arb(M_ARCS)
        th = th_lo.union(th_hi)
        sin_t, cos_t = th.sin_cos()
        t_box = acb(c + R * cos_t, R * sin_t)
        U_box = G(K_acb * t_box)
        mw_up = (U_box.abs_upper() ** ell).upper()
        if mw_up > M_W_upper:
            M_W_upper = mw_up

    cert_M_W = arb(xres['M_W'])
    print('M_W (наш, %d дуг, upper) = %s' % (M_ARCS, M_W_upper.str(50, radius=False)))
    print('M_W (сертификат)         = %s' % cert_M_W.str(50, radius=False))
    if M_W_upper.lower() > cert_M_W.upper():
        print('ВНИМАНИЕ: наш M_W определённо БОЛЬШЕ заявленного — отдельная находка, '
              'не по теме этих ворот (см. S3-tierB-xresid: M_W confirmed на 2048/4096 дугах).')

    # --- G сдвинут в центр c (для маршрута Б, только для сверки направления) ---
    G_at_1 = arb(0)
    for ak in a64:
        G_at_1 = G_at_1 + ak
    abar = -arb(1) / G_at_1

    # --- Маршрут А (ОФИЦИАЛЬНЫЙ, гейтящий): M_H <= Σ|a_k|·M_W^k -------------
    M_H_A = arb(0)
    Mp = arb(1)
    for ak in a64:
        M_H_A = M_H_A + abs(ak) * Mp
        Mp = Mp * M_W_upper
    ratio = r_val / R
    tail_F_A = abs(abar) * M_H_A * (ratio ** (N_ALG + 1)) / (1 - ratio)

    # --- Маршрут Б (только сверка направления, НЕ гейтит и НЕ пишется) ------
    # Дословное воспроизведение tube_lib.py::compute_F_tail_bound (строки
    # 1114-1162, только чтение формулы, код не импортируется).
    G_c = poly_shift_c(a64, c)

    def gabs_at(x):
        s = arb(0)
        xp = arb(1)
        for j in range(len(G_c)):
            s = s + abs(G_c[j]) * xp
            xp = xp * x
        return s

    inv_ae = K  # = abar^{-ell} по построению (abar совпадает с alpha)
    s_R = abs(c * (inv_ae - arb(1))) + R * inv_ae
    M_U_R = gabs_at(s_R)
    M_W_R = M_U_R ** ell
    M_H_B = gabs_at(M_W_R + c)
    tail_F_B = abs(abar) * M_H_B * (ratio ** (N_ALG + 1)) / (1 - ratio)

    cert_tail_F = arb(xres['tail_F'])
    cert_F_norm_strict = arb(xres['F_norm_strict'])
    poly_F_norm = arb(xres['poly_F_norm'])   # соседнее поле, независимо подтверждено (S3-tierB), не пересчитывается здесь
    F_norm_strict_A = poly_F_norm + tail_F_A

    print()
    print('=== tail_F ===')
    print('маршрут А (официальный, тесный arc-M_W)      = %s' % tail_F_A.str(60, radius=False))
    print('маршрут Б (сверка, диск-мажорант compute_F_tail_bound) = %s' % tail_F_B.str(60, radius=False))
    print('сертификат                                    = %s' % cert_tail_F.str(60, radius=False))
    print('оба маршрута больше сертификата? %s' %
          (bool(tail_F_A.lower() > cert_tail_F.upper() and tail_F_B.lower() > cert_tail_F.upper())))
    print()
    print('=== F_norm_strict (= poly_F_norm[серт.] + tail_F[маршрут А]) ===')
    print('наш   F_norm_strict = %s' % F_norm_strict_A.str(60, radius=False))
    print('серт. F_norm_strict = %s' % cert_F_norm_strict.str(60, radius=False))

    if ОБНОВИТЬ:
        xres['tail_F'] = tail_F_A.str(ЗНАКОВ)
        xres['F_norm_strict'] = F_norm_strict_A.str(ЗНАКОВ)
        text = json.dumps(xres, ensure_ascii=False, indent=2).replace('\n', '\r\n')
        io.open(XRESID, 'w', encoding='utf-8', newline='').write(text)
        print()
        print('СЕРТИФИКАТ ЗАПИСАН: %s' % XRESID)
        return 0

    # --- защита от fail-open: вырождение пересчитанных хвостов ---
    # Без этой проверки ворот был fail-open: если обнулить tail_F_A (мутация
    # `tail_F_A = arb(0)`), то `cert_tail_F.upper() < tail_F_A.lower()` ложно,
    # `F_norm_strict_A` сжимается до poly_F_norm, оба условия ниже не срабатывают,
    # печаталось «ok — сертификат не обещает меньше, чем честно пересчитано» и
    # exit 0. Честно пересчитанный хвост строго положителен по построению
    # (геометрическая мажоранта с ratio < 1 и ненулевым |abar|).
    вырожд = [nm for nm, v in (('tail_F маршрут А', tail_F_A),
                               ('tail_F маршрут Б', tail_F_B),
                               ('poly_F_norm', poly_F_norm))
              if not (v.lower() > 0)]
    if вырожд:
        print()
        print('_xresid_tail_F_l25: ПРОВАЛ ВЫРОЖДЕНИЯ — пересчёт дал нуль: %s. '
              'Измерение не состоялось, ворот не имеет силы.' % ', '.join(вырожд))
        return 3
    print('невырожденность: все три пересчитанные величины строго положительны')

    плохо = []
    if cert_tail_F.upper() < tail_F_A.lower():
        плохо.append('tail_F: в сертификате %s, честный пересчёт (маршрут А) %s — '
                      'сертификат ЗАНИЖАЕТ хвост' % (cert_tail_F.str(30, radius=False),
                                                      tail_F_A.str(30, radius=False)))
    if cert_F_norm_strict.upper() < F_norm_strict_A.lower():
        плохо.append('F_norm_strict: в сертификате %s, честный пересчёт %s — '
                      'сертификат ЗАНИЖАЕТ норму' % (cert_F_norm_strict.str(30, radius=False),
                                                      F_norm_strict_A.str(30, radius=False)))
    if плохо:
        print()
        print('_xresid_tail_F_l25: РАСХОЖДЕНИЕ')
        for x in плохо:
            print('  ' + x)
        return 2
    print()
    print('_xresid_tail_F_l25: ok — сертификат не обещает меньше, чем честно пересчитано')
    return 0


if __name__ == '__main__':
    sys.exit(main())
