# -*- coding: utf-8 -*-
"""
delta_scan.py — константы Фейгенбаума как ФУНКЦИИ показателя ℓ на всём [2,4].

Параметрический сертификат дал центр P(ℓ) аналитически на 20 боксах. Значит
спектр производной оператора вдоль ветви считается на любой сетке по ℓ
практически даром — чего марш не позволял в принципе.

Считаем на сетке ℓ:
    α(ℓ) = -1/G(1)          — масштабная константа (Фейгенбаумова α)
    δ(ℓ) = |λ₁| матрицы M′  — скорость удвоения (Фейгенбаумова δ)
    λ₂(ℓ)                    — второе по модулю с.з. (универсальная константа
                               класса; при ℓ=3 сертифицирована отдельно)

Всё во float64 — это РАЗВЕДКА, не сертификат. Строгие значения есть в двух
точках (ℓ=3 и ℓ=5/2) и служат здесь контрольными: если скан их не
воспроизводит, скан неверен. Плюс классическая контрольная точка ℓ=2,
где δ и α известны с XX века.

Вывод: delta_scan.json + delta_scan.md (таблица) + печать.
"""
import os, sys, json, glob, time
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.dirname(HERE)
METHOD = os.path.join(RES, '_VERIFY-PARAM', 'method-snapshot')
SWEEP = os.path.join(RES, '_VERIFY-PARAM', 'results', 'sweep_out')
sys.path.insert(0, METHOD)

import fp_lib as fl

LOG = open(os.path.join(HERE, 'delta_scan.log'), 'w', encoding='utf-8')


def say(s):
    print(s, flush=True)
    LOG.write(s + '\n'); LOG.flush()


# --- сертифицированные якоря (из статьи, §3-§6) ---
ANCHORS = {3.0: {'delta': 6.084689074262122, 'lam2': 0.23714611165001134,
                 'src': 'точечный сертификат Кравчика (+ λ₂)'},
           2.5: {'delta': 5.412736346083841, 'lam2': None,
                 'src': 'точечный сертификат Кравчика'}}
# классика для ℓ=2 (квадратичный случай), для сверки порядка величины
CLASSIC2 = {'delta': 4.669201609102990, 'alpha': 2.502907875095892}

boxes = []
for bf in sorted(glob.glob(os.path.join(SWEEP, 'box_*.json'))):
    b = json.load(open(bf, encoding='utf-8'))
    nz = os.path.join(SWEEP, 'branch_%s.npz' % b['idx'])
    if os.path.exists(nz):
        boxes.append({'idx': b['idx'], 'ell0': b['ell0'], 'w': b['w'],
                      'lo': b['ell0'] - b['w'] / 2, 'hi': b['ell0'] + b['w'] / 2,
                      'npz': nz})
say('боксов: %d' % len(boxes))
CACHE = {}


def P_float(ell):
    """P(ℓ) во float из ветки бокса с наибольшим запасом до края."""
    cand = [b for b in boxes if b['lo'] <= ell <= b['hi']]
    if not cand:
        return None, None
    b = max(cand, key=lambda q: min(ell - q['lo'], q['hi'] - ell))
    if b['idx'] not in CACHE:
        z = np.load(b['npz'])
        CACHE[b['idx']] = (z['c_a'], int(z['m'][0]))
    c_a, m = CACHE[b['idx']]
    x = 2.0 * (ell - b['ell0']) / b['w']
    P = np.array([fl.cheb_eval(c_a[:m + 1, k], x) for k in range(c_a.shape[1])])
    P[0] = 1.0                      # та же точная нормировка, что в rl.P_at
    return P, b['idx']


def spec(ell):
    """Спектр DT|X₀ в точке P(ℓ).

    ВАЖНО: M′ — производная НЕВЯЗКИ F(G) = G + ᾱ·G∘W, а не оператора
    ренормализации. Связь спектров: μ = 1 − λ. Проверено при ℓ=3: даёт
    ровно δ★ = 6.084689074262 и λ₂ = 0.237146111650 — обе сертифицированные
    константы, до 12 знаков. Без этой поправки δ выходит меньше ровно на 1.
    """
    P, idx = P_float(ell)
    if P is None:
        return None
    op = fl.Op(P, ell)
    _, Mp = fl.build_Mprime(op)
    mu = 1.0 - np.linalg.eigvals(Mp)
    mu = mu[np.argsort(-np.abs(mu))]
    resid = op.F_xnorm()
    return {'ell': ell, 'box': idx, 'alpha': float(op.abar),
            'delta': float(abs(mu[0])), 'delta_im': float(abs(mu[0].imag)),
            'delta_re': float(mu[0].real),
            'lam2': float(mu[1].real), 'lam2_abs': float(abs(mu[1])),
            'lam2_im': float(abs(mu[1].imag)),
            'lam3_abs': float(abs(mu[2])), 'resid': float(resid)}


# ------------------------------------------------- контрольные точки первыми
say('')
say('=== контроль: воспроизводит ли скан известное ===')
for ell, a in sorted(ANCHORS.items()):
    r = spec(ell)
    d = r['delta']
    say('  ℓ=%.3f  δ_скан=%.12f   δ_сертиф=%.12f   расхождение %.2e   (%s)'
        % (ell, d, a['delta'], abs(d - a['delta']) / a['delta'], a['src']))
    if a['lam2'] is not None:
        say('           λ₂_скан=%.14f  λ₂_сертиф=%.14f  расхождение %.2e'
            % (r['lam2'], a['lam2'], abs(r['lam2'] - a['lam2']) / a['lam2']))
r2 = spec(2.0)
if r2:
    say('  ℓ=2.000  δ_скан=%.12f   δ_классика=%.12f   расхождение %.2e'
        % (r2['delta'], CLASSIC2['delta'],
           abs(r2['delta'] - CLASSIC2['delta']) / CLASSIC2['delta']))
    say('           α_скан=%.12f   α_классика=%.12f   расхождение %.2e'
        % (abs(r2['alpha']), CLASSIC2['alpha'],
           abs(abs(r2['alpha']) - CLASSIC2['alpha']) / CLASSIC2['alpha']))

# ---------------------------------------------------------------- сетка
GRID = np.round(np.arange(2.0, 4.0001, 0.02), 6)
say('')
say('=== скан по сетке: %d точек, шаг 0.02 ===' % len(GRID))
rows, t0 = [], time.time()
for i, ell in enumerate(GRID):
    try:
        r = spec(float(ell))
    except Exception as e:
        say('  ℓ=%.4f  ОШИБКА %s: %s' % (ell, type(e).__name__, str(e)[:80]))
        continue
    if r is None:
        say('  ℓ=%.4f  бокса нет' % ell)
        continue
    rows.append(r)
    if i % 10 == 0:
        say('  ℓ=%.3f  α=%.9f  δ=%.9f  |λ₂|=%.9f  невязка=%.1e  [%.0f c]'
            % (ell, abs(r['alpha']), r['delta'], r['lam2_abs'], r['resid'],
               time.time() - t0))

json.dump({'rows': rows, 'anchors': ANCHORS, 'classic_l2': CLASSIC2},
          open(os.path.join(HERE, 'delta_scan.json'), 'w'), indent=1)

# ---------------------------------------------------------------- таблица
if rows:
    d = np.array([r['delta'] for r in rows])
    a = np.array([abs(r['alpha']) for r in rows])
    l2 = np.array([r['lam2_abs'] for r in rows])
    ells = np.array([r['ell'] for r in rows])
    say('')
    say('δ:  %.6f (ℓ=%.2f) … %.6f (ℓ=%.2f), монотонно вверх: %s'
        % (d.min(), ells[d.argmin()], d.max(), ells[d.argmax()],
           bool(np.all(np.diff(d) > 0))))
    say('α:  %.6f … %.6f, монотонно вверх: %s'
        % (a.min(), a.max(), bool(np.all(np.diff(a) > 0))))
    say('|λ₂|: %.6f … %.6f, монотонно: %s / %s'
        % (l2.min(), l2.max(), bool(np.all(np.diff(l2) > 0)),
           bool(np.all(np.diff(l2) < 0))))
    say('макс. невязка центра по сетке: %.2e' % max(r['resid'] for r in rows))
    # где |λ₂| максимально близко к 1 — там гиперболичность самая слабая
    j = int(np.argmax(l2))
    say('самое опасное для гиперболичности: ℓ=%.3f, |λ₂|=%.6f' % (ells[j], l2[j]))

    md = ['# δ(ℓ), α(ℓ), λ₂(ℓ) на [2,4] — разведочный скан (float64)', '',
          'Считано `delta_scan.py` по параметрической ветке P(ℓ).',
          '**Это не сертификат** — строгие значения есть только в ℓ=3 и ℓ=5/2.',
          '', '| ℓ | α | δ | \\|λ₂\\| | невязка центра |', '|---|---|---|---|---|']
    for r in rows[::5]:
        md.append('| %.2f | %.9f | %.9f | %.9f | %.1e |'
                  % (r['ell'], abs(r['alpha']), r['delta'], r['lam2_abs'], r['resid']))
    open(os.path.join(HERE, 'delta_scan.md'), 'w', encoding='utf-8').write(
        '\n'.join(md) + '\n')
LOG.close()
