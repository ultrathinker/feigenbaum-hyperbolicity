# -*- coding: utf-8 -*-
"""
xcheck_scale.py — независимая сверка ДВУХ методов в масштабе.

xcheck3 показал в ОДНОЙ точке (ℓ=3.02), что параметрический центр P(ℓ) —
настоящий нуль оператора, которым пользуется марш. Здесь то же самое делается
сразу по всему покрытию марша: берутся 28 компонент из 55, равномерно по
НОМЕРУ компоненты (N_MAX ниже), включая первую и последнюю.

Для каждой выборочной ℓ:
  1. берём бокс параметрического сертификата, содержащий ℓ, и его ветку
     (branch_*.npz), считаем P(ℓ) Клэншоу в arb;
  2. считаем невязку ‖F̃(P(ℓ),ℓ)‖₁ = Σ_{k≥1}|F_k|·r^k движком МАРША
     (tube_lib.compute_F_poly, arb 256 бит) — сторонний код в этом шаге не участвует;
  3. рядом считаем то же для НАМЕРЕННО сдвинутого вектора (контроль
     чувствительности: тест обязан уметь провалиться);
  4. достаём запись марша, накрывающую ℓ, и сравниваем невязку с её Y0
     и с 20 старшими коэффициентами её собственного центра.

Вывод: xcheck_scale.json + печать таблицы.
"""
import os, sys, json, glob, time
import numpy as np

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.dirname(HERE)
METHOD = os.path.join(RES, '_VERIFY-PARAM', 'method-snapshot')
SWEEP = os.path.join(RES, '_VERIFY-PARAM', 'results', 'sweep_out')
sys.path.insert(0, METHOD)

import rig_lib as rl
import tube_lib as tl
from flint import arb, ctx

ctx.prec = 256
NP = tl.N_p
R = tl.r_arb
KICK = 1e-8          # сдвиг контроля: на 3 порядка меньше ρ′ марша (~3e-5)
KICK_IDX = 5

LOG = open(os.path.join(HERE, 'xcheck_scale.log'), 'w', encoding='utf-8')


def say(s):
    print(s, flush=True)
    LOG.write(s + '\n')
    LOG.flush()


def resid_norm(vec, ell):
    """‖F̃‖₁ = Σ_{k≥1}|F_k|·r^k — ровно та норма, в которой марш меряет Y0."""
    a = [x if isinstance(x, arb) else arb(x) for x in vec]
    F = tl.compute_F_poly(a, arb('%.17e' % ell))
    s = arb(0); rk = arb(1)
    for k in range(1, NP + 1):
        rk = rk * R
        s = s + abs(F[k]) * rk
    return s


# ---------------------------------------------------------------- боксы
boxes = []
for bf in sorted(glob.glob(os.path.join(SWEEP, 'box_*.json'))):
    b = json.load(open(bf, encoding='utf-8'))
    idx = b['idx']
    nz = os.path.join(SWEEP, 'branch_%s.npz' % idx)
    if not os.path.exists(nz):
        continue
    boxes.append({'idx': idx, 'ell0': b['ell0'], 'w': b['w'], 'm': b['m'],
                  'lo': b['ell0'] - b['w'] / 2, 'hi': b['ell0'] + b['w'] / 2,
                  'npz': nz, 'Y0': b.get('Y0'), 'passed': b.get('passed')})
say('боксов с веткой: %d' % len(boxes))


def box_for(ell):
    """бокс, содержащий ℓ; при нескольких — с наибольшим запасом до края."""
    cand = [b for b in boxes if b['lo'] <= ell <= b['hi']]
    if not cand:
        return None
    return max(cand, key=lambda b: min(ell - b['lo'], b['hi'] - ell))


# ------------------------------------------------- выборка ℓ из покрытия
cov = json.load(open(os.path.join(HERE, 'coverage.json'), encoding='utf-8'))
U = [(float(a), float(b)) for a, b in cov['union']]
# одна точка на компоненту, но не более N_MAX — берём равномерно по номеру
N_MAX = 28
# равномерно по НОМЕРУ компоненты, обязательно включая первую и последнюю,
# иначе выборка обрывается на середине диапазона марша
idxs = sorted(set(int(round(t)) for t in np.linspace(0, len(U) - 1, N_MAX)))
picks = [0.5 * (U[i][0] + U[i][1]) for i in idxs]
say('точек сверки: %d, диапазон %.4f … %.4f' % (len(picks), picks[0], picks[-1]))

# ------------------------------------------- индекс записей марша по ℓ
say('строю индекс записей марша …')
march = []
for f in glob.glob(os.path.join(RES, '_BANK-RUN2', '*', 'results', '**', 'results.json'),
                   recursive=True) + \
         glob.glob(os.path.join(RES, 'kit_batch', 'park_local', 'park', 'results',
                                '**', 'results.json'), recursive=True):
    try:
        for r in json.load(open(f, encoding='utf-8')):
            if r.get('gate_pass'):
                march.append((float(r['ell_lo']), float(r['ell_hi']), r))
    except Exception:
        pass
march.sort(key=lambda t: t[0])
say('записей марша в индексе: %d' % len(march))


def march_rec(ell):
    for lo, hi, r in march:
        if lo <= ell <= hi:
            return r
    return None


def mid(s):
    """середина arb-строки вида '[x +/- e]' или обычного числа."""
    s = str(s)
    if s.startswith('['):
        s = s[1:].split('+/-')[0].strip()
    return float(s)


# ----------------------------------------------------------------- прогон
rows = []
t0 = time.time()
for n, ell in enumerate(picks):
    b = box_for(ell)
    if b is None:
        say('%2d  ℓ=%.6f  БОКСА НЕТ' % (n, ell))
        continue
    z = np.load(b['npz'])
    c_a, m = z['c_a'], int(z['m'][0])
    x = 2.0 * (ell - b['ell0']) / b['w']
    P = rl.P_at(c_a, m, arb('%.17e' % x))

    rn = resid_norm(P, ell)
    Pk = list(P)
    Pk[KICK_IDX] = Pk[KICK_IDX] + arb('%.17e' % KICK)
    rk = resid_norm(Pk, ell)

    mr = march_rec(ell)
    y0 = mid(mr['Y0']) if mr else float('nan')
    rho = mid(mr['rho_prime_eff']) if mr else float('nan')
    # частичное расстояние по 20 старшим коэффициентам (нижняя оценка ‖·‖_X)
    dhead = float('nan')
    if mr and 'seed_head' in mr:
        sh = [float(v) for v in mr['seed_head']]
        d = 0.0
        for k in range(1, min(len(sh), NP + 1)):
            d += abs(float(P[k]) - sh[k]) * (0.8 ** k)
        dhead = d

    row = {'ell': ell, 'box': b['idx'], 'resid': float(rn.mid()),
           'resid_kick': float(rk.mid()), 'march_Y0': y0, 'march_rho': rho,
           'd_head_partial': dhead,
           'ratio': float(rk.mid()) / max(float(rn.mid()), 1e-300)}
    rows.append(row)
    say('%2d  ℓ=%.6f  box=%-8s  ‖F̃(P)‖=%.3e   контроль=%.3e  (×%.1e)   '
        'марш Y0=%.2e ρ′=%.2e  d_head=%.2e   [%.0f c]'
        % (n, ell, b['idx'], row['resid'], row['resid_kick'], row['ratio'],
           y0, rho, dhead, time.time() - t0))

json.dump({'kick': KICK, 'kick_idx': KICK_IDX, 'rows': rows},
          open(os.path.join(HERE, 'xcheck_scale.json'), 'w'), indent=1)

if rows:
    rr = [r['resid'] for r in rows]
    say('')
    say('ИТОГ: точек %d, невязка max=%.3e  min=%.3e' % (len(rows), max(rr), min(rr)))
    say('      контроль (сдвиг %g в коэф. %d) слабее в %.1e … %.1e раз'
        % (KICK, KICK_IDX, min(r['ratio'] for r in rows),
           max(r['ratio'] for r in rows)))
    worst = max(rows, key=lambda r: r['resid'] / max(r['march_Y0'], 1e-300))
    say('      худшее отношение невязка/Y0_марша: %.3e при ℓ=%.6f'
        % (worst['resid'] / worst['march_Y0'], worst['ell']))
LOG.close()
