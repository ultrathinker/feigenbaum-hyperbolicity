#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
merge_bank.py — свод банка марша run-2 в карту покрытия.

Читает ВСЕ seg/results.json со всех машин (7 в _BANK-RUN2 + локальный ROG),
берёт записи с gate_pass=True, строит объединение интервалов [ell_lo, ell_hi],
находит щели и печатает статистику.

Запуск:
    python merge_bank.py            # пишет COVERAGE.md рядом с собой
"""
import json, os, sys, glob, io
from collections import defaultdict

ROOT = os.path.dirname(os.path.abspath(__file__))
RES = os.path.dirname(ROOT)                     # корень рабочего дерева
BANK = os.path.join(RES, '_BANK-RUN2')
ROG = os.path.join(RES, 'kit_batch', 'park_local', 'park', 'results')

# Слипание соседних микроячеек: стык считается сплошным, если зазор <= EPS.
# Микрошаг h ~ 1e-6..8.5e-6, стыки в float64 дают мусор ~1e-15.
EPS = 1e-12


def find_files():
    """(machine, path) для всех seg/results.json."""
    out = []
    for mdir in sorted(glob.glob(os.path.join(BANK, '*'))):
        if not os.path.isdir(mdir):
            continue
        m = os.path.basename(mdir)
        for f in sorted(glob.glob(os.path.join(mdir, 'results', '**', 'results.json'),
                                  recursive=True)):
            out.append((m, f))
    for f in sorted(glob.glob(os.path.join(ROG, '**', 'results.json'), recursive=True)):
        out.append(('ROG', f))
    return out


def main():
    files = find_files()
    print(f'файлов results.json: {len(files)}', flush=True)

    recs_by_machine = defaultdict(int)
    pass_by_machine = defaultdict(int)
    iv_by_machine = defaultdict(list)
    bad_files = []
    n_total = n_pass = n_fail = 0
    h_min, h_max, h_sum = 1e9, -1e9, 0.0
    zmax = -1e9
    ivs = []

    for i, (m, f) in enumerate(files):
        try:
            recs = json.load(open(f, encoding='utf-8'))
        except Exception as e:
            bad_files.append((f, str(e)))
            continue
        for r in recs:
            n_total += 1
            recs_by_machine[m] += 1
            if not r.get('gate_pass', False):
                n_fail += 1
                continue
            n_pass += 1
            pass_by_machine[m] += 1
            lo, hi = float(r['ell_lo']), float(r['ell_hi'])
            if hi > lo:
                ivs.append((lo, hi))
                iv_by_machine[m].append((lo, hi))
            h = float(r.get('h_used', 0.0))
            h_min = min(h_min, h); h_max = max(h_max, h); h_sum += h
            z = r.get('Z_hat_eff')
            if z is not None:
                zmax = max(zmax, float(z))
        if (i + 1) % 20 == 0:
            print(f'  {i+1}/{len(files)} файлов, записей {n_total}', flush=True)

    def union(iv, eps=EPS):
        if not iv:
            return []
        iv = sorted(iv)
        out = [list(iv[0])]
        for lo, hi in iv[1:]:
            if lo <= out[-1][1] + eps:
                out[-1][1] = max(out[-1][1], hi)
            else:
                out.append([lo, hi])
        return [tuple(x) for x in out]

    U = union(ivs)
    covered = sum(hi - lo for lo, hi in U)

    lines = []
    A = lines.append
    A('# COVERAGE — свод банка марша run-2 (независимый кросс-чек)')
    A('')
    A('Сгенерировано `merge_bank.py`. Марш остановлен 20:27 17.08.2026 —')
    A('существование на ℓ ∈ [2,4] закрыто параметрическим методом')
    A('(параметрический метод — §3 статьи), а банк марша служит **независимой проверкой**')
    A('того же утверждения другим алгоритмом.')
    A('')
    A('## 1. Объём')
    A('')
    A('| Величина | Значение |')
    A('|---|---|')
    A(f'| Файлов `results.json` | {len(files)} |')
    A(f'| Записей всего | {n_total:,} |'.replace(',', ' '))
    A(f'| Из них `gate_pass=True` | {n_pass:,} |'.replace(',', ' '))
    A(f'| Из них `gate_pass=False` | {n_fail:,} |'.replace(',', ' '))
    A(f'| Нечитаемых файлов | {len(bad_files)} |')
    A(f'| Суммарная длина покрытия | {covered:.6f} |')
    A(f'| Компонент связности | {len(U)} |')
    if n_pass:
        A(f'| Микрошаг h: min / avg / max | {h_min:.3e} / {h_sum/n_pass:.3e} / {h_max:.3e} |')
        A(f'| max Ẑ_eff по банку | {zmax:.6f} |')
    A('')
    A('## 2. Покрытые интервалы (объединение)')
    A('')
    A('| # | ℓ_lo | ℓ_hi | длина |')
    A('|---|---|---|---|')
    for k, (lo, hi) in enumerate(U):
        A(f'| {k} | {lo:.8f} | {hi:.8f} | {hi-lo:.8f} |')
    A('')
    A('## 3. Щели между компонентами')
    A('')
    if len(U) <= 1:
        A('Щелей нет — покрытие односвязно.')
    else:
        A('| после # | от | до | ширина |')
        A('|---|---|---|---|')
        for k in range(len(U) - 1):
            A(f'| {k} | {U[k][1]:.8f} | {U[k+1][0]:.8f} | {U[k+1][0]-U[k][1]:.3e} |')
    A('')
    A('## 4. По машинам')
    A('')
    A('| Машина | записей | pass | своё покрытие | компонент |')
    A('|---|---|---|---|---|')
    for m in sorted(recs_by_machine):
        um = union(iv_by_machine[m])
        cm = sum(hi - lo for lo, hi in um)
        A(f'| {m} | {recs_by_machine[m]:,} | {pass_by_machine[m]:,} | {cm:.6f} | {len(um)} |'
          .replace(',', ' '))
    A('')
    if bad_files:
        A('## 5. Нечитаемые файлы')
        A('')
        for f, e in bad_files[:20]:
            A(f'- `{f}` — {e}')
        A('')

    txt = '\n'.join(lines) + '\n'
    out = os.path.join(ROOT, 'COVERAGE.md')
    with io.open(out, 'w', encoding='utf-8') as fh:
        fh.write(txt)
    json.dump({'union': U, 'n_total': n_total, 'n_pass': n_pass, 'n_fail': n_fail,
               'covered': covered, 'zmax': zmax,
               'h': [h_min, h_sum / max(n_pass, 1), h_max],
               'by_machine': {m: {'n': recs_by_machine[m], 'pass': pass_by_machine[m],
                                  'union': union(iv_by_machine[m])}
                              for m in recs_by_machine}},
              open(os.path.join(ROOT, 'coverage.json'), 'w'), indent=1)
    print(txt[:2000])
    print(f'\n-> {out}')


if __name__ == '__main__':
    main()
