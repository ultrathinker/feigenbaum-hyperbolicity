# -*- coding: utf-8 -*-
"""Отладка падений Ш0 — вывод A, P и P − A^T P A для проваленных случаев."""
import numpy as np
import scipy.linalg as la

rng = np.random.default_rng(42)
case_idx = 0
for trial in range(15):
    n = int(rng.integers(2, 6))
    ev_real = rng.uniform(0.1, 4.0, size=n)
    ev_real = np.where(np.abs(ev_real - 1.0) < 0.05, ev_real + 0.1, ev_real)
    Q = rng.standard_normal((n, n))
    Q, _ = np.linalg.qr(Q)
    A = Q @ np.diag(ev_real) @ np.linalg.inv(Q)
    case_idx += 1
    if case_idx in (3, 6):  # trial=2 -> 3-й кейс (counting diag+rotation+два теста), trial=5 -> 6-й
        print(f'========= case {case_idx}, n={n}, trial={trial} =========')
        print('A =')
        print(A)
        print('eigenvalues of A:', np.linalg.eigvals(A))
        # Решение
        P = la.solve_discrete_lyapunov(A.T, np.eye(n))
        # Проверим P − A^T P A = I ?
        S = A.T @ P @ A - P
        eps = np.linalg.norm(P - A.T @ P @ A - np.eye(n))
        print('eps P - A^T P A - I:', eps)
        print('eigenvalues of P:', np.linalg.eigvalsh(0.5 * (P + P.T)))
        # In P (через LDL)
        P_sym = 0.5 * (P + P.T)
        _, d, _ = la.ldl(P_sym)
        print('P pivots:', np.diag(d))
        # In S
        S_sym = 0.5 * (S + S.T)
        _, d, _ = la.ldl(S_sym)
        print('S pivots:', np.diag(d))
        print()
