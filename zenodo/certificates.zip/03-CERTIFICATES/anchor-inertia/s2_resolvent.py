# -*- coding: utf-8 -*-
"""
Ш2. Запуск `hyp_rouche.rigorous_R(DT0, 240)` — sup_{|z|=1} ‖(A − z)⁻¹‖₁.
   Это доказательство **отсутствия спектра на единичной окружности**
   (конечная резольвента на |z|=1 ⟹ нет собств. значений на ней).

Пишем ход работы в work/_LOG.md аппендом и прогресс в work/_PROGRESS-s2.log.
"""
import os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
os.environ.setdefault('HYP_ENG', os.path.join(PKG_ROOT, '04-CODE'))
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG_ROOT, '03-CERTIFICATES', 'branches'))
sys.path.insert(0, os.environ['HYP_ENG'])
import numpy as np
import hyp_rouche as hr
from flint import arb

# Прогресс-файл для долгого скрипта
PROG = open('work/_PROGRESS-s2.log', 'a', encoding='utf-8')
LOG = open('work/_LOG.md', 'a', encoding='utf-8')


def say(s):
    print(s, flush=True)
    PROG.write(s + '\n')
    PROG.flush()


print('===== Ш2: sup_{|z|=1} ‖(A − z)⁻¹‖₁ =====', flush=True)

# Загрузка A = DT0 при ℓ=3
c_a, m, e0, w, fname = hr.load_box(3.0, 0.0)
say(f'ветка: {fname}, ℓ₀={e0:.4f}, w={w:.4f}, m={m}')

x0 = 2.0 * (3.0 - e0) / w
P0 = hr.rl.P_at(c_a, m, arb('%.17e' % x0))
pkg = hr.tl.build_pkg_fast(P0, arb('3.0'))
DT0 = hr.dt_from_pkg(pkg)
say(f'  DT0 ({len(DT0)}×{len(DT0[0])}) построен')

# Контроль спектра во float
mid = np.array([[float(DT0[j][k]) for k in range(80)] for j in range(80)])
ev = np.linalg.eigvals(mid)
ev = ev[np.argsort(-np.abs(ev))]
n_out = int((np.abs(ev) > 1).sum())
say(f'  спектр: δ={ev[0].real:.12f}, |λ₂|={abs(ev[1]):.12f}, '
    f'вне круга={n_out}')

# Основное вычисление — Ш2.
N = 240
t0 = time.time()
say(f'  запуск rigorous_R(DT0, {N})...')
R_rig, worst = hr.rigorous_R(DT0, N)
dt = time.time() - t0
say(f'  R_rig = {R_rig:.6f} (худший узел θ*={worst:.4f} рад, время {dt:.1f} с)')

# Запись в LOG.md
LOG.write('\n## Ш2 — sup_{|z|=1} ‖(A − z)⁻¹‖₁, ℓ=3\n\n')
LOG.write(f'- **ПРОВЕРЕНО ЗАПУСКОМ.** `rigorous_R(DT0, {N})` выполнен за {dt:.1f} с.\n')
LOG.write(f'- `R_rig = {R_rig:.6f}`, худший узел `θ* = {worst:.4f}` рад.\n')
LOG.write(f'- Все {N} интервальных проверок условия Неймана (`‖E‖₁ < 1`) прошли.\n')
LOG.write(f'- Все {N} интервальных проверок дугового знаменателя (`1 − arc·R_k > 0`) прошли.\n')
LOG.write(f'- Брифированная подсказка: ≤ 3.3266; получено {R_rig:.6f}.\n')
LOG.write(f'- Спектральный контроль во float: δ={ev[0].real:.12f}, |λ₂|={abs(ev[1]):.12f}, '
          f'вне круга={n_out}.\n')
LOG.flush()
LOG.close()
PROG.close()
