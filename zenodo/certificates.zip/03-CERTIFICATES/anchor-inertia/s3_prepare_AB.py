# -*- coding: utf-8 -*-
"""
Ш3 + Ш4 — основное доказательство.

Ш3: A^T P A − P ≺ 0 интервально.
Ш4: Инерция P = (79, 1, 0) интервально.

Алгоритм:
  1) Построить A = DT|X₀ при ℓ=3 (arb).
  2) Решить P − A^T P A = I во float (scipy.solve_discrete_lyapunov).
  3) Поднять P в arb, симметризовать.
  4) Поднять A из arb, построить S = A^T P A − P (в arb).
  5) Интервальный LDL^T по столбцам, для каждого пивота -S проверить,
     что верхняя граница строго > 0.
  6) Интервальный LDL^T для P (у симметричной P) — то же для самой P,
     проверить число строго положительных и отрицательных пивот.
"""
import io, os, re, sys, time, tempfile
# Раньше здесь стояли АБСОЛЮТНО ЖЁСТКИЕ 'method'/'reference/branches' —
# путей рабочего дерева, которого в пакете нет и быть не может (движок лежит в
# 04-CODE/, ветки — в 03-CERTIFICATES/branches/).  Прямой запуск падал
# `ModuleNotFoundError: No module named 'hyp_rouche'`, а ни README, ни
# REPRODUCE не объясняли, что нужно вручную создавать junction'ы method/ и
# reference/branches/.  Следование предписанному минимальному маршруту
# проверяло якорь — «фундамент всей цепочки Руше» — только float-версией
# (`_anchor_check.py`, чей же докстринг честно пишет «не заменяет
# интервальную часть»), а строгую arb-версию нельзя было запустить вовсе.
# Теперь пути берутся из окружения с умолчанием, соответствующим РЕАЛЬНОЙ
# раскладке пакета (как во всех остальных скриптах 04-CODE) — никаких
# junction'ов создавать не нужно.
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))          # .../03-CERTIFICATES/.. -> корень пакета
ENG = os.environ.get('HYP_ENG', os.path.join(PKG_ROOT, '04-CODE'))
BRANCHES = os.environ.get('HYP_BRANCHES', os.path.join(PKG_ROOT, '03-CERTIFICATES', 'branches'))
os.environ.setdefault('HYP_BRANCHES', BRANCHES)
sys.path.insert(0, ENG)
import numpy as np
import scipy.linalg as la
import hyp_rouche as hr
from flint import arb, ctx

ctx.prec = 256
NP = hr.NP  # = 80


def ldl_interval_pivots(M, name=''):
    """Бесповоротное LDLᵀ-разложение симметричной интервальной матрицы M.
       M передаётся как список списков arb размера n×n.
       Возвращает (pivots, n_plus, n_minus, n_zero, n_unsafe),
       где pivots[j] = D[j,j] как arb-интервал.
       n_plus = #{j : upper(D[j,j]) <= 0  ??? нет, lower(D[j,j]) > 0}
       n_minus = #{j : upper(D[j,j]) < 0}
       n_zero — пивоты, чьи интервал содержит 0 (неопределённый знак).
       n_unsafe — пивоты с плохим определением знака (см. is_positive, is_negative).

       Используем БЕЗ перестановок: тогда знаки пивот = знаки собств. значений
       (закон Сильвестра не предполагает перестановок, если LDL без них возможен).
    """
    n = len(M)
    # копия для разрушения
    A = [[M[j][k] for k in range(n)] for j in range(n)]
    pivots = []
    sign_pos = 0  # d > 0 strict
    sign_neg = 0  # d < 0 strict
    sign_zero = 0  # d содержит 0
    sign_uncertain = 0  # d > 0 или d < 0 не STRICT — содержит 0
    for j in range(n):
        # Берём диагональ как пивот
        d = A[j][j]
        pivots.append(d)
        # Классифицируем знак:
        # d > 0 STRICT iff lower(d) > 0
        # d < 0 STRICT iff upper(d) < 0
        # d содержит 0 iff lower(d) <= 0 <= upper(d)
        lo = float(d.lower())
        hi = float(d.upper())
        if lo > 0:
            sign_pos += 1
        elif hi < 0:
            sign_neg += 1
        elif lo <= 0 <= hi:
            sign_zero += 1
        else:
            sign_uncertain += 1
        # Обновляем A[i][k] -= A[i][j] * A[j][k] / d, для i, k > j
        if hi == 0 and lo == 0:
            # пивот точно нуль — неопределённость (не должно случиться)
            continue
        inv_d = arb(1) / d
        for i in range(j + 1, n):
            if A[i][j] == arb(0):
                continue
            ratio = A[i][j] * inv_d
            for k in range(j + 1, n):
                A[i][k] = A[i][k] - ratio * A[j][k]
    return pivots, sign_pos, sign_neg, sign_zero, sign_uncertain


def sym(A):
    """Симметризация arb-матрицы."""
    n = len(A)
    return [[(A[j][k] + A[k][j]) / arb(2) for k in range(n)] for j in range(n)]


# Та же болезнь: 'work/' относительно CWD требовал ручного mkdir и,
# при запуске из корня пакета, писал бы прямо внутрь пакета (портя сверку с
# манифестом — тот же класс дефекта, что и hyp_rouche.log).  Теперь
# путь настраиваем и создаём сами; по умолчанию — временный каталог ОС.
WORK = os.environ.get('HYP_ANCHOR_WORK', os.path.join(tempfile.gettempdir(), 'anchor-work'))
os.makedirs(WORK, exist_ok=True)
# Опубликованные границы радиусов.  Каждая из них стоит в прозе
# (§5.1.1 статьи, 02-REPRODUCE.md, REPORT-ANCHOR.md); здесь они становятся
# калитками, а ниже — ещё и сверяются С САМОЙ ПРОЗОЙ, чтобы правка текста
# в одну сторону не разъехалась с замером.
PUB_RAD_NEGS = 4.76e-72   # max rad пивота -S   (замер 4.7542e-72)
PUB_RAD_P = 6.12e-75      # max rad пивота P    (замер 6.1153e-75)
PUB_RAD_NEG = 3.81e-77    # rad отрицательного пивота P (замер 3.8020e-77)

PROG = open(os.path.join(WORK, '_PROGRESS-s3.log'), 'a', encoding='utf-8')
LOG = open(os.path.join(WORK, '_LOG.md'), 'a', encoding='utf-8')


def say(s):
    print(s, flush=True)
    PROG.write(s + '\n')
    PROG.flush()


# 1) Построить A = DT|X₀ при ℓ=3
say('===== Ш3 + Ш4: основное доказательство =====')
t0 = time.time()
c_a, m, e0, w, fname = hr.load_box(3.0, 0.0)
say(f'  ветка: {fname}, ℓ₀={e0:.4f}, w={w:.4f}, m={m}')
x0 = 2.0 * (3.0 - e0) / w
P0 = hr.rl.P_at(c_a, m, arb('%.17e' % x0))
pkg = hr.tl.build_pkg_fast(P0, arb('3.0'))
DT0 = hr.dt_from_pkg(pkg)
say(f'  DT0 ({NP}×{NP}) построен за {time.time()-t0:.1f} с')

# 2) Решить P − A^T P A = I во float
n = NP
A_mid = np.array([[float(DT0[j][k]) for k in range(n)] for j in range(n)])
t0 = time.time()
# P приходила из ФЛОАТНОГО LAPACK, а LAPACK/BLAS у каждой сборки
# свой: на T480 (manylinux/OpenBLAS) решение отличалось от нашего в младших
# разрядах, и радиусы интервальных пивот выходили другими — max rad(P) =
# 6.7959e-75 против опубликованных 6.1153e-75.  Калитка ниже краснела на своей
# же статье, хотя вывод держался на обеих машинах: in(P) = (79,1,0), -S ≻ 0.
# Расходилась точность охвата, а не результат.
# P — это СЕРТИФИКАТ, а не вычисление: доказательству нужна любая симметричная
# P с in(P) = (79,1,0) и AᵀPA − P ≺ 0.  Поэтому ту самую P, которой посчитана
# статья, храним в пакете (hex float — побитно одна и та же везде) и читаем
# оттуда.  Строгость не страдает: знаки пивот по-прежнему считает arb-LDL ниже,
# он и остаётся условием выхода.  Нет файла — старое поведение.
P_REF = os.path.join(HERE, 'P_anchor.json')
# `--с-нуля` — решить Ляпунова заново тем LAPACK, что есть здесь.
# Строгие ворота (инерция, знак -S) в этом режиме работают как обычно; не применяется
# только сверка с ОПУБЛИКОВАННЫМИ радиусами: они — свойство конкретной P.
С_НУЛЯ = ('--с-нуля' in sys.argv) or os.environ.get('HYP_ANCHOR_FROM_SCRATCH') == '1'
P = None
if os.path.exists(P_REF) and not С_НУЛЯ:
    import json as _jsP
    _dP = _jsP.load(io.open(P_REF, encoding='utf-8'))
    if _dP['n'] != n:
        raise SystemExit('P_anchor.json: n = %s, ожидалось %d' % (_dP['n'], n))
    P = np.array([[float.fromhex(x) for x in row] for row in _dP['P_hex']])
    say('  P = эталонная матрица из %s (%d×%d, hex, воспроизводима побитно)'
        % (os.path.basename(P_REF), n, n))
try:
    if P is None:
        P = la.solve_discrete_lyapunov(A_mid.T, np.eye(n))
        say(f'  P = решение Ляпунова получено через solve_discrete_lyapunov за {time.time()-t0:.2f} с')
except np.linalg.LinAlgError as e:
    say(f'  solve_discrete_lyapunov провалился: {e}')
    say('  Переходим к фолбэку: Q = I + возмущение')
    rng = np.random.default_rng(2024)
    while True:
        eps = 0.01
        pert = rng.standard_normal((n, n))
        Q2 = np.eye(n) + eps * (pert @ pert.T)
        try:
            P = la.solve_discrete_lyapunov(A_mid.T, Q2)
            say(f'  P получено с возмущённой Q, ||Q − I||_2 ≈ {np.linalg.norm(Q2 - np.eye(n)):.2e}')
            break
        except np.linalg.LinAlgError:
            pass

P = 0.5 * (P + P.T)  # симметризация
# Использованную P всегда выкладываем рядом с результатом — она и
# есть сертификат; из этой выгрузки P_anchor.json и кладётся в пакет.
import json as _jsD
io.open(os.path.join(WORK, 'P_anchor.json'), 'w', encoding='utf-8').write(_jsD.dumps(
    {'n': n,
     'что': 'решение P − AᵀPA = I при ℓ=3, симметризованное; hex-float, точное',
     'источник': 'P_anchor.json' if P_REF and os.path.exists(P_REF) else 'solve_discrete_lyapunov',
     'P_hex': [[float(P[j][k]).hex() for k in range(n)] for j in range(n)]},
    ensure_ascii=False))
S_mid = A_mid.T @ P @ A_mid - P

# Контроль во float
eigP = np.linalg.eigvalsh(P)
posP = int(np.sum(eigP > 1e-9))
negP = int(np.sum(eigP < -1e-9))
zerP = n - posP - negP
eigS = np.linalg.eigvalsh(S_mid)
maxS = float(np.max(eigS))
say(f'  float in(P) = ({posP}, {negP}, {zerP}); max eigenvalue of S = {maxS:.6e}')
# Не `assert`: под `python -O` голый assert исчезает, и обе калитки
# несущего утверждения (инерция якоря и знакоопределённость S) стали бы
# бездействующими при коде возврата 0.
if not (posP == 79 and negP == 1 and zerP == 0):
    raise SystemExit(f'unexpected inP: {(posP, negP, zerP)}')
if not (maxS < 0):
    raise SystemExit('S not negative definite in float')
say('  float-контроль прошёл: in(P) = (79,1,0), S ≺ 0')

# 3) Поднять P в arb, симметризовать
t0 = time.time()
P_arb = [[arb(0) for _ in range(n)] for _ in range(n)]
for j in range(n):
    for k in range(n):
        P_arb[j][k] = arb('%.17e' % P[j][k])

# 4) Поднять A из arb, построить S = A^T P A − P (в arb)
A_arb = [[None for _ in range(n)] for _ in range(n)]
for j in range(n):
    for k in range(n):
        A_arb[j][k] = DT0[j][k]

# S = A^T P A − P
S_arb = [[None for _ in range(n)] for _ in range(n)]
for j in range(n):
    for k in range(n):
        # S[j,k] = sum_l sum_m A[l,j] P[l,m] A[m,k] - P[j,k]
        s = arb(0)
        for l in range(n):
            for m in range(n):
                s = s + A_arb[l][j] * P_arb[l][m] * A_arb[m][k]
        S_arb[j][k] = s - P_arb[j][k]

S_arb = sym(S_arb)
say(f'  S построен в arb за {time.time()-t0:.1f} с')

# 5) Интервальный LDL для -S (это должно быть ≻ 0)
t0 = time.time()
neg_S = [[(-S_arb[j][k]) for k in range(n)] for j in range(n)]
neg_S = sym(neg_S)
pivots_negS, p_plus, p_minus, p_zero, p_uns = ldl_interval_pivots(neg_S, '-S')
say(f'  LDL на -S ({time.time()-t0:.1f} с): +{p_plus} -{p_minus} 0:{p_zero} ?:{p_uns}')

min_pivot_neg_S = min(pivots_negS, key=lambda x: float(x.lower()))
say(f'  минимум lower(-S пивот) = {float(min_pivot_neg_S.lower()):.4e}')
say(f'  минимум upper(-S пивот) = {float(min_pivot_neg_S.upper()):.4e}')

# 6) Интервальный LDL для P
P_arb = sym(P_arb)
t0 = time.time()
pivots_P, p_plusP, p_minusP, p_zeroP, p_unsP = ldl_interval_pivots(P_arb, 'P')
say(f'  LDL на P ({time.time()-t0:.1f} с): +{p_plusP} -{p_minusP} 0:{p_zeroP} ?:{p_unsP}')

# Покажем минимальные пивоты P
sorted_by_lowerP = sorted(pivots_P, key=lambda x: float(x.lower()))
say('  5 наименьших по lower():')
for i in range(5):
    p = sorted_by_lowerP[i]
    say(f'    piv_{i}: [{float(p.lower()):.6e}, {float(p.upper()):.6e}], rad={float(p.rad()):.3e}')

# Максимумы радиусов по ВСЕМ пивотам — раньше не считались вовсе:
# наружу шли только пять наименьших по lower(), а проза публиковала
# «радиусы ≤ 10⁻⁷⁵» и «~10⁻⁷⁷», не опираясь ни на что.
max_rad_negS = max(float(p.rad()) for p in pivots_negS)
max_rad_P = max(float(p.rad()) for p in pivots_P)
_negs = [p for p in pivots_P if float(p.upper()) < 0]
rad_neg_P = max(float(p.rad()) for p in _negs) if _negs else 0.0
min_abs_neg_P = min(abs(float(p.upper())) for p in _negs) if _negs else 0.0
say(f'  max rad(-S) = {max_rad_negS:.4e}, max rad(P) = {max_rad_P:.4e}')
say(f'  отрицательный пивот P: |pivot| >= {min_abs_neg_P:.6f}, '
    f'rad <= {rad_neg_P:.4e}')

# Сохраним в файл
import json
res = {
    'ell0': 3.0,
    # откуда взялась P — от этого зависят все радиусы ниже
    'P_source': 'P_anchor.json' if os.path.exists(P_REF) else 'solve_discrete_lyapunov',
    'branch': fname,
    'inP_via_eigvalsh_float': (posP, negP, zerP),
    'min_lower_-S_pivot': float(min_pivot_neg_S.lower()),
    'min_upper_-S_pivot': float(min_pivot_neg_S.upper()),
    'pivots_sign_-S': (p_plus, p_minus, p_zero, p_uns),
    'pivots_sign_P': (p_plusP, p_minusP, p_zeroP, p_unsP),
    'min5_lower_P': [float(p.lower()) for p in sorted_by_lowerP[:5]],
    'min5_upper_P': [float(p.upper()) for p in sorted_by_lowerP[:5]],
    'min5_rad_P': [float(p.rad()) for p in sorted_by_lowerP[:5]],
    # носитель для опубликованных радиусов
    'max_rad_negS_pivot': max_rad_negS,
    'max_rad_P_pivot': max_rad_P,
    'rad_neg_pivot_P': rad_neg_P,
    'min_abs_neg_pivot_P': min_abs_neg_P,
    'published_rad_bounds': {'negS': PUB_RAD_NEGS, 'P': PUB_RAD_P,
                             'neg_pivot': PUB_RAD_NEG},
}
with open(os.path.join(WORK, '_s3s4_result.json'), 'w', encoding='utf-8') as f:
    json.dump(res, f, ensure_ascii=False, indent=1)
say(f'  результат сохранён в {os.path.join(WORK, "_s3s4_result.json")}')

# Запись в LOG
LOG.write('\n## Ш3+Ш4 — S ≺ 0 и in(P) интервально\n\n')
LOG.write(f'- **ПРОВЕРЕНО ЗАПУСКОМ.** `solve_discrete_lyapunov(A.T, I)` (P = решение '
          f'`P − Aᵀ P A = I`) выдал `P` вещественно-симметричной 80×80.\n')
LOG.write(f'- float-контроль: `in(P) = ({posP}, {negP}, {zerP})`, `max eig(S) = {maxS:.3e}`.\n')
LOG.write(f'- **Ш3:** интервальный LDL на `-S` (без перестановок),'
          f' `+{p_plus}, -{p_minus}, 0:{p_zero}, ?:{p_uns}` — все '
          f'пивоты `-S` имеют `lower > 0` ⇒ `-S ≻ 0` ⇒ `S ≺ 0`. '
          f'Мин. `lower(-S пивот) = {float(min_pivot_neg_S.lower()):.3e}`, '
          f'верхняя `= {float(min_pivot_neg_S.upper()):.3e}`.\n')
LOG.write(f'- **Ш4:** интервальный LDL на `P`,'
          f' `+{p_plusP}, -{p_minusP}, 0:{p_zeroP}, ?:{p_unsP}`.\n')
LOG.write(f'- 5 наименьших (по lower) пивот `P`: ')
for i in range(5):
    p = sorted_by_lowerP[i]
    LOG.write(f'[{float(p.lower()):.3e}, {float(p.upper()):.3e}]')
LOG.write('\n')
LOG.flush()
LOG.close()
PROG.close()

# До сих пор строгая часть якоря не имела ни одной калитки: обе
# калитки выше («unexpected inP», «S not negative definite in float» —
# не assert, см. комментарий там же) проверяли только ФЛОАТ-контроль, а знаки
# ИНТЕРВАЛЬНЫХ пивот — то, ради чего скрипт и написан, — лишь печатались.
# Фальсификация (подмена классификации `if lo > 0` на `if lo > 1e9`)
# давала «+0 -0 0:0 ?:80», то есть НЕ ДОКАЗАНО НИЧЕГО, и RC=0.  Теперь
# инерция (79,1,0) в интервальной арифметике — условие выхода.
_bad = []
if (p_plus, p_minus, p_zero, p_uns) != (n, 0, 0, 0):
    _bad.append('-S: ожидалось +%d -0 0:0 ?:0, получено +%d -%d 0:%d ?:%d'
                % (n, p_plus, p_minus, p_zero, p_uns))
if (p_plusP, p_minusP, p_zeroP, p_unsP) != (n - 1, 1, 0, 0):
    _bad.append('P: ожидалось +%d -1 0:0 ?:0, получено +%d -%d 0:%d ?:%d'
                % (n - 1, p_plusP, p_minusP, p_zeroP, p_unsP))
if float(min_pivot_neg_S.lower()) <= 0:
    _bad.append('минимальный пивот -S не строго положителен: %.3e'
                % float(min_pivot_neg_S.lower()))

# --- Радиусы против опубликованного -------------------------------------
# Претензии к РАДИУСАМ копятся отдельно — в режиме `--с-нуля` они не ворота,
# а наблюдение. Претензии к ИНЕРЦИИ и знакам остаются в _bad всегда.
_rad_bad = []
for _nm, _got, _pub in (('-S', max_rad_negS, PUB_RAD_NEGS),
                        ('P', max_rad_P, PUB_RAD_P),
                        ('отрицательный пивот P', rad_neg_P, PUB_RAD_NEG)):
    if _got > _pub:
        _rad_bad.append('max rad(%s) = %.4e больше опубликованного %.1e'
                        % (_nm, _got, _pub))

# ...и против САМОЙ прозы.  Берём только те утверждения о радиусе, рядом с
# которыми стоит слово «пивот»: без этого фильтра под ту же гребёнку
# попадали радиус ворот Канторовича (§3), радиус элементов `A` и радиусы
# прогонов устойчивости — величины другой природы.  «~» читаем как порядок
# величины (допуск x10), «<=» — как строгую границу.  Сравниваем с
# ГЛОБАЛЬНЫМ максимумом по обеим матрицам, кроме утверждений про
# отрицательный пивот: делить прозу тоньше — значит гадать, о какой из
# двух матриц идёт речь, а глобальная граница верна всегда.
_SUP = {'\u2070': '0', '\u00b9': '1', '\u00b2': '2', '\u00b3': '3',
        '\u2074': '4', '\u2075': '5', '\u2076': '6', '\u2077': '7',
        '\u2078': '8', '\u2079': '9'}
_ANCH = os.path.dirname(os.path.abspath(__file__))
_DOCS = [os.path.join(_ANCH, '..', '..', '01-ARTICLE.md'),
         os.path.join(_ANCH, '..', '..', '02-REPRODUCE.md'),
         os.path.join(_ANCH, 'REPORT-ANCHOR.md')]
_RE = re.compile('(?:радиус\\w*|rad)[^.\\n]{0,40}?([\u2264~])\\s*`?\\s*'
                 '(?:([0-9.]+)[\u00b7\u00d7])?10\u207b'
                 '([\u2070-\u2079\u00b9\u00b2\u00b3]+)')
_max_all = max(max_rad_negS, max_rad_P)
_seen = 0
for _d in _DOCS:
    _d = os.path.normpath(_d)
    if not os.path.exists(_d):
        _bad.append('не найден документ для сверки радиусов: %s' % _d)
        continue
    _txt = io.open(_d, encoding='utf-8').read()
    for _m in _RE.finditer(_txt):
        _ctx = _txt[max(0, _m.start() - 220):_m.end()]
        if 'пивот' not in _ctx.lower():
            continue
        _seen += 1
        _e = int(''.join(_SUP[ch] for ch in _m.group(3)))
        _claim = float(_m.group(2) or '1.0') * 10.0 ** (-_e)
        # Не «есть ли слово где-то в окне», а какое
        # знаковое слово стоит БЛИЖЕ ВСЕГО перед числом: строки про
        # отрицательный и про положительные пивоты идут подряд, и первая
        # перетягивала вторую на свой (в 10^5 раз более слабый) порог.
        _low = _ctx.lower()
        _ineg = _low.rfind('отрицательн')
        _ipos = max(_low.rfind('положительн'), _low.rfind('общая границ'),
                    _low.rfind('общ. границ'))
        _isneg = _ineg > _ipos
        _got = rad_neg_P if _isneg else _max_all
        _tol = 10.0 if _m.group(1) == '~' else 1.0
        if _got > _claim * _tol:
            _rad_bad.append('%s: заявлен радиус «%s %.3g» (%s), замер %.4e больше'
                        % (os.path.basename(_d), _m.group(1), _claim,
                           'отрицательный пивот' if _isneg else 'любой пивот',
                           _got))
# Порог «не меньше N» оставлял дыру: утверждение,
# выпавшее из-под регулярки (например, из-за оборота «rad ~ 10^-75 против
# пивота 1.0», где слово «пивот» стоит СПРАВА от числа), просто переставало
# сверяться, а счётчик оставался выше порога.  Расширять окно вправо нельзя
# — рядом стоят утверждения про радиус ЭЛЕМЕНТОВ матрицы, они начали бы
# ложно краснеть.  Поэтому число сверяемых утверждений зафиксировано точно.
_SEEN_EXPECTED = 12
if _seen != _SEEN_EXPECTED:
    _bad.append('сверено %d утверждений о радиусах пивот, ожидалось %d — '
                'проза переформулирована и вышла из-под сверки (или, '
                'наоборот, появилось новое утверждение): проверьте регулярку '
                'и обновите _SEEN_EXPECTED' % (_seen, _SEEN_EXPECTED))
else:
    print('  сверено с прозой утверждений о радиусах пивот: %d' % _seen)

# Раздельные максимумы публикуются в таблице REPORT-ANCHOR.md точными
# числами (без «<=»), поэтому сканером выше они не ловятся; проверяем их
# присутствие отдельно — иначе замер снова разъедется с текстом молча.
_RA = io.open(os.path.join(_ANCH, 'REPORT-ANCHOR.md'), encoding='utf-8').read()
for _nm, _got in (('-S', max_rad_negS), ('P', max_rad_P),
                  ('отрицательный', rad_neg_P)):
    _s = '%.4e' % _got            # 4.7542e-72
    _mant, _ex = _s.split('e')
    _pub = _mant + '\u00d710\u207b' + ''.join(
        dict((v, k) for k, v in _SUP.items())[c] for c in str(abs(int(_ex))))
    if _pub not in _RA:
        _rad_bad.append('в REPORT-ANCHOR.md нет замера max rad(%s) = %s'
                        % (_nm, _pub))

# Свести обратно. В обычном прогоне радиусные претензии — такие же ворота,
# как и раньше; в `--с-нуля` они печатаются как наблюдение, потому что чужой LAPACK
# не обязан попадать в наши цифры — от него требуется устоявший ВЫВОД.
if С_НУЛЯ:
    print('--с-нуля: P посчитана заново, сверка с опубликованными радиусами НЕ применяется')
    print('  замеры этой машины: max rad(-S) = %.4e, max rad(P) = %.4e, '
          'rad(отрицательный) = %.4e' % (max_rad_negS, max_rad_P, rad_neg_P))
    for _b in _rad_bad:
        print('  наблюдение (не ворота): ' + _b)
else:
    _bad.extend(_rad_bad)

if _bad:
    for _b in _bad:
        print('*** FAIL: ' + _b)
    sys.exit(1)
print('ИНЕРЦИЯ ЯКОРЯ (интервально): in(P) = (%d, 1, 0), -S > 0 — ok'
      % (n - 1))
