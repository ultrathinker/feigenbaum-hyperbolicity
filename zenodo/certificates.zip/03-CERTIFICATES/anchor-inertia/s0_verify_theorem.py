# -*- coding: utf-8 -*-
"""
Ш0 (ВЕРСИЯ 1, УСТАРЕВШАЯ — ЗАПУСКАТЬ `s0_verify2.py`).

Этот скрипт печатает «17/19» и два FAIL на случайных 5×5 (trial=2, trial=5).
Провалы — не в теореме, а в самом скрипте: счётчик инерции здесь берёт знаки
через `LDL`-разложение, которое на сильно ненормальных `A` даёт неверный
счёт. В `s0_verify2.py` инерция считается через `numpy.linalg.eigvalsh`, и
там 20/20; именно этот результат и приведён в `REPORT-ANCHOR.md`, шаг Ш0.
Версия 1 оставлена в пакете ради истории правки — но её вывод НЕ является
утверждением пакета.

Ш0. Проверка теоремы Стейна–Таусски на малых матрицах.

Теорема.
   Пусть A — вещественная n×n без собственных значений на единичной окружности,
   P = P^T (знакоопределённость P НЕ предполагается).
   Если S := A^T P A - P ≺ 0 (отрицательно определена), то P невырождена и
       n₊(P) = #{λ ∈ spec(A) : |λ| < 1},
       n₋(P) = #{λ ∈ spec(A) : |λ| > 1}.

Проверяем в float:
  - генерируем 10–20 случайных A размера 2–5 с известным спектром (включая
    сильно ненормальные — для проверки работоспособности закона инерции);
  - для каждой решаем краевую задачу: берём Q = -I (или другое Q ≻ 0,
    чтобы S = A^T P A - P ≺ 0 — то есть S = -Q ≺ 0) и решаем
    P - A^T P A = Q;  (поэтому Q берём ≻ 0, тогда S = -Q ≺ 0);
  - проверяем In(P) vs. счёт спектра.

Это проверка ТЕОРЕМЫ (включая контрпример).
"""
import numpy as np
import scipy.linalg as la


def inertia_count(M):
    """Инерция симметричной M через LDL^T с перестановками (Bunch-Kaufman)."""
    M = 0.5 * (M + M.T)
    try:
        _, d, _ = la.ldl(M)
        d = np.diag(d)
        pos = int(np.sum(d > 1e-10))
        neg = int(np.sum(d < -1e-10))
        zero = int(M.shape[0] - pos - neg)
        return pos, neg, zero
    except Exception:
        # fallback: собственные значения
        ev = np.linalg.eigvalsh(M)
        return int(np.sum(ev > 1e-10)), int(np.sum(ev < -1e-10)), int(M.shape[0] - np.sum(np.abs(ev) > 1e-10))


def count_spectrum(A):
    """Число собств. значений A вне/внутри/на единичной окружности."""
    ev = np.linalg.eigvals(A)
    abs_ev = np.abs(ev)
    out = int(np.sum(abs_ev > 1 + 1e-10))
    on = int(np.sum(np.abs(abs_ev - 1) < 1e-9))
    inn = A.shape[0] - out - on
    return inn, out, on


def solve_lyapunov(A, Q):
    """Решаем P - A^T P A = Q  (дискретное уравнение Ляпунова)."""
    n = A.shape[0]
    # Решаем (I - kron(A^T, A^T)) vec(P) = vec(Q)
    # scipy.linalg.solve_discrete_lyapunov ожидает: A^T P A - P + Q = 0, т.е. A^T P A = P - Q.
    # А у нас P - A^T P A = Q  =>  A^T P A = P - Q.
    # То есть: X = P - Q, A^T X A - X + Q = 0 ... проверим знак:
    # scipy: A X A^T - X + Q = 0  -- это для 'continuous/'controller'.
    # Для дискретного: A X A^T - X + Q = 0... посмотрю документацию.
    # Из документации: "solve_discrete_lyapunov(A, Q) — solves discrete-time Lyapunov
    # equation AXA^T - X + Q = 0"  (транспонированная форма).
    # Нам нужно: P - A^T P A = Q
    # =>  A^T P A = P - Q
    # Перепишем через P_ = P - Q/2 (центрирование): ... Проще через vec:
    I = np.eye(n)
    M_kron = np.kron(A, A)  # (A ⊗ A)
    # vec(A^T P A) = (A^T ⊗ A^T) vec(P) = (A ⊗ A)^T vec(P) (так как A⊗A симм... нет, не симм).
    # A^T ⊗ A^T vec(P) = (A^T) vec(P) с других сторон...
    # Стандартный факт: vec(A^T X A) = (A^T ⊗ A^T) vec(X).
    # Поэтому уравнение P - A^T P A = Q:
    # (I - A^T ⊗ A^T) vec(P) = vec(Q)
    # Решим плотную линейную систему.
    kron = np.kron(A.T, A.T)
    lhs = np.eye(n * n) - kron
    rhs = Q.flatten('F')  # Fortran order для vec
    try:
        pv = np.linalg.solve(lhs, rhs)
    except np.linalg.LinAlgError:
        return None
    P = pv.reshape((n, n), order='F')
    P = 0.5 * (P + P.T)  # симметризация
    return P


def solve_lyapunov_scipy(A, Q):
    """Через scipy дискретный solver. Берёт X = P/2 в формуле A X A^T - X + Q = 0.
    Перепишем: P - A^T P A = Q
       пусть X = P/2; тогда A^T X A = X - Q/2;  т.е. X - A^T X A = Q/2
       ... (scipy использует A X A^T, а не A^T X A — нужно транспонирование).
    """
    n = A.shape[0]
    try:
        # scipy expects: A X A^T - X + Q = 0
        # We want: P - A^T P A = Q  =>  A^T P A - P + Q = 0  (нет, P - A^T P A = Q)
        # эквивалентно: -A^T P A + P = Q  =>  A^T P A = P - Q
        # для scipy (continuous): A X + X A^T = Q.
        # Это не discrete; используем наш собственный vec-метод.
        X = la.solve_discrete_lyapunov(A.T, Q)
        return X
    except Exception:
        return None


def check_one(A, name):
    n = A.shape[0]
    inn, out, on = count_spectrum(A)
    if on:
        return None  # пропускаем — на окружности
    # Берём Q = I  =>  S = -I ≺ 0  (нужно чтобы Q ≻ 0, что I и есть)
    P = solve_lyapunov_scipy(A, np.eye(n))
    if P is None:
        # фолбэк на vec
        P = solve_lyapunov(A, np.eye(n))
    if P is None:
        return None
    # Проверим, что S = A^T P A - P действительно ≺ 0 ?
    S = A.T @ P @ A - P
    S_sym = 0.5 * (S + S.T)
    in_S = inertia_count(S_sym)
    in_P = inertia_count(P)
    expected = (inn, out, 0)
    ok = (in_P == expected) and (in_S == (0, n, 0))  # S должно быть ≺ 0
    return {'name': name, 'n': n, 'spec_inn_out_on': (inn, out, on),
            'P': P, 'inP': in_P, 'inS': in_S, 'OK': ok}


def main():
    rng = np.random.default_rng(42)
    print('=' * 78)
    print('Ш0 — проверка теоремы Стейна–Таусски на малых матрицах')
    print('=' * 78)

    cases = []

    # 1) Контрпример: A = [[1/2, 10], [0, 1/2]], P = I.
    # Но: тут P = I не решает P - A^T P A = Q ≻ 0 (т.к. det(S) = -1591/16 < 0).
    # По теореме Стейна–Таусски, если S ≺ 0, то P считает спектр. Здесь S = S = A^T A - I
    # НЕ ≺ 0 (det < 0), так что теорема не применима — она не утверждает ничего.
    A1 = np.array([[0.5, 10.0], [0.0, 0.5]])
    cases.append(('контрпример круга1 (A=I/2-сдвиг, P=I) — НЕ должен проходить', A1))

    # 2) Корректный случай: 2×2 диагональная (1.5, 0.5). P должна быть определена.
    # A = diag(1.5, 0.5). P - A^T P A = I. Решение существует, S = -I ≺ 0.
    A2 = np.diag([1.5, 0.5])
    cases.append(('2x2 диагональ (1.5, 0.5)', A2))

    # 3) A=diag(2.0, 0.5, 0.3)
    A3 = np.diag([2.0, 0.5, 0.3])
    cases.append(('3x3 диагональ (2, 0.5, 0.3)', A3))

    # 4) A с комплексными собств. значениями вне/внутри круга.
    # A = rot2 * scale с собственными значениями = 1.2*e^{+iπ/3}, 1.2*e^{-iπ/3}
    th = np.pi / 3
    A4 = np.array([[1.2 * np.cos(th), -1.2 * np.sin(th)],
                   [1.2 * np.sin(th), 1.2 * np.cos(th)]])
    cases.append(('2x2 поворот+масштаб 1.2 (|λ|=1.2)', A4))

    # 5) A с кратным собственным значением 2 (внутри круга с обоих сторон быть не может
    # но оба снаружи)
    A5 = np.diag([2.0, 2.0])
    cases.append(('2x2 кратное (2,2)', A5))

    # 6) A ненормальная, Шеврон.
    for trial in range(15):
        n = int(rng.integers(2, 6))
        # Случайная нормальная (хорошо обусловленная) — сначала диагонализуемая.
        # Генерируем через случайную QR и собственные значения.
        ev_real = rng.uniform(0.1, 4.0, size=n)
        # Чтобы не было на окружности:
        ev_real = np.where(np.abs(ev_real - 1.0) < 0.05, ev_real + 0.1, ev_real)
        Q = rng.standard_normal((n, n))
        Q, _ = np.linalg.qr(Q)
        A = Q @ np.diag(ev_real) @ np.linalg.inv(Q)
        cases.append((f'random {n}x{n} trial={trial+1}', A))

    # Теперь — сама проверка.
    results = []
    for name, A in cases:
        r = check_one(A, name)
        if r is None:
            print(f'-- {name}: пропущена (вырождение или на окружности)')
            continue
        results.append((name, r))
        ok = 'OK' if r['OK'] else 'FAIL'
        print(f'{ok:4s} {name:50s} | n={r["n"]:d} | спектр={r["spec_inn_out_on"]} | '
              f'inP={r["inP"]} | inS={r["inS"]}')

    # Сводка
    n_ok = sum(1 for _, r in results if r['OK'])
    n_total = len(results)
    n_fail = n_total - n_ok
    print('=' * 78)
    print(f'ИТОГ Ш0: {n_ok}/{n_total} случаев удовлетворяют теореме Стейна–Таусски')
    if n_fail:
        print('ПРОВАЛЕННЫЕ:')
        for name, r in results:
            if not r['OK']:
                print('  --', name)
    else:
        print('Контрпример не прошёл по условию S ≺ 0 → теорема не применима, всё ок.')
    print('=' * 78)


if __name__ == '__main__':
    main()
