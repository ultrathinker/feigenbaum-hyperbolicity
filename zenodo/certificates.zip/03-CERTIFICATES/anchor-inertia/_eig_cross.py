import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
os.environ.setdefault('HYP_ENG', os.path.join(PKG_ROOT, '04-CODE'))
os.environ.setdefault('HYP_BRANCHES',
                      os.path.join(PKG_ROOT, '03-CERTIFICATES', 'branches'))
sys.path.insert(0, os.environ['HYP_ENG'])
import hyp_rouche as hr
from flint import arb, ctx
import numpy as np

ctx.prec = 256
n = 80

print('===== Cross-check: eigvalsh(P) for both ell values =====')
for ell in [3.0, 2.5]:
    c_a, m, e0, w, fname = hr.load_box(ell, 0.0)
    x0 = 2.0 * (ell - e0) / w
    P0 = hr.rl.P_at(c_a, m, arb('%.17e' % x0))
    pkg = hr.tl.build_pkg_fast(P0, arb('%.17e' % ell))
    DT0 = hr.dt_from_pkg(pkg)
    A_mid = np.array([[float(DT0[j][k]) for k in range(n)] for j in range(n)])
    import scipy.linalg as la
    P = la.solve_discrete_lyapunov(A_mid.T, np.eye(n))
    P = 0.5 * (P + P.T)
    ev = sorted(np.linalg.eigvalsh(P).tolist())
    pos = sum(1 for x in ev if x > 1e-9)
    neg = sum(1 for x in ev if x < -1e-9)
    zer = n - pos - neg
    print(f'ell={ell}: branch={fname}')
    print(f'  eigvalsh P ascending: {ev[:5]} ... {ev[-5:]}')
    print(f'  in(P) via eigvalsh: ({pos}, {neg}, {zer})')
    print()
