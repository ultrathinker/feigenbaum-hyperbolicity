# -*- coding: utf-8 -*-
"""Ш0 v2 — с правильным inertia_count через LDL с 2×2 блоками."""
import numpy as np
import scipy.linalg as la


def inertia_via_eigvalsh(M):
    """Инерция симметричной M через собственные значения (точный метод)."""
    ev = np.linalg.eigvalsh(0.5 * (M + M.T))
    pos = int(np.sum(ev > 1e-10))
    neg = int(np.sum(ev < -1e-10))
    zero = M.shape[0] - pos - neg
    return pos, neg, zero


def inertia_via_ldl(M):
    """Инерция симметричной M через LDL^T scipy, корректно обрабатывая 2×2 блоки.
       Идея: проведём LDL^T явно через eigvalsh итоговой D.
    """
    M = 0.5 * (M + M.T)
    _, d, _ = la.ldl(M)
    ev = np.linalg.eigvalsh(d)  # собственные значения блок-диагональной D
    pos = int(np.sum(ev > 1e-10))
    neg = int(np.sum(ev < -1e-10))
    zero = M.shape[0] - pos - neg
    return pos, neg, zero, ev


def count_spectrum(A):
    ev = np.linalg.eigvals(A)
    abs_ev = np.abs(ev)
    out = int(np.sum(abs_ev > 1 + 1e-10))
    on = int(np.sum(np.abs(abs_ev - 1) < 1e-9))
    inn = A.shape[0] - out - on
    return inn, out, on


_RANDOM_Q = np.random.default_rng(123)


def make_P(A, rng=_RANDOM_Q):
    """Решаем P - A^T P A = Q (Q ≻ 0). Используем scipy (может упасть на singular).
       Если singular — добавим небольшое диаг. возмущение к Q, чтобы система
       оставалась невырожденной, но всё ещё ≻ 0."""
    n = A.shape[0]
    Q = np.eye(n)
    try:
        P = la.solve_discrete_lyapunov(A.T, Q)
    except np.linalg.LinAlgError:
        # singular — добавим диагональное возмущение
        eps = 0.01
        perturb = rng.standard_normal((n, n))
        Q2 = np.eye(n) + eps * (perturb @ perturb.T)
        try:
            P = la.solve_discrete_lyapunov(A.T, Q2)
            Q = Q2
        except np.linalg.LinAlgError:
            # последний фолбэк: решаем плотно vec-методом
            Iden = np.eye(n * n)
            kron = np.kron(A.T, A.T)
            lhs = Iden - kron
            rhs = Q.flatten()
            pv = np.linalg.lstsq(lhs, rhs, rcond=None)[0]
            P = pv.reshape((n, n), order='F')
    P = 0.5 * (P + P.T)
    S = A.T @ P @ A - P
    return P, S, Q


def main():
    rng = np.random.default_rng(42)
    print('=' * 78)
    print('Ш0 v2 — проверка теоремы Стейна–Таусски (ИСПРАВЛЕННЫЙ inertia_count)')
    print('=' * 78)

    cases = []
    # контрпример
    A1 = np.array([[0.5, 10.0], [0.0, 0.5]])
    cases.append(('контрпример круга1', A1))
    A2 = np.diag([1.5, 0.5])
    cases.append(('diag(1.5, 0.5)', A2))
    A3 = np.diag([2.0, 0.5, 0.3])
    cases.append(('diag(2, 0.5, 0.3)', A3))
    th = np.pi / 3
    A4 = np.array([[1.2 * np.cos(th), -1.2 * np.sin(th)],
                   [1.2 * np.sin(th), 1.2 * np.cos(th)]])
    cases.append(('rot+scale 1.2', A4))
    A5 = np.diag([2.0, 2.0])
    cases.append(('diag(2,2)', A5))
    for trial in range(15):
        n = int(rng.integers(2, 6))
        ev_real = rng.uniform(0.1, 4.0, size=n)
        ev_real = np.where(np.abs(ev_real - 1.0) < 0.05, ev_real + 0.1, ev_real)
        Q = rng.standard_normal((n, n))
        Q, _ = np.linalg.qr(Q)
        A = Q @ np.diag(ev_real) @ np.linalg.inv(Q)
        cases.append((f'rand {n}x{n} t={trial+1}', A))

    results = []
    for name, A in cases:
        n = A.shape[0]
        inn, out, on = count_spectrum(A)
        if on:
            print(f'-- {name}: на окружности, пропускаем')
            continue
        P, S, Q = make_P(A)
        in_P = inertia_via_eigvalsh(P)
        in_S = inertia_via_eigvalsh(S)
        # диагностика: инерция P через LDL с блоками
        in_ldl, ev_ldl = inertia_via_ldl(P)[:2], inertia_via_ldl(P)[3]
        # ОТЛАДКА: проверка, что в случае 2x2 блоков в D пивоты не совпадают
        # с собственными значениями.
        expected = (inn, out, 0)
        ok = (in_P == expected) and (in_S == (0, n, 0))
        # Здесь стояло `ok_ldl = (in_ldl == expected)`, где `in_ldl` —
        # ДВУХкортеж (pos, neg), а `expected` —
        # ТРЁХкортеж (pos, neg, zero).  Равенство невозможно ни при каких
        # данных, поэтому итоговая строка «ИТОГ (inertia_via_ldl): 0/20 OK»
        # не могла стать OK никогда — счётчик-инвариант, который приучает
        # не замечать плохие строки.  Сравниваем однородно, по двум первым
        # компонентам; нулевых пивотов у невырожденной P нет, и это
        # проверяется отдельно ниже по `ok`.
        ok_ldl = (tuple(in_ldl) == expected[:2])
        results.append({'name': name, 'n': n, 'spec': (inn, out, on),
                        'inP': in_P, 'inS': in_S, 'OK': ok,
                        'ldl_P': in_ldl, 'ev_P_ldl': ev_ldl, 'OK_ldl': ok_ldl})
        print(f'{"OK" if ok else "FAIL":4s} {name:30s} | n={n} | spec={inn,out,on} '
              f'| inP={in_P} (ldl:{in_ldl}) | inS={in_S} | OK_ldl={ok_ldl}')
        if not ok:
            # вывести собственные значения P
            print('  ev(P) =', np.linalg.eigvalsh(P))
            print('  ev(ldl) =', ev_ldl)

    n_ok = sum(1 for r in results if r['OK'])
    n_ok_ldl = sum(1 for r in results if r['OK_ldl'])
    print('=' * 78)
    print(f'ИТОГ (inertia_via_eigvalsh): {n_ok}/{len(results)} OK')
    print(f'ИТОГ (inertia_via_ldl):     {n_ok_ldl}/{len(results)} OK')
    if n_ok < len(results):
        print('ПРОВАЛЕННЫЕ:')
        for r in results:
            if not r['OK']:
                print('  --', r['name'], r['spec'], 'inP=', r['inP'])
    print('=' * 78)


if __name__ == '__main__':
    main()
