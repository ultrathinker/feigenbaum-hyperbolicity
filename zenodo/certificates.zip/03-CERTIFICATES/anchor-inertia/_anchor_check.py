# -*- coding: utf-8 -*-
"""
_anchor_check.py — независимая проверка якоря (теорема Стейна–Таусски).

Утверждение: при ℓ=3 у `DT|X₀` ровно одно собственное значение вне
единичного круга, и это доказано интервально через инерцию `P`, где
`P − AᵀPA = I`.  Здесь я перепроверяю ключевые числа своим кодом:
  * сама теорема на контрпримере и на паре тестов;
  * `P` решается независимо, инерция считается через `eigvalsh`;
  * невязка уравнения Стейна;
  * согласие с прямым счётом спектра.
Это не заменяет интервальную часть, но ловит грубую ошибку в постановке.
"""
import os, sys
import numpy as np
# уравнение Стейна решаем сами через кронекер: scipy на 2x2 из этого контрпримера
# падает с 'singular', хотя система невырождена (lambda_i*lambda_j != 1)

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
# движок: либо рядом (рабочее дерево), либо в 04-CODE пакета
ENG = os.environ.get('HYP_ENG',
                     os.path.join(os.path.dirname(os.path.dirname(HERE)), '04-CODE'))
sys.path.insert(0, HERE)
sys.path.insert(0, ENG)
import hyp_rouche as hr
from flint import arb, ctx
ctx.prec = 256
NP = hr.NP


def inertia(M):
    ev = np.linalg.eigvalsh((M + M.T) / 2)
    return int((ev > 0).sum()), int((ev < 0).sum()), int((ev == 0).sum())


def stein_count(A):
    """(n_inside, n_outside) по инерции P, где P − AᵀPA = I."""
    n = A.shape[0]
    K = np.eye(n * n) - np.kron(A.T, A.T)
    P = np.linalg.solve(K, np.eye(n).flatten()).reshape(n, n)
    P = (P + P.T) / 2
    S = A.T @ P @ A - P
    resid = np.linalg.norm(S + np.eye(A.shape[0]))
    npos, nneg, nz = inertia(P)
    smax = np.linalg.eigvalsh((S + S.T) / 2).max()
    return npos, nneg, nz, resid, smax, P


print('=== теорема на малых примерах ===')
tests = {
    'контрпример [[1/2,10],[0,1/2]]': np.array([[0.5, 10.0], [0.0, 0.5]]),
    'диаг (1.5, 0.5)': np.diag([1.5, 0.5]),
    # (2, 0.5, 0.3) намеренно НЕ берём: 2*0.5 = 1, уравнение Стейна вырождено
    # (теорема этим не рушится — ей нужна ЛЮБАЯ P с S<0, а не именно эта)
    'диаг (2, 0.4, 0.3)': np.diag([2.0, 0.4, 0.3]),
    'диаг (3, 2, 0.4)': np.diag([3.0, 2.0, 0.4]),
    'жорданова (2,2) с 1': np.array([[2.0, 1.0], [0.0, 2.0]]),
    'поворот 1.2·e^{iπ/3}': 1.2 * np.array([[np.cos(np.pi / 3), -np.sin(np.pi / 3)],
                                            [np.sin(np.pi / 3), np.cos(np.pi / 3)]]),
}
_fails = []
for name, A in tests.items():
    npos, nneg, nz, resid, smax, _ = stein_count(A)
    out_true = int((np.abs(np.linalg.eigvals(A)) > 1).sum())
    ok = (nneg == out_true) and smax < 0
    if not ok:
        _fails.append(name)
    print('  %-38s in(P)=(%d,%d,%d)  снаружи истинно=%d  S≺0:%s  -> %s'
          % (name, npos, nneg, nz, out_true, smax < 0, 'ok' if ok else 'РАСХОЖДЕНИЕ'))

print('\n=== якорь: DT|X0 при ell=3 ===')
c_a, m, e0, w, fname = hr.load_box(3.0, 0.0)
x0 = 2.0 * (3.0 - e0) / w
P0 = hr.rl.P_at(c_a, m, arb('%.17e' % x0))
pkg = hr.tl.build_pkg_fast(P0, arb('3.0'))
DT0 = hr.dt_from_pkg(pkg)
A = np.array([[float(DT0[j][k]) for k in range(NP)] for j in range(NP)])
npos, nneg, nz, resid, smax, P = stein_count(A)
ev = np.linalg.eigvals(A)
ev = ev[np.argsort(-np.abs(ev))]
print('  ветка:            %s' % fname)
print('  in(P) =           (%d, %d, %d)' % (npos, nneg, nz))
print('  невязка Стейна:   %.3e' % resid)
print('  max eig(S):       %.6f   (должно быть < 0)' % smax)
print('  мин |eig(P)|:     %.6f' % np.abs(np.linalg.eigvalsh((P + P.T) / 2)).min())
print('  спектр A напрямую: снаружи %d, δ = %.12f, |λ₂| = %.12f'
      % (int((np.abs(ev) > 1).sum()), ev[0].real, abs(ev[1])))
_n_out = int((np.abs(ev) > 1).sum())
_ok = (nneg == 1 and smax < 0 and _n_out == 1 and npos == NP - 1
       and nz == 0 and not _fails)
print('\n  вердикт: %s' % ('согласовано' if _ok else 'РАСХОЖДЕНИЕ'))

# Раньше здесь всё и кончалось: вердикт печатался, код возврата
# оставался нулевым при любом исходе, и приёмочный шаг `anchor` не мог
# покраснеть.  Теперь каждое условие вердикта — калитка.
if not _ok:
    print('*** FAIL: in(P)=(%d,%d,%d) при ожидаемой (%d,1,0); '
          'max eig(S)=%.6f; снаружи %d при ожидаемом 1; '
          'провалов на малых примерах: %d'
          % (npos, nneg, nz, NP - 1, smax, _n_out, len(_fails)))
    sys.exit(1)
print('ПРОВЕРКА ЯКОРЯ: ok')
