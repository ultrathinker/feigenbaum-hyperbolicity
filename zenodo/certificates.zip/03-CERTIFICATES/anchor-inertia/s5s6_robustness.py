# -*- coding: utf-8 -*-
"""
Ш5 + Ш6.

Ш5: устойчивость при другом Q (Q = 2I, случайная Q ≻ 0).
     P_new = решение уравнения P − A^T P A = Q; (P_new) должна тоже давать in(P) = (79, 1, 0)
     и S = A^T P_new A − P_new ≺ 0.

Ш6: повтор при ℓ = 2.5 (δ★ = 5.412736346083841).
"""
import os, sys, time, tempfile
# Тот же фикс путей, что в s3_prepare_AB.py: раньше хардкод
# 'method'/'reference/branches' не давал скрипту запуститься предписанным
# минимальным маршрутом пакета (ModuleNotFoundError).  Теперь пути берутся
# из окружения с умолчанием по реальной раскладке пакета.
HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(os.path.dirname(HERE))
ENG = os.environ.get('HYP_ENG', os.path.join(PKG_ROOT, '04-CODE'))
BRANCHES = os.environ.get('HYP_BRANCHES', os.path.join(PKG_ROOT, '03-CERTIFICATES', 'branches'))
os.environ.setdefault('HYP_BRANCHES', BRANCHES)
sys.path.insert(0, ENG)
import numpy as np
import scipy.linalg as la
import hyp_rouche as hr
from flint import arb, ctx

ctx.prec = 256
NP = hr.NP
n = NP


def ldl_interval_pivots(M):
    n_local = len(M)
    A = [[M[j][k] for k in range(n_local)] for j in range(n_local)]
    pivots = []
    s_pos = s_neg = s_zero = s_uns = 0
    for j in range(n_local):
        d = A[j][j]
        pivots.append(d)
        lo, hi = float(d.lower()), float(d.upper())
        if lo > 0:
            s_pos += 1
        elif hi < 0:
            s_neg += 1
        elif lo <= 0 <= hi:
            s_zero += 1
        else:
            s_uns += 1
        if hi == 0 and lo == 0:
            continue
        inv_d = arb(1) / d
        for i in range(j + 1, n_local):
            if A[i][j] == arb(0):
                continue
            ratio = A[i][j] * inv_d
            for k in range(j + 1, n_local):
                A[i][k] = A[i][k] - ratio * A[j][k]
    return pivots, (s_pos, s_neg, s_zero, s_uns)


def sym(A):
    n_local = len(A)
    return [[(A[j][k] + A[k][j]) / arb(2) for k in range(n_local)] for j in range(n_local)]


def build_arb_AR_P_Q(ell0_branch=3.0, Q_kind='I'):
    """Возвращает (A_arb, P_arb, Q).
       A_arb построен при ℓ = ℓ0_branch.
       Q_kind ∈ {'I', '2I', 'rand'}.
    """
    c_a, m, e0, w, fname = hr.load_box(ell0_branch, 0.0)
    x0 = 2.0 * (ell0_branch - e0) / w
    P0 = hr.rl.P_at(c_a, m, arb('%.17e' % x0))
    pkg = hr.tl.build_pkg_fast(P0, arb('%.17e' % ell0_branch))
    DT0 = hr.dt_from_pkg(pkg)
    A_mid = np.array([[float(DT0[j][k]) for k in range(n)] for j in range(n)])
    # Контроль спектра
    ev = np.linalg.eigvals(A_mid)
    ev_sorted = sorted(ev, key=lambda z: -abs(z))

    # Решаем с Q
    if Q_kind == 'I':
        Qf = np.eye(n)
    elif Q_kind == '2I':
        Qf = 2.0 * np.eye(n)
    elif Q_kind == 'rand':
        rng = np.random.default_rng(20250818)
        # сгенерируем ≻ 0 через M M^T + small I
        M = rng.standard_normal((n, n))
        Qf = M @ M.T + 0.1 * np.eye(n)
        # масштабируем, чтобы шкала была похожа на I
        Qf = Qf / np.linalg.norm(Qf) * n
    else:
        raise ValueError(Q_kind)
    # Решаем
    try:
        P = la.solve_discrete_lyapunov(A_mid.T, Qf)
    except np.linalg.LinAlgError:
        # Сингулярно — добавим возмущение к Q
        rng = np.random.default_rng(2)
        eps_q = 0.05
        pert = rng.standard_normal((n, n))
        Q_pert = Qf + eps_q * (pert @ pert.T)
        P = la.solve_discrete_lyapunov(A_mid.T, Q_pert)
        Qf = Q_pert
    P = 0.5 * (P + P.T)

    # A_arb
    A_arb = [[DT0[j][k] for k in range(n)] for j in range(n)]
    # P_arb
    P_arb = [[arb('%.17e' % P[j][k]) for k in range(n)] for j in range(n)]

    return A_arb, P_arb, Qf, ev_sorted, fname


def main():
    bad = []
    # путь настраиваем и создаём сами, по умолчанию — временный каталог ОС.
    WORK = os.environ.get('HYP_ANCHOR_WORK', os.path.join(tempfile.gettempdir(), 'anchor-work'))
    os.makedirs(WORK, exist_ok=True)
    PROG = open(os.path.join(WORK, '_PROGRESS-s5s6.log'), 'a', encoding='utf-8')
    LOG = open(os.path.join(WORK, '_LOG.md'), 'a', encoding='utf-8')

    def say(s):
        print(s, flush=True)
        PROG.write(s + '\n')
        PROG.flush()

    for label, Q_kind, ell_test in [
        ('Ш5.1 Q = 2I при ℓ=3', '2I', 3.0),
        ('Ш5.2 Q случайная при ℓ=3', 'rand', 3.0),
        ('Ш6   ℓ=2.5, Q = I', 'I', 2.5),
    ]:
        say('=' * 78)
        say(label)
        say('=' * 78)
        t0 = time.time()
        A_arb, P_arb, Q, ev, fname = build_arb_AR_P_Q(ell_test, Q_kind)
        say(f'  ветка {fname}, ℓ={ell_test}')
        say(f'  спектр: δ={ev[0].real:.6f}, |λ₂|={abs(ev[1]):.6f}')

        # Контроль во float
        P_mid = np.array([[float(P_arb[j][k]) for k in range(n)] for j in range(n)])
        A_mid = np.array([[float(A_arb[j][k]) for k in range(n)] for j in range(n)])
        S_mid = A_mid.T @ P_mid @ A_mid - P_mid
        eigP = np.linalg.eigvalsh(P_mid)
        inP_flt = (int(np.sum(eigP > 1e-9)), int(np.sum(eigP < -1e-9)), int(np.sum(np.abs(eigP) <= 1e-9)))
        maxS = float(np.max(np.linalg.eigvalsh(S_mid)))
        say(f'  float in(P) = {inP_flt}, max eig(S) = {maxS:.3e}')

        # Построим S в arb
        S_arb = [[None] * n for _ in range(n)]
        for j in range(n):
            for k in range(n):
                s = arb(0)
                for l in range(n):
                    for m in range(n):
                        s = s + A_arb[l][j] * P_arb[l][m] * A_arb[m][k]
                S_arb[j][k] = s - P_arb[j][k]
        S_arb = sym(S_arb)
        say(f'  S построен за {time.time()-t0:.1f} с')

        # LDL на -S
        neg_S = sym([[-S_arb[j][k] for k in range(n)] for j in range(n)])
        t1 = time.time()
        pivS, sigS = ldl_interval_pivots(neg_S)
        say(f'  LDL на -S ({time.time()-t1:.1f} с): знаки +{sigS[0]} -{sigS[1]} 0:{sigS[2]} ?:{sigS[3]}')
        min_pivS = min(pivS, key=lambda x: float(x.lower()))
        say(f'  минимум lower(-S пивот) = {float(min_pivS.lower()):.4e}, '
            f'upper = {float(min_pivS.upper()):.4e}')

        # LDL на P
        P_arb_sym = sym(P_arb)
        t1 = time.time()
        pivP, sigP = ldl_interval_pivots(P_arb_sym)
        say(f'  LDL на P ({time.time()-t1:.1f} с): знаки +{sigP[0]} -{sigP[1]} 0:{sigP[2]} ?:{sigP[3]}')
        # Минимальный по модулю пивот (запас)
        pivP_lower = sorted(pivP, key=lambda x: abs(float(x.mid())))
        say(f'  5 наименьших по |mid| пивот P:')
        for i in range(5):
            p = pivP_lower[i]
            say(f'    [{float(p.lower()):.6e}, {float(p.upper()):.6e}], rad={float(p.rad()):.3e}')

        # Запись в лог
        LOG.write(f'\n## {label}\n\n')
        LOG.write(f'- ветка: `{fname}`, ℓ = {ell_test}\n')
        LOG.write(f'- float in(P) = {inP_flt}, `max eig(S)` = {maxS:.3e}.\n')
        LOG.write(f'- **Ш3:** интервальный LDL на `-S`: знаки `{sigS}` ⇒ `-S ≻ 0` ⇒ `S ≺ 0`. '
                  f'Мин. `lower = {float(min_pivS.lower()):.3e}`, верхняя `{float(min_pivS.upper()):.3e}`.\n')
        LOG.write(f'- **Ш4:** интервальный LDL на `P`: знаки `{sigP}` ⇒ `in(P) = (79, 1, 0)`.\n')
        LOG.write(f'- 5 наименьших по `|mid|` пивот P:\n')
        for i in range(5):
            p = pivP_lower[i]
            LOG.write(f'  - [{float(p.lower()):.6e}, {float(p.upper()):.6e}]\n')
        LOG.flush()
        say(f'  => итого {time.time()-t0:.1f} с')

        # Знаки интервальных пивот раньше только печатались и
        # писались в лог: подмена классификации давала «?:80» и RC=0.
        # 02-REPRODUCE подаёт этот скрипт как проверку — значит, у него
        # должна быть калитка.
        _n = len(pivP)          # не `n`: имя занято глобальным размером
        if tuple(sigS) != (_n, 0, 0, 0):
            bad.append('%s: -S ожидалось +%d -0 0:0 ?:0, получено %s'
                       % (label, _n, tuple(sigS)))
        if tuple(sigP) != (_n - 1, 1, 0, 0):
            bad.append('%s: P ожидалось +%d -1 0:0 ?:0, получено %s'
                       % (label, _n - 1, tuple(sigP)))
        if inP_flt != (_n - 1, 1, 0):
            bad.append('%s: float in(P) = %s, ожидалось (%d, 1, 0)'
                       % (label, inP_flt, _n - 1))

    LOG.close()
    PROG.close()
    if bad:
        for b in bad:
            print('*** FAIL: ' + b)
        return 1
    print('УСТОЙЧИВОСТЬ ЯКОРЯ: ok')
    return 0


if __name__ == '__main__':
    sys.exit(main())
